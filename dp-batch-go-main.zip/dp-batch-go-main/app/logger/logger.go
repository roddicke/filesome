package logger

import (
	"log"
	"os"
)

var (
	Log *Logger
)

func init() {
	Log = newLogger()
}

type Logger struct {
	log *log.Logger
}

func newLogger() *Logger {
	return &Logger{
		log: log.New(os.Stdout, "", log.Ldate|log.Lmicroseconds|log.Lshortfile|log.Lmsgprefix),
	}
}

func (l *Logger) Infof(s string, v ...interface{}) {
	l.log.SetPrefix("[INFO]  ")
	l.log.Printf(s, v...)
}

func (l *Logger) Warningf(s string, v ...interface{}) {
	l.log.SetPrefix("[WARN]  ")
	l.log.Printf(s, v...)
}

func (l *Logger) Errorf(s string, v ...interface{}) {
	l.log.SetPrefix("[ERROR] ")
	l.log.Printf(s, v...)
}
