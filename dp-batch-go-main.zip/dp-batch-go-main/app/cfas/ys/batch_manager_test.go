package ys

import (
	"fmt"
	"os"
	"sort"
	"testing"
	"time"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"

	"dp-batch-go/app/cfas/model"
	"dp-batch-go/app/cfas/repository"
)

func TestBatchManager_MainLoop(t *testing.T) {
	type args struct {
		batchDate string
		filePaths []string
	}
	type wants struct {
		inOutSourcePath     string
		SalesTrendStatsPath string
	}
	batchTime := "20160329"
	testDate := time.Now()
	tests := []struct {
		name    string
		args    args
		wants   wants
		wantErr bool
	}{
		{name: "UT-001", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-001/UT-001_input_CM2CF035_minus.csv",
			"testdata/UT-001/UT-001_input_CM2CF035_plus.csv",
			"testdata/UT-001/UT-001_input_CM2CF038.csv",
			"testdata/UT-001/UT-001_actual_output_CM2CF035.csv",
			"testdata/UT-001/UT-001_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-001/UT-001_output_CM2CF035.csv",
				SalesTrendStatsPath: "testdata/UT-001/UT-001_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-002", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-002/UT-002_input_CM2CF035_minus.csv",
			"testdata/UT-002/UT-002_input_CM2CF035_plus.csv",
			"testdata/UT-002/UT-002_input_CM2CF038.csv",
			"testdata/UT-002/UT-002_actual_output_CM2CF035.csv",
			"testdata/UT-002/UT-002_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-002/UT-002_output_CM2CF035.csv",
				SalesTrendStatsPath: "testdata/UT-002/UT-002_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-003", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-003/UT-003_input_CM2CF035_minus.csv",
			"testdata/UT-003/UT-003_input_CM2CF035_plus.csv",
			"testdata/UT-003/UT-003_input_CM2CF038.csv",
			"testdata/UT-003/UT-003_actual_output_CM2CF035.csv",
			"testdata/UT-003/UT-003_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-003/UT-003_output_CM2CF035.csv",
				SalesTrendStatsPath: "testdata/UT-003/UT-003_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-004", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-004/UT-004_input_CM2CF035_minus.csv",
			"testdata/UT-004/UT-004_input_CM2CF035_plus.csv",
			"testdata/UT-004/UT-004_input_CM2CF038.csv",
			"testdata/UT-004/UT-004_actual_output_CM2CF035.csv",
			"testdata/UT-004/UT-004_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-004/UT-004_output_CM2CF035.csv",
				SalesTrendStatsPath: "testdata/UT-004/UT-004_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-005", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-005/UT-005_input_CM2CF035_minus.csv",
			"testdata/UT-005/UT-005_input_CM2CF035_plus.csv",
			"testdata/UT-005/UT-005_input_CM2CF038.csv",
			"testdata/UT-005/UT-005_actual_output_CM2CF035.csv",
			"testdata/UT-005/UT-005_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-005/UT-005_output_CM2CF035.csv",
				SalesTrendStatsPath: "testdata/UT-005/UT-005_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-006", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-006/UT-006_input_CM2CF035_minus.csv",
			"testdata/UT-006/UT-006_input_CM2CF035_plus.csv",
			"testdata/UT-006/UT-006_input_CM2CF038.csv",
			"testdata/UT-006/UT-006_actual_output_CM2CF035.csv",
			"testdata/UT-006/UT-006_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-006/UT-006_output_CM2CF035.csv",
				SalesTrendStatsPath: "testdata/UT-006/UT-006_output_CM2CF038.csv",
			},
			wantErr: false},
	}

	b := NewBatchManager(repository.NewLocalCsvFileRepository())
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := b.Execute(tt.args.batchDate, tt.args.filePaths); (err != nil) != tt.wantErr {
				t.Errorf("Execute() error = %v, wantErr %v", err, tt.wantErr)
			}

			err := compareInOutSources(tt.args.batchDate, testDate, tt.args.filePaths[3], tt.wants.inOutSourcePath)
			if err != nil {
				t.Error(err)
			}

			err = compareSalesTrendStats(tt.args.batchDate, testDate, tt.args.filePaths[4], tt.wants.SalesTrendStatsPath)
			if err != nil {
				t.Error(err)
			}

			// since actual results are not need, delete them.
			err = os.RemoveAll(tt.args.filePaths[3])
			if err != nil {
				t.Fatal(err)
			}
			err = os.RemoveAll(tt.args.filePaths[4])
			if err != nil {
				t.Fatal(err)
			}

		})
	}
}

func compareInOutSources(batchDate string, testDate time.Time, gotPath, wantPath string) error {
	repo := repository.NewLocalCsvFileRepository()
	rows, err := repo.Read(gotPath, true)
	if err != nil {
		return err
	}
	gots := make([]*model.InOutSourceInfo, 0)
	for _, row := range rows {
		d, err := model.NewInOutSourceInfo(row)
		if err != nil {
			return err
		}
		gots = append(gots, d)
	}
	sort.Slice(gots, func(i, j int) bool { return gots[i].RecordSeqNo < gots[j].RecordSeqNo })

	rows, err = repo.Read(wantPath, true)
	if err != nil {
		return err
	}
	wants := make([]*model.InOutSourceInfo, 0)
	for _, row := range rows {
		d, err := model.NewInOutSourceInfo(row)
		if err != nil {
			return err
		}
		wants = append(wants, d)
	}
	sort.Slice(wants, func(i, j int) bool { return wants[i].RecordSeqNo < wants[j].RecordSeqNo })

	if len(gots) != len(wants) {
		return fmt.Errorf("入出金元情報管理の実際の出力と予想の出力の行の長さが異なります: got %d, want %d",
			len(gots), len(wants))
	}

	for i := range gots {
		// since below values are program timestamp and batch time, cannot validate comparing wanted output.
		o := cmpopts.IgnoreFields(model.InOutSourceInfo{}, "RecordKshnYmd", "SystemYmd", "SystemHms")
		if diff := cmp.Diff(gots[i], wants[i], o); diff != "" {
			return fmt.Errorf("row: %d\n%s", i, diff)
		}
		if gots[i].RecordKshnYmd != batchDate {
			return fmt.Errorf("InOutSourceInfo.RecordKshnYmd != batchDate; rowID %d, got %s, want %s",
				i, gots[i].RecordKshnYmd, batchDate)
		}

		// 20060102150405 = YYYYMMDDhhmmss
		got, err := time.Parse("20060102150405", gots[i].SystemYmd+gots[i].SystemHms)
		if err != nil {
			return err
		}
		if got.Before(testDate) {
			return fmt.Errorf("SystemYmd SystemHms < テスト実施日時なので、SystemYmd SystemHmsが更新されてません。")
		}
	}
	return nil
}

func compareSalesTrendStats(batchDate string, testDate time.Time, gotPath, wantPath string) error {
	repo := repository.NewLocalCsvFileRepository()
	rows, err := repo.Read(gotPath, true)
	if err != nil {
		return err
	}
	gots := make([]*model.SalesTrendStat, 0)
	for _, row := range rows {
		d, err := model.NewSalesTrendStat(row)
		if err != nil {
			return err
		}
		gots = append(gots, d)
	}
	sort.Slice(gots, func(i, j int) bool {
		if gots[i].TorihikiId < gots[j].TorihikiId {
			return true
		} else if gots[i].TorihikiId == gots[j].TorihikiId {
			if gots[i].KirSeqNo == gots[j].KirSeqNo {
				return true
			}
		}
		return false
	})

	rows, err = repo.Read(wantPath, true)
	if err != nil {
		return err
	}
	wants := make([]*model.SalesTrendStat, 0)
	for _, row := range rows {
		d, err := model.NewSalesTrendStat(row)
		if err != nil {
			return err
		}
		wants = append(wants, d)
	}
	sort.Slice(wants, func(i, j int) bool {
		if wants[i].TorihikiId < wants[j].TorihikiId {
			return true
		} else if wants[i].TorihikiId == wants[j].TorihikiId {
			if wants[i].KirSeqNo < wants[j].KirSeqNo {
				return true
			}
		}
		return false
	})

	if len(gots) != len(wants) {
		return fmt.Errorf("販売動向統計の実際の出力と予想の出力の行の長さが異なります: got %d, want %d",
			len(gots), len(wants))
	}

	for i := range gots {
		// since below values are program timestamp and batch time, cannot validate comparing expected output.
		o := cmpopts.IgnoreFields(model.SalesTrendStat{},
			"KirSttiYmd", "KirKijunYmd", "RecordSksiYmd", "RecordKoshinYmd", "ShoriTaishoYmd", "SystemYmd", "SystemHms")
		if diff := cmp.Diff(gots[i], wants[i], o); diff != "" {
			return fmt.Errorf("row: %d\n%s", i, diff)
		}
		if gots[i].KirSttiYmd != batchDate {
			return fmt.Errorf("SalesTrendStat.KirSttiYmd != batchDate; rowID %d, got %s, want %s",
				i, gots[i].RecordSksiYmd, batchDate)
		}
		if !(gots[i].KirKijunYmd == batchDate || gots[i].KirKijunYmd == wants[i].KirKijunYmd) {
			return fmt.Errorf("SalesTrendStat.KirKijunYmd != batchDate or != want.KirKijunYmd; "+
				"rowID %d, got %s, want:batchDate %s, want:KirKijunYmd %s",
				i, gots[i].KirKijunYmd, batchDate, wants[i].KirKijunYmd)
		}
		if gots[i].RecordSksiYmd != batchDate {
			return fmt.Errorf("SalesTrendStat.RecordSksiYmd != batchDate; rowID %d, got %s, want %s",
				i, gots[i].RecordSksiYmd, batchDate)
		}
		if gots[i].RecordKoshinYmd != batchDate {
			return fmt.Errorf("SalesTrendStat.RecordKoshinYmd != batchDate; rowID %d, got %s, want %s",
				i, gots[i].RecordKoshinYmd, batchDate)
		}

		if gots[i].ShoriTaishoYmd != testDate.Format("20060102") {
			return fmt.Errorf("SalesTrendStat.ShoriTaishoYmd != test date (YYYYMMDD); rowID %d, got %s, want %s",
				i, gots[i].ShoriTaishoYmd, testDate.Format("20060102"))
		}

		// 20060102150405 = YYYYMMDDhhmmss
		got, err := time.Parse("20060102150405", gots[i].SystemYmd+gots[i].SystemHms)
		if err != nil {
			return err
		}
		if got.Before(testDate) {
			return fmt.Errorf("SystemYmd SystemHms < テスト実施日時なので、SystemYmd SystemHmsが更新されてません。")
		}
	}
	return nil
}
