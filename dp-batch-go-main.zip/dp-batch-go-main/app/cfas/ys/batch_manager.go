package ys

import (
	"fmt"
	"time"

	"dp-batch-go/app/cfas/base"
	"dp-batch-go/app/cfas/common"
	"dp-batch-go/app/cfas/model"
	"dp-batch-go/app/cfas/repository"
	"dp-batch-go/app/logger"
)

type BatchManager struct {
	base       *base.BatchManager
	systemDate string
	systemTime string
}

func NewBatchManager(fp repository.ICSVFileRepository) *BatchManager {
	now := time.Now().In(time.FixedZone("Asia/Tokyo", 9*60*60))
	return &BatchManager{
		base:       &base.BatchManager{FilePointer: fp},
		systemDate: now.Format("20060102"),
		systemTime: now.Format("150405"),
	}
}

/*Execute
batchData バッチ実行日付
filePaths {
	入力用　入出金元情報管理（マイナス）ファイルパス,
	入力用　入出金元情報管理（プラス）ファイルパス,
	入力用　販売動向統計ファイルパス,
	出力用　入出金元情報管理ファイルパス,
	出力用　販売動向統計ファイルパス,
}
*/
func (b *BatchManager) Execute(batchDate string, filePaths []string) error {
	//販売動向統計データファイルリード
	salesTrendStatHeaders, salesTrendStats, err := b.base.ReadSalesTrendStats(filePaths[2])
	if err != nil {
		logger.Log.Errorf("ファイルパス: %v", filePaths[2])
		return fmt.Errorf("販売動向統計のファイルを読み取りできませんでした; %v", err)
	}
	salesTrendStatsMap := model.NewSalesTrendStatsMap(salesTrendStats)

	//マイナスデータファイルリード
	inOutSourceHeaders, minusInOutSourceInfos, err := b.base.ReadInOutSourceInfos(filePaths[0])
	if err != nil {
		logger.Log.Errorf("ファイルパス: %v", filePaths[0])
		return fmt.Errorf("入出金元情報管理（マイナス）のファイルを読み取りできませんでした; %v", err)
	}

	//プラスデータファイルリード
	_, infos, err := b.base.ReadInOutSourceInfos(filePaths[1])
	if err != nil {
		logger.Log.Errorf("ファイルパス: %v", filePaths[1])
		return fmt.Errorf("入出金元情報管理（プラス）のファイルを読み取りできませんでした; %v", err)
	}
	plusInOutSourceInfosMap := model.NewPlusYSInOutSourceInfosMap(infos)

	var outputInOutSourceInfos []*model.InOutSourceInfo
	var outputSalesTrendStats []*model.SalesTrendStat
	//マイナスデータはフィルタされてソートされた状態でファイルが渡されるので、フィルタ・ソート不要
	for _, minusInOutSourceInfo := range minusInOutSourceInfos {
		//経路シーケンス番号取得 -
		//EXEC dbo.RQAJDDTCF0650_1
		key := model.SalesTrendStatKey{
			OriginalKozaNo: minusInOutSourceInfo.OriginalKozaNo,
			KijunYmd:       minusInOutSourceInfo.KijunYmd,
			ShtkmtDataKbn:  minusInOutSourceInfo.ShtkmtDataKbn,
			TorihikiNo:     minusInOutSourceInfo.TorihikiNo}
		routeMinusSalesTrendStat := salesTrendStatsMap.GetMaxSeqNOItem(key)
		if routeMinusSalesTrendStat == nil {
			logger.Log.Infof("入出金元情報管理[マイナス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
			// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
			routeMinusSalesTrendStat = &model.SalesTrendStat{}
		}

		isMinusInOutDeleted := false //入出金元情報管理[マイナス]を削除処理したか判定するフラグ
		minusInOutKessaiSeisanKingakuKisny := minusInOutSourceInfo.KessaiSeisanKingakuKisny
		plusInOutSourceInfos := plusInOutSourceInfosMap.GetInOutSourceInfos(minusInOutSourceInfo)
		for _, plusInOutSourceInfo := range plusInOutSourceInfos {
			//経路シーケンス番号取得 +
			//EXEC dbo.RQAJDDTCF0650_1
			key := model.SalesTrendStatKey{
				OriginalKozaNo: plusInOutSourceInfo.OriginalKozaNo,
				KijunYmd:       plusInOutSourceInfo.KijunYmd,
				ShtkmtDataKbn:  plusInOutSourceInfo.ShtkmtDataKbn,
				TorihikiNo:     plusInOutSourceInfo.TorihikiNo}
			routePlusSalesTrendStat := salesTrendStatsMap.GetMaxSeqNOItem(key)
			if routePlusSalesTrendStat == nil {
				logger.Log.Infof("入出金元情報管理[プラス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
				// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
				routePlusSalesTrendStat = &model.SalesTrendStat{}
			}

			var (
				wkTorihikiID     string
				wkKirSeqNO       int64
				wkHmzkTorihikiID string
				wkHmzkKirSeqNO   int64
			)

			if minusInOutKessaiSeisanKingakuKisny.GreaterThan(plusInOutSourceInfo.KessaiSeisanKingakuKisny) {
				/* マイナスデータ ＞ プラスデータ */
				/* 2.4関連更新処理4 */
				/* 経路．シーケンス番号等を設定 */
				wkTorihikiID = routeMinusSalesTrendStat.TorihikiId
				wkKirSeqNO = routeMinusSalesTrendStat.KirSeqNo + 1

				// 経路シーケンス（対応する販売動向統計）が取得できない場合は初期値をセットする
				if routePlusSalesTrendStat.IsFetched() {
					wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
					wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				} else {
					wkHmzkTorihikiID = ""
					wkHmzkKirSeqNO = 0
				}
				/* 2.2.1販売動向統計判定処理 */
				//EXEC dbo.RQAJDDTCF0650_2
				// ポインタから実体に変換することでデータを複製して代入する
				routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
				inOutSourceInfoForGenerate := *plusInOutSourceInfo
				routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
				routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
				cond := &model.GenerateConditionForYS{
					ShohinDibnriKbn: minusInOutSourceInfo.ShohinDibnriKbn,
					UkwtshYMD:       plusInOutSourceInfo.UkwtshYmd,
				}
				o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
					&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate,
					batchDate)
				if err != nil {
					return err
				}
				if o != nil {
					outputSalesTrendStats = append(outputSalesTrendStats, o)
					// 追加したもの含めて再度検索できるように追加する
					salesTrendStatsMap.Add(o)
				}
				routeMinusSalesTrendStat.KirSeqNo++ //dbo.RQAJDDTCF0650_2内でやっていたものを外出し

				/* 2.2.1販売動向統計判定処理 */
				/* 経路．シーケンス番号等を設定 */
				if !routeMinusSalesTrendStat.IsFetched() { //初期値""なら経路シーケンスデータが取得できなかったと判断
					wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
					wkTorihikiID = ""
					wkKirSeqNO = 0
				}

				//EXEC dbo.RQAJDDTCF0650_2
				// ポインタから実体に変換することでデータを複製して代入する
				routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
				inOutSourceInfoForGenerate = *minusInOutSourceInfo
				routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
				inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = plusInOutSourceInfo.KessaiSeisanKingakuKisny
				cond = &model.GenerateConditionForYS{
					ShohinDibnriKbn: plusInOutSourceInfo.ShohinDibnriKbn,
					UkwtshYMD:       plusInOutSourceInfo.UkwtshYmd,
				}
				o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
					&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate,
					batchDate)
				if err != nil {
					return err
				}
				if o != nil {
					outputSalesTrendStats = append(outputSalesTrendStats, o)
					// 追加したもの含めて再度検索できるように追加する
					salesTrendStatsMap.Add(o)
				}

				/* 決済．最終精算金額（計算用）を計算 */
				minusInOutKessaiSeisanKingakuKisny =
					minusInOutKessaiSeisanKingakuKisny.Sub(plusInOutSourceInfo.KessaiSeisanKingakuKisny)

				plusInOutSourceInfo.SkjFlg = 1
				plusInOutSourceInfo.RecordKshnYmd = batchDate
				plusInOutSourceInfo.SystemYmd = b.systemDate
				plusInOutSourceInfo.SystemHms = b.systemTime
				//EXEC dbo.RQAJDDTCF0650_5
				//削除フラグを立てたデータを入出金元情報管理　結果ファイルへ出力
				outputInOutSourceInfos = append(outputInOutSourceInfos, plusInOutSourceInfo)

			} else if minusInOutKessaiSeisanKingakuKisny.Equal(plusInOutSourceInfo.KessaiSeisanKingakuKisny) {
				/* マイナスデータ ＝ プラスデータ */
				/* 2.2関連更新処理2 */
				/* 経路．シーケンス番号等を設定 */
				wkTorihikiID = routeMinusSalesTrendStat.TorihikiId
				wkKirSeqNO = routeMinusSalesTrendStat.KirSeqNo + 1
				if routePlusSalesTrendStat.IsFetched() { //経路シーケンスデータ+が存在
					wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
					wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				} else { //経路シーケンスデータ+が存在しない
					wkHmzkTorihikiID = ""
					wkHmzkKirSeqNO = 0
				}

				//販売動向統計判定処理呼び出し（－）02
				// EXEC dbo.RQAJDDTCF0650_2
				// ポインタから実体に変換することでデータを複製して代入する
				routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
				inOutSourceInfoForGenerate := *plusInOutSourceInfo
				routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
				routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
				cond := &model.GenerateConditionForYS{
					ShohinDibnriKbn: minusInOutSourceInfo.ShohinDibnriKbn,
					UkwtshYMD:       plusInOutSourceInfo.UkwtshYmd,
				}
				o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
					&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate,
					batchDate)
				if err != nil {
					return err
				}
				if o != nil {
					outputSalesTrendStats = append(outputSalesTrendStats, o)
					// 追加したもの含めて再度検索できるように追加する
					salesTrendStatsMap.Add(o)
				}
				routeMinusSalesTrendStat.KirSeqNo++ //dbo.RQAJDDTCF0650_2内でやっていたものを外出し

				/* 2.2.1販売動向統計判定処理 */
				/* 経路．シーケンス番号等を設定 */
				if !routeMinusSalesTrendStat.IsFetched() {
					wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
					wkTorihikiID = ""
					wkKirSeqNO = 0
				}
				//EXEC dbo.RQAJDDTCF0650_2
				routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
				inOutSourceInfoForGenerate = *minusInOutSourceInfo
				routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
				inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = minusInOutKessaiSeisanKingakuKisny
				cond = &model.GenerateConditionForYS{
					ShohinDibnriKbn: plusInOutSourceInfo.ShohinDibnriKbn,
					UkwtshYMD:       plusInOutSourceInfo.UkwtshYmd,
				}
				o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
					&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate,
					batchDate)
				if err != nil {
					return err
				}
				if o != nil {
					outputSalesTrendStats = append(outputSalesTrendStats, o)
					// 追加したもの含めて再度検索できるように追加する
					salesTrendStatsMap.Add(o)
				}

				//EXEC dbo.RQAJDDTCF0650_5
				minusInOutSourceInfo.SkjFlg = 1
				minusInOutSourceInfo.RecordKshnYmd = batchDate
				minusInOutSourceInfo.SystemYmd = b.systemDate
				minusInOutSourceInfo.SystemHms = b.systemTime
				outputInOutSourceInfos = append(outputInOutSourceInfos, minusInOutSourceInfo)
				isMinusInOutDeleted = true // SkjFlgを立てたの削除済みに変更

				/* 入出金元情報管理DB削除 */
				//EXEC dbo.RQAJDDTCF0650_5
				plusInOutSourceInfo.SkjFlg = 1
				plusInOutSourceInfo.RecordKshnYmd = batchDate
				plusInOutSourceInfo.SystemYmd = b.systemDate
				plusInOutSourceInfo.SystemHms = b.systemTime
				outputInOutSourceInfos = append(outputInOutSourceInfos, plusInOutSourceInfo)
				/* ループエンド */
				break
			} else { //minusInOutSourceInfo.KessaiSeisanKingakuKisny < plusInOutSourceInfo.KessaiSeisanKingakuKisny
				/* 上記以外 */
				/* 2.3関連更新処理3 */
				/* 経路．シーケンス番号等を設定 */
				wkTorihikiID = routeMinusSalesTrendStat.TorihikiId
				wkKirSeqNO = routeMinusSalesTrendStat.KirSeqNo + 1
				if routePlusSalesTrendStat.IsFetched() {
					wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
					wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				} else {
					wkHmzkTorihikiID = ""
					wkHmzkKirSeqNO = 0
				}

				/* 2.2.1販売動向統計判定処理 */
				// EXEC dbo.RQAJDDTCF0650_2
				// ポインタから実体に変換することでデータを複製して代入する
				routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
				inOutSourceInfoForGenerate := *plusInOutSourceInfo
				routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
				routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
				inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = minusInOutKessaiSeisanKingakuKisny
				cond := &model.GenerateConditionForYS{
					ShohinDibnriKbn: minusInOutSourceInfo.ShohinDibnriKbn,
					UkwtshYMD:       plusInOutSourceInfo.UkwtshYmd,
				}
				o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
					&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate,
					batchDate)
				if err != nil {
					return err
				}
				if o != nil {
					outputSalesTrendStats = append(outputSalesTrendStats, o)
					// 追加したもの含めて再度検索できるように追加する
					salesTrendStatsMap.Add(o)
				}
				routeMinusSalesTrendStat.KirSeqNo++

				/* 2.2.1販売動向統計判定処理 */
				//販売動向統計判定処理呼び出し（＋）03

				/* 経路．シーケンス番号等を設定 */
				if !routeMinusSalesTrendStat.IsFetched() {
					wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
					wkTorihikiID = ""
					wkKirSeqNO = 0
				}

				routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
				inOutSourceInfoForGenerate = *minusInOutSourceInfo
				routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
				inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = minusInOutKessaiSeisanKingakuKisny
				cond = &model.GenerateConditionForYS{
					ShohinDibnriKbn: plusInOutSourceInfo.ShohinDibnriKbn,
					UkwtshYMD:       plusInOutSourceInfo.UkwtshYmd,
				}
				o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
					&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate,
					batchDate)
				if err != nil {
					return err
				}
				if o != nil {
					outputSalesTrendStats = append(outputSalesTrendStats, o)
					// 追加したもの含めて再度検索できるように追加する
					salesTrendStatsMap.Add(o)
				}

				/* 入出金元情報管理DB削除 */
				//EXEC dbo.RQAJDDTCF0650_5
				minusInOutSourceInfo.SkjFlg = 1
				minusInOutSourceInfo.RecordKshnYmd = batchDate
				minusInOutSourceInfo.SystemYmd = b.systemDate
				minusInOutSourceInfo.SystemHms = b.systemTime
				outputInOutSourceInfos = append(outputInOutSourceInfos, minusInOutSourceInfo)
				isMinusInOutDeleted = true // SkjFlgを立てたの削除済みに変更

				/* 入出金元情報管理更新処理 */
				//EXEC dbo.RQAJDDTCF0650_4
				plusInOutSourceInfo.KessaiSeisanKingakuKisny = plusInOutSourceInfo.KessaiSeisanKingakuKisny.Sub(minusInOutKessaiSeisanKingakuKisny)
				plusInOutSourceInfo.RecordKshnYmd = batchDate
				plusInOutSourceInfo.SystemYmd = b.systemDate
				plusInOutSourceInfo.SystemHms = b.systemTime
				outputInOutSourceInfos = append(outputInOutSourceInfos, plusInOutSourceInfo)
				/* ループエンド */
				break
			}
		}

		/* 入出金元情報管理[マイナス]をまだ削除してない場合 */
		if !isMinusInOutDeleted {
			/* 2.2.1販売動向統計判定処理 */
			wkKirSeqNO := routeMinusSalesTrendStat.KirSeqNo + 1
			//EXEC dbo.RQAJDDTCF0650_2
			routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
			routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
			inOutSourceInfoForGenerate := model.InitInOutSourceInfo()
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = minusInOutKessaiSeisanKingakuKisny
			inOutSourceInfoForGenerate.TishkKbn = "1"
			inOutSourceInfoForGenerate.KijunYmd = batchDate // レコードが存在しない場合は販売動向統計のKirKijunYmdにバッチ実行日が入る
			inOutSourceInfoForGenerate.IfJshnYmd = minusInOutSourceInfo.IfJshnYmd
			cond := &model.GenerateConditionForYS{
				ShohinDibnriKbn: minusInOutSourceInfo.ShohinDibnriKbn,
				UkwtshYMD:       0,
			}
			o, err := b.generateSalesTrendStat(cond, "", 0,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate,
				batchDate)
			if err != nil {
				return err
			}
			if o != nil {
				outputSalesTrendStats = append(outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				salesTrendStatsMap.Add(o)
			}
			routeMinusSalesTrendStat.KirSeqNo++ //dbo.RQAJDDTCF0650_2内でやっていたものを外出し

			/* 入出金元情報管理DB削除 */
			//EXEC dbo.RQAJDDTCF0650_5
			minusInOutSourceInfo.SkjFlg = 1
			minusInOutSourceInfo.RecordKshnYmd = batchDate
			minusInOutSourceInfo.SystemYmd = b.systemDate
			minusInOutSourceInfo.SystemHms = b.systemTime
			outputInOutSourceInfos = append(outputInOutSourceInfos, minusInOutSourceInfo)
		}
	}

	err = b.base.WriteInOutSourceInfos(filePaths[3], inOutSourceHeaders, outputInOutSourceInfos)
	if err != nil {
		return fmt.Errorf("入出金元情報管理のファイルを書き出しできませんでした; %v", err)
	}
	err = b.base.WriteSalesTrendStats(filePaths[4], salesTrendStatHeaders, outputSalesTrendStats)
	if err != nil {
		return fmt.Errorf("販売動向統計のファイルを書き出しできませんでした; %v", err)
	}
	return nil
}

func (b *BatchManager) generateSalesTrendStat(condition *model.GenerateConditionForYS, wkHmzkTorihikiID string, wkHmzkKirSeqNO int64,
	salesTrendStat *model.SalesTrendStat, inOutSourceInfo *model.InOutSourceInfo, batchDate string) (
	outSalesTrendStat *model.SalesTrendStat, err error) {
	// 部店コードが空 == 対応する販売動向統計のデータが取得できないケースは
	// 新しく販売動向統計のデータを登録しない
	if !salesTrendStat.IsFetched() {
		logger.Log.Infof("対応する販売動向統計が取得ができなかったため、販売動向統計の登録処理をスキップします")
		return nil, nil
	}

	if condition.ShohinDibnriKbn == "20" {
		logger.Log.Infof("商品大分類区分(ShohinDibnriKbn)==20であったため、販売動向統計の登録処理をスキップします; model=%+v", inOutSourceInfo)
		return nil, nil
	}

	var (
		wkKirKirKbn          string
		wkKirShohinDibnriKbn string
		wkKirShohinChbnriKbn string
		wkKirShohinShbnriKbn string
	)
	/* 1ヶ月前処理日付 */
	//SET @wk_before1Month = CAST(CONVERT(varchar,DATEADD(month,-1,CONVERT(date,@i_batchDate)),112) AS DECIMAL(8, 0));
	oneMonthAgo, err := common.MinusOneMonth(batchDate)
	if err != nil {
		return nil, err
	}
	/* 経路．経路区分 */
	/* 経路．商品大分類区分 */
	/* 経路．商品中分類区分 */
	/* 経路．商品小分類区分 */
	if oneMonthAgo > condition.UkwtshYMD {
		wkKirKirKbn = "200000"
		wkKirShohinDibnriKbn = "20"
		wkKirShohinChbnriKbn = "2000"
		wkKirShohinShbnriKbn = "200000"
	} else {
		wkKirKirKbn = inOutSourceInfo.KirKbn
		wkKirShohinDibnriKbn = inOutSourceInfo.ShohinDibnriKbn
		wkKirShohinChbnriKbn = inOutSourceInfo.ShohinChbnriKbn
		wkKirShohinShbnriKbn = inOutSourceInfo.ShohinShbnriKbn
	}

	//INSERT INTO dbo.CM2CF038
	outData := &model.SalesTrendStat{
		TorihikiId:                 salesTrendStat.TorihikiId,
		UserCd:                     salesTrendStat.UserCd,
		ButenCd:                    salesTrendStat.ButenCd,
		OriginalKozaNo:             salesTrendStat.OriginalKozaNo,
		KozaNo:                     salesTrendStat.KozaNo,
		CashHiritsuPer:             salesTrendStat.CashHiritsuPer,
		ShtkmtTblId:                salesTrendStat.ShtkmtTblId,
		ShtkmtDataKbn:              salesTrendStat.ShtkmtDataKbn,
		TorihikiKbn:                salesTrendStat.TorihikiKbn,
		TorihikiKbnShinyo:          salesTrendStat.TorihikiKbnShinyo,
		TaishoTrhkKbn:              salesTrendStat.TaishoTrhkKbn,
		KirKbn:                     salesTrendStat.KirKbn,
		ShohinDibnriKbn:            salesTrendStat.ShohinDibnriKbn,
		ShohinChbnriKbn:            salesTrendStat.ShohinChbnriKbn,
		ShohinShbnriKbn:            salesTrendStat.ShohinShbnriKbn,
		ToriatsukaiChannelCd:       salesTrendStat.ToriatsukaiChannelCd,
		AtsukaishaCd:               salesTrendStat.AtsukaishaCd,
		MgId:                       salesTrendStat.MgId,
		MgCd:                       salesTrendStat.MgCd,
		KokunaiGaiKbn:              salesTrendStat.KokunaiGaiKbn,
		ShohinKbn:                  salesTrendStat.ShohinKbn,
		ShohinCd:                   salesTrendStat.ShohinCd,
		ShohinCd1:                  salesTrendStat.ShohinCd1,
		ShohinCd2:                  salesTrendStat.ShohinCd2,
		ShohinCd3:                  salesTrendStat.ShohinCd3,
		ShohinCd4:                  salesTrendStat.ShohinCd4,
		HknKaishaCd:                salesTrendStat.HknKaishaCd,
		ShohinZksiCd:               salesTrendStat.ShohinZksiCd,
		KijunYmd:                   salesTrendStat.KijunYmd,
		JchNo:                      salesTrendStat.JchNo,
		YkjYmd:                     salesTrendStat.YkjYmd,
		UkwtshYmd:                  salesTrendStat.UkwtshYmd,
		TorihikiNo:                 salesTrendStat.TorihikiNo,
		TishkKbn:                   salesTrendStat.TishkKbn,
		TorihikiNaiyo:              salesTrendStat.TorihikiNaiyo,
		YkjSuryo:                   salesTrendStat.YkjSuryo, // DECIMAL(23,8) 計算に使用しないのでstring
		KessaiTsukaCd:              salesTrendStat.KessaiTsukaCd,
		HkLastSeisanKingaku:        salesTrendStat.HkLastSeisanKingaku,     // DECIMAL(20,3) 計算に使用しないのでstring
		KessaiLastSeisanKingaku:    salesTrendStat.KessaiLastSeisanKingaku, // DECIMAL(20,3) 計算に使用しないのでstring
		ChmnChannelCd:              salesTrendStat.ChmnChannelCd,
		GenkinKir:                  salesTrendStat.GenkinKir,
		SwKbn:                      salesTrendStat.SwKbn,
		SwTaishoKbn:                salesTrendStat.SwTaishoKbn,
		HknNyknFlg:                 salesTrendStat.HknNyknFlg,
		TrkshKbn:                   salesTrendStat.TrkshKbn,
		KirSeqNo:                   salesTrendStat.KirSeqNo,
		KirKirKbn:                  wkKirKirKbn,
		KirShohinDibnriKbn:         wkKirShohinDibnriKbn,
		KirShohinChbnriKbn:         wkKirShohinChbnriKbn,
		KirShohinShbnriKbn:         wkKirShohinShbnriKbn,
		KirSttiYmd:                 batchDate,
		KirKijunYmd:                inOutSourceInfo.KijunYmd,
		KirMgId:                    inOutSourceInfo.MgId,
		KirMgCd:                    inOutSourceInfo.MgCd,
		KirKokunaiGaiKbn:           inOutSourceInfo.KokunaiGaiKbn,
		KirShohinKbn:               inOutSourceInfo.ShohinKbn,
		KirShohinCd:                inOutSourceInfo.ShohinCd,
		KirShohinCd_1:              inOutSourceInfo.ShohinCd1,
		KirShohinCd_2:              inOutSourceInfo.ShohinCd2,
		KirShohinCd_3:              inOutSourceInfo.ShohinCd3,
		KirShohinCd_4:              inOutSourceInfo.ShohinCd4,
		KirHknKaishaCd:             inOutSourceInfo.HknKaishaCd,
		KirShohinZksiCd:            inOutSourceInfo.ShohinZksiCd,
		KirYkjYmd:                  inOutSourceInfo.YkjYmd,
		KirUkwtshYmd:               inOutSourceInfo.UkwtshYmd,
		KirTorihikiNo:              inOutSourceInfo.TorihikiNo,
		KirTishkKbn:                inOutSourceInfo.TishkKbn,
		KirTorihikiNaiyo:           inOutSourceInfo.TorihikiNaiyo,
		KirYkjSuryo:                inOutSourceInfo.YkjSuryo,
		KirHkLastSeisanKingaku:     inOutSourceInfo.HkSeisanKingakuOriginal,
		KirKessaiLastSeisanKingaku: inOutSourceInfo.KessaiSeisanKingakuOriginal,
		KirChmnChannelCd:           inOutSourceInfo.ChmnChannelCd,
		KirTrkshKbn:                inOutSourceInfo.TrkshKbn,
		KirKingaku:                 inOutSourceInfo.KessaiSeisanKingakuKisny,
		HmzkTorihikiId:             wkHmzkTorihikiID,
		HmzkKirSeqNo:               wkHmzkKirSeqNO,
		KratFlg:                    salesTrendStat.KratFlg,
		RecordSksiYmd:              batchDate,
		RecordKoshinYmd:            batchDate,
		IfJshnYmd:                  inOutSourceInfo.IfJshnYmd,
		ShoriTaishoYmd:             b.systemDate,
		SystemYmd:                  b.systemDate,
		SystemHms:                  b.systemTime,
		DataSourceId:               salesTrendStat.DataSourceId,
	}

	return outData, nil
}
