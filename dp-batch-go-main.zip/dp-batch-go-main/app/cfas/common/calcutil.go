package common

import (
	"github.com/shopspring/decimal"
)

/*CalcKeiroKingaku 経路金額を計算する。次のロジックを再現している。

SET @WK_kirKingaku = CAST(CAST(@hkSeisanKingakuOriginal AS DECIMAL(27, 10)) *
	(CAST(@kessaiSeisanKingakuKisny AS DECIMAL(27, 10)) / CAST(@kessaiSeisanKingakuOriginal AS DECIMAL(27, 10))) AS DECIMAL(27, 0));
*/
func CalcKeiroKingaku(hkSeisanKingakuOriginal, kessaiSeisanKingakuKisny, kessaiSeisanKingakuOriginal decimal.Decimal) decimal.Decimal {
	// 割り算によって精度が変わるので、精度の境目で四捨五入する
	// scale = max(6, s1 + p2 + 1) = max(6, 10 + 27 + 1) = max(6, 38) = 38
	// https://docs.microsoft.com/ja-jp/sql/t-sql/data-types/precision-scale-and-length-transact-sql?view=sql-server-ver15
	return hkSeisanKingakuOriginal.Mul(
		kessaiSeisanKingakuKisny.Div(
			kessaiSeisanKingakuOriginal).Round(38)).Round(0)
}

/*CalcKessaiSeisanKingakuGikMMF 決済_精算金額(外貨MMF)を計算する。次のロジックを再現している。

DECLARE @WK_kessaiSeisanKingakuGikMmf DECIMAL(20,3)
SET @WK_kessaiSeisanKingakuGikMmf = CAST(ABS(@WK_kirKingaku) AS DECIMAL(27, 10)) /
	CAST(@i_hkSeisanKingakuOriginal AS DECIMAL(27, 10)) * CAST(@i_kessaiSeisanKingakuOriginal AS DECIMAL(27, 10));
*/
func CalcKessaiSeisanKingakuGikMMF(kirKingaku, hkSeisanKingakuOriginal, kessaiSeisanKingakuOriginal decimal.Decimal) decimal.Decimal {
	// 割り算によって精度が変わるので、精度の境目で四捨五入する
	// scale = max(6, s1 + p2 + 1) = max(6, 10 + 27 + 1) = max(6, 38) = 38
	// https://docs.microsoft.com/ja-jp/sql/t-sql/data-types/precision-scale-and-length-transact-sql?view=sql-server-ver15
	return kirKingaku.Abs().
		Div(hkSeisanKingakuOriginal).Round(38).
		Mul(kessaiSeisanKingakuOriginal).Round(3)
}
