package common

import (
	"fmt"
	"strconv"
	"time"
)

/*MinusOneMonth 1ヵ月前のYYYYMMDDのint64を取得する。
date string "YYYYMMDD"
*/
func MinusOneMonth(date string) (int64, error) {
	dt, err := time.Parse("20060102", date)
	if err != nil {
		return -1, fmt.Errorf("'date' を time.Time 型に変換できませんでした。'YYYYMMDD'の形である必要があります; %v", err)
	}

	before1Month := dt.AddDate(0, -1, 0)

	d, err := strconv.Atoi(before1Month.Format("20060102"))
	if err != nil {
		return -1, fmt.Errorf("time.Time型をint型に変換できませんでした。; %v", err)
	}
	return int64(d), nil
}
