package model

import (
	"fmt"
	"strconv"

	"github.com/shopspring/decimal"
)

/*
InOutSourceInfo 入出金元情報管理
円決・外決ともに同じ構造体を利用。
null値を扱うのとパースが面倒なため、Go内の処理で使わない値は string 型で保持する。
*/
type InOutSourceInfo struct {
	ShoriYmd                    string
	RecordSeqNo                 string
	UserCd                      string
	ButenCd                     string
	OriginalKozaNo              string
	KozaNo                      string
	ShtkmtTblId                 string
	ShtkmtDataKbn               string
	KirKbn                      string
	ShohinDibnriKbn             string
	ShohinChbnriKbn             string
	ShohinShbnriKbn             string
	ToriatsukaiChannelCd        string
	AtsukaishaCd                string
	MgId                        string
	MgCd                        string
	KokunaiGaiKbn               string
	ShohinKbn                   string
	ShohinCd                    string
	ShohinCd1                   string
	ShohinCd2                   string
	ShohinCd3                   string
	ShohinCd4                   string
	HknKaishaCd                 string
	ShohinZksiCd                string
	KijunYmd                    string
	YkjYmd                      string
	UkwtshYmd                   int64
	TorihikiNo                  string
	TishkKbn                    string
	TorihikiNaiyo               string
	YkjSuryo                    string
	KessaiTsukaCd               string
	HkSeisanKingakuOriginal     decimal.Decimal
	KessaiSeisanKingakuOriginal decimal.Decimal
	KessaiSeisanKingakuKisny    decimal.Decimal
	KessaiSeisanKingakuGikMmf   decimal.Decimal
	ChmnChannelCd               string
	NyushukkinKratKbn           string
	FtjtsFlg                    string
	TrkshKbn                    string
	SkjFlg                      int64
	RecordSksiYmd               string
	RecordKshnYmd               string
	IfJshnYmd                   string
	ShoriTaishoYmd              string
	SystemYmd                   string
	SystemHms                   string
	DataSourceId                string
}

func InitInOutSourceInfo() InOutSourceInfo {
	d := InOutSourceInfo{}
	d.ShoriYmd = "0"
	d.RecordSeqNo = "0"
	d.KijunYmd = "0"
	d.YkjYmd = "0"
	d.TishkKbn = "0"
	d.YkjSuryo = "0"
	d.HkSeisanKingakuOriginal = decimal.Zero
	d.KessaiSeisanKingakuOriginal = decimal.Zero
	d.KessaiSeisanKingakuGikMmf = decimal.Zero
	return d
}
func NewInOutSourceInfo(l []string) (d *InOutSourceInfo, err error) {
	if len(l) != 49 {
		return nil, fmt.Errorf("入出金元情報管理の列数が想定と一致しません; 想定 49, 実際 %v", len(l))
	}
	d = &InOutSourceInfo{}
	d.ShoriYmd = l[0]
	d.RecordSeqNo = l[1]
	d.UserCd = l[2]
	d.ButenCd = l[3]
	d.OriginalKozaNo = l[4]
	d.KozaNo = l[5]
	d.ShtkmtTblId = l[6]
	d.ShtkmtDataKbn = l[7]
	d.KirKbn = l[8]
	d.ShohinDibnriKbn = l[9]
	d.ShohinChbnriKbn = l[10]
	d.ShohinShbnriKbn = l[11]
	d.ToriatsukaiChannelCd = l[12]
	d.AtsukaishaCd = l[13]
	d.MgId = l[14]
	d.MgCd = l[15]
	d.KokunaiGaiKbn = l[16]
	d.ShohinKbn = l[17]
	d.ShohinCd = l[18]
	d.ShohinCd1 = l[19]
	d.ShohinCd2 = l[20]
	d.ShohinCd3 = l[21]
	d.ShohinCd4 = l[22]
	d.HknKaishaCd = l[23]
	d.ShohinZksiCd = l[24]
	d.KijunYmd = l[25]
	d.YkjYmd = l[26]
	d.UkwtshYmd, err = strconv.ParseInt(l[27], 10, 64)
	if err != nil {
		return nil, fmt.Errorf("入出金元情報管理 UkwtshYmd の読み取りに失敗しました: %v", err)
	}
	d.TorihikiNo = l[28]
	d.TishkKbn = l[29]
	d.TorihikiNaiyo = l[30]
	d.YkjSuryo = l[31]
	d.KessaiTsukaCd = l[32]
	d.HkSeisanKingakuOriginal, err = decimal.NewFromString(l[33])
	if err != nil {
		return nil, fmt.Errorf("入出金元情報管理 HkSeisanKingakuOriginal の読み取りに失敗しました: %v", err)
	}
	d.KessaiSeisanKingakuOriginal, err = decimal.NewFromString(l[34])
	if err != nil {
		return nil, fmt.Errorf("入出金元情報管理 KessaiSeisanKingakuOriginal の読み取りに失敗しました: %v", err)
	}
	d.KessaiSeisanKingakuKisny, err = decimal.NewFromString(l[35])
	if err != nil {
		return nil, fmt.Errorf("入出金元情報管理 KessaiSeisanKingakuKisny の読み取りに失敗しました: %v", err)
	}
	d.KessaiSeisanKingakuGikMmf, err = decimal.NewFromString(l[36])
	if err != nil {
		return nil, fmt.Errorf("入出金元情報管理 KessaiSeisanKingakuGikMmf の読み取りに失敗しました: %v", err)
	}
	d.ChmnChannelCd = l[37]
	d.NyushukkinKratKbn = l[38]
	d.FtjtsFlg = l[39]
	d.TrkshKbn = l[40]
	d.SkjFlg, err = strconv.ParseInt(l[41], 10, 64)
	if err != nil {
		return nil, fmt.Errorf("入出金元情報管理 SkjFlg の読み取りに失敗しました: %v", err)
	}
	d.RecordSksiYmd = l[42]
	d.RecordKshnYmd = l[43]
	d.IfJshnYmd = l[44]
	d.ShoriTaishoYmd = l[45]
	d.SystemYmd = l[46]
	d.SystemHms = l[47]
	d.DataSourceId = l[48]
	return d, nil
}

func (d *InOutSourceInfo) ToSlice() []string {
	return []string{
		d.ShoriYmd,
		d.RecordSeqNo,
		d.UserCd,
		d.ButenCd,
		d.OriginalKozaNo,
		d.KozaNo,
		d.ShtkmtTblId,
		d.ShtkmtDataKbn,
		d.KirKbn,
		d.ShohinDibnriKbn,
		d.ShohinChbnriKbn,
		d.ShohinShbnriKbn,
		d.ToriatsukaiChannelCd,
		d.AtsukaishaCd,
		d.MgId,
		d.MgCd,
		d.KokunaiGaiKbn,
		d.ShohinKbn,
		d.ShohinCd,
		d.ShohinCd1,
		d.ShohinCd2,
		d.ShohinCd3,
		d.ShohinCd4,
		d.HknKaishaCd,
		d.ShohinZksiCd,
		d.KijunYmd,
		d.YkjYmd,
		strconv.FormatInt(d.UkwtshYmd, 10),
		d.TorihikiNo,
		d.TishkKbn,
		d.TorihikiNaiyo,
		d.YkjSuryo,
		d.KessaiTsukaCd,
		d.HkSeisanKingakuOriginal.String(),
		d.KessaiSeisanKingakuOriginal.String(),
		d.KessaiSeisanKingakuKisny.String(),
		d.KessaiSeisanKingakuGikMmf.String(),
		d.ChmnChannelCd,
		d.NyushukkinKratKbn,
		d.FtjtsFlg,
		d.TrkshKbn,
		strconv.FormatInt(d.SkjFlg, 10),
		d.RecordSksiYmd,
		d.RecordKshnYmd,
		d.IfJshnYmd,
		d.ShoriTaishoYmd,
		d.SystemYmd,
		d.SystemHms,
		d.DataSourceId,
	}
}
