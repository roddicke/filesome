package model

import "math"

// SalesTrendStatKey 販売動向統計　キー情報
type SalesTrendStatKey struct {
	OriginalKozaNo string
	KijunYmd       string
	ShtkmtDataKbn  string
	TorihikiNo     string
}

type SalesTrendStatsMap map[SalesTrendStatKey][]*SalesTrendStat

func NewSalesTrendStatsMap(stats []*SalesTrendStat) SalesTrendStatsMap {
	m := make(SalesTrendStatsMap)
	for _, r := range stats {
		key := SalesTrendStatKey{
			OriginalKozaNo: r.OriginalKozaNo,
			KijunYmd:       r.KijunYmd,
			ShtkmtDataKbn:  r.ShtkmtDataKbn,
			TorihikiNo:     r.TorihikiNo,
		}
		m[key] = append(m[key], r)
	}
	return m
}

/*GetMaxSeqNOItem 販売動向統計マップから指定されたキーで販売動向統計のスライスを取得し、その中から経路シーケンスが最大な販売動向統計を返す。
経路シーケンス最大な販売動向統計が見つからない場合は nil を返す。
*/
func (s *SalesTrendStatsMap) GetMaxSeqNOItem(key SalesTrendStatKey) *SalesTrendStat {
	stats, ok := (*s)[key]
	if !ok {
		return nil
	}
	// 経路シーケンス最大の物を取得
	m := int64(math.MinInt64)
	var target *SalesTrendStat
	for _, s := range stats {
		if s.KirSeqNo > m {
			m = s.KirSeqNo
			target = s
		}
	}
	return target
}

/*Add 販売動向統計を新しく登録する。すでにポインタが登録されている場合は登録をスキップする。
 */
func (s *SalesTrendStatsMap) Add(stat *SalesTrendStat) {
	key := SalesTrendStatKey{
		OriginalKozaNo: stat.OriginalKozaNo,
		KijunYmd:       stat.KijunYmd,
		ShtkmtDataKbn:  stat.ShtkmtDataKbn,
		TorihikiNo:     stat.TorihikiNo,
	}

	// 登録されている場合はスキップ
	if IsSalesTrendStatContains((*s)[key], stat) {
		return
	}

	(*s)[key] = append((*s)[key], stat)
}
