package model

// GenerateConditionForYS 円決処理時の販売動向統計判定処理の判定情報を扱う構造体
type GenerateConditionForYS struct {
	ShohinDibnriKbn string
	UkwtshYMD       int64
}

// GenerateConditionForFCS 外決処理時の販売動向統計判定処理の判定情報を扱う構造体
type GenerateConditionForFCS struct {
	UkwtshYMD int64
}
