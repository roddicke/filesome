package model

import (
	"sort"
)

type PlusYSInOutSourceInfoKey struct {
	OriginalKozaNo string
}

type PlusYSInOutSourceInfosMap map[PlusYSInOutSourceInfoKey][]*InOutSourceInfo

func NewPlusYSInOutSourceInfosMap(infos []*InOutSourceInfo) PlusYSInOutSourceInfosMap {
	m := make(PlusYSInOutSourceInfosMap)
	for _, info := range infos {
		key := PlusYSInOutSourceInfoKey{OriginalKozaNo: info.OriginalKozaNo}
		s, ok := m[key]
		if !ok {
			s = []*InOutSourceInfo{}
		}
		s = append(s, info)
		m[key] = s
	}
	return m
}

/*GetInOutSourceInfos 基準となる入出金元情報管理を活用して円決の条件に合致する入出金元情報管理（プラス）を取得する。
 */
func (m *PlusYSInOutSourceInfosMap) GetInOutSourceInfos(base *InOutSourceInfo) (infos []*InOutSourceInfo) {
	key := PlusYSInOutSourceInfoKey{OriginalKozaNo: base.OriginalKozaNo}
	candidates, ok := (*m)[key]
	if !ok {
		return nil
	}

	for _, candidate := range candidates {
		// ネストを回避するために条件に該当しない場合はスキップする
		if !(candidate.TishkKbn == "1") {
			continue
		}

		if !(candidate.UkwtshYmd <= base.UkwtshYmd) {
			continue
		}

		if !(candidate.SkjFlg == 0) {
			continue
		}

		infos = append(infos, candidate)
	}

	// ネストが浅い方が優先度高い
	// ORDER BY
	//  GP.UKWTSH_YMD DESC,
	// 	GP.SHOHIN_DIBNRI_KBN,
	// 	GP.SHOHIN_CHBNRI_KBN,
	// 	GP.SHOHIN_SHBNRI_KBN,
	// 	GP.TORIHIKI_NO,
	// 	GP.YKJ_YMD DESC,
	// 	GP.KESSAI_SEISAN_KINGAKU_KISNY DESC
	sort.SliceStable(infos, func(i, j int) bool {
		if infos[i].UkwtshYmd > infos[j].UkwtshYmd { // 降順
			return true
		} else if infos[i].UkwtshYmd == infos[j].UkwtshYmd {
			if infos[i].ShohinDibnriKbn < infos[j].ShohinDibnriKbn {
				return true
			} else if infos[i].ShohinDibnriKbn == infos[j].ShohinDibnriKbn {
				if infos[i].ShohinChbnriKbn < infos[j].ShohinChbnriKbn {
					return true
				} else if infos[i].ShohinChbnriKbn == infos[j].ShohinChbnriKbn {
					if infos[i].ShohinShbnriKbn < infos[j].ShohinShbnriKbn {
						return true
					} else if infos[i].ShohinShbnriKbn == infos[j].ShohinShbnriKbn {
						if infos[i].TorihikiNo < infos[j].TorihikiNo {
							return true
						} else if infos[i].TorihikiNo == infos[j].TorihikiNo {
							if infos[i].YkjYmd > infos[j].YkjYmd { // 降順
								return true
							} else if infos[i].YkjYmd == infos[j].YkjYmd {
								if infos[i].KessaiSeisanKingakuKisny.GreaterThan(infos[j].KessaiSeisanKingakuKisny) { // 降順
									return true
								}
							}
						}
					}
				}
			}
		}
		return false
	})

	return infos
}
