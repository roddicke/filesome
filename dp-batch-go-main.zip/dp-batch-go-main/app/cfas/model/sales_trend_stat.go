package model

import (
	"fmt"
	"strconv"

	"github.com/shopspring/decimal"
)

/*
SalesTrendStat 販売動向統計
null値を扱うのとパースが面倒なため、Go内の処理で使わない値は string 型で保持する。
*/
type SalesTrendStat struct {
	TorihikiId                 string
	UserCd                     string
	ButenCd                    string
	OriginalKozaNo             string
	KozaNo                     string
	CashHiritsuPer             string
	ShtkmtTblId                string
	ShtkmtDataKbn              string
	TorihikiKbn                string
	TorihikiKbnShinyo          string
	TaishoTrhkKbn              string
	KirKbn                     string
	ShohinDibnriKbn            string
	ShohinChbnriKbn            string
	ShohinShbnriKbn            string
	ToriatsukaiChannelCd       string
	AtsukaishaCd               string
	MgId                       string
	MgCd                       string
	KokunaiGaiKbn              string
	ShohinKbn                  string
	ShohinCd                   string
	ShohinCd1                  string
	ShohinCd2                  string
	ShohinCd3                  string
	ShohinCd4                  string
	HknKaishaCd                string
	ShohinZksiCd               string
	KijunYmd                   string
	JchNo                      string
	YkjYmd                     string
	UkwtshYmd                  int64
	TorihikiNo                 string
	TishkKbn                   string
	TorihikiNaiyo              string
	YkjSuryo                   string
	KessaiTsukaCd              string
	HkLastSeisanKingaku        decimal.Decimal
	KessaiLastSeisanKingaku    decimal.Decimal
	ChmnChannelCd              string
	GenkinKir                  string
	SwKbn                      string
	SwTaishoKbn                string
	HknNyknFlg                 string
	TrkshKbn                   string
	KirSeqNo                   int64
	KirKirKbn                  string
	KirShohinDibnriKbn         string
	KirShohinChbnriKbn         string
	KirShohinShbnriKbn         string
	KirSttiYmd                 string
	KirKijunYmd                string
	KirMgId                    string
	KirMgCd                    string
	KirKokunaiGaiKbn           string
	KirShohinKbn               string
	KirShohinCd                string
	KirShohinCd_1              string
	KirShohinCd_2              string
	KirShohinCd_3              string
	KirShohinCd_4              string
	KirHknKaishaCd             string
	KirShohinZksiCd            string
	KirYkjYmd                  string
	KirUkwtshYmd               int64
	KirTorihikiNo              string
	KirTishkKbn                string
	KirTorihikiNaiyo           string
	KirYkjSuryo                string
	KirHkLastSeisanKingaku     decimal.Decimal
	KirKessaiLastSeisanKingaku decimal.Decimal
	KirChmnChannelCd           string
	KirTrkshKbn                string
	KirKingaku                 decimal.Decimal
	HmzkTorihikiId             string
	HmzkKirSeqNo               int64
	KratFlg                    string
	RecordSksiYmd              string
	RecordKoshinYmd            string
	IfJshnYmd                  string
	ShoriTaishoYmd             string
	SystemYmd                  string
	SystemHms                  string
	DataSourceId               string
}

func NewSalesTrendStat(l []string) (d *SalesTrendStat, err error) {
	if len(l) != 84 {
		return nil, fmt.Errorf("販売動向統計の列数が想定と一致しません; 想定 84, 実際 %v", len(l))
	}
	d = &SalesTrendStat{}
	d.TorihikiId = l[0]
	d.UserCd = l[1]
	d.ButenCd = l[2]
	d.OriginalKozaNo = l[3]
	d.KozaNo = l[4]
	d.CashHiritsuPer = l[5]
	d.ShtkmtTblId = l[6]
	d.ShtkmtDataKbn = l[7]
	d.TorihikiKbn = l[8]
	d.TorihikiKbnShinyo = l[9]
	d.TaishoTrhkKbn = l[10]
	d.KirKbn = l[11]
	d.ShohinDibnriKbn = l[12]
	d.ShohinChbnriKbn = l[13]
	d.ShohinShbnriKbn = l[14]
	d.ToriatsukaiChannelCd = l[15]
	d.AtsukaishaCd = l[16]
	d.MgId = l[17]
	d.MgCd = l[18]
	d.KokunaiGaiKbn = l[19]
	d.ShohinKbn = l[20]
	d.ShohinCd = l[21]
	d.ShohinCd1 = l[22]
	d.ShohinCd2 = l[23]
	d.ShohinCd3 = l[24]
	d.ShohinCd4 = l[25]
	d.HknKaishaCd = l[26]
	d.ShohinZksiCd = l[27]
	d.KijunYmd = l[28]
	d.JchNo = l[29]
	d.YkjYmd = l[30]
	d.UkwtshYmd, err = strconv.ParseInt(l[31], 10, 64)
	if err != nil {
		return nil, fmt.Errorf("販売動向統計 UkwtshYmd の読み取りに失敗しました: %v", err)
	}
	d.TorihikiNo = l[32]
	d.TishkKbn = l[33]
	d.TorihikiNaiyo = l[34]
	d.YkjSuryo = l[35]
	d.KessaiTsukaCd = l[36]
	d.HkLastSeisanKingaku, err = decimal.NewFromString(l[37])
	if err != nil {
		return nil, fmt.Errorf("販売動向統計 HkLastSeisanKingaku の読み取りに失敗しました: %v", err)
	}
	d.KessaiLastSeisanKingaku, err = decimal.NewFromString(l[38])
	if err != nil {
		return nil, fmt.Errorf("販売動向統計 KessaiLastSeisanKingaku の読み取りに失敗しました: %v", err)
	}
	d.ChmnChannelCd = l[39]
	d.GenkinKir = l[40]
	d.SwKbn = l[41]
	d.SwTaishoKbn = l[42]
	d.HknNyknFlg = l[43]
	d.TrkshKbn = l[44]
	d.KirSeqNo, err = strconv.ParseInt(l[45], 10, 64)
	if err != nil {
		return nil, fmt.Errorf("販売動向統計 KirSeqNo の読み取りに失敗しました: %v", err)
	}
	d.KirKirKbn = l[46]
	d.KirShohinDibnriKbn = l[47]
	d.KirShohinChbnriKbn = l[48]
	d.KirShohinShbnriKbn = l[49]
	d.KirSttiYmd = l[50]
	d.KirKijunYmd = l[51]
	d.KirMgId = l[52]
	d.KirMgCd = l[53]
	d.KirKokunaiGaiKbn = l[54]
	d.KirShohinKbn = l[55]
	d.KirShohinCd = l[56]
	d.KirShohinCd_1 = l[57]
	d.KirShohinCd_2 = l[58]
	d.KirShohinCd_3 = l[59]
	d.KirShohinCd_4 = l[60]
	d.KirHknKaishaCd = l[61]
	d.KirShohinZksiCd = l[62]
	d.KirYkjYmd = l[63]
	d.KirUkwtshYmd, err = strconv.ParseInt(l[64], 10, 64)
	if err != nil {
		return nil, fmt.Errorf("販売動向統計 KirUkwtshYmd の読み取りに失敗しました: %v", err)
	}
	d.KirTorihikiNo = l[65]
	d.KirTishkKbn = l[66]
	d.KirTorihikiNaiyo = l[67]
	d.KirYkjSuryo = l[68]
	d.KirHkLastSeisanKingaku, err = decimal.NewFromString(l[69])
	if err != nil {
		return nil, fmt.Errorf("販売動向統計 KirHkLastSeisanKingaku の読み取りに失敗しました: %v", err)
	}
	d.KirKessaiLastSeisanKingaku, err = decimal.NewFromString(l[70])
	if err != nil {
		return nil, fmt.Errorf("販売動向統計 KirKessaiLastSeisanKingaku の読み取りに失敗しました: %v", err)
	}
	d.KirChmnChannelCd = l[71]
	d.KirTrkshKbn = l[72]
	d.KirKingaku, err = decimal.NewFromString(l[73])
	if err != nil {
		return nil, fmt.Errorf("販売動向統計 KirKingaku の読み取りに失敗しました: %v", err)
	}
	d.HmzkTorihikiId = l[74]
	d.HmzkKirSeqNo, err = strconv.ParseInt(l[75], 10, 64)
	if err != nil {
		return nil, fmt.Errorf("販売動向統計 HmzkKirSeqNo の読み取りに失敗しました: %v", err)
	}
	d.KratFlg = l[76]
	d.RecordSksiYmd = l[77]
	d.RecordKoshinYmd = l[78]
	d.IfJshnYmd = l[79]
	d.ShoriTaishoYmd = l[80]
	d.SystemYmd = l[81]
	d.SystemHms = l[82]
	d.DataSourceId = l[83]
	return d, nil
}

func (h SalesTrendStat) ToSlice() []string {
	return []string{
		h.TorihikiId,
		h.UserCd,
		h.ButenCd,
		h.OriginalKozaNo,
		h.KozaNo,
		h.CashHiritsuPer,
		h.ShtkmtTblId,
		h.ShtkmtDataKbn,
		h.TorihikiKbn,
		h.TorihikiKbnShinyo,
		h.TaishoTrhkKbn,
		h.KirKbn,
		h.ShohinDibnriKbn,
		h.ShohinChbnriKbn,
		h.ShohinShbnriKbn,
		h.ToriatsukaiChannelCd,
		h.AtsukaishaCd,
		h.MgId,
		h.MgCd,
		h.KokunaiGaiKbn,
		h.ShohinKbn,
		h.ShohinCd,
		h.ShohinCd1,
		h.ShohinCd2,
		h.ShohinCd3,
		h.ShohinCd4,
		h.HknKaishaCd,
		h.ShohinZksiCd,
		h.KijunYmd,
		h.JchNo,
		h.YkjYmd,
		strconv.FormatInt(h.UkwtshYmd, 10),
		h.TorihikiNo,
		h.TishkKbn,
		h.TorihikiNaiyo,
		h.YkjSuryo,
		h.KessaiTsukaCd,
		h.HkLastSeisanKingaku.String(),
		h.KessaiLastSeisanKingaku.String(),
		h.ChmnChannelCd,
		h.GenkinKir,
		h.SwKbn,
		h.SwTaishoKbn,
		h.HknNyknFlg,
		h.TrkshKbn,
		strconv.FormatInt(h.KirSeqNo, 10),
		h.KirKirKbn,
		h.KirShohinDibnriKbn,
		h.KirShohinChbnriKbn,
		h.KirShohinShbnriKbn,
		h.KirSttiYmd,
		h.KirKijunYmd,
		h.KirMgId,
		h.KirMgCd,
		h.KirKokunaiGaiKbn,
		h.KirShohinKbn,
		h.KirShohinCd,
		h.KirShohinCd_1,
		h.KirShohinCd_2,
		h.KirShohinCd_3,
		h.KirShohinCd_4,
		h.KirHknKaishaCd,
		h.KirShohinZksiCd,
		h.KirYkjYmd,
		strconv.FormatInt(h.KirUkwtshYmd, 10),
		h.KirTorihikiNo,
		h.KirTishkKbn,
		h.KirTorihikiNaiyo,
		h.KirYkjSuryo,
		h.KirHkLastSeisanKingaku.String(),
		h.KirKessaiLastSeisanKingaku.String(),
		h.KirChmnChannelCd,
		h.KirTrkshKbn,
		h.KirKingaku.String(),
		h.HmzkTorihikiId,
		strconv.FormatInt(h.HmzkKirSeqNo, 10),
		h.KratFlg,
		h.RecordSksiYmd,
		h.RecordKoshinYmd,
		h.IfJshnYmd,
		h.ShoriTaishoYmd,
		h.SystemYmd,
		h.SystemHms,
		h.DataSourceId,
	}
}

/*
IsFetched
販売動向統計が取得できたかどうかを返す。取得できる場合は True になる。
*/
func (h *SalesTrendStat) IsFetched() bool {
	// 取得可否は部店コードの値で判断する
	// 取得できない場合は構造体の初期化がされていて、部店コードが空になるため(部店コードはNonNull)
	if h.ButenCd == "" {
		return false
	}
	return true
}

func IsSalesTrendStatContains(l []*SalesTrendStat, t *SalesTrendStat) bool {
	for _, s := range l {
		if s == t {
			return true
		}
	}

	return false
}
