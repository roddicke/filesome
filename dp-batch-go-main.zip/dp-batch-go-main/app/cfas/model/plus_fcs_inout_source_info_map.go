package model

import (
	"sort"

	"dp-batch-go/app/cfas/common"
)

type PlusFCSInOutSourceInfoKey struct {
	OriginalKozaNo string
	KessaiTsukaCd  string
}

type PlusFCSInOutSourceInfosMap map[PlusFCSInOutSourceInfoKey][]*InOutSourceInfo

func NewPlusFCSInOutSourceInfosMap(infos []*InOutSourceInfo) PlusFCSInOutSourceInfosMap {
	m := make(PlusFCSInOutSourceInfosMap)
	for _, info := range infos {
		key := PlusFCSInOutSourceInfoKey{OriginalKozaNo: info.OriginalKozaNo, KessaiTsukaCd: info.KessaiTsukaCd}
		s, ok := m[key]
		if !ok {
			s = []*InOutSourceInfo{}
		}
		s = append(s, info)
		m[key] = s
	}
	return m
}

/*GetInOutSourceInfos 基準となる入出金元情報管理を活用して外決の条件に合致する入出金元情報管理（プラス）を取得する。
 */
func (m *PlusFCSInOutSourceInfosMap) GetInOutSourceInfos(base *InOutSourceInfo) (infos []*InOutSourceInfo) {
	key := PlusFCSInOutSourceInfoKey{OriginalKozaNo: base.OriginalKozaNo, KessaiTsukaCd: base.KessaiTsukaCd}
	candidates, ok := (*m)[key]
	if !ok {
		return nil
	}

	for _, candidate := range candidates {
		// ネストを回避するために条件に該当しない場合はスキップする
		if !(candidate.TishkKbn == "1") {
			continue
		}

		if !(candidate.UkwtshYmd <= base.UkwtshYmd) {
			continue
		}

		// AND GP.NYUSHUKKIN_KRAT_KBN IN ('', ' ', '1')
		if !((candidate.NyushukkinKratKbn == "") || (candidate.NyushukkinKratKbn == " ") || (candidate.NyushukkinKratKbn == "1")) {
			continue
		}

		if !(candidate.SkjFlg == 0) {
			continue
		}

		infos = append(infos, candidate)
	}

	// ネストが浅い方が優先度高い
	// ORDER BY
	//  GP.UKWTSH_YMD DESC,
	// 	GP.SHOHIN_DIBNRI_KBN,
	// 	GP.SHOHIN_CHBNRI_KBN,
	// 	GP.SHOHIN_SHBNRI_KBN,
	// 	GP.TORIHIKI_NO,
	// 	GP.YKJ_YMD DESC,
	// 	GP.KESSAI_SEISAN_KINGAKU_KISNY DESC
	sort.SliceStable(infos, func(i, j int) bool {
		if infos[i].UkwtshYmd > infos[j].UkwtshYmd { // 降順
			return true
		} else if infos[i].UkwtshYmd == infos[j].UkwtshYmd {
			if infos[i].ShohinDibnriKbn < infos[j].ShohinDibnriKbn {
				return true
			} else if infos[i].ShohinDibnriKbn == infos[j].ShohinDibnriKbn {
				if infos[i].ShohinChbnriKbn < infos[j].ShohinChbnriKbn {
					return true
				} else if infos[i].ShohinChbnriKbn == infos[j].ShohinChbnriKbn {
					if infos[i].ShohinShbnriKbn < infos[j].ShohinShbnriKbn {
						return true
					} else if infos[i].ShohinShbnriKbn == infos[j].ShohinShbnriKbn {
						if infos[i].TorihikiNo < infos[j].TorihikiNo {
							return true
						} else if infos[i].TorihikiNo == infos[j].TorihikiNo {
							if infos[i].YkjYmd > infos[j].YkjYmd { // 降順
								return true
							} else if infos[i].YkjYmd == infos[j].YkjYmd {
								if infos[i].KessaiSeisanKingakuKisny.GreaterThan(infos[j].KessaiSeisanKingakuKisny) { // 降順
									return true
								}
							}
						}
					}
				}
			}
		}
		return false
	})

	return infos
}

/*GetAllocatedInOutSourceInfos 基準となる入出金元情報管理を活用して引当済み処理で活用する入出金元情報管理（プラス）を取得する。
 */
func (m *PlusFCSInOutSourceInfosMap) GetAllocatedInOutSourceInfos(base *InOutSourceInfo, batchDate string) (infos []*InOutSourceInfo, err error) {
	key := PlusFCSInOutSourceInfoKey{OriginalKozaNo: base.OriginalKozaNo, KessaiTsukaCd: base.KessaiTsukaCd}
	candidates, ok := (*m)[key]
	if !ok {
		return nil, nil
	}

	// ネストを回避するために条件に該当しない場合はスキップする
	for _, candidate := range candidates {
		// AND GP.UKWTSH_YMD <= @GM_ukwtshYmd
		if !(candidate.UkwtshYmd <= base.UkwtshYmd) {
			continue
		}

		// AND GP.UKWTSH_YMD >= CAST(CONVERT(varchar,DATEADD(month,-1,CONVERT(date,@i_batchDate)),112) AS DECIMAL(8, 0))
		oneMonthAgo, err := common.MinusOneMonth(batchDate)
		if err != nil {
			return nil, err
		}
		if !(candidate.UkwtshYmd >= oneMonthAgo) {
			continue
		}

		// AND GP.NYUSHUKKIN_KRAT_KBN IN ('1', '2')
		if !((candidate.NyushukkinKratKbn == "1") || (candidate.NyushukkinKratKbn == "2")) {
			continue
		}

		if !(candidate.SkjFlg == 0) {
			continue
		}

		infos = append(infos, candidate)
	}

	// ネストが浅い方が優先度高い
	// ORDER BY
	//  GP.UKWTSH_YMD,
	// 	GP.SHOHIN_DIBNRI_KBN,
	// 	GP.SHOHIN_CHBNRI_KBN,
	// 	GP.SHOHIN_SHBNRI_KBN,
	// 	GP.TORIHIKI_NO,
	// 	GP.YKJ_YMD,
	// 	GP.KESSAI_SEISAN_KINGAKU_KISNY DESC
	sort.SliceStable(infos, func(i, j int) bool {
		if infos[i].UkwtshYmd < infos[j].UkwtshYmd {
			return true
		} else if infos[i].UkwtshYmd == infos[j].UkwtshYmd {
			if infos[i].ShohinDibnriKbn < infos[j].ShohinDibnriKbn {
				return true
			} else if infos[i].ShohinDibnriKbn == infos[j].ShohinDibnriKbn {
				if infos[i].ShohinChbnriKbn < infos[j].ShohinChbnriKbn {
					return true
				} else if infos[i].ShohinChbnriKbn == infos[j].ShohinChbnriKbn {
					if infos[i].ShohinShbnriKbn < infos[j].ShohinShbnriKbn {
						return true
					} else if infos[i].ShohinShbnriKbn == infos[j].ShohinShbnriKbn {
						if infos[i].TorihikiNo < infos[j].TorihikiNo {
							return true
						} else if infos[i].TorihikiNo == infos[j].TorihikiNo {
							if infos[i].YkjYmd < infos[j].YkjYmd {
								return true
							} else if infos[i].YkjYmd == infos[j].YkjYmd {
								if infos[i].KessaiSeisanKingakuKisny.GreaterThan(infos[j].KessaiSeisanKingakuKisny) { // 降順
									return true
								}
							}
						}
					}
				}
			}
		}
		return false
	})

	return infos, nil
}
