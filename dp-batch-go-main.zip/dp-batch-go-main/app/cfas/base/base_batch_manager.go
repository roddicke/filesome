package base

import (
	"strings"

	"dp-batch-go/app/cfas/model"
	"dp-batch-go/app/cfas/repository"
)

type BatchManager struct {
	FilePointer repository.ICSVFileRepository
}

func (b *BatchManager) ReadSalesTrendStats(path string) (
	headers []string, salesTrendStats []*model.SalesTrendStat, err error) {
	records, err := b.FilePointer.Read(path, false)
	if err != nil {
		return nil, nil, err
	}
	// ヘッダーすらない場合は何もしない
	if len(records) < 1 {
		return nil, nil, nil
	}

	headers = records[0]
	for _, r := range records[1:] {
		stat, err := model.NewSalesTrendStat(r)
		if err != nil {
			return nil, nil, err
		}
		salesTrendStats = append(salesTrendStats, stat)
	}
	return headers, salesTrendStats, nil
}

func (b *BatchManager) WriteSalesTrendStats(path string, headers []string, stats []*model.SalesTrendStat) error {
	var s [][]string
	s = append(s, headers)
	for _, stat := range stats {
		s = append(s, stat.ToSlice())
	}
	s = b.uniqueRows(s)
	return b.FilePointer.Write(path, s)
}

func (b *BatchManager) ReadInOutSourceInfos(path string) (
	headers []string, inOutSourceInfos []*model.InOutSourceInfo, err error) {
	records, err := b.FilePointer.Read(path, false)
	if err != nil {
		return nil, nil, err
	}
	// ヘッダーすらない場合は何もしない
	if len(records) < 1 {
		return nil, nil, nil
	}

	headers = records[0]
	for _, r := range records[1:] {
		info, err := model.NewInOutSourceInfo(r)
		if err != nil {
			return nil, nil, err
		}
		inOutSourceInfos = append(inOutSourceInfos, info)
	}
	return headers, inOutSourceInfos, nil
}

func (b *BatchManager) WriteInOutSourceInfos(path string, headers []string, infos []*model.InOutSourceInfo) error {
	var s [][]string
	s = append(s, headers)
	for _, info := range infos {
		s = append(s, info.ToSlice())
	}
	s = b.uniqueRows(s)
	return b.FilePointer.Write(path, s)
}

// 現行の外決処理では一部にまったく同じデータを複数回出力する区分があるのでユニークして取り除く
func (b *BatchManager) uniqueRows(rows [][]string) (outs [][]string) {
	m := make(map[string]bool)
	for _, row := range rows {
		// データ検出のキーに要素を連結させたものを使う
		// スライスのままだとポインタがキーになって一致しなくなるため
		key := strings.Join(row, "")
		_, ok := m[key]
		if !ok {
			outs = append(outs, row)
			m[key] = true
		}
	}
	return outs
}
