package fcs

import (
	"fmt"
	"os"
	"sort"
	"testing"
	"time"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"

	"dp-batch-go/app/cfas/model"
	"dp-batch-go/app/cfas/repository"
)

func TestBatchManager_MainLoop(t *testing.T) {
	type args struct {
		batchDate string
		filePaths []string
	}
	type wants struct {
		inOutSourcePath     string
		SalesTrendStatsPath string
	}
	batchTime := "20160329"
	testDate := time.Now()
	tests := []struct {
		name    string
		args    args
		wants   wants
		wantErr bool
	}{
		{name: "UT-001", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-001/UT-001_input_CM2CF036_minus.csv",
			"testdata/UT-001/UT-001_input_CM2CF036_plus.csv",
			"testdata/UT-001/UT-001_input_CM2CF038.csv",
			"testdata/UT-001/UT-001_actual_output_CM2CF036.csv",
			"testdata/UT-001/UT-001_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-001/UT-001_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-001/UT-001_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-002", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-002/UT-002_input_CM2CF036_minus.csv",
			"testdata/UT-002/UT-002_input_CM2CF036_plus.csv",
			"testdata/UT-002/UT-002_input_CM2CF038.csv",
			"testdata/UT-002/UT-002_actual_output_CM2CF036.csv",
			"testdata/UT-002/UT-002_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-002/UT-002_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-002/UT-002_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-003", args: args{batchDate: "20160430", filePaths: []string{
			"testdata/UT-003/UT-003_input_CM2CF036_minus.csv",
			"testdata/UT-003/UT-003_input_CM2CF036_plus.csv",
			"testdata/UT-003/UT-003_input_CM2CF038.csv",
			"testdata/UT-003/UT-003_actual_output_CM2CF036.csv",
			"testdata/UT-003/UT-003_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-003/UT-003_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-003/UT-003_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-004", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-004/UT-004_input_CM2CF036_minus.csv",
			"testdata/UT-004/UT-004_input_CM2CF036_plus.csv",
			"testdata/UT-004/UT-004_input_CM2CF038.csv",
			"testdata/UT-004/UT-004_actual_output_CM2CF036.csv",
			"testdata/UT-004/UT-004_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-004/UT-004_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-004/UT-004_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-005", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-005/UT-005_input_CM2CF036_minus.csv",
			"testdata/UT-005/UT-005_input_CM2CF036_plus.csv",
			"testdata/UT-005/UT-005_input_CM2CF038.csv",
			"testdata/UT-005/UT-005_actual_output_CM2CF036.csv",
			"testdata/UT-005/UT-005_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-005/UT-005_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-005/UT-005_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-006", args: args{batchDate: "20160430", filePaths: []string{
			"testdata/UT-006/UT-006_input_CM2CF036_minus.csv",
			"testdata/UT-006/UT-006_input_CM2CF036_plus.csv",
			"testdata/UT-006/UT-006_input_CM2CF038.csv",
			"testdata/UT-006/UT-006_actual_output_CM2CF036.csv",
			"testdata/UT-006/UT-006_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-006/UT-006_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-006/UT-006_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-007", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-007/UT-007_input_CM2CF036_minus.csv",
			"testdata/UT-007/UT-007_input_CM2CF036_plus.csv",
			"testdata/UT-007/UT-007_input_CM2CF038.csv",
			"testdata/UT-007/UT-007_actual_output_CM2CF036.csv",
			"testdata/UT-007/UT-007_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-007/UT-007_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-007/UT-007_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-008", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-008/UT-008_input_CM2CF036_minus.csv",
			"testdata/UT-008/UT-008_input_CM2CF036_plus.csv",
			"testdata/UT-008/UT-008_input_CM2CF038.csv",
			"testdata/UT-008/UT-008_actual_output_CM2CF036.csv",
			"testdata/UT-008/UT-008_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-008/UT-008_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-008/UT-008_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-009", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-009/UT-009_input_CM2CF036_minus.csv",
			"testdata/UT-009/UT-009_input_CM2CF036_plus.csv",
			"testdata/UT-009/UT-009_input_CM2CF038.csv",
			"testdata/UT-009/UT-009_actual_output_CM2CF036.csv",
			"testdata/UT-009/UT-009_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-009/UT-009_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-009/UT-009_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-010", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-010/UT-010_input_CM2CF036_minus.csv",
			"testdata/UT-010/UT-010_input_CM2CF036_plus.csv",
			"testdata/UT-010/UT-010_input_CM2CF038.csv",
			"testdata/UT-010/UT-010_actual_output_CM2CF036.csv",
			"testdata/UT-010/UT-010_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-010/UT-010_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-010/UT-010_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-011", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-011/UT-011_input_CM2CF036_minus.csv",
			"testdata/UT-011/UT-011_input_CM2CF036_plus.csv",
			"testdata/UT-011/UT-011_input_CM2CF038.csv",
			"testdata/UT-011/UT-011_actual_output_CM2CF036.csv",
			"testdata/UT-011/UT-011_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-011/UT-011_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-011/UT-011_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-012", args: args{batchDate: "20160430", filePaths: []string{
			"testdata/UT-012/UT-012_input_CM2CF036_minus.csv",
			"testdata/UT-012/UT-012_input_CM2CF036_plus.csv",
			"testdata/UT-012/UT-012_input_CM2CF038.csv",
			"testdata/UT-012/UT-012_actual_output_CM2CF036.csv",
			"testdata/UT-012/UT-012_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-012/UT-012_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-012/UT-012_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-013", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-013/UT-013_input_CM2CF036_minus.csv",
			"testdata/UT-013/UT-013_input_CM2CF036_plus.csv",
			"testdata/UT-013/UT-013_input_CM2CF038.csv",
			"testdata/UT-013/UT-013_actual_output_CM2CF036.csv",
			"testdata/UT-013/UT-013_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-013/UT-013_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-013/UT-013_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-014", args: args{batchDate: "20220430", filePaths: []string{
			"testdata/UT-014/UT-014_input_CM2CF036_minus.csv",
			"testdata/UT-014/UT-014_input_CM2CF036_plus.csv",
			"testdata/UT-014/UT-014_input_CM2CF038.csv",
			"testdata/UT-014/UT-014_actual_output_CM2CF036.csv",
			"testdata/UT-014/UT-014_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-014/UT-014_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-014/UT-014_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-015", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-015/UT-015_input_CM2CF036_minus.csv",
			"testdata/UT-015/UT-015_input_CM2CF036_plus.csv",
			"testdata/UT-015/UT-015_input_CM2CF038.csv",
			"testdata/UT-015/UT-015_actual_output_CM2CF036.csv",
			"testdata/UT-015/UT-015_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-015/UT-015_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-015/UT-015_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-016", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-016/UT-016_input_CM2CF036_minus.csv",
			"testdata/UT-016/UT-016_input_CM2CF036_plus.csv",
			"testdata/UT-016/UT-016_input_CM2CF038.csv",
			"testdata/UT-016/UT-016_actual_output_CM2CF036.csv",
			"testdata/UT-016/UT-016_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-016/UT-016_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-016/UT-016_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-017", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-017/UT-017_input_CM2CF036_minus.csv",
			"testdata/UT-017/UT-017_input_CM2CF036_plus.csv",
			"testdata/UT-017/UT-017_input_CM2CF038.csv",
			"testdata/UT-017/UT-017_actual_output_CM2CF036.csv",
			"testdata/UT-017/UT-017_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-017/UT-017_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-017/UT-017_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-018", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-018/UT-018_input_CM2CF036_minus.csv",
			"testdata/UT-018/UT-018_input_CM2CF036_plus.csv",
			"testdata/UT-018/UT-018_input_CM2CF038.csv",
			"testdata/UT-018/UT-018_actual_output_CM2CF036.csv",
			"testdata/UT-018/UT-018_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-018/UT-018_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-018/UT-018_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-019", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-019/UT-019_input_CM2CF036_minus.csv",
			"testdata/UT-019/UT-019_input_CM2CF036_plus.csv",
			"testdata/UT-019/UT-019_input_CM2CF038.csv",
			"testdata/UT-019/UT-019_actual_output_CM2CF036.csv",
			"testdata/UT-019/UT-019_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-019/UT-019_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-019/UT-019_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-020", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-020/UT-020_input_CM2CF036_minus.csv",
			"testdata/UT-020/UT-020_input_CM2CF036_plus.csv",
			"testdata/UT-020/UT-020_input_CM2CF038.csv",
			"testdata/UT-020/UT-020_actual_output_CM2CF036.csv",
			"testdata/UT-020/UT-020_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-020/UT-020_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-020/UT-020_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-021", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-021/UT-021_input_CM2CF036_minus.csv",
			"testdata/UT-021/UT-021_input_CM2CF036_plus.csv",
			"testdata/UT-021/UT-021_input_CM2CF038.csv",
			"testdata/UT-021/UT-021_actual_output_CM2CF036.csv",
			"testdata/UT-021/UT-021_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-021/UT-021_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-021/UT-021_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-022", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-022/UT-022_input_CM2CF036_minus.csv",
			"testdata/UT-022/UT-022_input_CM2CF036_plus.csv",
			"testdata/UT-022/UT-022_input_CM2CF038.csv",
			"testdata/UT-022/UT-022_actual_output_CM2CF036.csv",
			"testdata/UT-022/UT-022_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-022/UT-022_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-022/UT-022_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-023", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-023/UT-023_input_CM2CF036_minus.csv",
			"testdata/UT-023/UT-023_input_CM2CF036_plus.csv",
			"testdata/UT-023/UT-023_input_CM2CF038.csv",
			"testdata/UT-023/UT-023_actual_output_CM2CF036.csv",
			"testdata/UT-023/UT-023_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-023/UT-023_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-023/UT-023_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-024", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-024/UT-024_input_CM2CF036_minus.csv",
			"testdata/UT-024/UT-024_input_CM2CF036_plus.csv",
			"testdata/UT-024/UT-024_input_CM2CF038.csv",
			"testdata/UT-024/UT-024_actual_output_CM2CF036.csv",
			"testdata/UT-024/UT-024_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-024/UT-024_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-024/UT-024_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-025", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-025/UT-025_input_CM2CF036_minus.csv",
			"testdata/UT-025/UT-025_input_CM2CF036_plus.csv",
			"testdata/UT-025/UT-025_input_CM2CF038.csv",
			"testdata/UT-025/UT-025_actual_output_CM2CF036.csv",
			"testdata/UT-025/UT-025_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-025/UT-025_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-025/UT-025_output_CM2CF038.csv",
			},
			wantErr: false},
		{name: "UT-026", args: args{batchDate: batchTime, filePaths: []string{
			"testdata/UT-026/UT-026_input_CM2CF036_minus.csv",
			"testdata/UT-026/UT-026_input_CM2CF036_plus.csv",
			"testdata/UT-026/UT-026_input_CM2CF038.csv",
			"testdata/UT-026/UT-026_actual_output_CM2CF036.csv",
			"testdata/UT-026/UT-026_actual_output_CM2CF038.csv",
		}},
			wants: wants{
				inOutSourcePath:     "testdata/UT-026/UT-026_output_CM2CF036.csv",
				SalesTrendStatsPath: "testdata/UT-026/UT-026_output_CM2CF038.csv",
			},
			wantErr: false},
	}

	f := repository.NewLocalCsvFileRepository()
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			b := NewBatchManager(f)
			if err := b.Execute(tt.args.batchDate, tt.args.filePaths); (err != nil) != tt.wantErr {
				t.Errorf("Execute() error = %v, wantErr %v", err, tt.wantErr)
			}

			err := compareInOutSources(tt.args.batchDate, testDate, tt.args.filePaths[3], tt.wants.inOutSourcePath)
			if err != nil {
				t.Error(err)
			}

			err = compareSalesTrendStats(tt.args.batchDate, testDate, tt.args.filePaths[4], tt.wants.SalesTrendStatsPath)
			if err != nil {
				t.Error(err)
			}

			//since actual results are not need, delete them.
			err = os.RemoveAll(tt.args.filePaths[3])
			if err != nil {
				t.Fatal(err)
			}
			err = os.RemoveAll(tt.args.filePaths[4])
			if err != nil {
				t.Fatal(err)
			}

		})
	}
}

func compareInOutSources(batchDate string, testDate time.Time, gotPath, wantPath string) error {
	repo := repository.NewLocalCsvFileRepository()
	rows, err := repo.Read(gotPath, true)
	if err != nil {
		return err
	}
	gots := make([]*model.InOutSourceInfo, 0)
	for _, row := range rows {
		d, err := model.NewInOutSourceInfo(row)
		if err != nil {
			return err
		}
		gots = append(gots, d)
	}
	sort.Slice(gots, func(i, j int) bool { return gots[i].RecordSeqNo < gots[j].RecordSeqNo })

	rows, err = repo.Read(wantPath, true)
	if err != nil {
		return err
	}
	wants := make([]*model.InOutSourceInfo, 0)
	for _, row := range rows {
		d, err := model.NewInOutSourceInfo(row)
		if err != nil {
			return err
		}
		wants = append(wants, d)
	}
	sort.Slice(wants, func(i, j int) bool { return wants[i].RecordSeqNo < wants[j].RecordSeqNo })

	if len(gots) != len(wants) {
		return fmt.Errorf("入出金元情報管理の実際の出力と予想の出力の行の長さが異なります: got %d, want %d",
			len(gots), len(wants))
	}

	for i := range gots {
		// since below values are program timestamp and batch time, cannot validate comparing wanted output.
		o := cmpopts.IgnoreFields(model.InOutSourceInfo{}, "RecordKshnYmd", "SystemYmd", "SystemHms")
		if diff := cmp.Diff(gots[i], wants[i], o); diff != "" {
			return fmt.Errorf("row: %d\n%s", i, diff)
		}
		if gots[i].RecordKshnYmd != batchDate {
			return fmt.Errorf("InOutSourceInfo.RecordKshnYmd != batchDate; rowID %d, got %s, want %s",
				i, gots[i].RecordKshnYmd, batchDate)
		}

		// 20060102150405 = YYYYMMDDhhmmss
		got, err := time.Parse("20060102150405", gots[i].SystemYmd+gots[i].SystemHms)
		if err != nil {
			return err
		}
		if got.Before(testDate) {
			return fmt.Errorf("SystemYmd SystemHms < テスト実施日時なので、SystemYmd SystemHmsが更新されてません。")
		}
	}
	return nil
}

func compareSalesTrendStats(batchDate string, testDate time.Time, gotPath, wantPath string) error {
	repo := repository.NewLocalCsvFileRepository()
	rows, err := repo.Read(gotPath, true)
	if err != nil {
		return err
	}
	gots := make([]*model.SalesTrendStat, 0)
	for _, row := range rows {
		d, err := model.NewSalesTrendStat(row)
		if err != nil {
			return err
		}
		gots = append(gots, d)
	}
	sort.Slice(gots, func(i, j int) bool {
		if gots[i].TorihikiId < gots[j].TorihikiId {
			return true
		} else if gots[i].TorihikiId == gots[j].TorihikiId {
			if gots[i].KirSeqNo < gots[j].KirSeqNo {
				return true
			}
		}
		return false
	})

	rows, err = repo.Read(wantPath, true)
	if err != nil {
		return err
	}
	wants := make([]*model.SalesTrendStat, 0)
	for _, row := range rows {
		d, err := model.NewSalesTrendStat(row)
		if err != nil {
			return err
		}
		wants = append(wants, d)
	}
	sort.Slice(wants, func(i, j int) bool {
		if wants[i].TorihikiId < wants[j].TorihikiId {
			return true
		} else if wants[i].TorihikiId == wants[j].TorihikiId {
			if wants[i].KirSeqNo < wants[j].KirSeqNo {
				return true
			}
		}
		return false
	})

	if len(gots) != len(wants) {
		return fmt.Errorf("販売動向統計の実際の出力と予想の出力の行の長さが異なります: got %d, want %d",
			len(gots), len(wants))
	}

	for i := range gots {
		// since below values are program timestamp and batch time, cannot validate comparing expected output.
		o := cmpopts.IgnoreFields(model.SalesTrendStat{},
			"KirSttiYmd", "KirKijunYmd", "RecordSksiYmd", "RecordKoshinYmd", "ShoriTaishoYmd", "SystemYmd", "SystemHms")
		if diff := cmp.Diff(gots[i], wants[i], o); diff != "" {
			return fmt.Errorf("row: %d\n%s", i, diff)
		}
		if gots[i].KirSttiYmd != batchDate {
			return fmt.Errorf("SalesTrendStat.KirSttiYmd != batchDate; rowID %d, got %s, want %s",
				i, gots[i].KirSttiYmd, batchDate)
		}
		if !(gots[i].KirKijunYmd == batchDate || gots[i].KirKijunYmd == wants[i].KirKijunYmd) {
			return fmt.Errorf("SalesTrendStat.KirKijunYmd != batchDate or != want.KirKijunYmd; "+
				"rowID %d, got %s, want:batchDate %s, want:KirKijunYmd %s",
				i, gots[i].KirKijunYmd, batchDate, wants[i].KirKijunYmd)
		}
		if gots[i].RecordSksiYmd != batchDate {
			return fmt.Errorf("SalesTrendStat.RecordSksiYmd != batchDate; rowID %d, got %s, want %s",
				i, gots[i].RecordSksiYmd, batchDate)
		}
		if gots[i].RecordKoshinYmd != batchDate {
			return fmt.Errorf("SalesTrendStat.RecordKoshinYmd != batchDate; rowID %d, got %s, want %s",
				i, gots[i].RecordKoshinYmd, batchDate)
		}

		if gots[i].ShoriTaishoYmd != testDate.Format("20060102") && gots[i].ShoriTaishoYmd != "-1" { // ある条件ではここのテストができないので、テストデータに-1を入れてスキップするようにする
			return fmt.Errorf("SalesTrendStat.ShoriTaishoYmd != test date (YYYYMMDD); rowID %d, got %s, want %s",
				i, gots[i].ShoriTaishoYmd, testDate.Format("20060102"))
		}

		// 20060102150405 = YYYYMMDDhhmmss
		got, err := time.Parse("20060102150405", gots[i].SystemYmd+gots[i].SystemHms)
		if err != nil {
			return err
		}
		if got.Before(testDate) {
			return fmt.Errorf("SystemYmd SystemHms < テスト実施日時なので、SystemYmd SystemHmsが更新されてません。")
		}
	}
	return nil
}
