package fcs

import (
	"fmt"
	"sort"
	"time"

	"github.com/shopspring/decimal"

	"dp-batch-go/app/cfas/base"
	"dp-batch-go/app/cfas/common"
	"dp-batch-go/app/cfas/model"
	"dp-batch-go/app/cfas/repository"
	"dp-batch-go/app/logger"
)

// ForeignCurrencyMMF 外貨建てMMF商品物理名
const ForeignCurrencyMMF = "139201"

type BatchManager struct {
	base                    *base.BatchManager
	systemDate              string
	systemTime              string
	batchDate               string
	salesTrendStatsMap      model.SalesTrendStatsMap
	plusInOutSourceInfosMap model.PlusFCSInOutSourceInfosMap
	outputInOutSourceInfos  []*model.InOutSourceInfo
	outputSalesTrendStats   []*model.SalesTrendStat
}

func NewBatchManager(fp repository.ICSVFileRepository) *BatchManager {
	now := time.Now()
	return &BatchManager{
		base:       &base.BatchManager{FilePointer: fp},
		systemDate: now.Format("20060102"),
		systemTime: now.Format("150405"),
	}
}

/*Execute
batchData バッチ実行日付
filePaths {
	入力用　入出金元情報管理（マイナス）ファイルパス,
	入力用　入出金元情報管理（プラス）ファイルパス,
	入力用　販売動向統計ファイルパス,
	出力用　入出金元情報管理ファイルパス,
	出力用　販売動向統計ファイルパス,
}
*/
func (b *BatchManager) Execute(batchDate string, filePaths []string) error {
	b.batchDate = batchDate

	//販売動向統計データファイルリード
	salesTrendStatHeaders, salesTrendStats, err := b.base.ReadSalesTrendStats(filePaths[2])
	if err != nil {
		return fmt.Errorf("販売動向統計のファイルを読み取りできませんでした; %v", err)
	}
	b.salesTrendStatsMap = model.NewSalesTrendStatsMap(salesTrendStats)

	//マイナスデータファイルリード
	inOutSourceHeaders, minusInOutSourceInfos, err := b.base.ReadInOutSourceInfos(filePaths[0])
	if err != nil {
		return fmt.Errorf("入出金元情報管理（マイナス）のファイルを読み取りできませんでした; %v", err)
	}

	//プラスデータファイルリード
	_, infos, err := b.base.ReadInOutSourceInfos(filePaths[1])
	if err != nil {
		return fmt.Errorf("入出金元情報管理（プラス）のファイルを読み取りできませんでした; %v", err)
	}
	b.plusInOutSourceInfosMap = model.NewPlusFCSInOutSourceInfosMap(infos)

	//マイナスデータはフィルタされてソートされた状態でファイルが渡されるので、フィルタ・ソート不要
	for _, minusInOutSourceInfo := range minusInOutSourceInfos {
		if minusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF {
			/* 商品コード＝'139201'（外貨建MMF） */
			/* 2.1 経路分析(外決)外貨MMF分処理 */
			//EXEC dbo.RQAJDDTCF0680_1
			err = b.routeAnalysisForForeignCurrencyMMF(minusInOutSourceInfo)
			if err != nil {
				return fmt.Errorf("経路分析（外決）外貨MMF分処理でエラーが発生しました; %v", err)
			}
		} else {
			/* 2.2 経路分析(外決)外貨MMF以外分処理 */
			//EXEC dbo.RQAJDDTCF0680_2
			err = b.routeAnalysisForNonForeignCurrencyMMF(minusInOutSourceInfo)
			if err != nil {
				return fmt.Errorf("経路分析（外決）外貨MMF以外分処理でエラーが発生しました; %v", err)
			}
		}
	}

	err = b.base.WriteInOutSourceInfos(filePaths[3], inOutSourceHeaders, b.outputInOutSourceInfos)
	if err != nil {
		return fmt.Errorf("入出金元情報管理のファイルを書き出しできませんでした; %v", err)
	}
	err = b.base.WriteSalesTrendStats(filePaths[4], salesTrendStatHeaders, b.outputSalesTrendStats)
	if err != nil {
		return fmt.Errorf("販売動向統計のファイルを書き出しできませんでした; %v", err)
	}
	return nil
}

//routeAnalysisForForeignCurrencyMMF 経路分析（外決）外貨建てMMF用処理 RQAJDDTCF0680_1.sql
func (b *BatchManager) routeAnalysisForForeignCurrencyMMF(minusInOutSourceInfo *model.InOutSourceInfo) (err error) {
	isMinusInOutDeleted := false //入出金元情報管理[マイナス]を削除処理したか判定するフラグ
	minusInOutKessaiSeisanKingakuKisny := minusInOutSourceInfo.KessaiSeisanKingakuKisny
	plusInOutSourceInfos := b.plusInOutSourceInfosMap.GetInOutSourceInfos(minusInOutSourceInfo)
	for _, plusInOutSourceInfo := range plusInOutSourceInfos {
		/* 経路シーケンス番号取得処理（－） */
		//EXEC dbo.RQAJDDTCF0680_4
		key := model.SalesTrendStatKey{
			OriginalKozaNo: minusInOutSourceInfo.OriginalKozaNo,
			KijunYmd:       minusInOutSourceInfo.KijunYmd,
			ShtkmtDataKbn:  minusInOutSourceInfo.ShtkmtDataKbn,
			TorihikiNo:     minusInOutSourceInfo.TorihikiNo}
		routeMinusSalesTrendStat := b.salesTrendStatsMap.GetMaxSeqNOItem(key)
		if routeMinusSalesTrendStat == nil {
			logger.Log.Infof("入出金元情報管理[マイナス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
			// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
			routeMinusSalesTrendStat = &model.SalesTrendStat{}
		}

		/* 経路シーケンス番号取得処理（＋） */
		var routePlusSalesTrendStat *model.SalesTrendStat
		if plusInOutSourceInfo.ShohinDibnriKbn != "20" {
			/* 商品大分類区分≠'20'(MRF・預り金・普通預金) */
			//EXEC dbo.RQAJDDTCF0680_4
			key = model.SalesTrendStatKey{
				OriginalKozaNo: plusInOutSourceInfo.OriginalKozaNo,
				KijunYmd:       plusInOutSourceInfo.KijunYmd,
				ShtkmtDataKbn:  plusInOutSourceInfo.ShtkmtDataKbn,
				TorihikiNo:     plusInOutSourceInfo.TorihikiNo}
			routePlusSalesTrendStat = b.salesTrendStatsMap.GetMaxSeqNOItem(key)
			if routePlusSalesTrendStat == nil {
				logger.Log.Infof("入出金元情報管理[プラス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
				routePlusSalesTrendStat = &model.SalesTrendStat{}
			}
		} else {
			/* 上記以外 */
			routePlusSalesTrendStat = &model.SalesTrendStat{}
		}

		/* 仮充て区分 */
		var wkKratFlg string
		// IF (@GP_shohinCd = '139201' AND @GM_shohinCd <> '139201') OR (@GP_shohinCd <> '139201' AND @GM_shohinCd = '139201')
		// 判定実装が冗長だが現行実装を真似る
		if (plusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF && minusInOutSourceInfo.ShohinCd != ForeignCurrencyMMF) ||
			(plusInOutSourceInfo.ShohinCd != ForeignCurrencyMMF && minusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF) {
			wkKratFlg = "1"
		} else {
			wkKratFlg = ""
		}

		var (
			wkTorihikiID     string
			wkKirSeqNO       int64
			wkHmzkTorihikiID string
			wkHmzkKirSeqNO   int64
			wkKirKingaku     decimal.Decimal
		)
		if minusInOutKessaiSeisanKingakuKisny.GreaterThan(plusInOutSourceInfo.KessaiSeisanKingakuKisny) {
			/* マイナスデータ ＞ プラスデータ */
			/* 販売動向統計判定処理 */

			/* 経路．シーケンス番号等を設定 */
			wkTorihikiID = routeMinusSalesTrendStat.TorihikiId
			wkKirSeqNO = routeMinusSalesTrendStat.KirSeqNo + 1

			// 経路シーケンス（対応する販売動向統計）が取得できない場合は初期値をセットする
			if routePlusSalesTrendStat.IsFetched() {
				wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
			} else {
				wkHmzkTorihikiID = ""
				wkHmzkKirSeqNO = 0
			}
			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(minusInOutSourceInfo.HkSeisanKingakuOriginal,
				plusInOutSourceInfo.KessaiSeisanKingakuKisny,
				minusInOutSourceInfo.KessaiSeisanKingakuOriginal)
			//EXEC dbo.RQAJDDTCF0680_6
			// ポインタから実体に変換することでデータを複製して代入する
			routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
			inOutSourceInfoForGenerate := *plusInOutSourceInfo
			routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
			routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond := &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 販売動向統計判定処理 */
			/* 経路．シーケンス番号等を設定 */
			if !routeMinusSalesTrendStat.IsFetched() {
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				wkTorihikiID = ""
				wkKirSeqNO = 0
			}

			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(plusInOutSourceInfo.HkSeisanKingakuOriginal,
				plusInOutSourceInfo.KessaiSeisanKingakuKisny,
				plusInOutSourceInfo.KessaiSeisanKingakuOriginal)
			//EXEC dbo.RQAJDDTCF0680_6
			// ポインタから実体に変換することでデータを複製して代入する
			routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
			inOutSourceInfoForGenerate = *minusInOutSourceInfo
			routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond = &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 決済．精算金額（計算用）を計算 */
			minusInOutKessaiSeisanKingakuKisny = minusInOutKessaiSeisanKingakuKisny.Sub(
				plusInOutSourceInfo.KessaiSeisanKingakuKisny)

			if plusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF {
				/* 外貨MMF */
				//EXEC dbo.RQAJDDTCF0680_8
				plusInOutSourceInfo.SkjFlg = 1
			} else {
				/* 外貨MMF 以外*/
				//EXEC dbo.RQAJDDTCF0680_8
				plusInOutSourceInfo.KessaiSeisanKingakuGikMmf = plusInOutSourceInfo.KessaiSeisanKingakuGikMmf.Add(
					plusInOutSourceInfo.KessaiSeisanKingakuKisny)
				plusInOutSourceInfo.NyushukkinKratKbn = "2"
				plusInOutSourceInfo.KessaiSeisanKingakuKisny = decimal.Zero
			}
			plusInOutSourceInfo.RecordKshnYmd = b.batchDate
			plusInOutSourceInfo.SystemYmd = b.systemDate
			plusInOutSourceInfo.SystemHms = b.systemTime
			//RQAJDDTCF0680_8の共通部分を1箇所にまとめた
			b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)

		} else if minusInOutKessaiSeisanKingakuKisny.Equal(plusInOutSourceInfo.KessaiSeisanKingakuKisny) {
			/* マイナスデータ ＝ プラスデータ */
			/* 販売動向統計判定処理 */
			/* 経路．シーケンス番号等を設定 */
			wkTorihikiID = routeMinusSalesTrendStat.TorihikiId
			wkKirSeqNO = routeMinusSalesTrendStat.KirSeqNo + 1

			if routePlusSalesTrendStat.IsFetched() {
				wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
			} else {
				wkHmzkTorihikiID = ""
				wkHmzkKirSeqNO = 0
			}
			/* 経路金額 */
			kessaiSeisanKingakuCalc := common.CalcKeiroKingaku(minusInOutSourceInfo.HkSeisanKingakuOriginal,
				plusInOutSourceInfo.KessaiSeisanKingakuKisny,
				minusInOutSourceInfo.KessaiSeisanKingakuOriginal)

			//EXEC dbo.RQAJDDTCF0680_6
			// ポインタから実体に変換することでデータを複製して代入する
			routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
			inOutSourceInfoForGenerate := *plusInOutSourceInfo
			routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
			routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = kessaiSeisanKingakuCalc
			cond := &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 販売動向統計判定処理 */
			/* 経路．シーケンス番号等を設定 */
			if !routeMinusSalesTrendStat.IsFetched() {
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				wkTorihikiID = ""
				wkKirSeqNO = 0
			}
			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(plusInOutSourceInfo.HkSeisanKingakuOriginal,
				plusInOutSourceInfo.KessaiSeisanKingakuKisny,
				plusInOutSourceInfo.KessaiSeisanKingakuOriginal)
			//EXEC dbo.RQAJDDTCF0680_6
			routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
			inOutSourceInfoForGenerate = *minusInOutSourceInfo
			routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond = &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 入出金元情報管理更新処理 */
			//EXEC dbo.RQAJDDTCF0680_8
			minusInOutSourceInfo.SkjFlg = 1
			minusInOutSourceInfo.RecordKshnYmd = b.batchDate
			minusInOutSourceInfo.SystemYmd = b.systemDate
			minusInOutSourceInfo.SystemHms = b.systemTime
			b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, minusInOutSourceInfo)
			isMinusInOutDeleted = true // SkjFlgを立てたの削除済みに変更

			if plusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF {
				/* 外貨MMF */
				//EXEC dbo.RQAJDDTCF0680_8
				plusInOutSourceInfo.SkjFlg = 1
			} else {
				/* 外貨MMF 以外 */
				//EXEC dbo.RQAJDDTCF0680_8
				plusInOutSourceInfo.KessaiSeisanKingakuGikMmf = plusInOutSourceInfo.KessaiSeisanKingakuGikMmf.Add(
					plusInOutSourceInfo.KessaiSeisanKingakuKisny)
				plusInOutSourceInfo.NyushukkinKratKbn = "2"
				plusInOutSourceInfo.KessaiSeisanKingakuKisny = decimal.Zero
			}
			plusInOutSourceInfo.RecordKshnYmd = b.batchDate
			plusInOutSourceInfo.SystemYmd = b.systemDate
			plusInOutSourceInfo.SystemHms = b.systemTime
			//RQAJDDTCF0680_8の共通部分を1箇所にまとめた
			b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)
			/* ループエンド */
			break
		} else { //@GM_kessaiSeisanKingakuKisny < @GP_kessaiSeisanKingakuKisny
			/* 販売動向統計判定処理 */
			/* 経路．シーケンス番号等を設定 */
			wkTorihikiID = routeMinusSalesTrendStat.TorihikiId
			wkKirSeqNO = routeMinusSalesTrendStat.KirSeqNo + 1

			if routePlusSalesTrendStat.IsFetched() {
				wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
			} else {
				wkHmzkTorihikiID = ""
				wkHmzkKirSeqNO = 0
			}
			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(minusInOutSourceInfo.HkSeisanKingakuOriginal,
				minusInOutKessaiSeisanKingakuKisny,
				minusInOutSourceInfo.KessaiSeisanKingakuOriginal)
			//EXEC dbo.RQAJDDTCF0680_6
			// ポインタから実体に変換することでデータを複製して代入する
			routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
			inOutSourceInfoForGenerate := *plusInOutSourceInfo
			routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
			routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond := &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 販売動向統計判定処理 */
			/* 経路．シーケンス番号等を設定 */
			if !routeMinusSalesTrendStat.IsFetched() {
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				wkTorihikiID = ""
				wkKirSeqNO = 0
			}

			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(
				plusInOutSourceInfo.HkSeisanKingakuOriginal,
				minusInOutKessaiSeisanKingakuKisny,
				plusInOutSourceInfo.KessaiSeisanKingakuOriginal)

			//EXEC dbo.RQAJDDTCF0680_6
			routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
			inOutSourceInfoForGenerate = *minusInOutSourceInfo
			routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond = &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 入出金元情報管理更新処理 */
			//EXEC dbo.RQAJDDTCF0680_8
			minusInOutSourceInfo.SkjFlg = 1
			minusInOutSourceInfo.RecordKshnYmd = b.batchDate
			minusInOutSourceInfo.SystemYmd = b.systemDate
			minusInOutSourceInfo.SystemHms = b.systemTime
			b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, minusInOutSourceInfo)
			isMinusInOutDeleted = true // SkjFlgを立てたの削除済みに変更

			if plusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF {
				/* 外貨MMF */
				/* 入出金元情報管理更新処理 */
				//EXEC dbo.RQAJDDTCF0680_8
				plusInOutSourceInfo.KessaiSeisanKingakuKisny = plusInOutSourceInfo.KessaiSeisanKingakuKisny.Sub(
					minusInOutKessaiSeisanKingakuKisny)
			} else {
				/* 外国通貨MMF以外 */
				/* 入出金元情報管理更新処理 */
				//EXEC dbo.RQAJDDTCF0680_8
				//@GP_kessaiSeisanKingakuCalc = @GP_kessaiSeisanKingakuKisny - @GM_kessaiSeisanKingakuKisny;
				plusInOutSourceInfo.KessaiSeisanKingakuKisny = plusInOutSourceInfo.KessaiSeisanKingakuKisny.Sub(
					minusInOutKessaiSeisanKingakuKisny)
				//@GP_kessaiSeisanKingakuCalc2 = @GP_kessaiSeisanKingakuGikMmf + @GM_kessaiSeisanKingakuKisny
				plusInOutSourceInfo.KessaiSeisanKingakuGikMmf = plusInOutSourceInfo.KessaiSeisanKingakuGikMmf.Add(
					minusInOutKessaiSeisanKingakuKisny)
				plusInOutSourceInfo.NyushukkinKratKbn = "1"

			}
			plusInOutSourceInfo.RecordKshnYmd = b.batchDate
			plusInOutSourceInfo.SystemYmd = b.systemDate
			plusInOutSourceInfo.SystemHms = b.systemTime
			//RQAJDDTCF0680_8の共通部分を1箇所にまとめた
			b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)
			/* ループエンド */
			break
		}
	}

	/* 入出金元情報管理[マイナス]をまだ削除してない場合 */
	if !isMinusInOutDeleted {
		/* 経路シーケンス番号取得処理（－） */
		//EXEC dbo.RQAJDDTCF0680_4
		key := model.SalesTrendStatKey{
			OriginalKozaNo: minusInOutSourceInfo.OriginalKozaNo,
			KijunYmd:       minusInOutSourceInfo.KijunYmd,
			ShtkmtDataKbn:  minusInOutSourceInfo.ShtkmtDataKbn,
			TorihikiNo:     minusInOutSourceInfo.TorihikiNo}
		routeMinusSalesTrendStat := b.salesTrendStatsMap.GetMaxSeqNOItem(key)
		if routeMinusSalesTrendStat == nil {
			logger.Log.Infof("入出金元情報管理[マイナス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
			routeMinusSalesTrendStat = &model.SalesTrendStat{}
		}

		/* 経路金額 */
		wkKirKingaku := common.CalcKeiroKingaku(minusInOutSourceInfo.HkSeisanKingakuOriginal,
			minusInOutKessaiSeisanKingakuKisny,
			minusInOutSourceInfo.KessaiSeisanKingakuOriginal)

		wkKirSeqNO := routeMinusSalesTrendStat.KirSeqNo + 1

		//EXEC dbo.RQAJDDTCF0680_6
		// ポインタから実体に変換することでデータを複製して代入する
		routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
		routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
		routeSalesTrendStatForGenerate.KratFlg = ""
		inOutSourceInfoForGenerate := model.InitInOutSourceInfo()
		inOutSourceInfoForGenerate.KijunYmd = b.batchDate
		inOutSourceInfoForGenerate.TishkKbn = "1"
		inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
		inOutSourceInfoForGenerate.IfJshnYmd = minusInOutSourceInfo.IfJshnYmd
		// RQAJDDTCF0680_1では判定用受渡日は999999になっているが、0にすることで
		// 経路.経路区分, 経路.商品大分類区分, 経路.商品大分類区分, 経路.商品大分類区分の初期値を
		// generateSalesTrendStat 内で適切に設定することができるため、そのように実装する
		cond := &model.GenerateConditionForFCS{UkwtshYMD: 0}
		o, err := b.generateSalesTrendStat(cond, "", 0,
			&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
		if err != nil {
			return err
		}
		if o != nil {
			b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
			// 追加したもの含めて再度検索できるように追加する
			b.salesTrendStatsMap.Add(o)
		}

		/* 入出金元情報管理更新処理 */
		//EXEC dbo.RQAJDDTCF0680_8
		minusInOutSourceInfo.SkjFlg = 1
		minusInOutSourceInfo.RecordKshnYmd = b.batchDate
		minusInOutSourceInfo.SystemYmd = b.systemDate
		minusInOutSourceInfo.SystemHms = b.systemTime
		b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, minusInOutSourceInfo)
	}
	return nil
}

//routeAnalysisForNonForeignCurrencyMMF 経路分析（外決）外貨MMF以外分処理用処理 RQAJDDTCF0680_2.sql
func (b *BatchManager) routeAnalysisForNonForeignCurrencyMMF(minusInOutSourceInfo *model.InOutSourceInfo) (err error) {
	isMinusInOutDeleted := false //入出金元情報管理[マイナス]を削除処理したか判定するフラグ
	minusInOutKessaiSeisanKingakuKisny := minusInOutSourceInfo.KessaiSeisanKingakuKisny
	minusInOutKessaiSeisanKingakuGikMmf := minusInOutSourceInfo.KessaiSeisanKingakuGikMmf
	minusInOutNyushukkinKratKbn := minusInOutSourceInfo.NyushukkinKratKbn
	plusInOutSourceInfos := b.plusInOutSourceInfosMap.GetInOutSourceInfos(minusInOutSourceInfo)
	for _, plusInOutSourceInfo := range plusInOutSourceInfos {
		/* 経路シーケンス番号取得 */
		/* 経路シーケンス番号取得処理（－） */
		//EXEC dbo.RQAJDDTCF0680_5
		var routeMinusSalesTrendStat *model.SalesTrendStat
		if minusInOutSourceInfo.ShohinDibnriKbn == "20" {
			logger.Log.Infof("入出金元情報管理[マイナス]の商品大分類区分==20だったため、対応する販売動向統計の検索をスキップします; 入出金元情報管理[マイナス]=%+v",
				minusInOutSourceInfo)
			// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
			routeMinusSalesTrendStat = &model.SalesTrendStat{}
		} else {
			key := model.SalesTrendStatKey{
				OriginalKozaNo: minusInOutSourceInfo.OriginalKozaNo,
				KijunYmd:       minusInOutSourceInfo.KijunYmd,
				ShtkmtDataKbn:  minusInOutSourceInfo.ShtkmtDataKbn,
				TorihikiNo:     minusInOutSourceInfo.TorihikiNo}
			routeMinusSalesTrendStat = b.salesTrendStatsMap.GetMaxSeqNOItem(key)
			if routeMinusSalesTrendStat == nil {
				logger.Log.Infof("入出金元情報管理[マイナス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
				// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
				routeMinusSalesTrendStat = &model.SalesTrendStat{}
			}
		}

		/* 経路シーケンス番号取得処理（＋） */
		//EXEC dbo.RQAJDDTCF0680_5
		var routePlusSalesTrendStat *model.SalesTrendStat
		if plusInOutSourceInfo.ShohinDibnriKbn == "20" {
			logger.Log.Infof("入出金元情報管理[プラス]の商品大分類区分==20だったため、対応する販売動向統計の検索をスキップします; 入出金元情報管理[プラス]=%+v",
				plusInOutSourceInfo)
			// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
			routePlusSalesTrendStat = &model.SalesTrendStat{}
		} else {
			key := model.SalesTrendStatKey{
				OriginalKozaNo: plusInOutSourceInfo.OriginalKozaNo,
				KijunYmd:       plusInOutSourceInfo.KijunYmd,
				ShtkmtDataKbn:  plusInOutSourceInfo.ShtkmtDataKbn,
				TorihikiNo:     plusInOutSourceInfo.TorihikiNo}
			routePlusSalesTrendStat = b.salesTrendStatsMap.GetMaxSeqNOItem(key)
			if routePlusSalesTrendStat == nil {
				logger.Log.Infof("入出金元情報管理[プラス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
				// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
				routePlusSalesTrendStat = &model.SalesTrendStat{}
			}
		}

		/* 仮充て区分 */
		var wkKratFlg string
		// IF (@GP_shohinCd = '139201' AND @GM_shohinCd <> '139201') OR (@GP_shohinCd <> '139201' AND @GM_shohinCd = '139201')
		// 判定実装が冗長だが現行実装を真似る
		if (plusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF && minusInOutSourceInfo.ShohinCd != ForeignCurrencyMMF) ||
			(plusInOutSourceInfo.ShohinCd != ForeignCurrencyMMF && minusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF) {
			wkKratFlg = "1"
		} else {
			wkKratFlg = ""
		}

		var (
			wkTorihikiID     string
			wkKirSeqNO       int64
			wkHmzkTorihikiID string
			wkHmzkKirSeqNO   int64
			wkKirKingaku     decimal.Decimal
		)
		if minusInOutKessaiSeisanKingakuKisny.GreaterThan(plusInOutSourceInfo.KessaiSeisanKingakuKisny) {
			/* マイナスデータ ＞ プラスデータ */
			/* 販売動向統計登録処理 */
			/* 経路．シーケンス番号等を設定 */
			wkTorihikiID = routeMinusSalesTrendStat.TorihikiId
			wkKirSeqNO = routeMinusSalesTrendStat.KirSeqNo + 1
			if plusInOutSourceInfo.ShohinDibnriKbn != "20" && routePlusSalesTrendStat.IsFetched() {
				wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
			} else {
				wkHmzkTorihikiID = ""
				wkHmzkKirSeqNO = 0
			}

			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(minusInOutSourceInfo.HkSeisanKingakuOriginal,
				plusInOutSourceInfo.KessaiSeisanKingakuKisny,
				minusInOutSourceInfo.KessaiSeisanKingakuOriginal)
			//EXEC dbo.RQAJDDTCF0680_6
			routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
			inOutSourceInfoForGenerate := *plusInOutSourceInfo
			routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
			routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond := &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 販売動向統計登録処理 */
			/* 経路．シーケ ンス番号等を設定 */
			if !routeMinusSalesTrendStat.IsFetched() {
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				wkTorihikiID = ""
				wkKirSeqNO = 0
			}
			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(plusInOutSourceInfo.HkSeisanKingakuOriginal,
				plusInOutSourceInfo.KessaiSeisanKingakuKisny,
				plusInOutSourceInfo.KessaiSeisanKingakuOriginal)
			//EXEC dbo.RQAJDDTCF0680_6
			routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
			inOutSourceInfoForGenerate = *minusInOutSourceInfo
			routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond = &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 決済．精算金額（計算用）を計算 */
			minusInOutKessaiSeisanKingakuKisny = minusInOutKessaiSeisanKingakuKisny.Sub(
				plusInOutSourceInfo.KessaiSeisanKingakuKisny)

			if plusInOutSourceInfo.ShohinCd != ForeignCurrencyMMF {
				/* 外貨MMF以外 */
				if plusInOutSourceInfo.KessaiSeisanKingakuGikMmf.Equal(decimal.Zero) {
					/* プラスデータ．決済．精算金額（外貨MMF）＝0 */
					/* 入出金管理更新処理 */
					//EXEC dbo.RQAJDDTCF0680_8
					plusInOutSourceInfo.SkjFlg = 1
				} else {
					/* プラスデータ．決済．精算金額（外貨MMF）!= 0 */
					/* 入出金管理更新処理 */
					//EXEC dbo.RQAJDDTCF0680_8
					plusInOutSourceInfo.NyushukkinKratKbn = "2"
				}
				plusInOutSourceInfo.KessaiSeisanKingakuKisny = decimal.Zero
			} else {
				/* 外貨MMF */
				/* 決済．精算金額（外貨MMF）を計算 */
				minusInOutKessaiSeisanKingakuGikMmf = minusInOutKessaiSeisanKingakuGikMmf.Add(
					plusInOutSourceInfo.KessaiSeisanKingakuKisny)
				/* '1'(半仮充て)→入出金仮充て区分（－）*/
				minusInOutNyushukkinKratKbn = "1"

				/* 入出金管理更新処理 */
				//EXEC dbo.RQAJDDTCF0680_8
				plusInOutSourceInfo.SkjFlg = 1
			}
			plusInOutSourceInfo.RecordKshnYmd = b.batchDate
			plusInOutSourceInfo.SystemYmd = b.systemDate
			plusInOutSourceInfo.SystemHms = b.systemTime
			//RQAJDDTCF0680_8の共通部分を1箇所にまとめた
			b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)

		} else if minusInOutKessaiSeisanKingakuKisny.Equal(plusInOutSourceInfo.KessaiSeisanKingakuKisny) {
			/* マイナスデータ ＝ プラスデータ */
			/* 販売動向統計登録処理 */
			/* 経路．シーケンス番号等を設定 */
			wkTorihikiID = routeMinusSalesTrendStat.TorihikiId
			wkKirSeqNO = routeMinusSalesTrendStat.KirSeqNo + 1
			if plusInOutSourceInfo.ShohinDibnriKbn != "20" && routePlusSalesTrendStat.IsFetched() {
				wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
			} else {
				wkHmzkTorihikiID = ""
				wkHmzkKirSeqNO = 0
			}

			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(minusInOutSourceInfo.HkSeisanKingakuOriginal,
				plusInOutSourceInfo.KessaiSeisanKingakuKisny,
				minusInOutSourceInfo.KessaiSeisanKingakuOriginal)

			//EXEC dbo.RQAJDDTCF0680_6
			routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
			inOutSourceInfoForGenerate := *plusInOutSourceInfo
			routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
			routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond := &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 経路．シーケンス番号等を設定 */
			if !routeMinusSalesTrendStat.IsFetched() {
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				wkTorihikiID = ""
				wkKirSeqNO = 0
			}

			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(plusInOutSourceInfo.HkSeisanKingakuOriginal,
				minusInOutKessaiSeisanKingakuKisny,
				plusInOutSourceInfo.KessaiSeisanKingakuOriginal)
			//EXEC dbo.RQAJDDTCF0680_6
			routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
			inOutSourceInfoForGenerate = *minusInOutSourceInfo
			routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond = &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			if plusInOutSourceInfo.ShohinCd != ForeignCurrencyMMF {
				/* 外貨MMF以外 */
				if minusInOutKessaiSeisanKingakuGikMmf.Equal(decimal.Zero) {
					/* マイナスデータ．決済．精算金額（外貨MMF）＝0 */
					/* 入出金管理更新処理 */
					//EXEC dbo.RQAJDDTCF0680_8
					minusInOutSourceInfo.SkjFlg = 1
					minusInOutSourceInfo.KessaiSeisanKingakuKisny = decimal.Zero
					minusInOutSourceInfo.RecordKshnYmd = b.batchDate
					minusInOutSourceInfo.SystemYmd = b.systemDate
					minusInOutSourceInfo.SystemHms = b.systemTime
					b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, minusInOutSourceInfo)
				} else {
					/* 外貨MMF */
					/* ZERO→決済．精算金額（計算用） */
					minusInOutKessaiSeisanKingakuKisny = decimal.Zero
					minusInOutNyushukkinKratKbn = "2"
				}

				if plusInOutSourceInfo.KessaiSeisanKingakuGikMmf.Equal(decimal.Zero) {
					/* プラスデータ．決済．精算金額（外貨MMF）＝0 */
					/* 入出金管理更新処理 */
					//EXEC dbo.RQAJDDTCF0680_8
					plusInOutSourceInfo.SkjFlg = 1
				} else {
					/* プラスデータ．決済．精算金額（外貨MMF）≠ 0 */
					/* 入出金管理更新処理 */
					//EXEC dbo.RQAJDDTCF0680_8
					plusInOutSourceInfo.NyushukkinKratKbn = "2"
				}
				// dbo.RQAJDDTCF0680_8 を共通化
				plusInOutSourceInfo.KessaiSeisanKingakuKisny = decimal.Zero
				plusInOutSourceInfo.RecordKshnYmd = b.batchDate
				plusInOutSourceInfo.SystemYmd = b.systemDate
				plusInOutSourceInfo.SystemHms = b.systemTime
				b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)
			} else {
				/* 外貨MMF */
				/* 決済．精算金額（外貨MMF）を計算 */
				minusInOutKessaiSeisanKingakuGikMmf = minusInOutKessaiSeisanKingakuGikMmf.Add(
					minusInOutKessaiSeisanKingakuKisny)

				/* ZERO→決済．精算金額（計算用） */
				minusInOutKessaiSeisanKingakuKisny = decimal.Zero
				/* '2'(全仮充て)→入出金仮充て区分（－）*/
				minusInOutNyushukkinKratKbn = "2"

				/* 入出金管理更新処理 */
				//EXEC dbo.RQAJDDTCF0680_8
				plusInOutSourceInfo.SkjFlg = 1
				plusInOutSourceInfo.RecordKshnYmd = b.batchDate
				plusInOutSourceInfo.SystemYmd = b.systemDate
				plusInOutSourceInfo.SystemHms = b.systemTime
				b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)
			}
			isMinusInOutDeleted = true // SkjFlgを立てた、もしくは仮充てしたため削除済みに変更
			/* ループエンド */
			break
		} else { //minusInOutData.KessaiSeisanKingakuKisny < plusInOutSourceInfo.KessaiSeisanKingakuKisny
			/* 上記以外 */
			/* 販売動向統計登録処理 */
			/* 経路．シーケンス番号等を設定 */
			wkTorihikiID = routeMinusSalesTrendStat.TorihikiId
			wkKirSeqNO = routeMinusSalesTrendStat.KirSeqNo + 1

			if plusInOutSourceInfo.ShohinDibnriKbn != "20" && routePlusSalesTrendStat.IsFetched() {
				wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
			} else {
				wkHmzkTorihikiID = ""
				wkHmzkKirSeqNO = 0
			}

			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(minusInOutSourceInfo.HkSeisanKingakuOriginal,
				minusInOutKessaiSeisanKingakuKisny,
				minusInOutSourceInfo.KessaiSeisanKingakuOriginal)
			//EXEC dbo.RQAJDDTCF0680_6
			routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
			inOutSourceInfoForGenerate := *plusInOutSourceInfo
			routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
			routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond := &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 販売動向統計登録処理 */
			/* 経路．シーケンス番号等を設定 */
			if !routeMinusSalesTrendStat.IsFetched() {
				wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				wkTorihikiID = ""
				wkKirSeqNO = 0
			}

			/* 経路金額 */
			wkKirKingaku = common.CalcKeiroKingaku(plusInOutSourceInfo.HkSeisanKingakuOriginal,
				minusInOutKessaiSeisanKingakuKisny,
				plusInOutSourceInfo.KessaiSeisanKingakuOriginal)
			//EXEC dbo.RQAJDDTCF0680_6
			routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
			inOutSourceInfoForGenerate = *minusInOutSourceInfo
			routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
			routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
			inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
			cond = &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
			o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
				&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
			if err != nil {
				return err
			}
			if o != nil {
				b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
				// 追加したもの含めて再度検索できるように追加する
				b.salesTrendStatsMap.Add(o)
			}

			/* 入出金管理更新処理 */
			//EXEC dbo.RQAJDDTCF0680_8
			plusInOutSourceInfo.KessaiSeisanKingakuKisny = plusInOutSourceInfo.KessaiSeisanKingakuKisny.Sub(
				minusInOutKessaiSeisanKingakuKisny)
			plusInOutSourceInfo.RecordKshnYmd = b.batchDate
			plusInOutSourceInfo.SystemYmd = b.systemDate
			plusInOutSourceInfo.SystemHms = b.systemTime
			b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)

			if plusInOutSourceInfo.ShohinCd != ForeignCurrencyMMF {
				/* 外貨MMF以外 */
				if minusInOutKessaiSeisanKingakuGikMmf.Equal(decimal.Zero) {
					/* マイナスデータ．決済．精算金額（外貨MMF）＝0 */
					/* 入出金管理更新処理 */
					//EXEC dbo.RQAJDDTCF0680_8
					minusInOutSourceInfo.KessaiSeisanKingakuKisny = decimal.Zero
					minusInOutSourceInfo.SkjFlg = 1
					minusInOutSourceInfo.RecordKshnYmd = b.batchDate
					minusInOutSourceInfo.SystemYmd = b.systemDate
					minusInOutSourceInfo.SystemHms = b.systemTime
					b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, minusInOutSourceInfo)
				} else {
					/* 上記以外 */
					/* ZERO→決済．精算金額（計算用） */
					minusInOutKessaiSeisanKingakuKisny = decimal.Zero
					/* '2'(全仮充て)→入出金仮充て区分（－）*/
					minusInOutNyushukkinKratKbn = "2"
				}
			} else {
				/* 外貨MMF */
				/* 決済．精算金額（外貨MMF）を計算 */
				minusInOutKessaiSeisanKingakuGikMmf = minusInOutKessaiSeisanKingakuGikMmf.Add(
					minusInOutKessaiSeisanKingakuKisny)

				/* ZERO→決済．精算金額（計算用） */
				minusInOutKessaiSeisanKingakuKisny = decimal.Zero

				/* '2'(全仮充て)→入出金仮充て区分（－）*/
				minusInOutNyushukkinKratKbn = "2"
			}
			isMinusInOutDeleted = true // SkjFlgを立てた、もしくは仮充てしたため削除済みに変更
			/* ループエンド */
			break
		}
	}

	/* 入出金元情報管理[マイナス]をまだ削除してない場合 */
	if !isMinusInOutDeleted {
		/* 経路シーケンス番号取得 */
		/* 経路シーケンス番号取得処理（－） */
		//EXEC dbo.RQAJDDTCF0680_5
		var routeMinusSalesTrendStat *model.SalesTrendStat
		if minusInOutSourceInfo.ShohinDibnriKbn == "20" {
			logger.Log.Infof("入出金元情報管理[マイナス]の商品大分類区分==20だったため、対応する販売動向統計の検索をスキップします; 入出金元情報管理[マイナス]=%+v",
				minusInOutSourceInfo)
			// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
			routeMinusSalesTrendStat = &model.SalesTrendStat{}
		} else {
			key := model.SalesTrendStatKey{
				OriginalKozaNo: minusInOutSourceInfo.OriginalKozaNo,
				KijunYmd:       minusInOutSourceInfo.KijunYmd,
				ShtkmtDataKbn:  minusInOutSourceInfo.ShtkmtDataKbn,
				TorihikiNo:     minusInOutSourceInfo.TorihikiNo}
			routeMinusSalesTrendStat = b.salesTrendStatsMap.GetMaxSeqNOItem(key)
			if routeMinusSalesTrendStat == nil {
				logger.Log.Infof("入出金元情報管理[マイナス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
				// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
				routeMinusSalesTrendStat = &model.SalesTrendStat{}
			}
		}

		/* 販売動向統計登録処理 */
		/* 経路．シーケンス番号等を設定 */
		wkTorihikiID := routeMinusSalesTrendStat.TorihikiId
		wkKirSeqNO := routeMinusSalesTrendStat.KirSeqNo + 1

		/* 経路金額 */
		wkKirKingaku := common.CalcKeiroKingaku(minusInOutSourceInfo.HkSeisanKingakuOriginal,
			minusInOutKessaiSeisanKingakuKisny,
			minusInOutSourceInfo.KessaiSeisanKingakuOriginal)
		//EXEC dbo.RQAJDDTCF0680_6
		routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
		routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
		routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
		routeSalesTrendStatForGenerate.KratFlg = ""
		inOutSourceInfoForGenerate := model.InitInOutSourceInfo()
		inOutSourceInfoForGenerate.KirKbn = "200000"
		inOutSourceInfoForGenerate.ShohinDibnriKbn = "20"
		inOutSourceInfoForGenerate.ShohinChbnriKbn = "2000"
		inOutSourceInfoForGenerate.ShohinShbnriKbn = "200000"
		inOutSourceInfoForGenerate.KijunYmd = b.batchDate
		inOutSourceInfoForGenerate.TishkKbn = "1"
		inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
		inOutSourceInfoForGenerate.IfJshnYmd = minusInOutSourceInfo.IfJshnYmd
		cond := &model.GenerateConditionForFCS{UkwtshYMD: 99999999}
		o, err := b.generateSalesTrendStat(cond, "", 0,
			&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
		if err != nil {
			return err
		}
		if o != nil {
			b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
			// 追加したもの含めて再度検索できるように追加する
			b.salesTrendStatsMap.Add(o)
		}

		if minusInOutKessaiSeisanKingakuGikMmf.Equal(decimal.Zero) {
			/* マイナスデータ．決済．精算金額（外貨MMF）＝0 */
			/* 入出金管理更新処理 */
			//EXEC dbo.RQAJDDTCF0680_8
			minusInOutSourceInfo.KessaiSeisanKingakuKisny = decimal.Zero
			minusInOutSourceInfo.SkjFlg = 1
			minusInOutSourceInfo.RecordKshnYmd = b.batchDate
			minusInOutSourceInfo.SystemYmd = b.systemDate
			minusInOutSourceInfo.SystemHms = b.systemTime
			b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, minusInOutSourceInfo)
		} else {
			/* マイナスデータ．決済．精算金額（外貨MMF）≠ 0 */
			/* ZERO→決済．精算金額（計算用） */
			minusInOutKessaiSeisanKingakuKisny = decimal.Zero
			/* '2'(全仮充て)→入出金仮充て区分（－）*/
			minusInOutNyushukkinKratKbn = "2"
		}
	}

	/* 引当済み更新処理 */
	if minusInOutNyushukkinKratKbn == "2" {
		isMinusInOutDeleted = false
		plusInOutSourceInfos, err := b.plusInOutSourceInfosMap.GetAllocatedInOutSourceInfos(minusInOutSourceInfo, b.batchDate)
		if err != nil {
			return fmt.Errorf("引当済み処理で利用する入出金元情報管理[プラス]を取得できませんでした。; %v", err)
		}
		for _, plusInOutSourceInfo := range plusInOutSourceInfos {
			/* 経路シーケンス番号取得 */
			/* 経路シーケンス番号取得処理（－） */
			//EXEC dbo.RQAJDDTCF0680_5
			var routeMinusSalesTrendStat *model.SalesTrendStat
			if minusInOutSourceInfo.ShohinDibnriKbn == "20" {
				logger.Log.Infof("入出金元情報管理[マイナス]の商品大分類区分==20だったため、対応する販売動向統計の検索をスキップします; 入出金元情報管理[マイナス]=%+v",
					minusInOutSourceInfo)
				// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
				routeMinusSalesTrendStat = &model.SalesTrendStat{}
			} else {
				key := model.SalesTrendStatKey{
					OriginalKozaNo: minusInOutSourceInfo.OriginalKozaNo,
					KijunYmd:       minusInOutSourceInfo.KijunYmd,
					ShtkmtDataKbn:  minusInOutSourceInfo.ShtkmtDataKbn,
					TorihikiNo:     minusInOutSourceInfo.TorihikiNo}
				routeMinusSalesTrendStat = b.salesTrendStatsMap.GetMaxSeqNOItem(key)
				if routeMinusSalesTrendStat == nil {
					logger.Log.Infof("入出金元情報管理[マイナス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
					// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
					routeMinusSalesTrendStat = &model.SalesTrendStat{}
				}
			}

			/* 経路シーケンス番号取得処理（＋） */
			//EXEC dbo.RQAJDDTCF0680_5
			var routePlusSalesTrendStat *model.SalesTrendStat
			if plusInOutSourceInfo.ShohinDibnriKbn == "20" {
				logger.Log.Infof("入出金元情報管理[プラス]の商品大分類区分==20だったため、対応する販売動向統計の検索をスキップします; 入出金元情報管理[プラス]=%+v",
					plusInOutSourceInfo)
				// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
				routePlusSalesTrendStat = &model.SalesTrendStat{}
			} else {
				key := model.SalesTrendStatKey{
					OriginalKozaNo: plusInOutSourceInfo.OriginalKozaNo,
					KijunYmd:       plusInOutSourceInfo.KijunYmd,
					ShtkmtDataKbn:  plusInOutSourceInfo.ShtkmtDataKbn,
					TorihikiNo:     plusInOutSourceInfo.TorihikiNo}
				routePlusSalesTrendStat = b.salesTrendStatsMap.GetMaxSeqNOItem(key)
				if routePlusSalesTrendStat == nil {
					logger.Log.Infof("入出金元情報管理[プラス]と対応する販売動向統計が見つかりませんでした; 検索キー=%+v", key)
					// 後続の処理でフィールドの初期値を利用するため、初期値をイニシャライズ
					routePlusSalesTrendStat = &model.SalesTrendStat{}
				}
			}

			if minusInOutKessaiSeisanKingakuGikMmf.GreaterThan(plusInOutSourceInfo.KessaiSeisanKingakuGikMmf) {
				/* マイナスデータ ＞ プラスデータ */
				/* 販売動向統計更新処理(2) */
				//EXEC dbo.RQAJDDTCF0680_10
				if routeMinusSalesTrendStat.IsFetched() {
					updates, err := b.updateSalesTrendStats2(minusInOutSourceInfo, plusInOutSourceInfo.KessaiSeisanKingakuGikMmf)
					if err != nil {
						return err
					}
					for _, s := range updates {
						// outputに入ってないポインタを追加する
						if !model.IsSalesTrendStatContains(b.outputSalesTrendStats, s) {
							b.outputSalesTrendStats = append(b.outputSalesTrendStats, s)
						}
						b.salesTrendStatsMap.Add(s)
					}
				}

				/* 販売動向統計更新処理(1) */
				//EXEC dbo.RQAJDDTCF0680_9
				//実際のストアドではプラスデータの存在確認しかしてないが、それは既存バグなのでマイナスデータの存在確認もする
				//存在確認をしないと初期値で初期化されたマイナスデータで既存のデータを上書きすることになる
				if routePlusSalesTrendStat.IsFetched() && routeMinusSalesTrendStat.IsFetched() {
					updates, err := b.updateSalesTrendStats1(plusInOutSourceInfo, minusInOutSourceInfo, routeMinusSalesTrendStat)
					if err != nil {
						return err
					}
					for _, s := range updates {
						// outputに入ってないポインタを追加する
						if !model.IsSalesTrendStatContains(b.outputSalesTrendStats, s) {
							b.outputSalesTrendStats = append(b.outputSalesTrendStats, s)
						}
						b.salesTrendStatsMap.Add(s)
					}
				}

				/* 決済．精算金額（外貨MMF）を計算 */
				//SET @GM_kessaiSeisanKingakuGikMmf = @GM_kessaiSeisanKingakuGikMmf - @GP_kessaiSeisanKingakuGikMmf;
				minusInOutKessaiSeisanKingakuGikMmf = minusInOutKessaiSeisanKingakuGikMmf.Sub(
					plusInOutSourceInfo.KessaiSeisanKingakuGikMmf)

				if plusInOutSourceInfo.KessaiSeisanKingakuKisny.Equal(decimal.Zero) {
					/* プラスデータ．決済．精算金額（計算用）＝ 0 */
					/* 入出金管理更新処理 */
					plusInOutSourceInfo.KessaiSeisanKingakuKisny = decimal.Zero
					plusInOutSourceInfo.SkjFlg = 1
					plusInOutSourceInfo.RecordKshnYmd = b.batchDate
					plusInOutSourceInfo.SystemYmd = b.systemDate
					plusInOutSourceInfo.SystemHms = b.systemTime
					b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)
				} else {
					/* プラスデータ．決済．精算金額（計算用）≠ 0 */
					/* 入出金管理更新処理 */
					plusInOutSourceInfo.KessaiSeisanKingakuGikMmf = decimal.Zero
					plusInOutSourceInfo.NyushukkinKratKbn = ""
					plusInOutSourceInfo.RecordKshnYmd = b.batchDate
					plusInOutSourceInfo.SystemYmd = b.systemDate
					plusInOutSourceInfo.SystemHms = b.systemTime
					b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)
				}
			} else if minusInOutKessaiSeisanKingakuGikMmf.Equal(plusInOutSourceInfo.KessaiSeisanKingakuGikMmf) {
				/* マイナスデータ ＝ プラスデータ */
				/* 決済．精算金額（計算用)（＋）を退避 */
				wkKessaiSeisanKingakuKisny := plusInOutSourceInfo.KessaiSeisanKingakuKisny

				/* 決済．精算金額（計算用）を計算 */
				minusInOutKessaiSeisanKingakuKisny = minusInOutKessaiSeisanKingakuGikMmf
				plusInOutKessaiSeisanKingakuKisny := plusInOutSourceInfo.KessaiSeisanKingakuGikMmf

				var wkKratFlg string
				// IF (@GP_shohinCd = '139201' AND @GM_shohinCd <> '139201') OR (@GP_shohinCd <> '139201' AND @GM_shohinCd = '139201')
				// 判定実装が冗長だが現行実装を真似る
				if (plusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF && minusInOutSourceInfo.ShohinCd != ForeignCurrencyMMF) || (plusInOutSourceInfo.ShohinCd != ForeignCurrencyMMF && minusInOutSourceInfo.ShohinCd == ForeignCurrencyMMF) {
					wkKratFlg = "1"
				} else {
					wkKratFlg = ""
				}

				/* 販売動向統計登録処理 */
				/* 経路．シーケンス番号等を設定 */
				wkTorihikiID := routeMinusSalesTrendStat.TorihikiId
				wkKirSeqNO := routeMinusSalesTrendStat.KirSeqNo + 1
				var wkHmzkTorihikiID string
				var wkHmzkKirSeqNO int64
				if plusInOutSourceInfo.ShohinDibnriKbn != "20" && routePlusSalesTrendStat.IsFetched() {
					wkHmzkTorihikiID = routePlusSalesTrendStat.TorihikiId
					wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
				} else {
					wkHmzkTorihikiID = ""
					wkHmzkKirSeqNO = 0
				}

				/* 経路金額 */
				wkKirKingaku := common.CalcKeiroKingaku(minusInOutSourceInfo.HkSeisanKingakuOriginal,
					plusInOutKessaiSeisanKingakuKisny,
					minusInOutSourceInfo.KessaiSeisanKingakuOriginal)

				//EXEC dbo.RQAJDDTCF0680_6
				routeSalesTrendStatForGenerate := *routeMinusSalesTrendStat
				inOutSourceInfoForGenerate := *plusInOutSourceInfo
				routeSalesTrendStatForGenerate.KirSeqNo = wkKirSeqNO
				routeSalesTrendStatForGenerate.TorihikiId = wkTorihikiID
				routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
				inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
				cond := &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
				o, err := b.generateSalesTrendStat(cond, wkHmzkTorihikiID, wkHmzkKirSeqNO,
					&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
				if err != nil {
					return err
				}
				if o != nil {
					b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
					// 追加したもの含めて再度検索できるように追加する
					b.salesTrendStatsMap.Add(o)
				}

				/* 販売動向統計登録処理 */

				/* 経路．シーケンス番号等を設定 */
				if !routeMinusSalesTrendStat.IsFetched() {
					wkHmzkKirSeqNO = routePlusSalesTrendStat.KirSeqNo + 1
					wkTorihikiID = ""
					wkKirSeqNO = 0
				}

				/* 経路金額 */
				wkKirKingaku = common.CalcKeiroKingaku(plusInOutSourceInfo.HkSeisanKingakuOriginal,
					minusInOutKessaiSeisanKingakuKisny,
					plusInOutSourceInfo.KessaiSeisanKingakuOriginal)
				// EXEC dbo.RQAJDDTCF0680_6
				routeSalesTrendStatForGenerate = *routePlusSalesTrendStat
				inOutSourceInfoForGenerate = *minusInOutSourceInfo
				routeSalesTrendStatForGenerate.KirSeqNo = wkHmzkKirSeqNO
				routeSalesTrendStatForGenerate.KratFlg = wkKratFlg
				inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = wkKirKingaku
				cond = &model.GenerateConditionForFCS{UkwtshYMD: plusInOutSourceInfo.UkwtshYmd}
				o, err = b.generateSalesTrendStat(cond, wkTorihikiID, wkKirSeqNO,
					&routeSalesTrendStatForGenerate, &inOutSourceInfoForGenerate)
				if err != nil {
					return err
				}
				if o != nil {
					b.outputSalesTrendStats = append(b.outputSalesTrendStats, o)
					// 追加したもの含めて再度検索できるように追加する
					b.salesTrendStatsMap.Add(o)
				}

				/* 販売動向統計更新処理(4) */
				//EXEC dbo.RQAJDDTCF0680_12
				if routeMinusSalesTrendStat != nil {
					updates, err := b.updateSalesTrendStats4(minusInOutSourceInfo)
					if err != nil {
						return err
					}
					for _, s := range updates {
						// outputに入ってないポインタを追加する
						if !model.IsSalesTrendStatContains(b.outputSalesTrendStats, s) {
							b.outputSalesTrendStats = append(b.outputSalesTrendStats, s)
						}
						b.salesTrendStatsMap.Add(s)
					}
				}

				/* 販売動向統計更新処理(4) */
				if routePlusSalesTrendStat != nil {
					updates, err := b.updateSalesTrendStats4(plusInOutSourceInfo)
					if err != nil {
						return err
					}
					for _, s := range updates {
						// outputに入ってないポインタを追加する
						if !model.IsSalesTrendStatContains(b.outputSalesTrendStats, s) {
							b.outputSalesTrendStats = append(b.outputSalesTrendStats, s)
						}
						b.salesTrendStatsMap.Add(s)
					}
				}

				/* 入出金管理更新処理 */
				//EXEC dbo.RQAJDDTCF0680_8
				minusInOutSourceInfo.SkjFlg = 1
				minusInOutSourceInfo.RecordKshnYmd = b.batchDate
				minusInOutSourceInfo.SystemYmd = b.systemDate
				minusInOutSourceInfo.SystemHms = b.systemTime
				b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, minusInOutSourceInfo)
				isMinusInOutDeleted = true // SkjFlgを立てたの削除済みに変更

				if wkKessaiSeisanKingakuKisny.Equal(decimal.Zero) {
					/* 決済．精算金額（計算用・退避)＝0 */
					/* 入出金管理更新処理 */
					plusInOutSourceInfo.SkjFlg = 1
					plusInOutSourceInfo.KessaiSeisanKingakuKisny = decimal.Zero
					plusInOutSourceInfo.RecordKshnYmd = b.batchDate
					plusInOutSourceInfo.SystemYmd = b.systemDate
					plusInOutSourceInfo.SystemHms = b.systemTime
					b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)
				} else {
					/* 上記以外 */
					/* 入出金管理更新処理 */
					plusInOutSourceInfo.NyushukkinKratKbn = ""
					plusInOutSourceInfo.KessaiSeisanKingakuGikMmf = decimal.Zero
					plusInOutSourceInfo.RecordKshnYmd = b.batchDate
					plusInOutSourceInfo.SystemYmd = b.systemDate
					plusInOutSourceInfo.SystemHms = b.systemTime
					b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)
				}
				/* ループエンド */
				break
			} else { //minusKingakuGikMmf < plusKingakuGikMmf
				/* 上記以外 */

				/* 販売動向統計更新処理(1) */
				//EXEC dbo.RQAJDDTCF0680_9
				//実際のストアドではマイナスデータの存在確認しかしてないが、それは既存バグなのでプラスデータの存在確認もする
				//存在確認をしないと初期値で初期化されたプラスデータで既存のデータを上書きすることになる
				if routeMinusSalesTrendStat.IsFetched() && routePlusSalesTrendStat.IsFetched() {
					updates, err := b.updateSalesTrendStats1(minusInOutSourceInfo, plusInOutSourceInfo, routePlusSalesTrendStat)
					if err != nil {
						return err
					}
					for _, s := range updates {
						// outputに入ってないポインタを追加する
						if !model.IsSalesTrendStatContains(b.outputSalesTrendStats, s) {
							b.outputSalesTrendStats = append(b.outputSalesTrendStats, s)
						}
						b.salesTrendStatsMap.Add(s)
					}
				}

				/* 販売動向統計更新処理(2) */
				//EXEC dbo.RQAJDDTCF0680_10
				if routePlusSalesTrendStat.IsFetched() {
					updates, err := b.updateSalesTrendStats2(plusInOutSourceInfo, minusInOutKessaiSeisanKingakuGikMmf)
					if err != nil {
						return err
					}
					for _, s := range updates {
						// outputに入ってないポインタを追加する
						if !model.IsSalesTrendStatContains(b.outputSalesTrendStats, s) {
							b.outputSalesTrendStats = append(b.outputSalesTrendStats, s)
						}
						b.salesTrendStatsMap.Add(s)
					}
				}

				/* 入出金管理更新処理 */
				//EXEC dbo.RQAJDDTCF0680_8
				minusInOutSourceInfo.SkjFlg = 1
				minusInOutSourceInfo.RecordKshnYmd = b.batchDate
				minusInOutSourceInfo.SystemYmd = b.systemDate
				minusInOutSourceInfo.SystemHms = b.systemTime
				b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, minusInOutSourceInfo)

				/* 入出金管理更新処理 */
				//EXEC dbo.RQAJDDTCF0680_8
				plusInOutSourceInfo.KessaiSeisanKingakuGikMmf = plusInOutSourceInfo.KessaiSeisanKingakuGikMmf.Sub(
					minusInOutKessaiSeisanKingakuGikMmf)
				plusInOutSourceInfo.RecordKshnYmd = b.batchDate
				plusInOutSourceInfo.SystemYmd = b.systemDate
				plusInOutSourceInfo.SystemHms = b.systemTime
				b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, plusInOutSourceInfo)
				/* ループエンド */
				break
			}
		}

		/* 入出金元情報管理[マイナス]をまだ削除してない場合 */
		if !isMinusInOutDeleted {
			minusInOutSourceInfo.SkjFlg = 1
			minusInOutSourceInfo.RecordKshnYmd = b.batchDate
			minusInOutSourceInfo.SystemYmd = b.systemDate
			minusInOutSourceInfo.SystemHms = b.systemTime
			b.outputInOutSourceInfos = append(b.outputInOutSourceInfos, minusInOutSourceInfo)
		}
	}
	return nil
}

/*extractTempAllocatedSalesTrendStats 販売動向統計更新処理で利用する仮当てフラグ==1である販売動向統計を適切な順番にソートして返す。
該当するものが存在しない場合は空スライスを返す。
*/
func (b *BatchManager) extractTempAllocatedSalesTrendStats(keyInOutSourceInfo *model.InOutSourceInfo) []*model.SalesTrendStat {
	key := model.SalesTrendStatKey{
		OriginalKozaNo: keyInOutSourceInfo.OriginalKozaNo,
		KijunYmd:       keyInOutSourceInfo.KijunYmd,
		ShtkmtDataKbn:  keyInOutSourceInfo.ShtkmtDataKbn,
		TorihikiNo:     keyInOutSourceInfo.TorihikiNo,
	}

	candidateStats := b.salesTrendStatsMap[key]

	var targetStats []*model.SalesTrendStat
	for _, s := range candidateStats {
		if s.KratFlg == "1" {
			targetStats = append(targetStats, s)
		}
	}

	sort.Slice(targetStats, func(i, j int) bool {
		return targetStats[i].KirSeqNo < targetStats[j].KirSeqNo
	})
	return targetStats
}

/*updateSalesTrendStats1 販売動向統計更新処理(1) RQAJDDTCF0680_9.sql
 */
func (b *BatchManager) updateSalesTrendStats1(keyInOutSourceInfo *model.InOutSourceInfo,
	kirInOutSourceInfo *model.InOutSourceInfo, routeSalesTrendStat *model.SalesTrendStat) (updates []*model.SalesTrendStat, err error) {
	/* 経路シーケンス番号の取得ができた場合、販売動向統計更新処理を行う */
	kirSeqNo := routeSalesTrendStat.KirSeqNo
	stats := b.extractTempAllocatedSalesTrendStats(keyInOutSourceInfo)
	for _, stat := range stats {
		/* レコードが存在する場合 */
		/* 経路．シーケンス番号(－) + 1 */
		kirSeqNo++

		///* 販売動向統計更新 */
		// 後続の処理で更新前の販売動向統計を利用するので退避する
		tempStat := *stat
		stat.KirKirKbn = kirInOutSourceInfo.KirKbn
		stat.KirShohinKbn = kirInOutSourceInfo.ShohinKbn
		stat.KirShohinDibnriKbn = kirInOutSourceInfo.ShohinDibnriKbn
		stat.KirShohinChbnriKbn = kirInOutSourceInfo.ShohinChbnriKbn
		stat.KirShohinShbnriKbn = kirInOutSourceInfo.ShohinShbnriKbn
		stat.KirSttiYmd = b.batchDate
		stat.KirKijunYmd = routeSalesTrendStat.KijunYmd
		stat.KirMgId = routeSalesTrendStat.MgId
		stat.KirMgCd = routeSalesTrendStat.MgCd
		stat.KirKokunaiGaiKbn = routeSalesTrendStat.KokunaiGaiKbn
		stat.KirShohinKbn = routeSalesTrendStat.KirShohinKbn
		stat.KirShohinCd = routeSalesTrendStat.ShohinCd
		stat.KirShohinCd_1 = routeSalesTrendStat.ShohinCd1
		stat.KirShohinCd_2 = routeSalesTrendStat.ShohinCd2
		stat.KirShohinCd_3 = routeSalesTrendStat.ShohinCd3
		stat.KirShohinCd_4 = routeSalesTrendStat.ShohinCd4
		stat.KirHknKaishaCd = routeSalesTrendStat.HknKaishaCd
		stat.KirShohinZksiCd = routeSalesTrendStat.ShohinZksiCd
		stat.KirYkjYmd = routeSalesTrendStat.YkjYmd
		stat.KirUkwtshYmd = routeSalesTrendStat.UkwtshYmd
		stat.KirTorihikiNo = routeSalesTrendStat.TorihikiNo
		stat.KirTishkKbn = routeSalesTrendStat.TishkKbn
		stat.KirTorihikiNaiyo = routeSalesTrendStat.TorihikiNaiyo
		stat.KirYkjSuryo = routeSalesTrendStat.YkjSuryo
		stat.KirHkLastSeisanKingaku = routeSalesTrendStat.HkLastSeisanKingaku
		stat.KirKessaiLastSeisanKingaku = routeSalesTrendStat.KessaiLastSeisanKingaku
		stat.KirChmnChannelCd = routeSalesTrendStat.ChmnChannelCd
		stat.KirTrkshKbn = routeSalesTrendStat.TrkshKbn
		stat.HmzkTorihikiId = routeSalesTrendStat.TorihikiId
		stat.HmzkKirSeqNo = kirSeqNo
		stat.KratFlg = ""
		stat.RecordKoshinYmd = b.batchDate
		stat.SystemYmd = b.systemDate
		stat.SystemHms = b.systemTime
		updates = append(updates, stat)

		/* 販売動向統計登録処理 */
		//EXEC dbo.RQAJDDTCF0680_6
		salesTrendStatForGenerate := *routeSalesTrendStat
		salesTrendStatForGenerate.KratFlg = ""
		salesTrendStatForGenerate.KirSeqNo = kirSeqNo
		// generateSalesTrendStatの引数だと上のstatを経路として設定できないので、一旦必要なものだけinOutSourceInfoに変換する
		inOutSourceInfoForGenerate := model.InitInOutSourceInfo()
		inOutSourceInfoForGenerate.KirKbn = stat.KirKbn
		inOutSourceInfoForGenerate.ShohinDibnriKbn = stat.ShohinDibnriKbn
		inOutSourceInfoForGenerate.ShohinChbnriKbn = stat.ShohinChbnriKbn
		inOutSourceInfoForGenerate.ShohinShbnriKbn = stat.ShohinShbnriKbn
		inOutSourceInfoForGenerate.KijunYmd = stat.KijunYmd
		inOutSourceInfoForGenerate.MgId = stat.MgId
		inOutSourceInfoForGenerate.MgCd = stat.MgCd
		inOutSourceInfoForGenerate.KokunaiGaiKbn = stat.KokunaiGaiKbn
		inOutSourceInfoForGenerate.ShohinKbn = stat.ShohinKbn
		inOutSourceInfoForGenerate.ShohinCd = stat.ShohinCd
		inOutSourceInfoForGenerate.ShohinCd1 = stat.ShohinCd1
		inOutSourceInfoForGenerate.ShohinCd2 = stat.ShohinCd2
		inOutSourceInfoForGenerate.ShohinCd3 = stat.ShohinCd3
		inOutSourceInfoForGenerate.ShohinCd4 = stat.ShohinCd4
		inOutSourceInfoForGenerate.HknKaishaCd = stat.HknKaishaCd
		inOutSourceInfoForGenerate.ShohinZksiCd = stat.ShohinZksiCd
		inOutSourceInfoForGenerate.YkjYmd = stat.YkjYmd
		inOutSourceInfoForGenerate.UkwtshYmd = stat.UkwtshYmd
		inOutSourceInfoForGenerate.TorihikiNo = stat.TorihikiNo
		inOutSourceInfoForGenerate.TishkKbn = stat.TishkKbn
		inOutSourceInfoForGenerate.TorihikiNaiyo = stat.TorihikiNaiyo
		inOutSourceInfoForGenerate.YkjSuryo = stat.YkjSuryo
		inOutSourceInfoForGenerate.HkSeisanKingakuOriginal = stat.HkLastSeisanKingaku         // 代入場所が異なってる点に注意。これで正しい。
		inOutSourceInfoForGenerate.KessaiSeisanKingakuOriginal = stat.KessaiLastSeisanKingaku // 代入場所が異なってる点に注意。これで正しい。
		inOutSourceInfoForGenerate.ChmnChannelCd = stat.ChmnChannelCd
		inOutSourceInfoForGenerate.TrkshKbn = stat.TrkshKbn
		inOutSourceInfoForGenerate.KessaiSeisanKingakuKisny = stat.KirKingaku // 代入場所が異なってる点に注意。これで正しい。
		inOutSourceInfoForGenerate.IfJshnYmd = keyInOutSourceInfo.IfJshnYmd   // ここだけ入出金元情報管理から持ってくる
		cond := &model.GenerateConditionForFCS{UkwtshYMD: 99999999}
		o, err := b.generateSalesTrendStat(cond, stat.TorihikiId, tempStat.KirSeqNo,
			&salesTrendStatForGenerate, &inOutSourceInfoForGenerate)
		if err != nil {
			return nil, err
		}
		if o != nil {
			updates = append(updates, o)
			// 追加したもの含めて再度検索できるように追加する
			b.salesTrendStatsMap.Add(o)
		}

		/* 販売動向統計取消処理 */
		//EXEC dbo.RQAJDDTCF0680_11
		linkedStat := b.updateSalesTrendStats3(&tempStat, decimal.Zero, "1")
		if linkedStat != nil {
			updates = append(updates, linkedStat)
		}
	}
	return updates, nil
}

/* updateSalesTrendStats2 販売動向統計更新処理(2) RQAJDDTCF0680_10.sql
 */
func (b *BatchManager) updateSalesTrendStats2(inOutSourceInfo *model.InOutSourceInfo,
	kessaiSeisanKingakuGikMmf decimal.Decimal) (updates []*model.SalesTrendStat, err error) {
	var (
		wkKirKingaku decimal.Decimal
		wkTrkshKbn   string
	)
	wkBreak := false
	wkKessaiSeisanKingakuGikMmf := decimal.Zero

	/* 販売動向統計更新処理 */
	/* 経路シーケンス番号の取得ができた場合、販売動向統計更新処理を行う */
	stats := b.extractTempAllocatedSalesTrendStats(inOutSourceInfo)
	for _, stat := range stats {
		/* レコードが存在する場合 */
		/* ワーク決済.精算金額(外貨MMF・退避)を初期化 */
		if wkKessaiSeisanKingakuGikMmf.LessThanOrEqual(decimal.Zero) {
			wkKessaiSeisanKingakuGikMmf = kessaiSeisanKingakuGikMmf
		}
		/* 該当レコードの経路金額算出 */
		wkKirKingaku = common.CalcKeiroKingaku(inOutSourceInfo.HkSeisanKingakuOriginal,
			wkKessaiSeisanKingakuGikMmf,
			inOutSourceInfo.KessaiSeisanKingakuOriginal)
		wkKirKingaku = stat.KirKingaku.Sub(wkKirKingaku.Abs())

		if wkKirKingaku.LessThan(decimal.Zero) {
			wkKessaiSeisanKingakuGikMmf = common.CalcKessaiSeisanKingakuGikMMF(wkKirKingaku,
				inOutSourceInfo.HkSeisanKingakuOriginal,
				inOutSourceInfo.KessaiSeisanKingakuOriginal)
			wkKirKingaku = decimal.Zero
		} else {
			wkBreak = true
		}

		/* 取消区分 */
		if wkKirKingaku.Equal(decimal.Zero) {
			wkTrkshKbn = "1"
		} else {
			wkTrkshKbn = ""
		}
		/* 販売動向統計更新 */
		stat.TrkshKbn = wkTrkshKbn
		stat.KirKingaku = wkKirKingaku
		stat.RecordKoshinYmd = b.batchDate
		stat.SystemYmd = b.systemDate
		stat.SystemHms = b.systemTime
		updates = append(updates, stat)

		///* 販売動向統計更新処理(3) */
		linkedStat := b.updateSalesTrendStats3(stat, wkKirKingaku, wkTrkshKbn)
		if linkedStat != nil {
			updates = append(updates, linkedStat)
		}

		if wkBreak {
			break /* ループエンド */
		}
	}
	return updates, nil
}

/*updateSalesTrendStats3 販売動向統計更新処理(3) RQAJDDTCF0680_11.sql

販売動向統計に紐づく販売動向統計を探して削除する。見つからない場合は何もしない。
*/
func (b *BatchManager) updateSalesTrendStats3(rootSalesTrendStat *model.SalesTrendStat,
	kirKingaku decimal.Decimal, trkshKbn string) (linkedStat *model.SalesTrendStat) {
	// 1.ヒューリスティックに、大抵のケースでは output の中に探しているものがあるのでそちらから探す
	for _, c := range b.outputSalesTrendStats {
		if c.TorihikiId == rootSalesTrendStat.HmzkTorihikiId && c.KirSeqNo == rootSalesTrendStat.HmzkKirSeqNo {
			linkedStat = c
			break
		}
	}
	// 2.見つからない場合は大本を探す
	// OPTIMIZE: 計算コスト大なので、もうちょいいい方法を用意したい
	if linkedStat == nil {
		for _, cs := range b.salesTrendStatsMap {
			for _, c := range cs {
				if c.TorihikiId == rootSalesTrendStat.HmzkTorihikiId && c.KirSeqNo == rootSalesTrendStat.HmzkKirSeqNo {
					linkedStat = c
					break
				}
			}
		}
	}
	// 3.それでも見つからない場合はログにコメントを残して正常終了
	if linkedStat == nil {
		logger.Log.Errorf("販売動向統計に紐づく販売動向統計が見つかりませんでした。紐づく販売動向統計の削除処理をスキップします; 紐づけ元販売動向統計=%v", rootSalesTrendStat)
		return nil
	}

	linkedStat.TrkshKbn = trkshKbn
	linkedStat.KirKingaku = kirKingaku
	linkedStat.RecordKoshinYmd = b.batchDate
	linkedStat.SystemYmd = b.systemDate
	linkedStat.SystemHms = b.systemTime
	return linkedStat
}

/*updateSalesTrendStats4 販売動向統計更新処理(4) RQAJDDTCF0680_12.sql
 */
func (b *BatchManager) updateSalesTrendStats4(keyInOutSourceInfo *model.InOutSourceInfo) (updates []*model.SalesTrendStat, err error) {
	// 対象となる販売動向統計を取得する
	stats := b.extractTempAllocatedSalesTrendStats(keyInOutSourceInfo)

	/* 販売動向統計更新処理 */
	for _, stat := range stats {
		/* 販売動向統計更新 */
		stat.TrkshKbn = "1"
		stat.KirKingaku = decimal.Zero
		stat.RecordKoshinYmd = b.batchDate
		stat.SystemYmd = b.systemDate
		stat.SystemHms = b.systemTime
		updates = append(updates, stat)

		/* 販売動向統計更新処理(3) */
		// EXEC dbo.RQAJDDTCF0680_11
		linkedStat := b.updateSalesTrendStats3(stat, decimal.Zero, "1")
		if linkedStat != nil {
			updates = append(updates, linkedStat)
		}
	}
	return updates, nil
}

//generateSalesTrendStat 販売動向統計登録処理 RQAJDDTCF0680_6.sql
func (b *BatchManager) generateSalesTrendStat(condition *model.GenerateConditionForFCS, wkHmzkTorihikiID string, wkHmzkKirSeqNO int64,
	salesTrendStat *model.SalesTrendStat, inOutSourceInfo *model.InOutSourceInfo) (
	outSalesTrendStat *model.SalesTrendStat, err error) {
	// 対応する販売動向統計のデータが取得できないケースは新しく販売動向統計のデータを登録しない
	if !salesTrendStat.IsFetched() {
		logger.Log.Infof("対応する販売動向統計が取得ができなかったため、販売動向統計の登録処理をスキップします")
		return nil, nil
	}

	/* 経路シーケンス番号の取得ができた場合、販売動向統計登録処理を行う */
	var (
		wkKirKirKbn          string
		wkKirShohinDibnriKbn string
		wkKirShohinChbnriKbn string
		wkKirShohinShbnriKbn string
	)

	/* 1ヶ月前処理日付 */
	oneMonthAgo, err := common.MinusOneMonth(b.batchDate)
	if err != nil {
		return nil, err
	}
	/* 経路．経路区分 */
	/* 経路．商品大分類区分 */
	/* 経路．商品中分類区分 */
	/* 経路．商品小分類区分 */
	if oneMonthAgo > condition.UkwtshYMD {
		wkKirKirKbn = "200000"
		wkKirShohinDibnriKbn = "20"
		wkKirShohinChbnriKbn = "2000"
		wkKirShohinShbnriKbn = "200000"
	} else {
		wkKirKirKbn = inOutSourceInfo.KirKbn
		wkKirShohinDibnriKbn = inOutSourceInfo.ShohinDibnriKbn
		wkKirShohinChbnriKbn = inOutSourceInfo.ShohinChbnriKbn
		wkKirShohinShbnriKbn = inOutSourceInfo.ShohinShbnriKbn
	}

	outSalesTrendStat = &model.SalesTrendStat{
		TorihikiId:                 salesTrendStat.TorihikiId,
		UserCd:                     salesTrendStat.UserCd,
		ButenCd:                    salesTrendStat.ButenCd,
		OriginalKozaNo:             salesTrendStat.OriginalKozaNo,
		KozaNo:                     salesTrendStat.KozaNo,
		CashHiritsuPer:             salesTrendStat.CashHiritsuPer,
		ShtkmtTblId:                salesTrendStat.ShtkmtTblId,
		ShtkmtDataKbn:              salesTrendStat.ShtkmtDataKbn,
		TorihikiKbn:                salesTrendStat.TorihikiKbn,
		TorihikiKbnShinyo:          salesTrendStat.TorihikiKbnShinyo,
		TaishoTrhkKbn:              salesTrendStat.TaishoTrhkKbn,
		KirKbn:                     salesTrendStat.KirKbn,
		ShohinDibnriKbn:            salesTrendStat.ShohinDibnriKbn,
		ShohinChbnriKbn:            salesTrendStat.ShohinChbnriKbn,
		ShohinShbnriKbn:            salesTrendStat.ShohinShbnriKbn,
		ToriatsukaiChannelCd:       salesTrendStat.ToriatsukaiChannelCd,
		AtsukaishaCd:               salesTrendStat.AtsukaishaCd,
		MgId:                       salesTrendStat.MgId,
		MgCd:                       salesTrendStat.MgCd,
		KokunaiGaiKbn:              salesTrendStat.KokunaiGaiKbn,
		ShohinKbn:                  salesTrendStat.ShohinKbn,
		ShohinCd:                   salesTrendStat.ShohinCd,
		ShohinCd1:                  salesTrendStat.ShohinCd1,
		ShohinCd2:                  salesTrendStat.ShohinCd2,
		ShohinCd3:                  salesTrendStat.ShohinCd3,
		ShohinCd4:                  salesTrendStat.ShohinCd4,
		HknKaishaCd:                salesTrendStat.HknKaishaCd,
		ShohinZksiCd:               salesTrendStat.ShohinZksiCd,
		KijunYmd:                   salesTrendStat.KijunYmd,
		JchNo:                      salesTrendStat.JchNo,
		YkjYmd:                     salesTrendStat.YkjYmd,
		UkwtshYmd:                  salesTrendStat.UkwtshYmd,
		TorihikiNo:                 salesTrendStat.TorihikiNo,
		TishkKbn:                   salesTrendStat.TishkKbn,
		TorihikiNaiyo:              salesTrendStat.TorihikiNaiyo,
		YkjSuryo:                   salesTrendStat.YkjSuryo, // DECIMAL(23,8) 計算に使用しないのでstring
		KessaiTsukaCd:              salesTrendStat.KessaiTsukaCd,
		HkLastSeisanKingaku:        salesTrendStat.HkLastSeisanKingaku,     // DECIMAL(20,3) 計算に使用しないのでstring
		KessaiLastSeisanKingaku:    salesTrendStat.KessaiLastSeisanKingaku, // DECIMAL(20,3) 計算に使用しないのでstring
		ChmnChannelCd:              salesTrendStat.ChmnChannelCd,
		GenkinKir:                  salesTrendStat.GenkinKir,
		SwKbn:                      salesTrendStat.SwKbn,
		SwTaishoKbn:                salesTrendStat.SwTaishoKbn,
		HknNyknFlg:                 salesTrendStat.HknNyknFlg,
		TrkshKbn:                   salesTrendStat.TrkshKbn,
		KirSeqNo:                   salesTrendStat.KirSeqNo,
		KirKirKbn:                  wkKirKirKbn,
		KirShohinDibnriKbn:         wkKirShohinDibnriKbn,
		KirShohinChbnriKbn:         wkKirShohinChbnriKbn,
		KirShohinShbnriKbn:         wkKirShohinShbnriKbn,
		KirSttiYmd:                 b.batchDate,
		KirKijunYmd:                inOutSourceInfo.KijunYmd,
		KirMgId:                    inOutSourceInfo.MgId,
		KirMgCd:                    inOutSourceInfo.MgCd,
		KirKokunaiGaiKbn:           inOutSourceInfo.KokunaiGaiKbn,
		KirShohinKbn:               inOutSourceInfo.ShohinKbn,
		KirShohinCd:                inOutSourceInfo.ShohinCd,
		KirShohinCd_1:              inOutSourceInfo.ShohinCd1,
		KirShohinCd_2:              inOutSourceInfo.ShohinCd2,
		KirShohinCd_3:              inOutSourceInfo.ShohinCd3,
		KirShohinCd_4:              inOutSourceInfo.ShohinCd4,
		KirHknKaishaCd:             inOutSourceInfo.HknKaishaCd,
		KirShohinZksiCd:            inOutSourceInfo.ShohinZksiCd,
		KirYkjYmd:                  inOutSourceInfo.YkjYmd,
		KirUkwtshYmd:               inOutSourceInfo.UkwtshYmd,
		KirTorihikiNo:              inOutSourceInfo.TorihikiNo,
		KirTishkKbn:                inOutSourceInfo.TishkKbn,
		KirTorihikiNaiyo:           inOutSourceInfo.TorihikiNaiyo,
		KirYkjSuryo:                inOutSourceInfo.YkjSuryo,
		KirHkLastSeisanKingaku:     inOutSourceInfo.HkSeisanKingakuOriginal,
		KirKessaiLastSeisanKingaku: inOutSourceInfo.KessaiSeisanKingakuOriginal,
		KirChmnChannelCd:           inOutSourceInfo.ChmnChannelCd,
		KirTrkshKbn:                inOutSourceInfo.TrkshKbn,
		KirKingaku:                 inOutSourceInfo.KessaiSeisanKingakuKisny,
		HmzkTorihikiId:             wkHmzkTorihikiID,
		HmzkKirSeqNo:               wkHmzkKirSeqNO,
		KratFlg:                    salesTrendStat.KratFlg,
		RecordSksiYmd:              b.batchDate,
		RecordKoshinYmd:            b.batchDate,
		IfJshnYmd:                  inOutSourceInfo.IfJshnYmd,
		ShoriTaishoYmd:             b.systemDate,
		SystemYmd:                  b.systemDate,
		SystemHms:                  b.systemTime,
		DataSourceId:               salesTrendStat.DataSourceId,
	}
	return outSalesTrendStat, nil
}
