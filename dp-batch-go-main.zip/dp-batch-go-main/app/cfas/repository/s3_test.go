package repository

import (
	"reflect"
	"testing"
)

func Test_splitToBucketAndKey(t *testing.T) {
	type args struct {
		path string
	}
	tests := []struct {
		name       string
		args       args
		wantBucket string
		wantKey    string
		wantErr    bool
	}{
		{
			name:       "correct shallow path",
			args:       args{path: "s3://example-bucket/test.txt"},
			wantBucket: "example-bucket",
			wantKey:    "test.txt",
			wantErr:    false,
		},
		{
			name:       "correct deep path",
			args:       args{path: "s3://example-bucket/test/test.txt"},
			wantBucket: "example-bucket",
			wantKey:    "test/test.txt",
			wantErr:    false,
		},
		{
			name:       "not s3 format (not correct protocol)",
			args:       args{path: "http://example-bucket/test/test.txt"},
			wantBucket: "",
			wantKey:    "",
			wantErr:    true,
		},
		{
			name:       "not s3 format (not bucket)",
			args:       args{path: "s3://test.txt"},
			wantBucket: "",
			wantKey:    "",
			wantErr:    true,
		},
		{
			name:       "not s3 format (not key)",
			args:       args{path: "s3://example-bucket"},
			wantBucket: "",
			wantKey:    "",
			wantErr:    true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotBucket, gotKey, err := splitToBucketAndKey(tt.args.path)
			if (err != nil) != tt.wantErr {
				t.Errorf("splitToBucketAndKey() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotBucket != tt.wantBucket {
				t.Errorf("splitToBucketAndKey() gotBucket = %v, want %v", gotBucket, tt.wantBucket)
			}
			if gotKey != tt.wantKey {
				t.Errorf("splitToBucketAndKey() gotKey = %v, want %v", gotKey, tt.wantKey)
			}
		})
	}
}

func TestAWSS3CSVFileRepository_Read(t *testing.T) {
	t.Skip("this test is for local debugging, so that this is skipped in whole test")

	r := NewAWSS3CSVFileRepository()

	path := "s3://n-snowflake-poc-staging/CFAS/test/test.csv"
	actual, err := r.Read(path, true)
	if err != nil {
		t.Fatalf("Read() error = %v", err)
	}

	expect := [][]string{
		{"1", "2", "3"},
		{"2", "3", "4"},
	}

	if !reflect.DeepEqual(actual, expect) {
		t.Errorf("Read() got = %v, want %v", actual, expect)
	}
}

func TestAWSS3CSVFileRepository_Write(t *testing.T) {
	t.Skip("this test is for local debugging, so that this is skipped in whole test")

	r := NewAWSS3CSVFileRepository()

	path := "s3://n-snowflake-poc-staging/CFAS/test2/test.csv"

	records := [][]string{
		{"header1", "header2", "header3"},
		{"1", "1", "1"},
		{"1", "1", "1"},
	}

	err := r.Write(path, records)
	if err != nil {
		t.Fatalf("Read() error = %v", err)
	}
}
