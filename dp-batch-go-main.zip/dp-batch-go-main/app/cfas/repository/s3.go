package repository

/*
以下のドキュメントを参照お願いします。
- https://docs.aws.amazon.com/sdk-for-go/api/aws/session/
- https://docs.aws.amazon.com/sdk-for-go/api/service/s3/
*/

import (
	"bytes"
	"encoding/csv"
	"fmt"
	"net/http"
	"regexp"
	"strings"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"

	"dp-batch-go/app/logger"
)

var (
	s3reg *regexp.Regexp
)

func init() {
	s3reg = regexp.MustCompile("s3://(?P<bucket>.+?)/(?P<key>.+)")
}

type AWSS3CSVFileRepository struct {
	downloader *s3manager.Downloader
	uploader   *s3manager.Uploader
}

// Read はpathに配置されているS3上のファイルをCSV形式で読み込みます。
// pathのフォーマットは "s3://<bucket>/<path_to_file>" です。
// 読み込むCSVファイルはヘッダーがあることを期待します。そのため１行目はスキップされます。
func (r *AWSS3CSVFileRepository) Read(path string, ignoreHeader bool) (records [][]string, err error) {
	bucket, key, err := splitToBucketAndKey(path)
	if err != nil {
		return nil, fmt.Errorf("cannot parse s3 path: %w", err)
	}

	b := aws.NewWriteAtBuffer([]byte{})
	_, err = r.downloader.Download(b, &s3.GetObjectInput{
		Bucket: aws.String(bucket),
		Key:    aws.String(key),
	})
	if err != nil {
		if reqerr, ok := err.(awserr.RequestFailure); ok {
			if reqerr.StatusCode() == http.StatusNotFound {
				logger.Log.Errorf("S3に %s のファイルが存在しません", path)
				logger.Log.Errorf("response: %v", reqerr)
				return nil, fmt.Errorf("cannot find file in s3: 404")
			}
		}
		return nil, fmt.Errorf("cannot access to s3: %w", err)
	}

	reader := csv.NewReader(bytes.NewBuffer(b.Bytes()))
	records, err = reader.ReadAll()
	if err != nil {
		return nil, fmt.Errorf("cannot read s3 file as csv: %w", err)
	}

	// Snowflakeが出力したCSVには謎のスペースが入ることがあるのでトリムする
	for i, record := range records {
		var t []string
		for _, e := range record {
			t = append(t, strings.TrimSpace(e))
		}
		records[i] = t
	}

	if ignoreHeader && len(records) > 0 {
		return records[1:], nil
	}

	return records, nil
}

// Write はpathに配置されているS3上のファイルをCSV形式で書き込みます。
// path のフォーマットは "s3://<bucket>/<path_to_file>" です。
// 書き込むrecordsはヘッダーがあることを期待します。
func (r *AWSS3CSVFileRepository) Write(path string, records [][]string) (err error) {
	bucket, key, err := splitToBucketAndKey(path)
	if err != nil {
		return fmt.Errorf("cannot parse s3 path: %w", err)
	}

	body := bytes.NewBuffer([]byte{})
	w := csv.NewWriter(body)
	err = w.WriteAll(records)
	if err != nil {
		return fmt.Errorf("cannot write records to bytes: %w", err)
	}

	_, err = r.uploader.Upload(&s3manager.UploadInput{
		Bucket: aws.String(bucket),
		Key:    aws.String(key),
		Body:   body,
	})

	return err
}

func NewAWSS3CSVFileRepository() ICSVFileRepository {
	// session では ~/.aws/credential [default] のクレデンシャルを利用する
	sess := session.Must(session.NewSessionWithOptions(session.Options{
		// ~/.aws/credential には region 情報がないので、~/.aws/config にある region 情報を読み込むように強制する
		SharedConfigState: session.SharedConfigEnable,
	}))
	downloader := s3manager.NewDownloader(sess)
	uploader := s3manager.NewUploader(sess)

	return &AWSS3CSVFileRepository{
		downloader: downloader,
		uploader:   uploader,
	}
}

func splitToBucketAndKey(path string) (bucket, key string, err error) {
	matches := s3reg.FindStringSubmatch(path)
	if matches == nil {
		return "", "", fmt.Errorf("path is not s3 format")
	}

	bucket = matches[1]
	key = matches[2]

	return bucket, key, nil
}
