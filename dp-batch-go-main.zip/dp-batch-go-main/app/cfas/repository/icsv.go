package repository

type ICSVFileRepository interface {
	Read(path string, ignoreHeader bool) ([][]string, error)
	Write(path string, rows [][]string) error
}
