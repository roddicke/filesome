package repository

import (
	"encoding/csv"
	"os"
)

type LocalCSVFileRepository struct{}

func NewLocalCsvFileRepository() ICSVFileRepository {
	return &LocalCSVFileRepository{}
}

func (r *LocalCSVFileRepository) Read(path string, ignoreHeader bool) ([][]string, error) {
	fp, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	csvReader := csv.NewReader(fp)
	tmpRows, err := csvReader.ReadAll()
	if err != nil {
		return nil, err
	}

	err = fp.Close()
	if err != nil {
		return nil, err
	}

	if ignoreHeader && len(tmpRows) > 0 {
		return tmpRows[1:], nil
	}
	return tmpRows, nil
}

func (r *LocalCSVFileRepository) Write(path string, rows [][]string) error {
	fp, err := os.Create(path)
	if err != nil {
		return err
	}
	csvWriter := csv.NewWriter(fp)
	err = csvWriter.WriteAll(rows)
	if err != nil {
		return err
	}

	return fp.Close()
}
