package dwh

import (
	"fmt"
	"strings"
)

type Config struct {
	File struct {
		LandingBucket string `json:"landingBucket"`
		StagingBucket string `json:"stagingBucket"`
		ExportBucket  string `json:"exportBucket"`
		SendingBucket string `json:"sendingBucket"`
		InputKey      string `json:"inputKey"`
		OutputKey     string `json:"outputKey"`
		Prefix        string `json:"prefix"`
		RecordSize    int64  `json:"recordSize"`
		SplitNum      int64  `json:"splitNum"`
		BufferSize    int    `json:"bufferSize"`
		TempFileDir   string `json:"tempFileDir"`
	} `json:"file"`
	OutputOption struct {
		Encoding    string `json:"encoding"`
		Compression string `json:"compression"`
		Newline     string `json:"newline"`
	} `json:"outputOption"`
	InputOption struct {
		Encoding string `json:"encoding"`
	} `json:"inputOption"`
	Columns []struct {
		Name    string `json:"name"`
		Start   int    `json:"start"`
		Size    int    `json:"size"`
		Padding string `json:"padding"`
		Adjust  string `json:"adjust"`
		Sign    bool   `json:"sign"`
	} `json:"columns"`
}

func (c *Config) OutputFileFormat() string {
	splitted := strings.Split(c.File.OutputKey, ".")
	withOutExt := strings.Join(splitted[:len(splitted)-1], ".")
	serialNumberFmt := "%04d" // 4桁ゼロ埋め
	ext := splitted[len(splitted)-1]

	var format string

	// 分割数が1の時は連番をつけない
	if c.File.SplitNum == 1 {
		if c.OutputOption.Compression == "gzip" {
			if withOutExt == "" {
				format = "%s%s.gz"
			} else {
				format = "%s.%s.gz"
			}
		} else {
			if withOutExt == "" {
				format = "%s%s"
			} else {
				format = "%s.%s"
			}
		}
		return fmt.Sprintf(
			format,
			withOutExt,
			ext,
		)
	}

	// 連番付きの場合
	if c.OutputOption.Compression == "gzip" {
		if withOutExt == "" {
			format = "%s-%s.gz"
			return fmt.Sprintf(
				format,
				ext,
				serialNumberFmt,
			)
		} else {
			format = "%s-%s.%s.gz"
		}
	} else {
		if withOutExt == "" {
			format = "%s%s.%s"
		} else {
			format = "%s-%s.%s"
		}
	}
	return fmt.Sprintf(
		format,
		withOutExt,
		serialNumberFmt,
		ext,
	)
}
