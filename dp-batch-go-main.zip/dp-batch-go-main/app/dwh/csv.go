package dwh

import (
	"encoding/csv"
	"fmt"
	"io"
	"strings"

	"golang.org/x/text/encoding/japanese"
	"golang.org/x/text/transform"
)

type CSVWriter struct {
	w *csv.Writer
	c *Config
}

func (w *CSVWriter) Write(p []byte) (n int, err error) {
	recordSize := int(w.c.File.RecordSize)

	// 1行ずつ書き込む
	for i := 0; i < len(p); i += recordSize {
		record := p[i : i+recordSize]
		// 固定長レコードを分割して配列にする
		columns := make([]string, 0, len(w.c.Columns))
		for _, colCfg := range w.c.Columns {
			col := string(record[colCfg.Start-1 : colCfg.Start+colCfg.Size-1])

			switch w.c.OutputOption.Encoding {
			case "UTF-8":

				switch w.c.InputOption.Encoding {
				case "ShiftJIS":
					// Shift-JISからUTF-8に変換
					decoded, _, err := transform.String(japanese.ShiftJIS.NewDecoder(), col)
					if err != nil {
						return 0, err
					}
					col = strings.TrimSpace(decoded)
				case "EUC-JP":
					// EUC-JPからUTF-8に変換
					decoded, _, err := transform.String(japanese.EUCJP.NewDecoder(), col)
					if err != nil {
						return 0, err
					}
					col = strings.TrimSpace(decoded)
				case "UTF-8":
					col = strings.TrimSpace(col)

				default:
					return 0, fmt.Errorf("invalid input encoding option: %s", w.c.InputOption.Encoding)
				}

			default:
				return 0, fmt.Errorf("invalid output encoding option: %s", w.c.OutputOption.Encoding)
			}

			columns = append(columns, col)
		}
		w.w.Write(columns)
	}
	w.w.Flush()
	return len(p), nil
}

func NewCSVWriter(w io.Writer, config *Config) *CSVWriter {
	return &CSVWriter{
		w: csv.NewWriter(w),
		c: config,
	}
}
