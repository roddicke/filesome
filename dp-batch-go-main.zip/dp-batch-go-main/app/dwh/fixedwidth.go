package dwh

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"encoding/csv"
	"io"
	"log"
	"os"
)

/*
CSV -> 固定長ファイルにエンコードする
*/

type FixedWidthWriter struct {
	src    *os.File
	dst    *string
	config *Config
}

func (w *FixedWidthWriter) Write(p []byte) (n int, err error) {
	return len(p), nil
}

func (w *FixedWidthWriter) Convert() {
	gzipReader, err := gzip.NewReader(w.src)
	// gzip判定処理
	if err == io.EOF {
		log.Fatal("インプットファイルはgzip形式のみサポートしています(0バイトファイルは例外)")
	}
	defer gzipReader.Close()
	target, err := os.Create(*w.dst)
	writer := bufio.NewWriter(target)
	if err != nil {
		log.Fatal(err)
	}
	//sjisWriter := bufio.NewCSVWriter(transform.NewCSVWriter(target, japanese.ShiftJIS.NewEncoder()))
	defer target.Close()
	reader := csv.NewReader(gzipReader)
	coverter := SjisConveter{}
	var line []string
	for {
		line, err = reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			log.Fatal(err)
			break
		}
		for idx, col := range line {
			if err != nil {
				log.Fatal(err)
			}
			// UTF-8からShift-jisに変換
			//var byte_buf bytes.Buffer//
			byte_buf := bytes.NewBuffer(make([]byte, 0, len(col)))
			sjis := ""
			for _, r := range col {
				sjis += coverter.ConvertFromUTF8(string(r))
			}
			byte_buf.WriteString(sjis)
			if err != nil {
				log.Fatal(err)
			}
			padding := w.config.Columns[idx].Size - len(sjis)
			// 左寄せパディング
			if w.config.Columns[idx].Adjust == "left" {
				// 符号あり
				for i := 0; i < padding; i++ {
					byte_buf.WriteString(w.config.Columns[idx].Padding)
				}
				writer.WriteString(byte_buf.String())
				continue
			}
			// 右寄せパディング
			if w.config.Columns[idx].Adjust == "right" {
				var value = ""
				// 数値符号あり
				if w.config.Columns[idx].Sign {
					if string(col[0]) == "-" {
						value += "-"
						padding += 1
					} else {
						value += "+"
					}
					for i := 0; i < padding-1; i++ {
						value += w.config.Columns[idx].Padding
					}
					if string(value[0]) == "-" {
						value += string(col[1:])
					} else {
						value += string(col)
					}
					writer.WriteString((value))
					continue
				}
				// その他右寄せ
				for i := 0; i < padding; i++ {
					value += w.config.Columns[idx].Padding
				}
				value += col
				writer.WriteString(value)
				continue
			}
		}
		// todo 改行コードの切り替え
		if w.config.OutputOption.Newline == "LF" {
			writer.WriteString("\n")
		} else {
			writer.WriteString("\r\n")
		}
		writer.Flush()
		// break
	}
}

func NewFixedWidthWriter(file *os.File, w *string, config *Config) *FixedWidthWriter {
	return &FixedWidthWriter{
		src:    file,
		dst:    w,
		config: config,
	}
}
