package dwh

import (
	"io"
)

type FixedBufWriter struct {
	err error
	buf []byte
	n   int
	wr  io.Writer
}

func (b *FixedBufWriter) Write(p []byte) (nn int, err error) {
	for len(p) > b.Available() && b.err == nil {
		n := copy(b.buf[b.n:], p)
		b.n += n
		b.Flush()
		nn += n
		p = p[n:]
	}
	if b.err != nil {
		return nn, b.err
	}
	n := copy(b.buf[b.n:], p)
	b.n += n
	nn += n
	return nn, nil
}

func (b *FixedBufWriter) Flush() error {
	if b.err != nil {
		return b.err
	}
	if b.n == 0 {
		return nil
	}
	n, err := b.wr.Write(b.buf[0:b.n])
	//log.Printf("Writed %d byte data...\n", n)

	if n < b.n && err == nil {
		err = io.ErrShortWrite
	}
	if err != nil {
		if n > 0 && n < b.n {
			copy(b.buf[0:b.n-n], b.buf[n:b.n])
		}
		b.n -= n
		b.err = err
		return err
	}
	b.n = 0
	return nil
}

// Available returns how many bytes are unused in the buffer.
func (b *FixedBufWriter) Available() int { return len(b.buf) - b.n }

func NewFixedBufWriter(w io.Writer, size int) *FixedBufWriter {
	return &FixedBufWriter{
		buf: make([]byte, size),
		wr:  w,
	}
}
