package dwh

import (
	"encoding/hex"
	"fmt"
	"strconv"
	"testing"

	"golang.org/x/text/encoding/japanese"
	"golang.org/x/text/transform"
)

func TestConvertFromSjisToUTF8(t *testing.T) {
	g := SjisConveter{}
	decoded, _ := hex.DecodeString("ee8080")
	fmt.Println(strconv.ParseInt("ee8080", 16, 64))
	fmt.Println(strconv.ParseInt("ee9d97", 16, 64))
	g.ConvertFromUTF8(string(decoded))
	sjis_gaiji := []byte{240, 93}
	fmt.Println(hex.EncodeToString(sjis_gaiji))
	result, _, _ := transform.String(japanese.ShiftJIS.NewDecoder(), string(sjis_gaiji))
	fmt.Println(hex.EncodeToString([]byte(result)))
	// 外字領域以外のUTF8 -> sjis 変換
}
