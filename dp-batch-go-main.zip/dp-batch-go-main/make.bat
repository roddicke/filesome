GOOS=windows GOARCH=amd64 go build -o bin/pre_go.exe cmd/pre/main.go
GOOS=windows GOARCH=amd64 go build -o bin/post_go.exe cmd/post/main.go