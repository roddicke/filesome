module dp-batch-go

go 1.16

require (
	github.com/aws/aws-sdk-go v1.39.5
	github.com/aws/aws-sdk-go-v2 v1.6.0
	github.com/aws/aws-sdk-go-v2/config v1.3.0
	github.com/aws/aws-sdk-go-v2/feature/s3/manager v1.2.3
	github.com/aws/aws-sdk-go-v2/service/s3 v1.10.0
	github.com/google/go-cmp v0.5.6
	github.com/shopspring/decimal v1.3.1
	golang.org/x/text v0.3.6
)
