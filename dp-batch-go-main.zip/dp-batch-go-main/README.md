# Goバッチアプリケーション
実行アーキで動作するバッチバイナリを作成するGoプログラム集です。
Goプログラムをビルドしてバイナリ化したものをバッチサーバ、IF GWにデプロイします。

## 含まれるアプリケーション
- S3の固定長のテキストファイルをストリーミングで読み込み、CSVへの変換、文字コード変換、gzip圧縮をした後S3に出力するプログラム
  - `cmd/dwh/pre`
  - `cmd/dwh/post`
- CFAS 650/680 の処理を行うプログラム
  - `cmd/cfas`

## 実行
```shell
go run cmd/.../main.go
```

## ビルド
### Unix
```sh
make build ## for unix
make build-windows ## for windows
```

### Windows
```
make_on_windows.bat
```

## 開発環境
- Go version 1.16.9+

### コーディング規約
規約だけだと、漏れが生じることがあるので、linterとformatterを活用。このプロジェクトでは下記のツールを利用する。

- linter: [staticcheck](https://staticcheck.io/docs/install)
- formatter: gofmt

コードをコミットする前に、linterとformatterでファイルを検疫すること。
おすすめはIDEのFile Watcher機能などを活用してファイルセーブ時に自動で走らせること。
もしくは `make check` をコミット前に実行すること。

### ディレクトリ構成
#### `/cmd`
`main.go` を配置する。

ユニットテストのしやすさを重視するため、この `main.go` にはビジネスロジックは書かないこと。
`main.go` の責務はコマンドライン引数を解析することと、ビジネスロジックを呼び出すこと。

#### `/app`
各バッチアプリケーションを配置する。

`app`配下のディレクトリ構成は基本的に領域ごとに区切り（`dwh`や`cfas`など）、
共通化できそうな部分は `common` など共通化ディレクトリを作成して入れる。

アプリケーションソースコードは必ずユニットテストを行うこと！！！！！！！。

参考文献：[テスト公式ドキュメント](https://pkg.go.dev/testing)

#### `/testdata`
テストデータで活用するデータを配置する。