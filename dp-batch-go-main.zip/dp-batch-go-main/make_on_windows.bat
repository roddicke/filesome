go build -o bin/pre_go.exe cmd/dwh/pre/main.go
go build -o bin/post_go.exe cmd/dwh/post/main.go