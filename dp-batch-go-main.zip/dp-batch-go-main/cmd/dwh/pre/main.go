/*
ファイルロード前処理​
Snowflakeへロード可能な形式にフォーマット変換​
固定長⇒CSV、ファイル分割​
文字コード／圧縮形式変換​
*/
package main

import (
	"bytes"
	"compress/gzip"
	"context"
	"dp-batch-go/app/dwh"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"os"
	"sync"

	"github.com/aws/aws-sdk-go-v2/aws"
	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/feature/s3/manager"
	"github.com/aws/aws-sdk-go-v2/service/s3"
)

func init() {
	// 時刻と時刻のマイクロ秒、ディレクトリパスを含めたファイル名を出力
	log.SetFlags(log.Ltime | log.Lmicroseconds | log.Llongfile)
}

func main() {
	f := flag.String("c", "pre_config.json", "configファイルパス")
	landingBucket := flag.String("lb", "", "landingバケット名")
	stagingBucket := flag.String("sb", "", "stagingバケット名")
	inputKey := flag.String("i", "", "インプットs3key名")
	outputKey := flag.String("o", "", "アウトプットs3key名")
	split_num := flag.Int64("s", 1, "ファイル分割")
	flag.Parse()
	// csv-format読み込み
	configFile, err := os.Open(*f)
	if err != nil {
		log.Fatalln("cannot open csv-format file: ", err)
	}
	defer configFile.Close()
	csvFormatString, err := io.ReadAll(configFile)
	if err != nil {
		log.Fatalln("cannot read csv-format file: ", err)
	}
	csvConfig := dwh.Config{}
	if err := json.Unmarshal(csvFormatString, &csvConfig); err != nil {
		log.Fatalln("cannot parse csv-format: ", err)
	}
	csvConfig.File.LandingBucket = *landingBucket
	csvConfig.File.StagingBucket = *stagingBucket
	csvConfig.File.InputKey = *inputKey
	csvConfig.File.OutputKey = *outputKey
	csvConfig.File.SplitNum = *split_num

	// AWS config
	awsConfig, err := awsconfig.LoadDefaultConfig(context.TODO())
	if err != nil {
		log.Fatalln("cannot load AWS config: ", err)
	}
	s3Client := s3.NewFromConfig(awsConfig)
	// インプットファイルサイズを取得
	resp, err := s3Client.HeadObject(context.TODO(), &s3.HeadObjectInput{
		Bucket: aws.String(csvConfig.File.LandingBucket),
		Key:    aws.String(csvConfig.File.InputKey),
	})
	if err != nil {
		log.Fatalln("cannot find inputfile: ", err)
	}
	// 並列で変換
	var wg sync.WaitGroup
	var fileSize int64 = resp.ContentLength
	// 0件ファイルの場合はS3に空ファイルを連携する。
	if fileSize == 0 {
		// 0件ファイルは分割できないので分割しない扱いにする。
		csvConfig.File.SplitNum = 1
		outFileKey := csvConfig.OutputFileFormat()
		sendBlankFile(&csvConfig, s3Client, outFileKey)
		return
	}
	var splitSize int64 = (fileSize/csvConfig.File.RecordSize/csvConfig.File.SplitNum + 1) * csvConfig.File.RecordSize
	var i int64
	for i = 0; i < fileSize; i += splitSize {
		wg.Add(1)
		// 分割しないときはファイル名に連番をつけない
		if csvConfig.File.SplitNum == 1 {
			outFileKey := csvConfig.OutputFileFormat()
			go convert(&csvConfig, s3Client, i, i+splitSize-1, outFileKey, &wg)
			continue
		}
		outFileKey := fmt.Sprintf(csvConfig.OutputFileFormat(), i/splitSize)
		go convert(&csvConfig, s3Client, i, i+splitSize-1, outFileKey, &wg)
	}

	wg.Wait()
}

func convert(
	csvConfig *dwh.Config,
	s3Client *s3.Client,
	readFrom int64,
	readTo int64,
	outFileKey string,
	wg *sync.WaitGroup) {

	defer wg.Done()
	pr, pw := io.Pipe()

	subWg := &sync.WaitGroup{}
	subWg.Add(2)

	// Run downloader
	go func() {
		defer func() {
			pw.Close()
			subWg.Done()
		}()

		var gw *gzip.Writer
		var cw *dwh.CSVWriter

		if csvConfig.OutputOption.Compression == "gzip" {
			// gzip形式のWriter作成
			var err error
			gw, err = gzip.NewWriterLevel(pw, gzip.BestSpeed)
			if err != nil {
				log.Fatalln("cannot create writer level: ", err)
			}
			defer gw.Close()
		}

		if csvConfig.OutputOption.Compression == "gzip" {
			cw = dwh.NewCSVWriter(gw, csvConfig)
		} else {
			cw = dwh.NewCSVWriter(pw, csvConfig)
		}

		bw := dwh.NewFixedBufWriter(cw, int(csvConfig.File.RecordSize)*10)

		resp, err := s3Client.GetObject(context.TODO(), &s3.GetObjectInput{
			Bucket: aws.String(csvConfig.File.LandingBucket),
			Key:    aws.String(csvConfig.File.InputKey),
			Range:  aws.String(fmt.Sprintf("bytes=%d-%d", readFrom, readTo)),
		})
		if err != nil {
			log.Fatalln("cannot download a object: ", err)
		}
		_, err = io.Copy(bw, resp.Body)
		if err != nil {
			log.Fatalln(err)
		}

		bw.Flush()
	}()

	// Run uploader
	uploader := manager.NewUploader(s3Client)
	go func() {
		defer func() {
			pr.Close()
			subWg.Done()
		}()
		if _, err := uploader.Upload(context.TODO(), &s3.PutObjectInput{
			Bucket: aws.String(csvConfig.File.StagingBucket),
			Key:    aws.String(outFileKey),
			Body:   pr,
		}); err != nil {
			log.Fatalln("cannot upload a object: ", err)
		}

		// // ファイルに出力する場合
		// out, err := os.Create(outFileKey)
		// if err != nil {
		// 	log.Fatalln("cannot create output file: ", err)
		// }
		// defer out.Close()
		// io.Copy(out, pr)
	}()

	subWg.Wait()
}

func compress(r io.Reader) (*bytes.Buffer, error) {
	buf := new(bytes.Buffer)
	gw, err := gzip.NewWriterLevel(buf, gzip.BestCompression)
	if err != nil {
		return buf, err
	}
	defer gw.Close()

	if _, err := io.Copy(gw, r); err != nil {
		return buf, err
	}
	return buf, nil
}

func sendBlankFile(csvConfig *dwh.Config, s3Client *s3.Client, outFileKey string) {
	tmpFile, _ := ioutil.TempFile("", "tmptest")
	defer os.Remove(tmpFile.Name())
	if csvConfig.OutputOption.Compression == "gzip" {
		// gzip形式のWriter作成
		gr, err := compress(bytes.NewBufferString(""))
		if err != nil {
			log.Fatalln("cannnot compress gzip file", err)
		}
		uploader := manager.NewUploader(s3Client)
		if _, err := uploader.Upload(context.TODO(), &s3.PutObjectInput{
			Bucket: aws.String(csvConfig.File.StagingBucket),
			Key:    aws.String(outFileKey),
			Body:   gr,
		}); err != nil {
			log.Fatalln("cannot upload a object: ", err)
		}
		return
	}

	uploader := manager.NewUploader(s3Client)
	if _, err := uploader.Upload(context.TODO(), &s3.PutObjectInput{
		Bucket: aws.String(csvConfig.File.StagingBucket),
		Key:    aws.String(outFileKey),
		Body:   tmpFile,
	}); err != nil {
		log.Fatalln("cannot upload a object: ", err)
	}
}
