/*
ファイルエクスポート後処理​
他シスが要求する形式にフォーマット変換​
ファイル結合、CSV→固定長​
他シスが要求する形式にフォーマット変換​
​*/

package main

import (
	"archive/zip"
	"context"
	"crypto/rand"
	"dp-batch-go/app/dwh"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/feature/s3/manager"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/aws/aws-sdk-go-v2/service/s3/types"
)

type File struct {
	Path string
	Size int64
}

type FileList []File

func (f FileList) Len() int {
	return len(f)
}
func (f FileList) Swap(i, j int) {
	f[i], f[j] = f[j], f[i]
}

type BySizeDesc struct {
	FileList
}

func (b BySizeDesc) Less(i, j int) bool {
	return b.FileList[i].Size > b.FileList[j].Size
}

func init() {
	// 時刻と時刻のマイクロ秒、ディレクトリパスを含めたファイル名を出力
	log.SetFlags(log.Ltime | log.Lmicroseconds | log.Llongfile)
}

func main() {
	f := flag.String("c", "post_config.json", "configファイルパス")
	// コマンドライン引数からのオーバーライド
	exportBucket := flag.String("eb", "", "exportバケット名")
	sendingBucket := flag.String("sb", "", "sendingバケット名")
	inputKey := flag.String("i", "", "インプットs3key名")
	outputKey := flag.String("o", "", "アウトプットs3key名")
	tempFileDir := flag.String("t", "", "一時ファイルディレクトリ")
	flag.Parse()

	// csv-format読み込み
	configFile, err := os.Open(*f)
	if err != nil {
		log.Fatalln("cannot open csv-format file: ", err)
	}
	defer configFile.Close()
	csvFormatString, err := io.ReadAll(configFile)
	if err != nil {
		log.Fatalln("cannot read csv-format file: ", err)
	}
	csvConfig := dwh.Config{}
	if err := json.Unmarshal(csvFormatString, &csvConfig); err != nil {
		log.Fatalln("cannot parse csv-format: ", err)
	}
	csvConfig.File.ExportBucket = *exportBucket
	csvConfig.File.SendingBucket = *sendingBucket
	csvConfig.File.InputKey = *inputKey
	csvConfig.File.OutputKey = *outputKey
	csvConfig.File.TempFileDir = *tempFileDir
	// AWS config
	awsConfig, err := awsconfig.LoadDefaultConfig(context.TODO())
	if err != nil {
		log.Fatalln("cannot load AWS config: ", err)
	}
	s3Client := s3.NewFromConfig(awsConfig)
	downloadFileList := []File{}
	// download
	paginator := s3.NewListObjectsV2Paginator(s3Client, &s3.ListObjectsV2Input{
		Bucket: aws.String(csvConfig.File.ExportBucket),
		Prefix: aws.String(csvConfig.File.InputKey),
	})
	var wg sync.WaitGroup
	for paginator.HasMorePages() {
		page, err := paginator.NextPage(context.Background())
		if err != nil {
			log.Fatalln(err)
		}
		Ch := make(chan File, 1000)
		count := 0
		for _, obj := range page.Contents {
			// フォルダ情報は除外する
			if strings.HasSuffix(*obj.Key, "/") {
				continue
			}
			if err != nil {
				log.Fatalln(err)
			}
			wg.Add(1)
			go download(&csvConfig, s3Client, *obj.Key, Ch, &wg)
			count++
		}
		for i := 0; i < count; i++ {
			downloadFileList = append(downloadFileList, <-Ch)
		}
	}
	wg.Wait()
	// convert
	Ch := make(chan File, 1000)
	count1 := 0
	convertFileList := []File{}
	for _, f := range downloadFileList {
		wg.Add(1)
		go convert(&csvConfig, f.Path, Ch, &wg)
		count1++
	}
	for i := 0; i < count1; i++ {
		convertFileList = append(convertFileList, <-Ch)
	}
	wg.Wait()
	// zip圧縮の時はファイルを連結する。
	if csvConfig.OutputOption.Compression == "zip" {
		files := make([]io.Reader, len(convertFileList))
		for i, file := range convertFileList {
			files[i], _ = os.Open(file.Path)
		}
		reader := io.MultiReader(files...)
		zipfilename := filepath.Base(csvConfig.File.OutputKey[:len(csvConfig.File.OutputKey)-len(filepath.Ext(csvConfig.File.OutputKey))])
		random, _ := MakeRandomStr(20)
		archivePath := fmt.Sprintf("%s/%s", csvConfig.File.TempFileDir, random)
		archive, err := os.Create(archivePath)
		if err != nil {
			log.Fatalln(err)
		}
		defer archive.Close()
		zipWriter := zip.NewWriter(archive)
		defer zipWriter.Close()
		w, err := zipWriter.Create(fmt.Sprintf("%s.dat", zipfilename))
		if err != nil {
			log.Fatalln(err)
		}
		if _, err := io.Copy(w, reader); err != nil {
			log.Fatalln(err)
		}
		zipWriter.Close()
		archiveFile := File{Path: archivePath}
		convertFileList = []File{archiveFile}
	}

	// upload
	sort.Sort(BySizeDesc{convertFileList})
	expiryDate := time.Now().AddDate(0, 0, 1)
	createResp, err := s3Client.CreateMultipartUpload(context.TODO(), &s3.CreateMultipartUploadInput{
		Bucket:  aws.String(csvConfig.File.SendingBucket),
		Key:     aws.String(csvConfig.File.OutputKey),
		Expires: &expiryDate,
	})
	if err != nil {
		log.Fatalln(err)
	}
	completedParts := []types.CompletedPart{}
	compCh := make(chan types.CompletedPart, 10)
	count := 0
	for idx, f := range convertFileList {
		wg.Add(1)
		go part_upload(s3Client, createResp, f.Path, int32(idx), compCh, &wg)
		count++
	}
	for i := 0; i < count; i++ {
		completedParts = append(completedParts, <-compCh)
	}
	wg.Wait()
	// partnumber順に並べないとエラーになります。
	sort.Slice(completedParts, func(i, j int) bool { return completedParts[i].PartNumber < completedParts[j].PartNumber })
	resp, err := s3Client.CompleteMultipartUpload(context.TODO(), &s3.CompleteMultipartUploadInput{
		Bucket:   createResp.Bucket,
		Key:      createResp.Key,
		UploadId: createResp.UploadId,
		MultipartUpload: &types.CompletedMultipartUpload{
			Parts: completedParts,
		},
	})
	if err != nil {
		log.Fatalln(err)
	}
	fmt.Println(resp.Key)
}

func download(csvConfig *dwh.Config, s3Client *s3.Client, key string, txtCh chan<- File, wg *sync.WaitGroup) {
	defer wg.Done()
	downloader := manager.NewDownloader(s3Client)
	random, _ := MakeRandomStr(20)
	download_file_path := fmt.Sprintf("%s/%s", csvConfig.File.TempFileDir, random)
	file, _ := os.Create(download_file_path)
	defer func() {
		err := file.Close()
		if err != nil {
			log.Fatalln(err)
		}
	}()
	_, err := downloader.Download(context.Background(), file, &s3.GetObjectInput{
		Bucket: aws.String(csvConfig.File.ExportBucket),
		Key:    aws.String(key),
	})
	if err != nil {
		log.Fatalln(err)
	}
	// ファイル情報取得
	fileinfo, err := file.Stat()
	if err != nil {
		log.Fatalln(err)
		return
	}
	// ファイルサイズを表示
	downloadFile := File{
		Path: download_file_path,
		Size: fileinfo.Size(),
	}
	txtCh <- downloadFile
}

func convert(csvConfig *dwh.Config, file_path string, ch chan<- File, wg *sync.WaitGroup) {
	defer wg.Done()
	src, err := os.Open(file_path)
	defer func() {
		err := src.Close()
		if err != nil {
			log.Fatalln(err)
		}
	}()
	if err != nil {
		log.Fatalln(err)
	}
	random, _ := MakeRandomStr(20)
	convert_file_path := fmt.Sprintf("%s/%s", csvConfig.File.TempFileDir, random)
	//dst, err := os.Create(convert_file_path)
	// 空ファイルの場合はコンバートしないのでそのまま転送する
	fileinfo, err := src.Stat()
	if err != nil {
		log.Fatalln(err)
		return
	}
	if fileinfo.Size() == 0 {
		os.Create(convert_file_path)
		convertFile := File{
			Path: convert_file_path,
			Size: 0,
		}
		ch <- convertFile
	} else {
		fw := dwh.NewFixedWidthWriter(src, &convert_file_path, csvConfig)
		fw.Convert()
		file, err := os.Open(convert_file_path)
		defer func() {
			err := file.Close()
			if err != nil {
				log.Fatalln(err)
			}
		}()
		if err != nil {
			log.Fatalln(err)
			return
		}
		fileinfo, err := file.Stat()
		if err != nil {
			log.Fatalln(err)
		}
		convertFile := File{
			Path: convert_file_path,
			Size: fileinfo.Size(),
		}
		ch <- convertFile
	}
}

func part_upload(s3Client *s3.Client, resp *s3.CreateMultipartUploadOutput, file_path string, idx int32, compCh chan<- types.CompletedPart, wg *sync.WaitGroup) {
	defer wg.Done()
	file, err := os.Open(file_path)
	defer func() {
		err := file.Close()
		if err != nil {
			log.Fatalln(err)
		}
	}()

	if err != nil {
		log.Fatalln(err)
	}
	stats, _ := file.Stat()
	fileSize := stats.Size()
	uploadResp, err := s3Client.UploadPart(context.TODO(), &s3.UploadPartInput{
		Body:          file,
		Bucket:        resp.Bucket,
		Key:           resp.Key,
		PartNumber:    idx + 1,
		UploadId:      resp.UploadId,
		ContentLength: fileSize,
	})
	if err != nil {
		log.Fatalln(err)
	}
	compCh <- types.CompletedPart{ETag: uploadResp.ETag, PartNumber: idx + 1}
}

func MakeRandomStr(digit uint32) (string, error) {
	const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	// 乱数を生成
	b := make([]byte, digit)
	if _, err := rand.Read(b); err != nil {
		return "", errors.New("unexpected error")
	}
	// letters からランダムに取り出して文字列を生成
	var result string
	for _, v := range b {
		// index が letters の長さに収まるように調整
		result += string(letters[int(v)%len(letters)])
	}
	return result, nil
}
