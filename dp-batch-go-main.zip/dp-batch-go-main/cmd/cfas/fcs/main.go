package main

import (
	"flag"
	"os"

	app "dp-batch-go/app/cfas/fcs"
	"dp-batch-go/app/cfas/repository"
	"dp-batch-go/app/logger"
)

func main() {
	// Note: 人が叩くわけではないので、parserは用意しない
	args := os.Args[1:]
	if len(args) != 6 {
		logger.Log.Errorf("コマンドライン引数が足りません。必要な引数はソースコードを読んでください。")
		logger.Log.Errorf("読み取れた引数: %v", args)
		os.Exit(1)
	}

	batchDate := args[0]
	filePaths := args[1:]

	fp := repository.NewAWSS3CSVFileRepository()
	b := app.NewBatchManager(fp)

	err := b.Execute(batchDate, filePaths)
	if err != nil && err != flag.ErrHelp {
		logger.Log.Errorf("%v", err)
		os.Exit(1)
	}
}
