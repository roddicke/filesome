
set ADT_HOME=\\amznfsxoywjevan.resource.jp.nomura.com\share\prd\dp-batch-framework\
python %ADT_HOME%batch_architecture\command.py run %1 --env prd --sys %2
