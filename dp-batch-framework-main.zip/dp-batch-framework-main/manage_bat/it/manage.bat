
set ADT_HOME=\\amznfsxmn5gji5j.resource.jp.nomura.com\share\it\dp-batch-framework\
python %ADT_HOME%batch_architecture\command.py run %1 --env it --sys %2
