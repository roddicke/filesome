
set ADT_HOME=\\amznfsxlpc8c1hs.resource.jp.nomura.com\share\it-feature-01\dp-batch-framework\
python %ADT_HOME%batch_architecture\command.py run %1 --env it_y_feature_01 --sys %2
