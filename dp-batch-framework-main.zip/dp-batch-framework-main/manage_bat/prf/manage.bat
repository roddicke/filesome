
set ADT_HOME=\\amznfsxoywjevan.resource.jp.nomura.com\share\prf\dp-batch-framework\
python %ADT_HOME%batch_architecture\command.py run %1 --env prf --sys %2
