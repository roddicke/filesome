
set ADT_HOME=\\amznfsxmn5gji5j.resource.jp.nomura.com\share\dev\dp-batch-framework\
python %ADT_HOME%batch_architecture\command.py run %1 --env dev --sys %2
