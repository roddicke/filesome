
set ADT_HOME=\\amznfsxoywjevan.resource.jp.nomura.com\share\stg\dp-batch-framework\
python %ADT_HOME%batch_architecture\command.py run %1 --env stg --sys %2
