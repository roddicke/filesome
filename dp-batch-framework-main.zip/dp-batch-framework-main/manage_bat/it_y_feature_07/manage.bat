
set ADT_HOME=\\amznfsxlpc8c1hs.resource.jp.nomura.com\share\it-feature-07\dp-batch-framework\
python %ADT_HOME%batch_architecture\command.py run %1 --env it_y_feature_07 --sys %2
