
set ADT_HOME=\\amznfsxhffsuffr.resource.jp.nomura.com\share\stg-feature-08\dp-batch-framework\
python %ADT_HOME%batch_architecture\command.py run %1 --env stg_y_feature_08 --sys %2
