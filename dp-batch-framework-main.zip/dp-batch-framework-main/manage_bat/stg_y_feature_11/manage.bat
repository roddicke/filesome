
set ADT_HOME=\\amznfsxhffsuffr.resource.jp.nomura.com\share\stg-feature-11\dp-batch-framework\
python %ADT_HOME%batch_architecture\command.py run %1 --env stg_y_feature_11 --sys %2
