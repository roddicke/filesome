from setuptools import setup

with open("requirements.txt") as f:
    requirements = f.read().splitlines()

setup(
    name="batch_architecture",
    version="0.0.1",
    install_requires=requirements,
    packages=[
        "batch_architecture",
        "batch_architecture.client",
        "batch_architecture.core",
        "batch_architecture.io_target",
        "batch_architecture.logic",
        "batch_architecture.model",
        "batch_architecture.etl",
    ],
    entry_points="""
      [console_scripts]
      adt = batch_architecture.command:cmd
      """,
)
