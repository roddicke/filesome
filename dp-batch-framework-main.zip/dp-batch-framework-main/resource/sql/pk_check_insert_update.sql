
insert into NSDWH.PUBLIC.pk_check_insert
(test_id, test_name)
values(2,4)
;
--split_point
update NSDWH.PUBLIC.pk_check_update
set test_update_name = 3
where test_update_id =1
;
