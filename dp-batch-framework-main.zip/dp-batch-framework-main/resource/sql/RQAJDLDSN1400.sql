-- IF受信日付
SET ifJshnYmd = 20211015;
-- 処理対象日付
SET shoriTaishoYmd = 20211015;
-- データソースID
SET dataSourceId = 'RQA';

// 洗替ということで一旦 TRUNCATE する
TRUNCATE TABLE IF EXISTS NSDWH.PUBLIC.CA0SN041;
COPY INTO NSDWH.PUBLIC.CA0SN041 FROM
    (
    SELECT
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,
        $ifJshnYmd,
        $shoriTaishoYmd,
        TO_DECIMAL(TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDD')),
        TO_DECIMAL(TO_VARCHAR(CURRENT_TIMESTAMP(), 'HH24MISS')),
        $dataSourceId
    FROM
        @NSDP_STAGE_STAGING
    )
    PATTERN = '.*dp-batch-framework-test.RQAJDLDSN1400.*.csv'
    FILE_FORMAT = (FORMAT_NAME = NSDWH.PUBLIC.FILE_FORMAT_SJIS_LF_COMMA)
    ON_ERROR = ABORT_STATEMENT
;