"""
テンプレート
"""
import os
from batch_architecture.core.base import CustomScriptBase


class CustomScript(CustomScriptBase):

    _LOGGER_NAME = os.path.basename(__file__)

    def __init__(self):
        pass

    def main(self):
        """
        メインロジック
        """

        self.logger.info("test11111")
        print("test")
        pass


if __name__ == "__main__":
    pass
