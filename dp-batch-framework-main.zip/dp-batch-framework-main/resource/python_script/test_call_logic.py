"""
テンプレート
"""
import os
from batch_architecture.core.base import CustomScriptBase


class CustomScript(CustomScriptBase):

    _LOGGER_NAME = os.path.basename(__file__)

    def main(self, **kargs):
        """メインロジック"""
        print(kargs["table_id"])
        print(os)
        pass


if __name__ == "__main__":
    # テストスクリプト
    CustomScript().main(table_id=1)
    pass
