"""
エンコード・デコード ユーティリティ
"""
import codecs
import shutil


def convert_character_encoding(
        src_path, src_encoding,
        dst_path, dst_encoding, with_bom=False):
    """
    指定したファイルの文字コード変換する

    :param src_path: 展開元のパス
    :param src_encoding: 展開元のエンコーディング
    :param dst_path: 展開先のパス
    :param dst_encoding: 展開先のエンコーディング
    :param with_bom: BOM付与フラグ
    """
    src_codec = codecs.lookup(src_encoding)
    dst_codec = codecs.lookup(dst_encoding)

    with open(str(src_path), "rb") as s, open(str(dst_path), "wb") as dest:
        stream = codecs.StreamRecoder(
            s,
            dst_codec.encode,
            src_codec.decode,
            src_codec.streamreader,
            dst_codec.streamwriter,
        )
        # BOM付与
        if with_bom is True:
            dest.write(b"\xEF\xBB\xBF")

        shutil.copyfileobj(stream, dest)
