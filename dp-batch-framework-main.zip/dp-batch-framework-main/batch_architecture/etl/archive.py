"""
圧縮解凍ユーティリティ
"""
import os
import shutil
import time
import gzip
import tarfile
import zipfile

from batch_architecture.cmd.windows_cmd import WindowsCMD
from batch_architecture.core.log import Logger

LOGGER_NAME = "batch_architecture.etl.archive"

PATH_7Z = '"C:\\Program Files\\7-Zip\\7z.exe"'

logger = Logger.get_logger(LOGGER_NAME)


def _check_path(path, allow_none=False, allow_file=False, allow_dir=False):
    """
    指定されたパスが、オプションで指定された条件を満たしているかチェックする。

    :param path: チェック対象のパス
    :param allow_none: パスが存在しないことを許可する
    :param allow_file: パスがファイルであることを許可する
    :param allow_dir: パスがディレクトリであることを許可する
    """

    # パスとしてファイルもしくはディレクトリのみ許可する場合は以下のようにする
    # _check_path(path, allow_file=True, allow_dir=True)

    # TODO: io の処理とマージして削除する
    from batch_architecture.io_target import LocalTarget

    path = LocalTarget(path)
    path._check_path(allow_none=allow_none, allow_file=allow_file, allow_dir=allow_dir)
    return path._path


def archive_file(src, dst, include_path=False):
    """
    対象ファイルを圧縮する。

    :param src: 圧縮元のパス
    :param dst: 圧縮先のパス
    :param include_path: (zipのみ)ディレクトリ構造をアーカイブに含めるかどうか
    """
    src = _check_path(src, allow_file=True)
    src = str(src)
    dst = _check_path(dst, allow_file=True, allow_none=True)
    dst_suffix = dst.suffix.lower()
    dst_suffixes = "".join(dst.suffixes).lower()
    dst = str(dst)

    if dst_suffix == ".gz":
        if dst_suffixes == ".tar.gz":
            archive_files([src], dst)
        else:
            with open(src, mode="rb") as f_in:
                with gzip.open(str(dst), "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)

    elif dst_suffix == ".zip":
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as f:
            if include_path:
                f.write(src)
            else:
                f.write(src, os.path.basename(src))

    else:
        msg = (
            "出力先として指定されたファイル {0} に圧縮できません。" "出力先の拡張子は .tar.gz, .gz, .zip いずれかを指定してください"
        )
        raise ValueError(msg.format(dst))


def _gather_src(src):
    """
    指定されたパスに含まれるファイル・ディレクトリから、圧縮用のディレクトリ構造を設定する。

    :param src: 圧縮元のパス
    """
    src = _check_path(src, allow_dir=True)
    src = str(src)

    targets = []
    # walkでファイルを探す
    for dir_path, dir_names, file_names in os.walk(src):
        for filename in file_names:
            file_path = os.path.join(dir_path, filename)
            # 作成するzipファイルのパスと同じファイルは除外する
            if file_path != src:
                arc_name = os.path.relpath(file_path, str(src))
                targets.append((file_path, arc_name))
        for dir_name in dir_names:
            file_path = os.path.join(dir_path, dir_name)
            arc_name = os.path.relpath(file_path, str(src))
            targets.append((file_path, arc_name))
    return targets


def archive_files(src, dst):
    """
    指定されたファイルのリストを圧縮する。

    :param src: 圧縮するファイルのリスト
    :param dst: 圧縮先のパス
    """
    # 入力チェックは ._archive_files で行う
    assert isinstance(src, list)
    src = [(s, os.path.basename(str(s))) for s in src]
    return _archive_files(src, dst)


def _archive_files(src, dst):
    """
    指定されたファイルのリストを圧縮する。

    :param src: 圧縮するファイルのリスト
    :param dst: 圧縮先のパス
    """
    dst = _check_path(dst, allow_none=True)
    dst = str(dst)

    if dst.endswith(".tar.gz"):
        with tarfile.open(dst, "w:gz") as tar:
            for s, n in src:
                s = str(_check_path(s, allow_file=True, allow_dir=True))
                tar.add(s, n)

    elif dst.endswith(".gz"):
        msg = "複数のファイルを .gz 形式で圧縮することはできません。" "拡張子に .tar.gz を指定してください"
        raise ValueError(msg)

    elif dst.endswith(".zip"):
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as f:
            for s, n in src:
                # 圧縮対象はディレクトリ or ファイル
                s = str(_check_path(s, allow_file=True, allow_dir=True))
                f.write(s, n, zipfile.ZIP_DEFLATED)

    else:
        msg = (
            "出力先として指定されたファイル {0} に圧縮できません。" "出力先の拡張子は .tar.gz, .gz, .zip いずれかを指定してください"
        )
        raise ValueError(msg.format(dst))


def archive_dir(src, dst):
    """
    対象ディレクトリを圧縮する。

    圧縮ファイルは、内部に対象ディレクトリと同じ構造を含む。展開した際には
    圧縮元ファイルと同じファイル・サブディレクトリを持つ。

    :param src: 圧縮元のパス
    :param dst: 圧縮先のパス
    """
    # dst の入力チェックは ._archive_files で行う
    targets = _gather_src(src)
    return _archive_files(targets, dst)


def extract(src, dst):
    """
    指定した圧縮ファイルを解凍する。

    :param src: 展開元のパス
    :param dst: 展開先のパス
    """
    src = _check_path(src, allow_file=True)
    src_suffix = src.suffix.lower()
    src_suffixes = "".join(src.suffixes).lower()
    src = str(src)

    if src_suffix == ".zip":
        dst = _check_path(dst, allow_none=True, allow_dir=True)
        if not dst.exists():
            dst.mkdir()

        with zipfile.ZipFile(str(src), 'r') as zip:
            for info in zip.infolist():
                zip.extract(info, path=str(dst))

                # confirm exists
                dst_file = dst / info.filename
                for _ in range(10):
                    if dst_file.exists():
                        break
                    else:
                        time.sleep(1)

    elif src_suffixes == ".tar.gz":
        dst = _check_path(dst, allow_none=True, allow_dir=True)
        if not dst.exists():
            dst.mkdir()

        with tarfile.open(str(src), 'r:gz') as tar:
            for info in tar.getmembers():
                tar.extract(info, path=str(dst))

                # confirm exists
                dst_file = dst / info.name
                for _ in range(10):
                    if dst_file.exists():
                        break
                    else:
                        time.sleep(1)

    elif src_suffix == ".tar":
        dst = _check_path(dst, allow_none=True, allow_dir=True)
        if not dst.exists():
            dst.mkdir()

        shutil.unpack_archive(str(src), extract_dir=str(dst))

    elif src_suffix == ".gz":
        return _extract_gz(src, dst)
    elif src_suffix == ".z":
        return _extract_lzw(src, dst)
    else:
        msg = (
            "入力元として指定されたファイル {0} を解凍できません。"
            "入力元の拡張子は .tar.gz, .gz, .zip, .Z いずれかを指定してください"
        )
        raise ValueError(msg.format(src))


def _extract_gz(src, dst):
    """
    指定した gz ファイルを解凍する。

    gz ファイルは `shutil.unpack_archive` で解凍できないため、個別に処理する。

    :param src: 展開元のパス
    :param dst: 展開先のパス
    """

    # Pathlib.Path へ変換
    dst = _check_path(dst, allow_none=True, allow_file=True, allow_dir=True)
    if dst.is_dir():
        dst = dst / os.path.basename(src).rsplit(".", maxsplit=1)[0]
    if not dst.exists():
        # ファイルが存在しない場合は作成
        dst.touch()

    # この時点で dst は存在するファイルを指す
    dst = _check_path(dst, allow_file=True)
    with gzip.open(str(src), "rb") as gz:
        with dst.open(mode="wb") as dst_file:
            for line in gz:
                dst_file.write(line)


def _extract_lzw(src, dst):
    """
    指定した Z ファイルを解凍する。
    Z ファイルは `shutil.unpack_archive` で解凍できないため、個別に処理する。

    :param src: 展開元のパス
    :param dst: 展開先のパス
    """
    # Pathlib.Path へ変換
    dst = _check_path(dst, allow_none=True, allow_file=True, allow_dir=False)
    dst_dir = str(dst).rsplit('\\', 1)[0]

    cmd_str = f"{PATH_7Z} x -y -o{dst_dir} {src}"

    logger.info(cmd_str)
    cmd = WindowsCMD()
    _, sys_out, _ = cmd.execute(cmd_str)
    logger.info(sys_out)
