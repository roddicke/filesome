"""
ヘッダー削除・フッター削除・文字列置換・ファイル分割・ファイル結合・ファイルフォーマット変換
"""
import csv

from batch_architecture.io_target.base import Target


def remove_header(input, n):
    """
    ファイルの先頭から n 行削除する

    :param input: 入力ファイル
    :param n: ヘッダー行数
    :return:
    """
    for i in range(n):
        next(input)
    while True:
        try:
            yield next(input)
        except StopIteration:
            return


def remove_footer(input, n):
    """
    ファイルの末尾から n 行削除する

    :param input: 入力ファイル
    :param n: フッター行数
    :return:
    """
    lists = []
    for line in input:
        lists.append(line)
        if len(lists) > n:
            yield lists.pop(0)


def replace_line_sep(input, sep_before, sep_after):
    """
    特定の文字列を置換する

    :param input: 入力ファイル
    :param sep_before: 変換前の文字列
    :param sep_after: 変換後の文字列
    :return:
    """
    while True:
        yield next(input).replace(sep_before, sep_after)


def file_split(input, row_count):
    """
    ファイルを指定した行数で分割する

    :param input: 入力ファイル
    :param row_count: ファイルを分割する行数
    :return:
    """
    while True:
        lists = []
        for _ in range(row_count):
            try:
                lists.append(next(input))
            except StopIteration:
                if len(lists) > 0:
                    yield lists
                return
        yield lists


def convert_csv_format(input, input_format, output, output_format):
    """
    ファイルのフォーマットを変換する

    :param input: 入力ファイル
    :param input_format: 入力ファイルのフォーマットを示す辞書
    :param output: 出力ファイル
    :param output_format: 出力ファイルのフォーマットを示す辞書
    :return:
    """
    # if Target.parse(output).exists():
    #     msg = (
    #         "変換先ファイル {0} と同名のファイルが既に存在するため、ファイルをフォーマット変換できません。"
    #         "変換先ファイル名を変更するか、同名のファイルを削除してください".format(output)
    #     )
    #     raise FileExistsError(msg)
    inf = open(input, "r", encoding="utf-8", newline=input_format["lineterminator"])
    outf = open(output, "w", encoding="utf-8", newline=output_format["lineterminator"])
    with inf, outf:
        reader = csv.reader(inf, **input_format)
        writer = csv.writer(outf, **output_format)
        try:
            for row in reader:
                writer.writerow(row)
        except UnicodeError as e:
            msg = (
                    "指定した文字コードに変換することができません。input_format,output_formatの文字コードを変更してください\n"
                    + str(e)
            )
            outf.close()
            Target.parse(output).delete()
            raise UnicodeError(msg)
