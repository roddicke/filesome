"""
実行アーキのリソース設定を管理するクラス
"""
from batch_architecture.core.settings import Settings
from batch_architecture.core.log import Logger


class _Resources(object):
    def __init__(self, path=None):
        """
        リソース設定管理クラスを初期化する。

        :param path: リソース設定ファイルのパス
        """
        if path is None:
            self.path = Settings.conf_dir / "resources_{}.ini".format(Settings.ENV)

        config = Settings.parse_config(self.path)

        self._resources = {}

        for section in config.sections():
            if "type" in config[section]:
                try:
                    attrs = dict(config[section])
                    typ = attrs.pop("type")
                    r = self.load_resource(typ, attrs)
                    self._resources[section] = r
                except:
                    logger = Logger.get_logger(__name__)
                    logger.error('read error: %s: [%s]' % (self.path, section))
                    raise
            else:
                msg = """設定ファイルで指定されたセクション {section} にtype属性が指定されていません。\n{content}"""
                raise ValueError(msg.format(section=section, content=config[section]))

    def get(self, key):
        """
        リソース設定を取得する。

        :param key: リソース設定の識別名
        """
        return self._resources[key]

    def load_resource(self, typ, config):
        """
        リソース設定を初期化する。

        :param typ: リソース設定の種類
        :param config: 各リソース設定を初期化するオプション
        """
        if typ == "redshift":
            return RedshiftResource(**config)
        elif typ == "ftp":
            return FTPResource(**config)
        elif typ == "sftp":
            return SFTPResource(**config)
        elif typ == "smtp":
            return SMTPResource(**config)
        elif typ == "s3":
            return S3Resource(**config)
        elif typ == "repository":
            return
        elif typ == "sqlserver":
            return SQLServerResource(**config)
        elif typ == "postgresql":
            return PostgreSQLResource(**config)
        elif typ == "s3_bucket":
            return S3BucketResource(**config)
        elif typ == "sqs":
            return AWSSQSResource(**config)
        elif typ == "snowflake":
            return SnowflakeResource(**config)
        elif typ == "glue":
            return AWSGlueResource(**config)
        elif typ == "sts":
            return AWSSTSResource(**config)
        elif typ == "logs":
            return AWSLogsResource(**config)
        else:
            msg = "指定された type={} が不正です。"
            raise ValueError(msg.format(typ))


# サーバー共通のリソース


class FTPResource(object):
    """FTP リソース設定"""

    def __init__(self, host, username, password, port=21, act_mode="0"):
        self._host = host
        self._port = int(port)
        self._username = username
        self._password = password
        self._act_mode = act_mode


class SFTPResource(object):
    """SFTP リソース設定"""

    def __init__(self, username, password=None, private_key=None):
        self._username = username
        self._password = password
        self._private_key = private_key


class SMTPResource(object):
    """SMTP リソース設定"""

    def __init__(self, host, port=25, account=None, password=None):
        self._host = host
        self._port = port
        self._account = account
        self._password = password


class DataBaseResource(object):
    """DB リソース設定"""

    def __init__(self, dbname, username, password, port):
        self._dbname = dbname
        self._username = username
        self._password = password
        self._port = port


class RedshiftResource(DataBaseResource):
    """Redshift リソース設定"""

    pass


class S3Resource(object):
    """S3 Bucket リソース設定"""

    def __init__(
            self,
            account_id=None,
            kms_key_id=None,
            access_key_id=None,
            secret_access_key=None,
    ):
        self._account_id = account_id
        self._kms_key_id = kms_key_id
        self._access_key_id = access_key_id
        self._secret_access_key = secret_access_key


class EmbulkResource(object):
    """Embulkリソース設定"""

    def __init__(self, dicts):
        self._plugin_home = ""
        self._exports = ["export dummy=dummy"]
        for k, v in dicts:
            if k == "plugin_home":
                self._plugin_home = "-b {}".format(v)
                continue
            self._exports.append("export {}={}".format(k.replace("env.", ""), v))

    def get_exports_command(self):
        return ";".join(self._exports)

    def get_plugin_home(self):
        return self._plugin_home


class SnowflakeResource(object):
    """Snowflakeリソース設定"""

    def __init__(self, username, private_key_file, account, warehouse, database, schema):
        self._username = username
        self._private_key_file = private_key_file
        self._account = account
        self._warehouse = warehouse
        self._database = database
        self._schema = schema


class SQLServerResource(object):
    """SQLServerリソース設定"""

    def __init__(self, username, password, server, port, database):
        self._username = username
        self._password = password
        self._server = server
        self._port = port
        self._database = database


class PostgreSQLResource(object):
    """PostgreSQLリソース設定"""

    def __init__(self, host, dbname, user, password, port):
        self._host = host
        self._dbname = dbname
        self._user = user
        self._password = password
        self._port = port


class S3BucketResource(object):
    """S3 Bucketリソース設定"""

    def __init__(
            self,
            landing_internal,
            landing_external,
            backup,
            staging,
            datalake,
            audit,
            temporary,
            export,
            migration,
            rcs_bucket
    ):
        self._landing_internal = landing_internal
        self._landing_external = landing_external
        self._backup = backup
        self._staging = staging
        self._datalake = datalake
        self._audit = audit
        self._temporary = temporary
        self._export = export
        self._migration = migration
        self._rcs_bucket = rcs_bucket


class AWSSQSResource(object):
    def __init__(self, job_queue, region, endpoint_url):
        self.job_queue = job_queue
        self.region = region
        self.endpoint_url = endpoint_url


class AWSGlueResource(object):
    def __init__(self, region, endpoint_url):
        self.region = region
        self.endpoint_url = endpoint_url


class AWSSTSResource(object):
    def __init__(self, region, endpoint_url):
        self.region = region
        self.endpoint_url = endpoint_url


class AWSLogsResource(object):
    def __init__(self, region, endpoint_url):
        self.region = region
        self.endpoint_url = endpoint_url


Resources = _Resources()
