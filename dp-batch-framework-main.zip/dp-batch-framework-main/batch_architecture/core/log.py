"""
実行アーキ共通ログ機能
"""
import os
import pathlib
import datetime
from logging import getLogger, StreamHandler, FileHandler, Formatter, INFO, WARN, ERROR  # noqa

from batch_architecture.core.settings import Settings

"""
ログ出力について

* ロガーは各モジュール別に logging.getLogger(モジュール名) によって作成することで、
  それぞれのログがどのモジュールから出力されたかわかりやすくする (root ロガーは利用しない)

* ロガーは BusinessLogic に紐付けて管理する。client / common で発生した例外は
  BusinessLogicで補足されない場合のみ記録される
  （そのため、client / commonにてロギングを行う必要はない）

* ログ出力先は ログ出力ディレクトリ以下に job_id 別に作成
  その中で、通常のログとスタックトレースのダンプに分けて出力する

  * {job_id}_{yyyymmdd}.log : 全レベルのログ
  * {job_id}_{yyyymmdd}.trace : スタックトレースのダンプ (未実装)

"""


class FileHandlerErrorCatch(FileHandler):
    """
    書き込みエラーを検知するファイルハンドラ
    """

    def __init__(self, filename, mode='a', encoding=None, delay=False, errors=None):
        super().__init__(filename, mode, encoding, delay, errors)

    def handleError(self, record):
        super().handleError(record)

        print("restore handler")
        Logger.restore_handler(record)


class LoggerWrapper(object):
    def __init__(self, name):
        self._logger = getLogger(name)
        self._dynamic_handler = []

        self._set_cout = False

    def setLevel(self, level):
        self._logger.setLevel(level)

    def addHandler(self, handler):
        if not isinstance(handler, FileHandler):
            self._dynamic_handler.append(handler)
            if self._set_cout:
                self._logger.addHandler(handler)
        else:
            self._logger.addHandler(handler)

    def removeHandler(self, handler):
        self._logger.removeHandler(handler)
        if handler in self._dynamic_handler:
            self._dynamic_handler.remove(handler)

    def _update_handler(self, cout):
        if Settings.EXEC_MODE not in ('NORMAL', 'DRY_RUN'):
            cout = True

        if cout != self._set_cout:
            if cout:
                for handler in self._dynamic_handler:
                    self._logger.addHandler(handler)
            else:
                for handler in self._dynamic_handler:
                    self._logger.removeHandler(handler)
            self._set_cout = cout

    def debug(self, msg, *args, cout=False):
        self._update_handler(cout)
        self._logger.debug(msg)

    def info(self, msg, *args, cout=False):
        self._update_handler(cout)
        self._logger.info(msg)

    def warn(self, msg, *args):
        self.warning(msg, *args)

    def warning(self, msg, *args, cout=False):
        self._update_handler(cout)
        self._logger.warning(msg)

    def error(self, msg, *args):
        self._update_handler(True)
        self._logger.error(msg)

    def exception(self, e):
        self._update_handler(True)
        self._logger.exception(e)


class Logger(object):
    _FMT = "{0}_{1}_{2}_{3}.log"
    _FORMATTER = Formatter(
        "[%(asctime)s.%(msecs)03d] [%(name)s] [%(levelname)s] %(message)s"
    )
    _LEVEL = INFO

    _FILE_HANDLER = None
    _CONSOLE_HANDLER = None

    _loggers = []

    _job_id = None
    _node_name = None
    _not_cout = None

    @classmethod
    def get_logger(cls, name):
        """
        Logger 名を元に Logger インスタンスを返す。

        :param name: ロガーの名称、通常はモジュール名
        :return: ロガー
        """
        logger = LoggerWrapper(name)

        if cls._CONSOLE_HANDLER is not None:
            logger.addHandler(cls._CONSOLE_HANDLER)
        if cls._FILE_HANDLER is not None:
            logger.addHandler(cls._FILE_HANDLER)

        logger.setLevel(cls._LEVEL)
        cls._loggers.append(logger)
        return logger

    @classmethod
    def remove_console_handler(cls):
        for logger in cls._loggers:
            logger.removeHandler(cls._CONSOLE_HANDLER)
        cls._CONSOLE_HANDLER = None

    @classmethod
    def set_handler(cls, job_id, node_name, not_cout=False):
        """
        Logger に対し、job_id に対応した Handler を紐づける。

        Handler には BaseLog インスタンスを用いる。BaseLog はジョブ実行時に
        1度だけ初期化が必要なため、一度作成した Handler をクラス属性としてキャッシュする。

        :param logger: Logger インスタンス
        :param job_id: ジョブ ID
        :param node_name: ノード名
        :param not_cout: コンソール出力を行わないフラグ
        :return: ロガー
        """
        cls._job_id = job_id
        cls._node_name = node_name
        cls._not_cout = not_cout

        # clear handler
        for logger in cls._loggers:
            if cls._CONSOLE_HANDLER:
                logger.removeHandler(cls._CONSOLE_HANDLER)
            if cls._FILE_HANDLER:
                logger.removeHandler(cls._FILE_HANDLER)

        from batch_architecture.core.settings import Settings

        log_dir = pathlib.Path(Settings.LOG_DIR)
        # ログ出力先が存在しない場合は作成
        if not log_dir.exists():
            log_dir.mkdir()

        cur_time = datetime.datetime.today().strftime("%Y%m%d_%H%M%S_%f")
        log_file = log_dir / cls._FMT.format(job_id, cur_time, node_name, os.getpid())
        Settings.LOG_FILE_NAME = os.path.basename(log_file)

        # TODO: ログファイルの文字コードをオプション指定
        handler = FileHandlerErrorCatch(filename=str(log_file), mode="a", encoding="utf-8")
        handler.setFormatter(cls._FORMATTER)
        handler.setLevel(INFO)
        cls._FILE_HANDLER = handler

        if not_cout:
            cls._CONSOLE_HANDLER = None
        else:
            handler = StreamHandler()
            handler.setFormatter(cls._FORMATTER)
            handler.setLevel(INFO)
            cls._CONSOLE_HANDLER = handler

        for logger in cls._loggers:
            if cls._CONSOLE_HANDLER:
                logger.addHandler(cls._CONSOLE_HANDLER)
            if cls._FILE_HANDLER:
                logger.addHandler(cls._FILE_HANDLER)

    @classmethod
    def restore_handler(cls, record=None):
        """
        ログ書き込みエラー時の、ハンドラ再設定処理
        """
        cls.set_handler(cls._job_id, cls._node_name, cls._not_cout)

        if record and cls._loggers:
            cls._loggers[0].warning("Log handler resotred")
            cls._loggers[0].info(record.msg)
