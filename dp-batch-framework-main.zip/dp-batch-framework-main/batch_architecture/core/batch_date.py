"""
みなし日ファイルを管理するクラス
"""
import os
import re
from datetime import datetime as dt
from dateutil.relativedelta import relativedelta
from stat import S_IREAD, S_IRGRP, S_IROTH, S_IWUSR

from batch_architecture.core.base import Base
from batch_architecture.core.settings import Settings


class BatchDateUtil:
    @classmethod
    def chmod_batch_date_file_readonly(cls):
        """全員読み取り専用にする"""
        from batch_architecture.core.settings import Settings

        path = Settings.RESOURCE_BATCH_DATE_DIR / "batch_date.txt"
        os.chmod(path, S_IREAD | S_IRGRP | S_IROTH)

    @classmethod
    def chmod_batch_date_file_editable(cls):
        """オーナー読み書き可能、他読みのみ"""
        from batch_architecture.core.settings import Settings

        path = Settings.RESOURCE_BATCH_DATE_DIR / "batch_date.txt"
        os.chmod(path, S_IWUSR | S_IREAD | S_IRGRP | S_IROTH)

    # ToDo: ログが出せない
    @classmethod
    def replace_batch_ymd_variable(cls, string):
        """
        みなし日前後の日付を表す変数({batch_xxx_yyy_zzz}/{partition_batch_xxx_yyy_zzz})を探索して置換する
        変数はケースインセンシティブ
        xxx : DATE, MONTH, YMD, YM
        yyy : MNS, PLS
        zzz : d+(Y|M|D)
        """
        # 引数の文字列から{batch_xxx_yyy_zzz}の変数を正規表現で検索しマッチしたらマッチした文字列がリストに格納される
        batch_ymd_variables = re.findall("{(?i)batch_.+?[^{}]}", string)
        partition_ymd_variables = re.findall("{(?i)partition_batch_.+?[^{}]}", string)
        batch_ymd_variables += partition_ymd_variables
        # 見つかった変数が0件の場合、そのまま返却
        if len(batch_ymd_variables) == 0:
            return string
        # 見つかった変数の数だけstringに変換処理が走る
        for batch_ymd_variable in batch_ymd_variables:
            is_partition_batch_ymd = False
            date_format = "%Y%m%d"
            month_format = "%Y%m"
            if batch_ymd_variable.lower().startswith('{partition_batch_'):
                is_partition_batch_ymd = True
                date_format = "y=%Y/m=%m/d=%d"
                month_format = "y=%Y/m=%m"
            # "_"で要素分解して解析する
            lst_batch_ymd_variable_elm = batch_ymd_variable.split("_")
            if is_partition_batch_ymd:
                lst_batch_ymd_variable_elm = lst_batch_ymd_variable_elm[1:]
            # xxxにはDATE, MONTH, YMD, YMが入る
            xxx = lst_batch_ymd_variable_elm[1].strip("{" "}").upper()
            calculated_date = None
            if xxx == "DATE":
                string = string.replace(batch_ymd_variable, Base().batch_date.batch_date)
            elif xxx == "MONTH":
                string = string.replace(batch_ymd_variable, Base().batch_date.batch_month)
            elif xxx == "YMD":
                # yyyにはMNSかPLSが入る
                yyy = lst_batch_ymd_variable_elm[2]
                if yyy not in ["MNS", "PLS"]:
                    msg = "{*batch_xxx_yyy_zzz}のyyyはPLSかMNSを指定してください"
                    raise ValueError(msg)
                batch_date = Base().batch_date.batch_date
                zzz = lst_batch_ymd_variable_elm[3].strip("{" "}")
                num = int(zzz[:-1])
                y_or_m_or_d = zzz[-1]
                if y_or_m_or_d == "Y":
                    if yyy == "MNS":
                        calculated_date = (dt.strptime(batch_date, "%Y%m%d") -
                                           relativedelta(years=num)).strftime(date_format)
                    elif yyy == "PLS":
                        calculated_date = (dt.strptime(batch_date, "%Y%m%d") +
                                           relativedelta(years=num)).strftime(date_format)
                elif y_or_m_or_d == "M":
                    if yyy == "MNS":
                        calculated_date = (dt.strptime(batch_date, "%Y%m%d") -
                                           relativedelta(months=num)).strftime(date_format)
                    elif yyy == "PLS":
                        calculated_date = (dt.strptime(batch_date, "%Y%m%d") +
                                           relativedelta(months=num)).strftime(date_format)
                elif y_or_m_or_d == "D":
                    if yyy == "MNS":
                        calculated_date = (dt.strptime(batch_date, "%Y%m%d") -
                                           relativedelta(days=num)).strftime(date_format)
                    elif yyy == "PLS":
                        calculated_date = (dt.strptime(batch_date, "%Y%m%d") +
                                           relativedelta(days=num)).strftime(date_format)
                else:
                    msg = "変数の指定方法が不正です。末尾は'Y','M','D'のいずれかを指定してください"
                    raise ValueError(msg)
                string = string.replace(batch_ymd_variable, calculated_date)

            elif xxx == "YM":
                # yyyにはMNSかPLSが入る
                yyy = lst_batch_ymd_variable_elm[2]
                if yyy not in ["MNS", "PLS"]:
                    msg = "{*batch_xxx_yyy_zzz}のyyyはPLSかMNSを指定してください"
                    raise ValueError(msg)
                batch_month = Base().batch_date.batch_month
                zzz = lst_batch_ymd_variable_elm[3].strip("{" "}")
                num = int(zzz[:-1])
                y_or_m_or_d = zzz[-1]
                if y_or_m_or_d == "Y":
                    if yyy == "MNS":
                        calculated_date = (dt.strptime(batch_month, "%Y%m") -
                                           relativedelta(years=num)).strftime(month_format)
                    elif yyy == "PLS":
                        calculated_date = (dt.strptime(batch_month, "%Y%m") +
                                           relativedelta(years=num)).strftime(month_format)
                elif y_or_m_or_d == "M":
                    if yyy == "MNS":
                        calculated_date = (dt.strptime(batch_month, "%Y%m") -
                                           relativedelta(months=num)).strftime(month_format)
                    elif yyy == "PLS":
                        calculated_date = (dt.strptime(batch_month, "%Y%m") +
                                           relativedelta(months=num)).strftime(month_format)
                else:
                    msg = "変数の指定方法が不正です。末尾は'Y','M'のいずれかを指定してください"
                    raise ValueError(msg)
                string = string.replace(batch_ymd_variable, calculated_date)

        return string


class _BatchDate(object):
    """バッチ処理日付ファイル"""

    _LOGGER_NAME = "batch_architecture.batch_date"

    def __init__(self) -> None:
        self.batch_date = None
        self.batch_datetime = None
        self.batch_month = None
        self.partition_ymd = None

        self.read_batch_date_file()
        # コマンドラインからバッチ日付を取得したか
        self.has_command_line_args_batch_date = False

    def read_batch_date_file(self):
        path = Settings.RESOURCE_BATCH_DATE_DIR / "batch_date.txt"
        with open(path) as f:
            batch_date = f.read().strip()
            # 値が正しいかdate_objectに変換してチェック
            try:
                dt.strptime(batch_date, "%Y%m%d")
            except ValueError:
                raise

        self.batch_date = batch_date
        self.batch_datetime = d = dt.strptime(self.batch_date, "%Y%m%d")
        self.batch_month = d.strftime("%Y%m")
        self.partition_ymd = d.strftime("y=%Y/m=%m/d=%d")

        return batch_date

    def set_batch_date(self, batch_date: str):
        self.batch_date = batch_date
        self.batch_datetime = d = dt.strptime(self.batch_date, "%Y%m%d")
        self.batch_month = d.strftime("%Y%m")
        self.partition_ymd = d.strftime("y=%Y/m=%m/d=%d")


BatchDate = _BatchDate()
