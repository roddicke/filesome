"""
ジョブ初期化を行うクラス
"""
import sys
import os
import json
import pathlib
import time
import random

from batch_architecture.core.base import Base
from batch_architecture.core.batch_date import BatchDateUtil
from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.core.settings import Settings


class Job(Base):
    """
    実行するジョブを管理するクラス。

    ジョブは、連続した複数のロジック制御から構成される。
    """

    _LOGGER_NAME = "batch_architecture.job"

    def __init__(
            self,
            job_id,
            job_name,
            job_args,
            logics,
            raw_definitions,
            parameter_path=None,
            parameters=None,
    ):
        """
        ジョブを初期化する。

        :param job_id: ジョブ ID
        :param logics: ジョブに含まれる ロジック制御インスタンスのリスト
        :param parameter_path: コマンド入力時に指定されたパラメータIDのファイルのパス
        :param parameters: パラメータファイル名のリスト
        """
        self.job_id = job_id
        self.job_name = job_name
        self.job_args = job_args
        self.logics = logics
        self.parameter_path = parameter_path
        self.parameters = parameters
        self.raw_definitions = raw_definitions
        self.next_job_id_list = []
        self.next_job_args = {}

        # 各BaseBusinessLogicインスタンスがJobを参照できるようにする
        for logic in logics:
            logic.set_job(self)

        # ロジック制御クラスの順序構造を設定
        assert all(
            isinstance(logic, BaseBusinessLogic) for logic in logics
        ), "ジョブ定義初期化エラー"

    def __len__(self):
        return len(self.logics)

    def __str__(self):
        rows = ["Job({0})".format(self.job_id)] + [str(l) for l in self.logics]
        return (os.linesep + "  ").join(rows)

    __repr__ = __str__

    @classmethod
    def load_json(
            cls, path_or_id, path_or_parameter=None, resource_dir=None, args=None
    ):
        """
        ジョブ定義ファイルIDを元に RESOURCE_DEF_DIR からジョブ定義ファイルを読み込む。
        ファイル名が直接指定された場合はそのファイルを読み込む。
        パラメータファイルが指定された場合は指定されたジョブ定義ファイル内の項目を置換する。

        :param path_or_id: ジョブ定義ファイルのID, もしくは (.json) のファイル名 (拡張子部分を除く)
        :param path_or_parameter: パラメータファイルのID,　もしくは(.ini)のファイル名(拡張子を除く)
        :param resource_dir: ジョブ定義ファイルを読み込むディレクトリ。
        :return: ジョブ
        """
        assert isinstance(path_or_id, str), type(path_or_id)

        file_path = cls.get_file_path(path_or_id, resource_dir, ".json")

        # ロジック制御クラスの初期化に利用する
        job_id = file_path.stem

        with file_path.open(encoding="utf_8_sig") as j:
            raw_definitions = j.read()

        # parameterが指定された場合、ジョブ定義ファイル内の指定項目を置換する
        if path_or_parameter is not None:
            parameter_path = cls.get_file_path(path_or_parameter, resource_dir, ".ini")
            parameters = Settings.parse_config(parameter_path)

            if "config" not in parameters.sections():
                msg = "指定されたパラメータファイル{0}のSection名が正しくありません。Section名は「config」を指定してください"
                raise ValueError(msg.format(parameter_path))

            update = dict(parameters.items("config"))
        else:
            parameter_path = None
            update = {}
            parameters = {}

        # definitions = cls.replace_definition(raw_definitions, update)

        # argsが指定された場合、ジョブ定義ファイル内の指定項目を置換する
        if args is not None:
            parameters = json.loads(args)

        definitions = cls.replace_definition(raw_definitions, parameters)
        programs = definitions["programs"]
        # definitions は ジョブ定義を含む dict の list
        assert isinstance(programs, list), "ジョブ定義シンタックスエラー"
        assert all(
            isinstance(d, dict) for d in programs
        ), "ジョブ定義シンタックスエラー"

        logics = []
        for d in programs:
            # BaseBusinessLogicインスタンスを生成
            logic = BaseBusinessLogic.from_definition(definition=d)
            logics.append(logic)

        return Job(
            job_id=job_id,
            job_name=definitions.get('job', {}).get('name', '-'),
            job_args=args,
            logics=logics,
            raw_definitions=raw_definitions,
            parameter_path=parameter_path,
            parameters=update,
        )

    @classmethod
    def get_file_path(cls, path, resource_dir, extension):
        # もし引数がファイルパスの場合は、指定のパスからファイルをロード
        if os.path.exists(path):
            file_path = pathlib.Path(path)
        else:
            if resource_dir is None:
                resource_dir = pathlib.Path(Settings.RESOURCE_DEF_DIR)
            else:
                resource_dir = pathlib.Path(resource_dir)
            file_path = resource_dir / "{0}{1}".format(path, extension)

        if not file_path.exists():
            msg = "指定されたファイル{0}が見つかりません"
            raise FileNotFoundError(msg.format(file_path))

        return file_path

    @classmethod
    def replace_definition(cls, definitions, update):
        for key, value in update.items():
            replacer = "{{" + key + "}}"
            if replacer in definitions:
                definitions = definitions.replace(replacer, str(value))

        # job定義内で定義された{batch_xxx}を置換する
        definitions = BatchDateUtil.replace_batch_ymd_variable(definitions)
        definitions = definitions.replace("{ENV}", Settings.ENV)
        # 監査ログ出力のパラメータを置換
        definitions = definitions.replace("{AUDIT_LOG_OUT_ENV}", Settings.APP["AUDIT_LOG_OUT_ENV"])
        definitions = definitions.replace("{AUDIT_LOG_PYTHONR_OUT_DIR}", Settings.APP["AUDIT_LOG_PYTHONR_OUT_DIR"])
        definitions = definitions.replace("{AUDIT_LOG_SAS_OUT_DIR}", Settings.APP["AUDIT_LOG_SAS_OUT_DIR"])
        definitions = definitions.replace("{AUDIT_LOG_MV_OUT_DIR}", Settings.APP["AUDIT_LOG_MV_OUT_DIR"])
        definitions = definitions.replace("{AUDIT_LOG_TORIKAN_OUT_DIR}", Settings.APP["AUDIT_LOG_TORIKAN_OUT_DIR"])
        definitions = definitions.replace("{AUDIT_LOG_NNAVI_OUT_DIR}", Settings.APP["AUDIT_LOG_NNAVI_OUT_DIR"])
        try:
            definitions = json.loads(definitions)
        except Exception as e:
            msg = "ジョブ定義ファイルのJSONフォーマットが不正です。"
            raise FileNotFoundError(msg.format(), e)
        return definitions

    def get_next_job_args(self):
        return self.next_job_args

    def execute(self):
        """ジョブを実行する。"""
        msg = "ジョブ [{id}]({job_name}) の処理を開始します"
        self.logger.info(msg.format(id=self.job_id, job_name=self.job_name), cout=True)
        # ジョブ中のロジックをログに出力
        flow = "ロジック : " + " -> ".join(["[{}]".format(logic) for logic in self.logics])
        self.logger.info(flow)
        # ジョブ定義をログに出力する
        self.logger.info("JOB_DEF :\n" + self.raw_definitions)
        # dry-runモードの場合ロジックを実行しない
        if self.settings.DRY_RUN is True:
            sleep_time = random.randint(self.settings.RANDOM_SLEEP_MIN, self.settings.RANDOM_SLEEP_MAX)
            self.logger.info(f"{sleep_time}秒待機します。", cout=True)
            time.sleep(sleep_time)
            msg = "ジョブ [{id}] のdry-runが正常終了しました"
            self.logger.info(msg.format(id=self.job_id), cout=True)
            return

        for i, logic in enumerate(self.logics):
            # ロジック実行
            # エラー発生時のログ出力は各ロジックにて実施
            self.logger.info(f'ロジック({i+1}/{len(self.logics)})の実行を開始します。')
            res = logic.execute()
            self.logger.info(f'ロジック({i+1}/{len(self.logics)})の実行を完了しました。')
            # 警告終了は現実装では発生しえないため削除
            # return code は manage.py にて管理

            # 後続処理をスキップさせたい場合、返り値に"skip"を渡す
            if res == "skip":
                self.logger.info('後続ロジックのスキップを検知しました。')
                break

        msg = "ジョブ [{id}] の処理が正常終了しました"
        self.logger.info(msg.format(id=self.job_id), cout=True)
