import os
from datetime import datetime, timedelta

from batch_architecture.core.settings import Settings
from batch_architecture.core.batch_date import BatchDate
from batch_architecture.core.log import Logger
from batch_architecture.client.postgresql_client import PostgresSQLClient

LOGGER_NAME = "batch_architecture.schedule_utils"

logger = Logger.get_logger(LOGGER_NAME)


class _ScheduleInfoUtils(object):
    def __init__(self):
        self._client = None

        self.batch_date_info = {}

    @property
    def client(self):
        """
        PostgresSQLへの接続
        """
        if self._client is None:
            self._client = PostgresSQLClient()
            self._client.connect()

        return self._client

    def get_view_list_from_view_update_schedule_mst(self, database_bind) -> dict:
        cli = self.client
        # マスタからVIEWの一覧を取得する
        reference_table = 'view_update_schedule_mst'
        query = f"SELECT view_name, schedule_id, schedule_name, src_database_bind\n" \
                f"FROM {Settings.LOG_TABLE_SCHEMA}.{reference_table}\n" \
                f"WHERE sys_name = '{os.environ['ADT_RESOURCE']}' AND database_bind = '{database_bind}'\n;"
        try:
            cli.execute_sql(query)
            rows = cli.fetch_all()
        except Exception as e:
            logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            raise
        dict_view_list = {}
        for i in range(len(rows)):
            view_name = rows[i][0]
            dict_view_list[view_name] = {
                'schedule_id': rows[i][1],
                'schedule_name': rows[i][2],
                'src_database_bind': rows[i][3]
            }

        return dict_view_list

    def get_view_list_from_ext_table_update_schedule_mst(self, database_bind) -> dict:
        cli = self.client
        # マスタからVIEWの一覧を取得する
        reference_table = 'ext_table_update_schedule_mst'
        query = f"SELECT ext_table_name, schedule_id, schedule_name, src_database_bind\n" \
                f"FROM {Settings.LOG_TABLE_SCHEMA}.{reference_table}\n" \
                f"WHERE database_bind = '{database_bind}'\n;"
        try:
            cli.execute_sql(query)
            rows = cli.fetch_all()
        except Exception as e:
            logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            raise
        dict_view_list = {}
        for i in range(len(rows)):
            ext_table_name = rows[i][0]
            dict_view_list[ext_table_name] = {
                'schedule_id': rows[i][1],
                'schedule_name': rows[i][2],
                'src_database_bind': rows[i][3]
            }

        return dict_view_list

    def get_batch_date_info(self, batch_date=None) -> dict:
        if batch_date is None:
            batch_date = BatchDate.batch_date
        batch_date = str(batch_date)
        if batch_date in self.batch_date_info:
            return self.batch_date_info[batch_date]

        cli = self.client
        reference_table = 'um2bt005'
        query = f"SELECT ymd_wk, ymd_wkdy, eg_flg\n" \
                f"FROM {Settings.LOG_TABLE_SCHEMA}.{reference_table}\n" \
                f"WHERE YMD = {batch_date};"
        try:
            cli.execute_sql(query)
            rows = cli.fetch_all()
        except Exception as e:
            logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            raise
        if len(rows) == 0:
            err_msg = f'営業日カレンダー"{reference_table}"に年月日"{batch_date}"のレコードが存在しません。'
            logger.error(err_msg)
            raise Exception(err_msg)

        dict_mapping_ymd_wkdy_week = {'1': '日', '2': '月', '3': '火', '4': '水', '5': '木', '6': '金', '7': '土'}
        ymd_wkdy = rows[0][1]
        batch_date_week = dict_mapping_ymd_wkdy_week[ymd_wkdy]
        eg_flg = rows[0][2]
        is_business_day = True if eg_flg == '1' else False
        dict_batch_date_info = {
            'batch_date': batch_date,
            'ymd_wk': rows[0][0],
            'ymd_wkdy': ymd_wkdy,
            'eg_flg': eg_flg,
            'batch_date_week': batch_date_week,
            'is_business_day': is_business_day
        }

        self.batch_date_info[batch_date] = dict_batch_date_info
        return dict_batch_date_info

    def _get_ymd_by_using_udf(self, udf_name, *args) -> int:
        lst_args = []
        for arg in args:
            lst_args.append(str(arg))
        udf_args = ','.join(lst_args)
        query = f"SELECT {Settings.LOG_TABLE_SCHEMA}.{udf_name}({udf_args});"
        try:
            self.client.execute_sql(query)
            rows = self.client.fetch_all()
        except Exception as e:
            logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            raise
        return rows[0][0]

    def _get_next_day(self, date_ymd):
        next_day = int(datetime.strftime(
            datetime.strptime(str(date_ymd), '%Y%m%d') + timedelta(days=1), '%Y%m%d'))
        return next_day

    def match_schedule(self, schedule_id, batch_date=None):
        if batch_date is None:
            batch_date = BatchDate.batch_date
        batch_date = int(batch_date)

        if schedule_id == 'T1CAL200':
            # 毎日稼働
            return True
        elif schedule_id == 'T1CAL01':
            # 証券営業日稼働
            info = self.get_batch_date_info(batch_date)
            return info['is_business_day']
        elif schedule_id == 'T1CAL51':
            # 翌日証券営業日稼働
            next_date = self._get_next_day(batch_date)
            return next_date == self._get_ymd_by_using_udf('get_next_bizdate_of_the_year', batch_date)
        elif schedule_id == 'T1CAL212':
            # 月～土稼働（'1'(日曜日)以外稼働）
            info = self.get_batch_date_info(batch_date)
            return info['ymd_wkdy'] != '1'
        elif schedule_id == 'T1CAL81':
            # 月火水木金稼働（'2'~'6'であれば稼働）
            info = self.get_batch_date_info(batch_date)
            return info['ymd_wkdy'] in ['2', '3', '4', '5', '6']
        elif schedule_id == 'T1CAL202':
            # 毎週日曜('1')稼働
            info = self.get_batch_date_info(batch_date)
            return info['ymd_wkdy'] == '1'
        elif schedule_id == 'T1CAL204':
            # 毎週月曜('2')稼働
            info = self.get_batch_date_info(batch_date)
            return info['ymd_wkdy'] == '2'
        elif schedule_id == 'T1CAL210':
            # 日～金稼働（'7'(土曜日)以外稼働）
            info = self.get_batch_date_info(batch_date)
            return info['ymd_wkdy'] != '7'
        elif schedule_id == 'T1CAL11':
            # 週初営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_week', batch_date, 1)
        elif schedule_id == 'T1CAL94':
            # 週初営業日前日稼働
            next_date = self._get_next_day(batch_date)
            return next_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_week', batch_date, 1)
        elif schedule_id == 'RQACAL525':
            # 非営業日を除く水曜日(水曜日が非営業日の時は、次営業日)稼働
            return batch_date == self._get_ymd_by_using_udf('get_wed_bizdate_of_the_week_rqacal525', batch_date)
        elif schedule_id == 'T1CAL137':
            # 毎月1日であれば遅延監視
            return str(batch_date)[-2:] == '01'
        elif schedule_id == 'T1CAL04':
            # 毎月月初営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_month', batch_date, 1)
        elif schedule_id == 'T1CAL20':
            # 月初第3営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_month', batch_date, 3)
        elif schedule_id == 'T1CAL21':
            # 月初第4営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_month', batch_date, 4)
        elif schedule_id == 'T1CAL22':
            # 月初第5営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_month', batch_date, 5)
        elif schedule_id == 'T1CAL30':
            # 月初第6営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_month', batch_date, 6)
        elif schedule_id == 'T1CAL18':
            # 月初第7営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_month', batch_date, 7)
        elif schedule_id == 'T1CAL32':
            # 月初第9営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_month', batch_date, 9)
        elif schedule_id == 'T1CAL322':
            # 月初第10営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_x_bizdate_of_the_month', batch_date, 10)
        elif schedule_id == 'T1CAL05':
            # 月末最終営業日稼働
            return batch_date == self._get_ymd_by_using_udf('get_last_bizdate_of_the_month', batch_date)
        elif schedule_id == 'T1CAL207':
            # 毎月月末稼働
            return batch_date == self._get_ymd_by_using_udf('get_last_date_of_the_month', batch_date)
        else:
            logger.warning('Unknown schedule_id: %s' % schedule_id)
            return False


ScheduleUtils = _ScheduleInfoUtils()
