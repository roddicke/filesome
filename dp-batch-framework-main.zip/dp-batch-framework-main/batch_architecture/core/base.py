"""
ADT 実行アーキの各モジュールの基底クラス
"""
import abc

from batch_architecture.core.log import Logger


class Base(object):
    """
    ADT 実行アーキの各モジュールの基底クラス
    """

    _LOGGER_NAME = None

    @property
    def settings(self):
        """ADT 実行アーキのグローバル設定を取得する。"""
        # TODO: 設定ファイルとプロパティ名を一致させる
        if getattr(self, "_settings", None) is None:
            from batch_architecture.core.settings import Settings

            self._settings = Settings
        return self._settings

    @property
    def resources(self):
        """ADT 実行アーキのリソース設定を取得する。"""
        if getattr(self, "_resources", None) is None:
            from batch_architecture.core.resources import Resources

            self._resources = Resources
        return self._resources

    # self.logger は BatchManager, BaseBusinessLogicでのみ利用される

    @property
    def logger(self):
        """Logger インスタンスの作成を行う。"""
        if getattr(self, "_logger", None) is None:
            name = self._LOGGER_NAME
            if name is None:
                msg = "{0} クラスのLogger名称 (_LOGGER_NAME) " "が設定されていないため、Loggerを取得できません"
                raise ValueError(msg.format(self.__class__.__name__))
            # この時点では、job_idがわからないため Handlerとの紐づけはされない
            self._logger = Logger.get_logger(name)
        return self._logger

    @property
    def batch_date(self):
        """バッチ日付設定を取得する。"""
        if getattr(self, "_batch_date", None) is None:
            from batch_architecture.core.batch_date import BatchDate

            self._batch_date = BatchDate

        return self._batch_date


class CustomScriptBase(Base, metaclass=abc.ABCMeta):
    __metaclass__ = abc.ABCMeta

    def __init__(self):
        self.job = None

    def set_job(self, job):
        self.job = job

    @property
    def job_id(self):
        return self.job.job_id

    @abc.abstractmethod
    def main(self, **kargs):
        pass
