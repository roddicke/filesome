"""
"""
import os
import time
import json

from batch_architecture.core.settings import Settings
from batch_architecture.core.log import Logger
from batch_architecture.client.postgresql_client import PostgresSQLClient

LOGGER_NAME = "batch_architecture.table_logging"

logger = Logger.get_logger(LOGGER_NAME)


class _TableLogging(object):
    def __init__(self):
        self._client = None

        self._batch_date = ''
        self._process_log_id = ''
        self._process_log_detail_id = ''

        self._skip_time = 0

    @property
    def client(self):
        """
        PostgresSQLへの接続
        """
        if self._client is None:
            self._client = PostgresSQLClient()
            self._client.connect()

        return self._client

    def job_logging(self, func):
        """
        実行アーキログテーブルに書き込むデコレータ
        """

        cli = self.client if Settings.LOGGING_TABLE else None

        def wrapper(job_obj, *args, **kwds):
            if not Settings.LOGGING_TABLE:
                logger.info('Skip table logging.')
                start_time = time.perf_counter()
                res = func(job_obj, *args, **kwds)
                end_time = time.perf_counter()
                perf_time = round(end_time - start_time, 3)
                logger.info("ジョブ [{job_id}]({job_name}) 実行処理時間 {perf_time} 秒".format(
                    job_id=job_obj.job_id, job_name=job_obj.job_name, perf_time=perf_time))
                return res

            start_time = time.perf_counter()
            sql = '\n'.join([
                "INSERT INTO {sc}.process_log ("
                " job_id, job_name, job_args, batch_date_ymd, start_at, end_at, status, "
                " node, target_system, log_file_name"
                ") VALUES ("
                " '{job_id}', '{job_name}', {job_args}, '{batch_date}', current_timestamp, null,"
                " 'incomplete', '{node}', '{system}', '{log_file_name}'"
                ") RETURNING id;"
            ]).format(
                sc=job_obj.settings.LOG_TABLE_SCHEMA,
                job_id=job_obj.job_id,
                job_name=job_obj.job_name,
                job_args="'%s'" % job_obj.job_args.replace("'", "''") if job_obj.job_args else 'null',
                batch_date=job_obj.batch_date.batch_date,
                node=Settings.node_name,
                system=os.environ["ADT_RESOURCE"],
                log_file_name=Settings.LOG_FILE_NAME,
            )
            try:
                cli.execute_sql(sql)
                self._process_log_id = process_log_id = cli.fetch_one()[0]
                self._batch_date = job_obj.batch_date.batch_date
                cli.commit()
            except Exception as e:
                logger.error('ERROR_SQL: %s' % sql)
                raise

            try:
                res = func(job_obj, *args, **kwds)
            except Exception as e:
                sql = '\n'.join([
                    'UPDATE {sc}.process_log SET',
                    " end_at=current_timestamp, duration_time=(current_timestamp - start_at),"
                    " status='error', exception_digest='{exception}'",
                    "WHERE id={id} AND batch_date_ymd='{batch_date}';"
                ]).format(
                    sc=job_obj.settings.LOG_TABLE_SCHEMA,
                    id=process_log_id,
                    batch_date=self._batch_date,
                    exception=str(e).replace("'", "''"),
                )
                try:
                    if cli.is_connected():
                        cli.execute_sql(sql)
                        cli.commit()
                except Exception as _e:
                    logger.error('ERROR_SQL: %s' % sql)
                    logger.exception(_e)
                    cli.rollback()
                raise
            else:
                sql = '\n'.join([
                    'UPDATE {sc}.process_log SET'
                    " end_at=current_timestamp, duration_time=(current_timestamp - start_at), status='success'",
                    'WHERE id={id};'
                ]).format(
                    sc=job_obj.settings.LOG_TABLE_SCHEMA,
                    id=process_log_id,
                )
                try:
                    cli.execute_sql(sql)
                    cli.commit()
                except Exception as e:
                    logger.error('ERROR_SQL: %s' % sql)
                    cli.rollback()
                    raise
            finally:
                end_time = time.perf_counter()
                perf_time = round(end_time - start_time, 3)
                logger.info("ジョブ [{job_id}]({job_name}) 実行処理時間 {perf_time} 秒".format(
                    job_id=job_obj.job_id, job_name=job_obj.job_name, perf_time=perf_time))
                pass
            return res

        return wrapper

    def logic_logging(self, func):
        """
        実行アーキログ詳細テーブルに書き込むデコレータ
        """
        cli = self.client if Settings.LOGGING_TABLE else None

        def wrapper(logic_obj, *args, **kwds):
            if not Settings.LOGGING_TABLE:
                logger.info('Skip table logging.')
                start_time = time.perf_counter()
                res = func(logic_obj, *args, **kwds)
                end_time = time.perf_counter()
                perf_time = round(end_time - start_time, 3)
                logger.info("ロジック [{logic}] ジョブ実行処理時間 {perf_time} 秒".format(
                    logic=logic_obj.definition.get('program_type', ''),
                    perf_time=perf_time))
                return res

            start_time = time.perf_counter()
            sql = '\n'.join([
                "INSERT INTO {sc}.process_log_detail ("
                " process_log_id, batch_date_ymd, start_at, end_at, status, logic,"
                " script_file, script_args, script_tags, top"
                ") VALUES("
                " '{process_log_id}', '{batch_date}', current_timestamp, null, "
                " 'incomplete', '{logic}',"
                " '{script_file}', '{script_args}', '{script_tags}', true"
                ") RETURNING id;"
            ]).format(
                sc=logic_obj.settings.LOG_TABLE_SCHEMA,
                process_log_id=self._process_log_id,
                batch_date=self._batch_date,
                script_file=logic_obj.definition.get('script', ''),
                script_args=json.dumps(
                    logic_obj.definition.get('script_args', {}),
                    ensure_ascii=False).replace("'", "''"),
                script_tags=json.dumps(
                    logic_obj.definition.get('script_tags', {}),
                    ensure_ascii=False).replace("'", "''"),
                logic=logic_obj.definition.get('program_type', ''),
            )
            try:
                cli.execute_sql(sql)
                self._process_log_detail_id = process_log_detail_id = cli.fetch_one()[0]
                cli.commit()
            except Exception:
                logger.error('ERROR_SQL: %s' % sql)
                cli.rollback()
                raise

            try:
                res = func(logic_obj, *args, **kwds)
            except Exception as e:
                sql = '\n'.join([
                    "UPDATE {sc}.process_log_detail SET",
                    " end_at=current_timestamp,"
                    " duration_time=(current_timestamp - start_at - cast('{skip_time} milliseconds' as INTERVAL)),"
                    " status='error'",
                    "WHERE id={id} AND batch_date_ymd='{batch_date}';"
                ]).format(
                    sc=logic_obj.settings.LOG_TABLE_SCHEMA,
                    skip_time=self._skip_time,
                    id=process_log_detail_id,
                    batch_date=self._batch_date,
                )
                try:
                    cli.execute_sql(sql)
                    cli.commit()
                except:
                    logger.error('ERROR_SQL: %s' % sql)
                    cli.rollback()
                    raise
                raise
            else:
                sql = '\n'.join([
                    "UPDATE {sc}.process_log_detail SET",
                    " end_at=current_timestamp,"
                    " duration_time=(current_timestamp - start_at - cast('{skip_time} milliseconds' as INTERVAL)),"
                    " status='success'",
                    "WHERE id={id} AND batch_date_ymd='{batch_date}';"
                ]).format(
                    sc=logic_obj.settings.LOG_TABLE_SCHEMA,
                    skip_time=self._skip_time,
                    id=process_log_detail_id,
                    batch_date=self._batch_date,
                )
                try:
                    if cli.is_connected():
                        cli.execute_sql(sql)
                        cli.commit()
                except:
                    logger.error('ERROR_SQL: %s' % sql)
                    cli.rollback()
                    raise
            finally:
                end_time = time.perf_counter()
                perf_time = round(end_time - start_time, 3)
                logger.info("ロジック [{logic}] ジョブ実行処理時間 {perf_time} 秒".format(
                    logic=logic_obj.definition.get('program_type', ''),
                    perf_time=perf_time))
                pass
            return res

        return wrapper

    def sub_func_logging(self, name, script_file=None):
        def deco_func(func):
            cli = self.client if Settings.LOGGING_TABLE else None

            def wrapper(*args, **kwds):
                if not Settings.LOGGING_TABLE:
                    logger.info('Skip table logging.')
                    res = func(*args, process_log_detail_id=None, **kwds)
                    return res

                sql = '\n'.join([
                    "INSERT INTO {sc}.process_log_detail ("
                    " process_log_id, batch_date_ymd, start_at, end_at, status, logic, script_file, top"
                    ") VALUES("
                    " '{process_log_id}', '{batch_date}', current_timestamp, null,"
                    " 'incomplete', '{logic}', {script_file}, false"
                    ") RETURNING id;"
                ]).format(
                    sc=Settings.LOG_TABLE_SCHEMA,
                    process_log_id=self._process_log_id,
                    batch_date=self._batch_date,
                    logic=name,
                    script_file=f"'{script_file}'" if script_file is not None else 'null'
                )
                try:
                    cli.execute_sql(sql)
                    n_id = cli.fetch_one()[0]
                    cli.commit()
                except:
                    logger.error('ERROR_SQL: %s' % sql)
                    cli.rollback()
                    raise

                try:
                    # start_time = time.time()
                    res = func(*args, process_log_detail_id=n_id, **kwds)
                    # d = (time.time() - start_time) * 1000
                    # self._skip_time += d
                except Exception as e:
                    sql = '\n'.join([
                        "UPDATE {sc}.process_log_detail SET",
                        " end_at=current_timestamp, duration_time=(current_timestamp - start_at), status='error'",
                        "WHERE id={id} AND batch_date_ymd='{batch_date}';"
                    ]).format(
                        sc=Settings.LOG_TABLE_SCHEMA,
                        id=n_id,
                        batch_date=self._batch_date,
                    )
                    try:
                        cli.execute_sql(sql)
                        cli.commit()
                    except:
                        logger.error('ERROR_SQL: %s' % sql)
                        cli.rollback()
                        raise
                    raise
                else:
                    sql = '\n'.join([
                        "UPDATE {sc}.process_log_detail SET",
                        " end_at=current_timestamp,"
                        " duration_time=(current_timestamp - start_at),"
                        " status='success'",
                        "WHERE id={id} AND batch_date_ymd='{batch_date}';"
                    ]).format(
                        sc=Settings.LOG_TABLE_SCHEMA,
                        id=n_id,
                        batch_date=self._batch_date,
                    )
                    try:
                        cli.execute_sql(sql)
                        cli.commit()
                    except:
                        logger.error('ERROR_SQL: %s' % sql)
                        cli.rollback()
                        raise
                finally:
                    pass
                return res

            return wrapper

        return deco_func

    def logging_query(self, query, process_log_detail_id=None, warehouse=None):
        if not Settings.LOGGING_TABLE:
            logger.info('Skip table logging.')
            return

        if warehouse is not None:
            set_wh = ", warehouse='%s'" % warehouse
        else:
            set_wh = ''

        cli = self.client
        sql = '\n'.join([
            'UPDATE {sc}.process_log_detail',
            "SET query_log='{query}'{set_wh}",
            "WHERE id={id} AND batch_date_ymd='{batch_date}';"
        ]).format(
            sc=Settings.LOG_TABLE_SCHEMA,
            id=process_log_detail_id if process_log_detail_id else self._process_log_detail_id,
            batch_date=self._batch_date,
            query=query.replace("'", "''"),
            set_wh=set_wh,
        )
        try:
            cli.execute_sql(sql)
            cli.commit()
        except:
            logger.error('ERROR_SQL: %s' % sql)
            cli.rollback()
            raise

    def logging_row_count(self, row_count, process_log_detail_id=None):
        if not Settings.LOGGING_TABLE or not isinstance(row_count, int):
            return

        cli = self.client
        sql = '\n'.join([
            'UPDATE {sc}.process_log_detail',
            "SET row_count={row_count}",
            "WHERE id={id} AND batch_date_ymd='{batch_date}';"
        ]).format(
            sc=Settings.LOG_TABLE_SCHEMA,
            id=process_log_detail_id if process_log_detail_id else self._process_log_detail_id,
            batch_date=self._batch_date,
            row_count=row_count,
        )
        try:
            cli.execute_sql(sql)
            cli.commit()
        except:
            logger.error('ERROR_SQL: %s' % sql)
            cli.rollback()
            raise

    def if_transfer_logging(self, dict_if_transfer_info):
        if not Settings.LOGGING_TABLE:
            logger.info('Skip table logging.')
            return

        cli = self.client
        sql = '\n'.join([
            "INSERT INTO {sc}.if_transfer_log"
            "(batch_date, file_id, if_file_name_jp, job_id, sys_name, transfer_type, transfer_path,"
            " created_at)",
            "SELECT '{batch_date}', '{file_id}', COALESCE(iwmtm.if_file_name_jp, ''), '{job_id}', '{sys_name}',"
            " '{transfer_type}', '{transfer_path}', CURRENT_TIMESTAMP",
            "FROM (SELECT '{job_id}' AS job_id) AS jid",
            "LEFT OUTER JOIN {sc}.if_watch_monitoring_time_mst iwmtm",
            "    ON iwmtm.job_id = jid.job_id",
            ";"
        ]).format(
            sc=Settings.LOG_TABLE_SCHEMA,
            batch_date=dict_if_transfer_info['batch_date'],
            file_id=dict_if_transfer_info['file_id'],
            job_id=dict_if_transfer_info['job_id'],
            sys_name=dict_if_transfer_info['sys_name'],
            transfer_type=dict_if_transfer_info['transfer_type'],
            transfer_path=dict_if_transfer_info['transfer_path']
        )
        try:
            cli.execute_sql(sql)
            cli.commit()
        except:
            logger.error('ERROR_SQL: %s' % sql)
            cli.rollback()
            raise

    def json_format_error_logging(self, job_id, e, batch_date):
        """
        job_def jsonフォーマットエラーをプロセスログに書き込む
        """
        if not Settings.LOGGING_TABLE:
            logger.info('Skip table logging.')
            return
        cli = self.client
        sql = '\n'.join([
            "INSERT INTO {sc}.process_log ("
            " job_id, job_name, job_args, batch_date_ymd, start_at, end_at, status, "
            " exception_digest, node, target_system, log_file_name"
            ") VALUES ("
            " '{job_id}', NULL, NULL, '{batch_date}', current_timestamp, current_timestamp,"
            " 'error', '{exception}', '{node}', '{system}', '{log_file_name}'"
            ");"
        ]).format(
            sc=Settings.LOG_TABLE_SCHEMA,
            job_id=job_id,
            batch_date=batch_date,
            exception=str(e).replace("'", "''"),
            node=Settings.node_name,
            system=os.environ["ADT_RESOURCE"],
            log_file_name=Settings.LOG_FILE_NAME,
        )
        try:
            cli.execute_sql(sql)
            cli.commit()
        except Exception as e:
            logger.error('ERROR_SQL: %s' % sql)
            raise


table_logging = _TableLogging()
