def byte_decode(x):
    try:
        x = x.decode('utf-8')
        return x
    except UnicodeDecodeError:
        pass

    try:
        x = x.decode('cp932')
        return x
    except UnicodeDecodeError:
        pass

    return x


def get_file_id(file_name):
    # 処理コントローラに実装されているものと同等のロジック
    sep_file_name = file_name.split('.')
    lst_ext = [
        "e", "finish", "end", "s", "trg", "fin", "t", "TRG", "byte", "date",
        "OK", "zip", "Z", "gz", "csv", "dat", "tar", "pdf", "log", "start"
    ]
    lst_ext_removed_sep_file_name = []
    for v in sep_file_name:
        if v not in lst_ext:
            lst_ext_removed_sep_file_name.append(v)
    file_id = '.'.join(lst_ext_removed_sep_file_name)
    return file_id
