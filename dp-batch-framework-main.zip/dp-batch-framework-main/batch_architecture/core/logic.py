"""
各ロジック制御クラスの基底クラス
"""
import time
import traceback
from abc import abstractmethod
import copy

from batch_architecture.core.base import Base
from batch_architecture.core.table_logging import table_logging


class BaseBusinessLogic(Base):
    """
    ロジック制御クラス。

    ロジックは 「ファイルの転送」や「ファイルの圧縮」など、単一の処理単位から成る。
    """

    _DISP_ATTR = []

    # 入出力名
    _input = None
    _output = None

    @classmethod
    def from_definition(cls, definition):
        """
        ジョブIDと、ジョブ定義に含まれる program_type に基づいてロジック制御クラス
        を生成する。

        :param definition: ロジック制御設定
        :return: 生成されたロジック制御
        """
        # job_idはロジック制御クラスでのログ出力のために必要
        # ロジック制御クラスの設定には影響しない
        assert isinstance(definition, dict)

        # program_type が指定されていない場合はエラー
        if "program_type" not in definition:
            msg = "ジョブ定義ファイル中に、JOB ID (program_type) が指定されていません"
            raise ValueError(msg)

        program_type = definition["program_type"]
        assert isinstance(program_type, str)

        from batch_architecture.logic import (
            FileArchiveLogic,
            FileExtractLogic,
            FileTransferLogic,
            FileTransformLogic,
            FileExistenceLogic,
            FileEncodeLogic,
            ExecuteLogic,
            WriteParametersLogic,
            FileRemoveLogic,
            FileConcatLogic,
            FileConcatPyLogic,
            FileLinkageDelayWarning,
            SnowflakeSQLExecuteLogic,
            SnowflakeSQLExecuteTrcLogic,
            SnowflakeSQLExecuteLoadLogic,
            SnowflakeSQLExecuteExportLogic,
            SnowflakeSQLExecuteReplaceSequenceLogic,
            SnowflakeSQLExecuteRevokeSelectViewLogic,
            SnowflakeSQLExecuteGrantSelectViewLogic,
            SnowflakeSQLExecuteGrantSelectViewAllLogic,
            SnowflakeSQLExecuteRevokeSelectExtTableLogic,
            SnowflakeSQLExecuteGrantSelectExtTableLogic,
            SnowflakeSQLExecuteGrantSelectExtTableAllLogic,
            CallPreprocessGoLogic,
            CallPostProcessGoLogic,
            SQLServerSQLExecuteLogic,
            SQLServerSQLExecuteReplaceSequenceLogic,
            CallPythonScriptLogic,
            RemoveErrorTableLogic,
            FileTransformCsvToParquetLogic,
            FileEditColumnLogic,
            FileCreateLogic,
            FilePollingRemoveLogic,
            UpdateBatchDateFile,
            NotifyS3Landing,
            DeleteS3Landing,
            ExecuteGlueJobLogic,
            DummyLogic
        )

        # program_type と実際に処理を行うロジック制御クラスの辞書
        PROGRAM_TYPE_DICT = {
            "TRANSFER": FileTransferLogic,
            "TRANSFORM": FileTransformLogic,
            "ARCHIVE": FileArchiveLogic,
            "EXTRACT": FileExtractLogic,
            "EXISTENCE": FileExistenceLogic,
            "EXECUTE": ExecuteLogic,
            "ENCODE": FileEncodeLogic,
            "WRITE_PARAMETERS": WriteParametersLogic,
            "REMOVE": FileRemoveLogic,
            "CONCAT": FileConcatLogic,
            "CONCAT_PY": FileConcatPyLogic,
            "QUERY_SNOWFLAKE": SnowflakeSQLExecuteLogic,
            "QUERY_SNOWFLAKE_TRC": SnowflakeSQLExecuteTrcLogic,
            "LOAD_SNOWFLAKE": SnowflakeSQLExecuteLoadLogic,
            "EXPORT_SNOWFLAKE": SnowflakeSQLExecuteExportLogic,
            "REPLACE_SEQUENCE_SNOWFLAKE": SnowflakeSQLExecuteReplaceSequenceLogic,
            "REVOKE_SELECT_VIEW": SnowflakeSQLExecuteRevokeSelectViewLogic,
            "GRANT_SELECT_VIEW": SnowflakeSQLExecuteGrantSelectViewLogic,
            "GRANT_SELECT_VIEW_ALL": SnowflakeSQLExecuteGrantSelectViewAllLogic,
            "REVOKE_SELECT_EXT_TABLE": SnowflakeSQLExecuteRevokeSelectExtTableLogic,
            "GRANT_SELECT_EXT_TABLE": SnowflakeSQLExecuteGrantSelectExtTableLogic,
            "GRANT_SELECT_EXT_TABLE_ALL": SnowflakeSQLExecuteGrantSelectExtTableAllLogic,
            "PRE_GO": CallPreprocessGoLogic,
            "POST_GO": CallPostProcessGoLogic,
            "QUERY_SQLSERVER": SQLServerSQLExecuteLogic,
            "REPLACE_SEQUENCE_SQLSERVER": SQLServerSQLExecuteReplaceSequenceLogic,
            "CALL_PY": CallPythonScriptLogic,
            "REMOVE_ERROR_TABLE": RemoveErrorTableLogic,
            "TRANSFORM_CSV_TO_PARQUET": FileTransformCsvToParquetLogic,
            "EDIT_COLUMN": FileEditColumnLogic,
            "FILE_CREATE": FileCreateLogic,
            "POLLING_REMOVE": FilePollingRemoveLogic,
            "UPDATE_BATCH_DATE_FILE": UpdateBatchDateFile,
            "NOTIFY_S3LANDING": NotifyS3Landing,
            "DELETE_S3LANDING": DeleteS3Landing,
            "EXECUTE_GLUE_JOB": ExecuteGlueJobLogic,
            "FILE_LINKAGE_DELAY_WARNING": FileLinkageDelayWarning,
            "DUMMY": DummyLogic
        }

        try:
            program_type = program_type.upper()
            klass = PROGRAM_TYPE_DICT[program_type]
        except KeyError:
            msg = "PROGRAM_TYPEの値が不正です: PROGRAM_TYPE=%s" % program_type
            raise ValueError(msg)

        return klass(definition=definition)

    def __init__(self, definition):
        """
        ジョブ定義ファイルIDと、ジョブ定義ファイルから読み取ったロジック制御設定
        を元にロジック制御クラスを初期化する。

        :param definition: ロジック制御設定の辞書
        """
        assert isinstance(definition, dict), type(definition)

        self.job = None

        # logger の初期化前に job_id を設定
        self.definition = copy.deepcopy(definition)
        # "program_type" 属性が存在する場合は削除
        self._program_type = definition.pop("program_type", None)
        # "program_name" 属性が存在する場合は削除
        self._program_name = definition.pop("program_name", None)
        # "comment" 属性が存在する場合は削除
        definition.pop("comment", None)

        # 入出力を設定
        self._input = definition['script_args'].get("input", None)
        self._output = definition['script_args'].get("output", None)
        self._delay = definition.pop("delay", 60)
        self._max_attempts = definition.pop("max_attempts", 1)
        if self._program_type in ["PRE_GO", "POST_GO"]:
            self._max_attempts = 3
        self._script_tags = definition.pop("script_tags", None)
        self.logger.info("script_tags: {}".format(self._script_tags), cout=True)
        if self._delay <= 0:
            msg = "処理時間(delay)が0秒以下に設定されています。"
            raise ValueError(msg)

        if self._max_attempts < 1:
            msg = "処理回数(max_attempts)が1回未満に設定されています。"
            raise ValueError(msg)

        try:
            # ロジック初期化
            self._init_logic(**definition)
        except Exception as e:
            # TODO: 設定ミス時のエラーメッセージをわかりやすく
            self.logger.error(traceback.format_exc())
            self.logger.error(msg="ロジック制御設定クラス初期化中にエラーが発生しました。%s" % e)
            raise

    def _init_logic(self, **definition):
        """
        BaseBusinessLogic を継承する際、サブクラス固有の初期化処理を行う。ロジック固有の
        オプションはこのメソッドに引数として渡される。
        """
        pass

    def __str__(self):
        if len(self._DISP_ATTR) > 0:
            attr = ", ".join(
                ["{0}={1}".format(k, getattr(self, k)) for k in self._DISP_ATTR]
            )
            fmt = "{klass}({type}, {attr})"
        else:
            attr = ""
            fmt = "{klass}({type})"
        return fmt.format(
            klass=self.__class__.__name__, type=self.program_type, attr=attr
        )

    __repr__ = __str__

    @property
    def program_type(self):
        return self._program_type

    @property
    def program_name(self):
        return self._program_name

    def set_job(self, job):
        self.job = job

    @property
    def job_id(self):
        return self.job.job_id

    @table_logging.logic_logging
    def execute(self):
        """ロジック制御クラスの処理を実行する"""
        res = None
        for i in range(1, self._max_attempts + 1):
            try:
                res = self._execute()
                break
            except Exception as e:
                msg1 = "ロジック {logic} の実行中に {e}({msg}) が発生しました。"
                self.logger.error(
                    msg1.format(logic=self, e=e.__class__.__name__, msg=e)
                )
                if i >= self._max_attempts:
                    msg2 = "現在の処理回数 {i}/{max} 回"
                    self.logger.error(msg2.format(i=i, max=self._max_attempts))
                    self._rollback()
                    raise
                else:
                    msg3 = "現在の処理回数 {i}/{max} 回\n{sec} 秒後にリトライ処理を実行します。"
                    self.logger.warning(
                        msg3.format(sec=self._delay, i=i, max=self._max_attempts)
                    )
                    self._rollback()
                    time.sleep(self._delay)
        return res

    @abstractmethod
    def _execute(self):
        pass

    def _rollback(self):
        """
        失敗時にロールバック処理を行う。
        失敗時に何らかのロールバック処理が必要な場合にオーバーライドする。
        """
        pass


class _InputOutputLogic(BaseBusinessLogic):
    """
    入出力先があるロジック制御クラス。
    """

    def __init__(self, definition):
        super().__init__(definition)

    @property
    def input(self):
        """
        入力元。
        """
        if self._input is None:
            msg = "入力 (input) が設定されていません。入力は省略できません"
            raise ValueError(msg)

        from batch_architecture.io_target import Target

        return Target.parse(self._input)

    @property
    def output(self):
        """出力先。"""
        if self._output is None:
            msg = "出力 (output) が設定されていません。出力は省略できません"
            raise ValueError(msg)

        from batch_architecture.io_target import Target

        return Target.parse(self._output)


class SQLBusinessLogic(BaseBusinessLogic):
    """
    SQLクライアントを利用するロジック制御の基底クラス
    """

    @property
    def client(self):
        # TODO: rename not to conflict with AWS client
        if hasattr(self, "_client", None) is None:
            from batch_architecture.client import SQLClient

            self._client = SQLClient()
            self._client.connect()
        return self._client

    @property
    def mode(self):
        return self.job.mode

    def _rollback(self):
        """失敗時にロールバック処理を行う場合にオーバーライドする"""
        self.client.rollback()
