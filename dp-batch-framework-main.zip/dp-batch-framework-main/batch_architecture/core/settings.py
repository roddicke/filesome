"""
実行アーキのグローバル設定を管理するクラス
"""
import os
import configparser
import platform
import pathlib
import distutils.util
import json


class _Settings(object):
    _CONF_DIR = pathlib.Path("config")

    def __init__(self, path=None):
        """
        グローバル設定管理クラスを初期化する。

        :param path: グローバル設定ファイルのパス
        """
        if path is None:
            # 環境変数がセットされてる場合は対応するconfigを読む
            try:
                self.config_path = self.conf_dir / "config_{}.ini".format(
                    os.environ["ADT_ENV"]
                )
            except KeyError:
                self.config_path = self.conf_dir / "config.ini"

        config = self.parse_config(self.config_path)

        # Config の初期化

        # TODO: デフォルト設定を指定

        # [logging]
        try:
            self.LOG_DIR = self.map_dir(pathlib.Path(config["logging"]["LOG_DIR"]))
        except KeyError:
            msg = "config.iniにログの出力先を指定してください"
            raise ValueError(msg)
        try:
            self.LOGGING_TABLE = bool(
                distutils.util.strtobool(config["logging"]["LOGGING_TABLE"])
            )
            self.LOG_TABLE_SCHEMA = config["logging"]["SCHEMA_NAME"]
        except KeyError:
            self.LOGGING_TABLE = False
            self.LOG_TABLE_SCHEMA = None
        self.LOG_FILE_NAME = "batch.log"

        # [local]
        try:
            self.TEMP_DIR = self.map_dir(pathlib.Path(config["local"]["TEMP_DIR"]))
        except KeyError:
            self.TEMP_DIR = None
        try:
            self.IFGW_LOCAL = self.map_dir(
                pathlib.Path(config["local"]["IFGW_LOCAL"])
            )
        except KeyError:
            self.IFGW_LOCAL = None
        try:
            self.END_FILE_DIR = str(config["local"]["END_FILE_DIR"])
        except KeyError:
            self.END_FILE_DIR = None
        try:
            self.POST_GO_TEMP_DIR = str(config["local"]["POST_GO_TEMP_DIR"])
        except KeyError:
            self.POST_GO_TEMP_DIR = None

        # [resource]
        try:
            self.RESOURCE_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_DIR = None
        try:
            self.RESOURCE_DEF_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_DEF_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_DEF_DIR = None
        try:
            self.RESOURCE_PYTHON_SCRIPT_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_PYTHON_SCRIPT_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_PYTHON_SCRIPT_DIR = None
        try:
            self.RESOURCE_BATCH_DATE_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_BATCH_DATE_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_BATCH_DATE_DIR = None
        try:
            self.RESOURCE_BATCH_DATE_DIR_RIT = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_BATCH_DATE_DIR"].format(
                        'rit'
                    )
                )
            )
        except KeyError:
            self.RESOURCE_BATCH_DATE_DIR_RIT = None
        try:
            self.RESOURCE_BATCH_DATE_DIR_MV = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_BATCH_DATE_DIR"].format(
                        'mv'
                    )
                )
            )
        except KeyError:
            self.RESOURCE_BATCH_DATE_DIR_MV = None
        try:
            self.RESOURCE_TABLE_DEF_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_TABLE_DEF_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_TABLE_DEF_DIR = None
        try:
            self.RESOURCE_FILE_DEF_PRE_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_FILE_DEF_PRE_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_FILE_DEF_PRE_DIR = None
        try:
            self.RESOURCE_FILE_DEF_POST_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_FILE_DEF_POST_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_FILE_DEF_POST_DIR = None
        try:
            self.RESOURCE_FILE_DEF_PARQUET_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_FILE_DEF_PARQUET_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_FILE_DEF_PARQUET_DIR = None
        try:
            self.RESOURCE_SQL_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_SQL_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_SQL_SQLS_DIR = None
        try:
            self.RESOURCE_SQL_SQLS_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_SQL_SQLS_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_SQL_SQLS_DIR = None
        try:
            self.RESOURCE_GO_EXE_DIR = self.map_dir(
                pathlib.Path(
                    config["resource"]["RESOURCE_GO_EXE_DIR"].format(
                        os.environ["ADT_RESOURCE"]
                    )
                )
            )
        except KeyError:
            self.RESOURCE_GO_EXE_DIR = None

        # [credentials]
        try:
            self.PROFILE_NAME = str(config["credentials"]["PROFILE_NAME"])
        except KeyError:
            self.PROFILE_NAME = "default"

        # [sqlserver_bind_sys]
        try:
            self.SQLSERVER_BIND = dict(
                config["sqlserver_bind_{}".format(os.environ["ADT_RESOURCE"])]
            )
        except KeyError:
            self.SQLSERVER_BIND = {}

        # [snowflake_bind_sys]
        try:
            self.SNOWFLAKE_BIND = dict(
                config["snowflake_bind_{}".format(os.environ["ADT_RESOURCE"])]
            )
        except KeyError:
            self.SNOWFLAKE_BIND = {}

        # [warehouse_bind]
        try:
            self.WAREHOUSE_BIND = dict(config["warehouse_bind"])
        except KeyError:
            self.WAREHOUSE_BIND = {}

        # [snowflake_role_bind]
        try:
            self.SNOWFLAKE_ROLE_BIND = dict(config["snowflake_role_bind"])
        except KeyError:
            self.SNOWFLAKE_ROLE_BIND = {}

        # [snowflake_schema]
        try:
            self.ERROR_SCHEMA = str(config["snowflake_schema"]["SQL_ERROR_SCHEMA"])
        except KeyError:
            self.ERROR_SCHEMA = None

        # [app]
        try:
            self.APP = dict(config["app"])
        except KeyError:
            self.APP = {}

        # [file_polling]
        try:
            self.MAX_FILE_POLLING_MIN = str(config["file_polling"]["MAX_POLLING_MIN"])
        except KeyError:
            self.MAX_FILE_POLLING_MIN = None
        try:
            self.FILE_POLLING_INTERVAL_SEC = str(config["file_polling"]["POLLING_INTERVAL_SEC"])
        except KeyError:
            self.FILE_POLLING_INTERVAL_SEC = None

        # [glue]
        try:
            self.USE_ASSUME_ROLE = bool(
                distutils.util.strtobool(config["glue"]["USE_ASSUME_ROLE"])
            )
        except KeyError:
            self.USE_ASSUME_ROLE = False
        try:
            self.ASSUME_ROLE_ARN = str(config["glue"]["ASSUME_ROLE_ARN"])
        except KeyError:
            self.ASSUME_ROLE_ARN = None
        try:
            self.MAX_GLUE_POLLING_MIN = str(config["glue"]["MAX_POLLING_MIN"])
        except KeyError:
            self.MAX_GLUE_POLLING_MIN = None
        try:
            self.GLUE_POLLING_INTERVAL_SEC = str(config["glue"]["POLLING_INTERVAL_SEC"])
        except KeyError:
            self.GLUE_POLLING_INTERVAL_SEC = None
        try:
            self.MULTI_AZ_EXECUTE = bool(
                distutils.util.strtobool(config["glue"]["MULTI_AZ_EXECUTE"])
            )
        except KeyError:
            self.MULTI_AZ_EXECUTE = None
        try:
            self.OUTPUT_CLOUDWATCH_LOGS = bool(
                distutils.util.strtobool(config["glue"]["OUTPUT_CLOUDWATCH_LOGS"])
            )
        except KeyError:
            self.OUTPUT_CLOUDWATCH_LOGS = False

        # [external_transfer]
        try:
            self.EXTERNAL_TRANSFER_SMTP_ENABLED = bool(
                distutils.util.strtobool(config["external_transfer"]["SMTP_ENABLED"])
            )
        except KeyError:
            self.EXTERNAL_TRANSFER_SMTP_ENABLED = False
        try:
            self.EXTERNAL_TRANSFER_FTP_STATUS = str(config["external_transfer"]["FTP_STATUS"])
        except KeyError:
            self.EXTERNAL_TRANSFER_FTP_STATUS = "disabled"
        try:
            self.EXTERNAL_TRANSFER_SFTP_STATUS = str(config["external_transfer"]["SFTP_STATUS"])
        except KeyError:
            self.EXTERNAL_TRANSFER_SFTP_STATUS = "disabled"

        # [execute_mode]
        try:
            self.DRY_RUN = bool(
                distutils.util.strtobool(config["execute_mode"]["DRY_RUN"])
            )
        except KeyError:
            self.DRY_RUN = False
        try:
            self.RANDOM_SLEEP_MIN = int(
                config["execute_mode"]["RANDOM_SLEEP_MIN"]
            )
        except KeyError:
            self.RANDOM_SLEEP_MIN = 21
        try:
            self.RANDOM_SLEEP_MAX = int(
                config["execute_mode"]["RANDOM_SLEEP_MAX"]
            )
        except KeyError:
            self.RANDOM_SLEEP_MAX = 40
        try:
            self.SENDING_NEXT_JOB_MSG = bool(
                distutils.util.strtobool(config["execute_mode"]["SENDING_NEXT_JOB_MSG"])
            )
        except KeyError:
            self.SENDING_NEXT_JOB_MSG = False

        # [node]
        try:
            self.NODE = dict(config["node"])
            self.NODE = {v: k for k, v in self.NODE.items()}
        except KeyError:
            self.NODE = {}

        self.ENV = os.environ["ADT_ENV"]
        self.SYS_NAME = os.environ["ADT_RESOURCE"]
        self.EXEC_MODE = 'NORMAL'  # NORMAL, DRY_RUN, VERBOSE

    def map_dir(self, path):
        """
        パス指定が相対パスの場合、ADT ホームディレクトリからのパスに変換する。
        """
        if path.is_absolute():
            return path
        else:
            return self.home_dir / path

    @property
    def home_dir(self):
        """
        ADTのホームディレクトリ(環境変数 ADT_HOME で指定されるパス、
        もしくはカレントディレクトリ) を取得する。
        """
        try:
            base = os.environ["ADT_HOME"]
        except KeyError:
            base = "."
        return pathlib.Path(base)

    @property
    def conf_dir(self):
        """
        ADTの設定ディレクトリを取得する。
        """

        try:
            base = os.environ["ADT_HOME"]
            typ = "環境変数 ADT_HOME で指定されるパス {0}".format(base)
        except KeyError:
            base = "."
            typ = "カレントディレクトリ"

        conf_dir = pathlib.Path(base) / self._CONF_DIR

        if not conf_dir.is_dir():
            msg = "{0} に {1} ディレクトリがありません。" "ADTの設定ファイルが読み込めません"
            raise FileNotFoundError(msg.format(typ, self._CONF_DIR))
        return conf_dir

    @property
    def node_name(self):
        node_name = platform.uname().node
        return self.NODE[node_name] if node_name in self.NODE else 'unknown'

    def parse_config(self, path):
        """
        指定された設定ファイルを読み込む。

        :param path: 設定ファイルのパスf
        """
        path = pathlib.Path(path)

        if not path.is_file():
            msg = "カレントディレクトリに {} ファイルがありません。" "ADTの設定ファイルが読み込めません"
            raise FileNotFoundError(msg.format(path))

        config = configparser.ConfigParser()
        config.optionxform = str
        config.read(str(path), encoding="utf-8")
        return config

    def parse_json_config(self, path):
        """
        指定されたJsonファイルをdictにして返す
        """
        path = pathlib.Path(path)
        if not path.is_file():
            msg = "カレントディレクトリに {} ファイルがありません。" "ADTの設定ファイルが読み込めません"
            raise FileNotFoundError(msg.format(path))
        with open(str(path), "r", encoding="utf-8") as j:
            try:
                json_dict = json.loads(j.read())
            except json.decoder.JSONDecodeError:
                msg = "jsonがパースできません。フォーマットに不備があります。{}"
                raise json.decoder.JSONDecodeError(msg.format(path))

        return json_dict


Settings = _Settings()
