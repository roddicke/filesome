"""
ADT 実行アーキの初期化、ジョブ実行を行うクラス
"""
import os
import re
import json
import warnings
import sys
from batch_architecture.core.batch_date import BatchDate

from batch_architecture.core.settings import Settings
from batch_architecture.core.base import Base
from batch_architecture.core.job import Job
from batch_architecture.core.table_logging import table_logging
from batch_architecture.client.sqs_client import SqsClient


class BatchManager(Base):
    """
    ADT 実行アーキの初期化、ジョブ実行を行うクラス
    """

    _LOGGER_NAME = "adt"

    def __init__(self, job_id, parameter_id=None, args=None):
        """
        実行アーキを初期化する。

        :param job_id: 実行する ジョブの ID (json ファイル名)
        :param parameter_id: ジョブ定義書内の置換項目を指定するパラメータのID(ini ファイル名)
        """
        self.job_id = job_id
        self.parameter_id = parameter_id
        self.args = args

        # 半角英数字以外が含まれているかチェックする。
        regexp = re.compile(r"^[\x20-\x7E]+$")
        result = regexp.search(self.job_id)
        if not result:
            msg = "Job ID に使用できるのは半角英数字のみです: {0}"
            raise ValueError(msg.format(self.job_id))

    def sending_next_job_message(self, next_job_args={}):
        """
        sqsに後続ジョブ発砲用のメッセージを送信する
        ①ジョブ定義の読み込み
        ②ジョブ定義内のパラメータの置換
        ③メッセージの作成
        ④メッセージの送信
        """
        file_path = Job.get_file_path(self.job_id, None, ".json")
        try:
            with file_path.open(encoding="utf_8_sig") as j:
                job_def = j.read()
            # job_def内の{{}}で囲まれた変数を--argsで渡された置換項目で置換
            if self.args is not None:
                parameters = json.loads(self.args)
                for key, value in parameters.items():
                    replacer = "{{" + key + "}}"
                    if replacer in job_def:
                        job_def = job_def.replace(replacer, str(value))
            # job_defはこの時点で文字列なので辞書型に変換
            job_def = json.loads(job_def)
            next_job_id_list = job_def["job"]["next_job_id"]
            # next_job_idが指定されていない場合SQS送信をスキップ
            if len(next_job_id_list) == 0:
                return
            job_args = job_def["job"].get("next_job_args", {})
            job_args.update(next_job_args)
            sqs = SqsClient()
            sqs_url = self.resources.get("sqs").job_queue
            messages = []
            for next_job_id in next_job_id_list:
                self.logger.info("SQSに送信するメッセージを作成します。")
                message_body = {
                    "Records": [
                        {
                            "eventSource": "dp:job",
                            "job": {
                                "id": "{}".format(next_job_id),
                                "name": "{}".format(next_job_id),
                                "args": job_args,
                                "system": "{}".format(os.environ["ADT_RESOURCE"]),
                            },
                        }
                    ]
                }
                # コマンドライン引数からバッチ日付を渡されている場合
                if BatchDate.has_command_line_args_batch_date is True:
                    message_body["Records"][0]["job"].update({"batch_date": BatchDate.batch_date})
                self.logger.info(message_body)
                messages.append(json.dumps(message_body))
            sqs.send_message_batch(sqs_url, messages, 3)
            self.logger.info(
                "次に実行するジョブをジョブキューに送信しました: {}".format(str(next_job_id_list))
            )
        except KeyError:
            msg = "ジョブ定義に'next_job_id'キーの設定がありません。"
            self.logger.warn(msg)
            return
        except Exception as e:
            msg = "ジョブキューメッセージ送信実行中に {e}({msg}) が発生しました。"
            self.logger.error(msg.format(logic=self, e=e.__class__.__name__, msg=e))
            raise

    def execute(self):
        """ジョブを実行する。"""
        self.logger.info("=" * 100, cout=True)
        self.logger.info("実行コマンド : " + " ".join(sys.argv), cout=True)
        self.logger.info("実行環境 : Python " + sys.version.replace('\n', ' '), cout=True)
        self.logger.info("JOB_ID : {}".format(self.job_id), cout=True)
        msg = "バッチ処理日付：[{batch_date}]"
        self.logger.info(msg.format(batch_date=self.batch_date.batch_date), cout=True)
        msg = "参照設定ファイル -> {config}, {resource}"
        self.logger.info(
            msg.format(config=self.settings.config_path, resource=self.resources.path),
            cout=True
        )
        self.logger.info("=" * 100, cout=True)

        try:
            job_def_path = Job.get_file_path(self.job_id, None, '.json')
            self.logger.info("ジョブ定義を読み込みます: {path}".format(path=job_def_path), cout=True)
            job = Job.load_json(
                path_or_id=self.job_id,
                path_or_parameter=self.parameter_id,
                args=self.args,
            )
        except Exception as e:
            table_logging.json_format_error_logging(self.job_id, e, BatchDate.batch_date)
            raise

        @table_logging.job_logging
        def exec_job(job):
            with warnings.catch_warnings(record=True) as w:
                try:
                    job.execute()
                finally:
                    if w:
                        self.logger.warning('[%s](%s:%s) %s' % (
                            w[-1].category.__name__, w[-1].filename, w[-1].lineno, w[-1].message))

            next_job_args = job.get_next_job_args()

            # 後続ジョブの実行指示メッセージをジョブキューに送る
            if Settings.SENDING_NEXT_JOB_MSG is True:
                try:
                    self.sending_next_job_message(next_job_args=next_job_args)
                except Exception:
                    raise

        exec_job(job)
        return
