"""
実行アーキの例外クラス
"""


class RetryOutError(Exception):
    """
    リトライ回数が規定値を超えた場合に発生させる例外
    """
    pass
