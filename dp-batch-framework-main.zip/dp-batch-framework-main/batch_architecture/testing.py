"""
テストの基底クラス
"""
import pathlib
import unittest

from batch_architecture.core.job import Job


class TestCase(unittest.TestCase):
    FTP_HOST = "10.0.3.168"

    SFTP_HOST = "10.0.3.236"
    SFTP_USER = "ec2-user"
    SFTP_PASS = "Test-sftp"

    TEST_HOME_DIR = "/home/ec2-user"

    # データレイク開発環境用バケット
    # S3_BUCKET = 'kddi-dmp-dev-datalake-work'
    # S3_BUCKET_BACKUP = 'kddi-dmp-dev-datalake-backup'

    # ACP環境用バケット
    S3_BUCKET = "adt-develop"
    S3_BUCKET_BACKUP = "adt-develop-backup"

    TEST_DIR = pathlib.Path(__file__).parent / "tests"
    TEST_RESOURCE = TEST_DIR / "resources"
    TEST_DATA = TEST_DIR / "testdata"

    def load_job(self, job_id, test=True):
        """
        本番用の resource_data からジョブを読み出す
        """
        if test is True:
            return Job.load_json(job_id, resource_dir=self.TEST_DATA / "job_def")
        else:
            return Job.load_json(job_id)

    @classmethod
    def cleanup_ftp_server(cls):
        """
        テスト用FTPサーバの「全ての」ファイル・ディレクトリを削除する。
        """
        from batch_architecture.client import FTPClient

        ftp = FTPClient()
        ftp.connect(cls.FTP_HOST)
        for p in ftp.ls():
            ftp.delete(p)

    @classmethod
    def cleanup_sftp_server(cls):
        """
        テスト用SFTPサーバの「全ての」ファイル・ディレクトリを削除する。
        """
        from batch_architecture.client import SFTPClient

        sftp = SFTPClient()
        sftp.connect(
            hostname=cls.SFTP_HOST, user=cls.SFTP_USER, port=22, passwd=cls.SFTP_PASS
        )
        sftp.cwd(cls.TEST_HOME_DIR)
        for p in sftp.ls():
            sftp.delete(p)

    @classmethod
    def cleanup_s3_bucket(cls):
        """
        テスト用S3バケットの「全ての」ファイル・ディレクトリを削除する。
        """
        import boto3

        s3 = boto3.resource("s3")
        bucket = s3.Bucket(cls.S3_BUCKET)

        for p in bucket.objects.all():
            p.delete()
