import os

from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.client.snowflake_client import SnowflakeClient


class UpdateBatchDateFile(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.update_batch_date_file"

    def _init_logic(self, script, script_args):
        self.script_bind = script_args.get("bind")
        env_bind = self.settings.SNOWFLAKE_BIND
        self.script_bind.update(env_bind)

    def _get_batch_date(self):

        self.sf_client = SnowflakeClient()
        self.sf_client.connect()
        self.logger.info("みなし日テーブルからみなし日を取得します。")
        get_batch_date_sql = "SELECT CRRNT_DATE FROM {DB_NAME}.{SCHEMA_NAME}.{TABLE_NAME}"
        self.logger.info(get_batch_date_sql)
        self.sf_client.execute_sql(get_batch_date_sql, self.script_bind)
        batch_date = str(self.sf_client.fetch_one()[0])
        self.logger.info(f"みなし日 : {batch_date}")

        return batch_date

    def _execute(self):
        """みなし日テーブルからみなし日を取得してファイルに書き込む"""
        batch_date = self._get_batch_date()
        batch_date_file = os.path.join(self.settings.RESOURCE_BATCH_DATE_DIR, "batch_date.txt")
        self.logger.info(f"みなし日ファイルを更新します: {batch_date_file}")
        with open(batch_date_file, "w") as f:
            f.write(batch_date)
        self.logger.info("みなし日ファイルの更新が完了しました。")

        """dwhのみなし日をritのbatch_date.txtファイルに書き込む"""
        if 'dwh' == self.settings.SYS_NAME:
            batch_date_file = os.path.join(self.settings.RESOURCE_BATCH_DATE_DIR_RIT, "batch_date.txt")
            self.logger.info(f"rit用のみなし日ファイルを更新します: {batch_date_file}")
            with open(batch_date_file, "w") as f:
                f.write(batch_date)
            self.logger.info("rit用のみなし日ファイルの更新が完了しました。")

            batch_date_file = os.path.join(self.settings.RESOURCE_BATCH_DATE_DIR_MV, "batch_date.txt")
            self.logger.info(f"mv用のみなし日ファイルを更新します: {batch_date_file}")
            with open(batch_date_file, "w") as f:
                f.write(batch_date)
            self.logger.info("mv用のみなし日ファイルの更新が完了しました。")