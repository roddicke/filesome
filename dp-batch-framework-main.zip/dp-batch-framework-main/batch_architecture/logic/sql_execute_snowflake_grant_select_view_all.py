import os

from batch_architecture.core.logic import SQLBusinessLogic
from batch_architecture.client.snowflake_client import SnowflakeClient
from batch_architecture.core.schedule_utils import ScheduleUtils
from batch_architecture.cmd.windows_log import WindowsEventLog


class SnowflakeSQLExecuteGrantSelectViewAllLogic(SQLBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake_grant_select_view_all"

    def _init_logic(self, script, script_args):
        """
        GrantSelectView 固有の初期化処理を行う
        """
        self.logger.info("snowflake バインド変数一覧: {}".format(self.settings.SNOWFLAKE_BIND))
        self.target_database_bind = script_args.get("target_database")
        self.warehouse = script_args.get('warehouse').format(**self.settings.WAREHOUSE_BIND)
        self.switch_user = script_args.get("switch_user")

    @property
    def client(self):
        """
        Snowflakeへの接続
        """
        if getattr(self, "_client", None) is None:
            res_user = None
            if self.switch_user:
                res_user = os.environ["ADT_RESOURCE"]
                os.environ["ADT_RESOURCE"] = self.switch_user
            try:
                self._client = SnowflakeClient(warehouse=self.warehouse)
                self._client.connect()
            finally:
                if res_user:
                    os.environ["ADT_RESOURCE"] = res_user

        return self._client

    def _get_current_mst_table_record(self) -> dict:
        query = "SELECT TBL_BTSR_ID, TBL_RNR FROM {DB_NSONLINET}.{SCHEMA_NAME}.SK9ON018;"
        query = query.format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info('現在のSK9ON018に存在するテーブルの一覧を取得します。')
        self.client.execute_sql(query)
        dict_current_mst_table = {t[0]: t[1] for t in self.client.fetch_all()}
        return dict_current_mst_table

    def _get_table_name_jp_from_tab_def(self, table_name) -> str:
        # テーブル論理名をtab_defから取得する
        tab_def_path = str(self.settings.RESOURCE_TABLE_DEF_DIR) + f'/{table_name}.json'
        try:
            d = self.settings.parse_json_config(tab_def_path)
            table_name_jp = d['table_name_jp']
        except FileNotFoundError:
            msg = "ファイルが見つかりません: {}".format(
                str(self.settings.RESOURCE_TABLE_DEF_DIR)
                + f"/{table_name}.json"
            )
            self.logger.error(msg)
            table_name_jp = ''
        except KeyError:
            msg = 'Key "table_name_jp" がjson内に見つかりません: {}'.format(
                str(self.settings.RESOURCE_TABLE_DEF_DIR)
                + f"/{table_name}.json"
            )
            self.logger.error(msg)
            table_name_jp = ''
        except Exception as e:
            raise e
        return table_name_jp

    def _execute(self) -> None:
        # VIEW一覧を取得する
        self.logger.info(f'view_update_schedule_mstテーブルから"{self.target_database_bind}"のVIEW一覧を取得します。')
        dict_view_list = ScheduleUtils.get_view_list_from_view_update_schedule_mst(self.target_database_bind)
        database = self.target_database_bind.format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info(f'Database: {database}, {len(dict_view_list)}本')

        # 現在のSK9ON018のテーブル一覧を取得
        dict_current_mst_table = self._get_current_mst_table_record()

        lst_err_msg = []
        grant_cnt = 0
        err_cnt = 0
        # SK9ON018のカラムKIK_KBNの値を1(開局)にアップデートするクエリ
        lst_update_query = [
            f"UPDATE {{DB_NSONLINET}}.{{SCHEMA_NAME}}.SK9ON018",
            f"SET",
            f"     KIK_KBN = 1",
            f"    ,UPDATED_UID = '{self.client._username}'",
            f"    ,UPDATED_YMDHMS = CURRENT_TIMESTAMP()"
        ]
        lst_where_cond_tables = []
        for view, dict_view_info in dict_view_list.items():
            grant_cnt += 1
            src_database_bind = dict_view_info['src_database_bind']
            self.logger.info(f'[{grant_cnt}]{database}.{{SCHEMA_NAME}}.{view}へのSELECT権限のGRANT文を発行します。'
                             .format(**self.settings.SNOWFLAKE_BIND))
            # GRANT文を発行する
            if self.target_database_bind in ['{DB_SASPRD}', '{DB_SASMA}', '{DB_SASWK}']:
                role = '{SAS_OWNER_ROLE}'.format(**self.settings.SNOWFLAKE_ROLE_BIND)
                query = f"GRANT SELECT ON VIEW {database}.{{SCHEMA_NAME}}.{view} TO ROLE {role};"
            elif self.target_database_bind in ['{DB_NSDCV_MASKED}', '{DB_NSDCV_SECURE}']:
                role = f'{database}.DB_ROLE'
                query = f"GRANT SELECT ON VIEW {database}.{{SCHEMA_NAME}}.{view} TO DATABASE ROLE {role};"
            else:
                role = f'{database}_OWNER_ROLE'
                query = f"GRANT SELECT ON VIEW {database}.{{SCHEMA_NAME}}.{view} TO ROLE {role};"
            query = query.format(**self.settings.SNOWFLAKE_BIND)
            try:
                self.client.execute_string(query)
            except Exception as e:
                err_cnt += 1
                self.logger.error('SQL実行中にエラーが発生しました。 %s' % e)
                lst_err_msg.append(f'[{err_cnt}]{database}.{{SCHEMA_NAME}}.{view}: {e}')
                continue

            lst_where_cond_tables.append(f"'{view}'")
            # NSDWHの場合は元テーブルのレコードがある場合がある
            if self.target_database_bind == '{DB_SASV}' and src_database_bind == '{DB_NAME}':
                org_table = view[1:]
                lst_where_cond_tables.append(f"'{org_table}'")

                # NSDWHの1層テーブルを参照するSASVレコードが存在しない場合はレコードを追加する
                if view not in dict_current_mst_table:
                    org_table = view[1:]
                    table_name_jp = self._get_table_name_jp_from_tab_def(org_table)
                    lst_query = [
                        f"INSERT INTO {{DB_NSONLINET}}.{{SCHEMA_NAME}}.SK9ON018 (",
                        f"     TBL_BTSR_ID",
                        f"    ,TBL_RNR",
                        f"    ,RRS",
                        f"    ,KEEP_INF",
                        f"    ,TBL_INF",
                        f"    ,KIK_KBN",
                        f"    ,CREATED_UID",
                        f"    ,UPDATED_UID",
                        f"    ,CREATED_YMDHMS",
                        f"    ,UPDATED_YMDHMS",
                        f")",
                        f"VALUES",
                        f"(",
                        f"     '{view}'",
                        f"    ,'{table_name_jp}'",
                        f"    ,''",
                        f"    ,''",
                        f"    ,'SASV'",
                        f"    ,1",
                        f"    ,'{self.client._username}'",
                        f"    ,'{self.client._username}'",
                        f"    ,CURRENT_TIMESTAMP()",
                        f"    ,CURRENT_TIMESTAMP()"
                        f");"
                    ]
                    self.logger.info(f'SK9ON018に{view}のレコードがないので追加します。')
                    query = '\n'.join(lst_query).format(**self.settings.SNOWFLAKE_BIND)
                    try:
                        self.client.execute_string(query)
                    except Exception as e:
                        err_cnt += 1
                        self.logger.error('INSERTのSQL実行中にエラーが発生しました。 %s' % e)
                        lst_err_msg.append(f'[{err_cnt}]{database}.{{SCHEMA_NAME}}.{view}: {e}')

        # GRANTを実行したVIEWのレコードのKIK_KBNの値を1(開局)に更新する
        where_cond_tables = '\n,'.join(lst_where_cond_tables)
        lst_update_query.append(f"WHERE TBL_BTSR_ID IN (\n{where_cond_tables}\n);")
        query = '\n'.join(lst_update_query).format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info(f'テーブルSK9ON018のカラムKIK_KBNの値を1(開局)に更新します。')
        try:
            self.client.execute_string(query)
        except Exception as e:
            self.logger.error('SK9ON018へのUPDATEのSQL実行中にエラーが発生しました。 %s' % e)
            lst_err_msg.append('SK9ON018へのUPDATEのSQL実行中にエラーが発生しました。')

        # SK9ON018内のテーブル論理名が空文字のレコードに対して、更新ができれば更新する
        lst_table_name_jp_empty_record = [
            k[1:] for k, v in dict_current_mst_table.items() if v == ''
        ]
        for table_name in lst_table_name_jp_empty_record:
            table_name_jp = self._get_table_name_jp_from_tab_def(table_name)
            if table_name_jp == '':
                continue
            lst_query = [
                f"UPDATE {{DB_NSONLINET}}.{{SCHEMA_NAME}}.SK9ON018",
                f"SET TBL_RNR = '{table_name_jp}'",
                f"WHERE TBL_BTSR_ID = 'V{table_name}'",
                ";"
            ]
            query = '\n'.join(lst_query).format(**self.settings.SNOWFLAKE_BIND)
            self.logger.info(f'{table_name}のテーブル論理名を更新します。')
            try:
                self.client.execute_sql(query)
            except Exception as e:
                self.logger.error('UPDATEのSQL実行中にエラーが発生しました。 %s' % e)
                lst_err_msg.append(f'SK9ON018への論理名UPDATEのSQL実行中にエラーが発生しました。: V{table_name}')

        self.client.close()

        self.logger.info(f'{grant_cnt - err_cnt}/{grant_cnt}件のGRANT文実行に成功しました。')
        if err_cnt > 0:
            self.logger.error(f'{err_cnt}件のエラーが発生しました。')
            err_msg_summary = f'個別開局リカバリ手動実行用プログラムアラート\n' \
                              f'JOB_ID: {self.job_id}\n' \
                              f'みなし日: {self.batch_date.batch_date}\n'\
                              + '\n'.join(lst_err_msg)
            self.logger.warning(f'Windowsイベントログに以下のWarningを出力します。\n{err_msg_summary}', cout=True)
            w = WindowsEventLog()
            w.output_event_log(err_msg_summary, 'Warning')
