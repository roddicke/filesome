import datetime
import configparser

from batch_architecture.core.logic import BaseBusinessLogic
from dateutil.relativedelta import relativedelta


class WriteParametersLogic(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.write_parameters"

    def _init_logic(self, update, fmt=None):
        """
        WriteParameters 固有の初期化処理を行う

        :param update: 更新項目と更新ルールを示す辞書
        :param fmt:日付表示のフォーマット
        """
        self.update = update
        if fmt is None:
            self.fmt = {}
        else:
            self.fmt = fmt

        for k in self.update:
            if self.update[k] == "day":
                self.fmt[k] = self.fmt.get(k, "%Y%m%d")
            elif self.update[k] == "month":
                self.fmt[k] = self.fmt.get(k, "%Y%m")

    def get_parameter_path(self):
        # WriteParametersLogicのインスタンスが生成された時点ではJobのインスタンスが生成されていない
        # parameter_pathはJobインスタンス生成後に取得可能
        if self.job.parameter_path is None:
            msg = "Job実行時にパラメータファイルが指定されていないため、パラメータファイルを更新できません"
            raise FileNotFoundError(msg)
        return self.job.parameter_path

    def update_parameter(self, param, rule, fmt, count=1):
        if rule == "day" or rule == "month":
            try:
                param = datetime.datetime.strptime(param, fmt)
            except ValueError:
                msg = (
                    "値 {param} を指定したフォーマット {fmt} へ変換できません。"
                    "パラメータファイル内の日付フォーマットを変更するか、"
                    "ジョブ定義ファイル内の指定フォーマットを変更してください。"
                )
                raise ValueError(msg.format(param=param, fmt=fmt))

            if rule == "day":
                # str型をdate型に変換
                newdate = param + relativedelta(days=count)
                return newdate.strftime(fmt)
            elif rule == "month":
                newdate = param + relativedelta(months=count)
                return newdate.strftime(fmt)
        else:
            msg = "ジョブ定義ファイル内に不正な更新ルール {rule} が含まれています。" "実行できる更新ルールはday, monthです"
            raise ValueError(msg.format(rule=rule))

        return param

    def _execute(self):
        parameters = self.job.parameters

        if not all(key in parameters for key in self.update):
            msg = "ジョブ定義ファイル内で指定された更新項目に、パラメータファイル内に存在しない項目が含まれているため、更新できません。"
            raise ValueError(msg)

        for key, value in parameters.items():
            if key in self.update:
                rule = self.update.get(key)
                fmt = self.fmt.get(key)
                new_value = self.update_parameter(param=value, rule=rule, fmt=fmt)
                parameters[key] = new_value

        parser = configparser.ConfigParser()
        parser["config"] = parameters

        parameter_path = self.job.parameter_path
        with open(str(parameter_path), "w") as file:
            parser.write(file)
