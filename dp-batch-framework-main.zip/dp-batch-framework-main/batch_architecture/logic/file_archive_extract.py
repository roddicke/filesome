"""
ファイル・ディレクトリの圧縮・展開処理
"""
import glob
import os

from batch_architecture.core.logic import _InputOutputLogic
from batch_architecture.io_target import LocalTarget


class _CompressionLogic(_InputOutputLogic):
    _COMP_FMT_FILE = [".csv", ".tsv", ".txt", ".dat"]
    _COMP_FMT_PRE = [".zip", ".gz", ".tar.gz", ".tar", ".Z"]
    _COMP_FMT = []

    for _file in _COMP_FMT_FILE:
        for suffix in _COMP_FMT_PRE:
            _COMP_FMT.append(_file + suffix)
    _COMP_FMT.extend(_COMP_FMT_PRE)


class FileArchiveLogic(_CompressionLogic):
    """ファイル圧縮"""

    _LOGGER_NAME = "batch_architecture.logic.file_archive"

    def _init_logic(self, script, script_args):
        self.original_file_delete = script_args.get('original_file_delete', False)

    def _execute(self):
        # 現在はローカルターゲットのみサポート
        if not isinstance(self.input, LocalTarget):
            msg = "入力 {} がローカルのファイル・ディレクトリではありません。" "ローカルのファイル・ディレクトリ以外は圧縮できません。"
            raise ValueError(msg.format(self.input))

        if not isinstance(self.output, LocalTarget):
            msg = "出力 {} がローカルの圧縮ファイルではありません。"
            raise ValueError(msg.format(self.output))

        if "".join(self.output.suffixes) not in self._COMP_FMT:
            msg = "出力 {out} で指定された圧縮形式はサポートしていません。" "拡張子として {fmt} いずれかを指定してください"
            raise ValueError(
                msg.format(out=self.output, fmt=", ".join(self._COMP_FMT))
            )

        import batch_architecture.etl.archive as a

        output_dir = os.path.dirname(str(self.output._path))
        if os.path.exists(output_dir) is False:
            os.makedirs(output_dir, exist_ok=True)

        if '*' in str(self.input._path):
            inputs = list(glob.glob(str(self.input._path)))
            a.archive_files(inputs, self.output._path)
        elif self.input.is_dir():
            a.archive_dir(self.input._path, self.output._path)
            if self.original_file_delete is True:
                self.logger.info("元ディレクトリを削除します。{}".format(self.input))
                self.input.delete()
            return
        elif self.input.is_file():
            a.archive_file(self.input._path, self.output._path)
            if self.original_file_delete is True:
                self.logger.info("元ファイルを削除します。{}".format(self.input))
                self.input.delete()
            return
        else:
            msg = "圧縮するパス {0} が存在しません".format(self.input)
            raise FileNotFoundError(msg)


class FileExtractLogic(_CompressionLogic):
    """圧縮ファイル解凍"""

    _LOGGER_NAME = "batch_architecture.logic.file_archive_extract"

    def _init_logic(self, script, script_args):
        self.original_file_delete = script_args.get('original_file_delete', False)

    def _execute(self):
        # 現在はローカルターゲットのみサポート
        if not isinstance(self.input, LocalTarget):
            msg = "入力 {} がローカルの圧縮ファイルではありません。" "ローカルのファイル以外は展開できません。"
            raise ValueError(msg.format(self.input))

        if "".join(self.input.suffixes) not in self._COMP_FMT:
            msg = "入力 {out} で指定された圧縮形式はサポートしていません。" "拡張子として {fmt} いずれかを指定してください"
            raise ValueError(
                msg.format(out=self.input, fmt=", ".join(self._COMP_FMT))
            )

        if self.input.get_file_size() == 0:
            msg = "入力 {} が0バイトファイルのため、ファイルを解凍せず、後続処理をスキップします。"
            self.logger.warning(msg.format(self.input))
            return "skip"

        if not isinstance(self.output, LocalTarget):
            msg = "出力 {} がローカルのファイル・ディレクトリではありません。"
            raise ValueError(msg.format(self.output))

        if self.input.exists():
            output_dir = os.path.dirname(str(self.output._path))
            if os.path.exists(output_dir) is False:
                os.makedirs(output_dir, exist_ok=True)

            # TODO: 上書き禁止
            import batch_architecture.etl.archive as a

            a.extract(self.input._path, self.output._path)
            if self.original_file_delete is True:
                self.logger.info("元ファイルを削除します。{}".format(self.input))
                self.input.delete()
            return
        else:
            msg = "解凍するパス {0} が存在しません".format(self.input)
            raise FileNotFoundError(msg)
