from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.io_target import Target


class FileExistenceLogic(BaseBusinessLogic):

    _LOGGER_NAME = "batch_architecture.logic.file_existence"

    def _init_logic(self, script, script_args):
        self.target = Target.parse(script_args['target'])

    def _execute(self):
        if self.target.is_file():
            pass
        elif self.target.is_dir():
            msg = "指定されたパス {0} はファイルではありません"
            raise FileExistsError(msg.format(self.target))
        else:
            msg = "指定されたパス {0} は存在しません"
            raise FileNotFoundError(msg.format(self.target))

    def _rollback(self):
        """
        失敗時にロールバック処理を行う。
        """
        if getattr(self.target, "_client", None) is not None:
            self.target._client = None
