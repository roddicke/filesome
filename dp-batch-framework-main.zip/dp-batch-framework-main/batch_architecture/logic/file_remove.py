from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.io_target import Target


class FileRemoveLogic(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.file_remove"

    def _init_logic(self, script, script_args):
        self.target = Target.parse(script_args['target'])
        if not self.target.exists:
            msg = "指定されたパス{0}は存在しません。"
            raise FileNotFoundError(msg)

    def _execute(self):
        self.target.delete()
