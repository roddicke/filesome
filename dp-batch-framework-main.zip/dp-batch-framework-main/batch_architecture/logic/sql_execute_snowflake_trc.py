from batch_architecture.core.batch_date import BatchDate
from batch_architecture.logic.sql_execute_snowflake import SnowflakeSQLExecuteLogic


class HandledDatabaseError(Exception):
    """
    エラーハンドリング済みのDBエラーに対し発生させる例外
    """

    def __init__(self, e=None):
        self._e = e

    def get_error_code(self):
        return self._e.args[0]


class SnowflakeSQLExecuteTrcLogic(SnowflakeSQLExecuteLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake_trc"

    def _init_logic(self, script, script_args):
        super()._init_logic(script, script_args)
        self.chk_lgc_seq_no = script_args.get("CHK_LGC_SEQ_NO")
        self.__lst_param_separator = [
            " ",
            ",",
            ";",
            "\t",
            "\n",
            ")",
            "*",
            "/",
            "+",
            "-",
            "%",
        ]

    def _preset_query_parameter(self, query, dict_params):
        """
        クエリの実行時パラメータをバインドする。
        但しODBCのバインドではなく、SQLクエリ中の文字列'?'で宣言された変数名を元に、SQL中の変数箇所を直接置換する
        :param query: ファイルから読み込んだSQL文そのもの。INSERTやDELETEなどのクエリ
        :param dict_params: SQL外部から取得したパラメータリスト
        :return:
        """
        self.logger.info("----+" * 10)
        self.logger.info("SQL ? パラメータセット")

        dict_query_params = {}  # 置換対象変数リスト。行単位で変数宣言箇所を解析の上、リストを作成する。
        lst_query_output = []

        # SQLを行単位で構文チェックし、①宣言された変数の識別と蓄積、②変数から値への置換、を逐次置換する
        for query_row in query.split("\n"):

            # ①コメントアウトされていない行で、SETでの宣言で、?が存在する行を対象に、変数識別
            if (
                    query_row.strip()[0:2] != "--"
                    and "SET" in query_row
                    and "?" in query_row
            ):

                # 行をスペース/タブで分割し、宣言文の構文解析
                lst_words = query_row.split()
                param_name = lst_words[1]  # 1:変数名(0:"SET")
                # 処理基準日
                if "targetDate" in query_row:
                    # シングルクォーテーションで囲む
                    var_batch_date = "'" + str(self.batch_date.batch_date) + "'"

                    self.logger.info(
                        "REPLACE: {n} = {v}".format(n="targetDate", v=var_batch_date)
                    )
                    dict_query_params["targetDate"] = {
                        "name": "処理基準日",
                        "value": var_batch_date,
                    }
                    lst_query_output.append(
                        "-- " + query_row.replace("?", str(var_batch_date))
                    )

                # 処理基準月
                elif "targetMonth" in query_row:
                    # シングルクォーテーションで囲む
                    var_batch_month = "'" + str(self.batch_date.batch_month) + "'"
                    self.logger.info(
                        "REPLACE: {n} = {v}".format(n="targetMonth", v=var_batch_month)
                    )
                    dict_query_params["targetMonth"] = {
                        "name": "処理基準月",
                        "value": var_batch_month,
                    }
                    lst_query_output.append(
                        "-- " + query_row.replace("?", str(var_batch_month))
                    )

                # その他のパラメータ
                else:
                    # 宣言されている変数の型桁に応じて、外部のマスタデータに定義された内容を編集のうえ、置換リストに追加
                    if param_name in dict_params:

                        # シングルクォーテーションで囲む
                        # カンマ区切りの場合はカンマで区切った単位でシングルクォーテーションで囲むようにする
                        param_value = (
                                "'"
                                + dict_params[param_name]["value"].replace(",", "','")
                                + "'"
                        )

                        # 置換対象変数リストに追加
                        dict_query_params[param_name] = {
                            "name": dict_params[param_name]["name"],
                            "value": param_value,
                        }
                        self.logger.info(
                            "REPLACE: {n} = {v}".format(n=param_name, v=param_value)
                        )

                        # 宣言識別の完了した変数宣言行は、実際には実行不要なため、コメントアウトする
                        lst_query_output.append(
                            "-- " + query_row.replace("?", str(param_value))
                        )
                    else:
                        raise ValueError(
                            "SQL内で宣言された変数{s}が、パラメータマスタに存在しないので置き換えできません。".format(
                                s=param_name
                            )
                        )

            # ②変数から値への置換：宣言部以外の行については、置換対象変数リストを基に置換
            else:
                replaced_query_row = self._replace_sql_parameter(
                    query_row, dict_query_params
                )
                lst_query_output.append(replaced_query_row)

        return "\n".join(lst_query_output)

    def _replace_sql_parameter(self, query_row, dict_params):
        """
        クエリの実行時パラメータを置換する。
        単純な文字列置換だと、命名が似通った変数を過って置換してしまうため、構文解析を正しく行ってから置換する。
        ※変数宣言の開始文字位置は'@'で固定であるが、終了文字位置は半角スペース/カンマ/タブ/改行/括弧等での識別が必要
        :param query_row:
        :param dict_params:
        :return:
        """
        # 構文解析を可能とするため、行末尾に改行コードを一時的に付与
        temp_row = query_row + "\n"

        # ログ向けコメントを用意。どこを置換したかを処理後に見てわかるようなコメントを付与するためのリスト
        lst_comment = []

        # 置換対象変数リスト全量について、変数名としてマッチするかを確認
        for param_name, dict_param in dict_params.items():

            # 構文解析用のセパレータを当て、完全一致するかを確認
            for separator in self.__lst_param_separator:

                # 完全一致したら、置換処理実行。コメントも記録
                if param_name + separator in temp_row:
                    temp_row = temp_row.replace(
                        "$" + param_name + separator, str(dict_param["value"]) + separator
                    )
                    if query_row[0:4] == "    ":
                        lst_comment.append(
                            "--  "
                            + query_row[4:]
                            + " -- ["
                            + dict_param["name"]
                            + "="
                            + str(dict_param["value"])
                            + "]"
                        )
                    elif query_row[0:1] == "\t":
                        lst_comment.append(
                            "--  "
                            + query_row[1:]
                            + " -- ["
                            + dict_param["name"]
                            + "="
                            + str(dict_param["value"])
                            + "]"
                        )
                    else:
                        lst_comment.append(
                            "--  "
                            + query_row
                            + " -- ["
                            + dict_param["name"]
                            + "="
                            + str(dict_param["value"])
                            + "]"
                        )

        # マッチしなければ未編集で返却
        if len(lst_comment) == 0:
            return query_row

        # マッチした場合は、返還後のクエリ行に、コメントを追記したうえで返却
        else:
            return "\n".join(lst_comment) + "\n" + temp_row.replace("\n", "")

    def _get_check_logic_params(self, chk_lgc_seq_no):
        """
        チェックロジック編集不可のロジックのパラメタをマスタから取得する
        :param chk_lgc_seq_no:
        :return:
        """
        self.logger.info("----+" * 10)
        self.logger.info("チェックロジックパラメータ取得")

        # SQL作成／実行
        try:
            query = "\n".join(
                [
                    "SELECT",
                    "    P.TAG",
                    "    ,P.PARAM_NAME",
                    "    ,TO_VARCHAR(P.PARAM_VAL) AS PARAM_VAL",
                    "FROM PA2CH_CHK_LGC_MST M",
                    "INNER JOIN",
                    "    PA2CH_CHK_LGC_PRMS P",
                    "    ON M.CHK_LGC_SEQ_NO = P.CHK_LGC_SEQ_NO",
                    "WHERE",
                    "    M.CHK_LGC_SEQ_NO = {s}".format(s=chk_lgc_seq_no),
                    "    AND TO_VARCHAR(P.TAG) NOT LIKE '%targetDate%'",  # マスタデータから削除すれば本コードは不要
                    "    AND TO_VARCHAR(P.TAG) NOT LIKE '%targetMonth%'",  # マスタデータから削除すれば本コードは不要
                ]
            )

            self.client.execute_sql(query)
            result = self.client.fetch_all()
        except Exception as e:
            self.logger.error("チェックロジックパラメータ取得中にエラーが発生しました。%s" % e)
            self.client.rollback()
            raise HandledDatabaseError(e)

        # 結果セット確認／変数へ格納し返却
        dict_params = {}
        for idx, record in enumerate(result):
            param_tag = record[0]
            param_name = record[1]
            param_value = record[2]
            dict_params[param_tag] = {"name": param_name, "value": param_value}
            self.logger.info(
                "TAG={t}, NAME={n}, VALUE={v}".format(
                    t=param_tag, n=param_name, v=param_value
                )
            )
        return dict_params

    def _get_query(self):
        """
        SQLスクリプトからクエリを取得して置換処理を行ったのちクエリを返却
        """
        if getattr(self.script, "read", None) is None:
            sql_file = self.script.open(encoding="utf-8")
        else:
            sql_file = self.script

        # チェックロジックマスタデータ確認／取得
        if self.chk_lgc_seq_no is not None:
            dict_params = self._get_check_logic_params(self.chk_lgc_seq_no)
        else:
            dict_params = {}  # チェックロジック以外の変数は初期SI時点では想定が無いので、ひとまず空辞書に。

        try:
            # 変数置換処理（取引管理システム固有変数）
            query = self._preset_query_parameter(sql_file.read(), dict_params)
            # _init_logicではまだJobインスタンスが作成されていないのでjob_idが参照できない
            self.script_bind.update({'JOB_ID': self.job_id})
            # 前段のprogramでみなし日更新された場合_init_logicでは最新batch_dateを参照できない
            self.script_bind.update({"CURRENT_DATE_SYORI": BatchDate.read_batch_date_file()})
            # バインド置換処理
            query = query.format(**self.script_bind)
            return query
        except FileNotFoundError as e:
            self.logger.error("SQLファイルが見つかりません。 %s" % e)
            raise e
        except Exception as e:
            self.logger.error("パラメータ変換処理中にエラーが発生しました。")
            raise e
