import os
import random
import time

from batch_architecture.core.logic import SQLBusinessLogic
from batch_architecture.client.snowflake_client import SnowflakeClient


class SnowflakeSQLExecuteGrantSelectExtTableLogic(SQLBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake_grant_select_ext_table"

    def _init_logic(self, script, script_args):
        """
        GrantSelectView 固有の初期化処理を行う
        """
        self.logger.info("snowflake バインド変数一覧: {}".format(self.settings.SNOWFLAKE_BIND))
        self.lst_target_view = script_args.get("target_views")
        self.warehouse = script_args.get('warehouse').format(**self.settings.WAREHOUSE_BIND)
        self.switch_user = script_args.get("switch_user")
        self.random_sleep_min = script_args.get('random_sleep_min', self.settings.RANDOM_SLEEP_MIN)
        self.random_sleep_max = script_args.get('random_sleep_max', self.settings.RANDOM_SLEEP_MAX)

    @property
    def client(self):
        """
        Snowflakeへの接続
        """
        if getattr(self, "_client", None) is None:
            res_user = None
            if self.switch_user:
                res_user = os.environ["ADT_RESOURCE"]
                os.environ["ADT_RESOURCE"] = self.switch_user
            try:
                self._client = SnowflakeClient(warehouse=self.warehouse)
                self._client.connect()
            finally:
                if res_user:
                    os.environ["ADT_RESOURCE"] = res_user

        return self._client

    def _get_source_ext_table_columns(self, source_database_bind, ext_table_name) -> list:
        lst_query = [
            f"SELECT",
            f"     COL.TABLE_NAME",
            f"    ,COL.COLUMN_NAME",
            f"    ,TAB.TABLE_TYPE",
            f"FROM {source_database_bind}.INFORMATION_SCHEMA.COLUMNS COL",
            f"INNER JOIN",
            f"(",
            f"    SELECT TABLE_NAME, 'TABLE' AS TABLE_TYPE FROM {source_database_bind}.INFORMATION_SCHEMA.TABLES",
            f"    WHERE TABLE_SCHEMA = '{{SCHEMA_NAME}}' AND TABLE_TYPE = 'EXTERNAL TABLE'",
            f"        AND TABLE_NAME = '{ext_table_name}'",
            f"    UNION ALL",
            f"    SELECT TABLE_NAME, 'VIEW' AS TABLE_TYPE  FROM {source_database_bind}.INFORMATION_SCHEMA.VIEWS",
            f"    WHERE TABLE_SCHEMA = '{{SCHEMA_NAME}}'",
            f"        AND TABLE_NAME = '{ext_table_name}'",
            f") TAB",
            f"    ON COL.TABLE_NAME = TAB.TABLE_NAME",
            f"    AND COL.TABLE_SCHEMA = '{{SCHEMA_NAME}}'",
            f";"
        ]
        query = '\n'.join(lst_query)
        # バインド変数を置換
        query = query.format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info(f'テーブル名およびカラム名を取得するSQLを実行します。')
        self.client.execute_sql(query)
        dict_target_ext_table = {}
        for r in self.client.fetch_all():
            table_name = r[0]
            column_name = r[1]
            table_type = r[2]
            # json型VALUEカラムを除く
            if column_name == 'VALUE':
                continue
            # 数字から始まるカラムや予約語カラムがあった場合のためにダブルクォートで括る
            column_name = '"' + column_name + '"'
            if table_name in dict_target_ext_table:
                dict_target_ext_table[table_name]['lst_column'].append(column_name)
            else:
                dict_target_ext_table[table_name] = {'lst_column' : [column_name], 'table_type' : table_type}

        if len(dict_target_ext_table) == 0:
            raise Exception(f'カラム情報の取得に失敗しました。（{source_database_bind}.{{SCHEMA_NAME}}.{ext_table_name}）'
                            .format(**self.settings.SNOWFLAKE_BIND))

        return dict_target_ext_table[ext_table_name]

    def _get_ddl_from_ext_table(self, source_database_bind, target_schema, ext_table_name, table_info_list) -> str:
        view_name = ext_table_name
 
        # 対象テーブルがVIEWの場合は、get_ddlの結果からVIEWを生成する
        if table_info_list['table_type'] == 'VIEW':
            query = f"SELECT GET_DDL('VIEW', '{source_database_bind}.{{SCHEMA_NAME}}.{view_name}');"
            query = query.format(**self.settings.SNOWFLAKE_BIND)
            self.client.execute_sql(query)
            view_ddl = self.client.fetch_one()[0]
            
        # 対象テーブルがVIEWでない場合は、カラム情報からVIEWを生成する
        else:
            columns = ', '.join(table_info_list['lst_column'])
            view_ddl = '\n'.join([
                f"CREATE OR REPLACE VIEW {{DB_SASV}}.{target_schema}.{view_name} AS",
                f"SELECT {columns}",
                f"FROM {source_database_bind}.{{SCHEMA_NAME}}.{ext_table_name};"
            ])
        
        view_ddl = view_ddl.format(**self.settings.SNOWFLAKE_BIND)
        return view_ddl

    def _get_current_mst_table_record(self) -> dict:
        query = "SELECT TBL_BTSR_ID, TBL_RNR FROM {DB_NSONLINET}.{SCHEMA_NAME}.EXT_TABLE_STATUS_MST;"
        query = query.format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info('現在のEXT_TABLE_STATUS_MSTに存在するテーブルの一覧を取得します。')
        self.client.execute_sql(query)
        dict_current_mst_table = {t[0]: t[1] for t in self.client.fetch_all()}
        return dict_current_mst_table

    def _execute(self) -> None:
        grant_cnt = 0

        # 現在のEXT_TABLE_STATUS_MSTのテーブル一覧を取得
        dict_current_mst_table = self._get_current_mst_table_record()

        for dict_target_info in self.lst_target_view:
            grant_cnt += 1
            database_bind = dict_target_info['target']['database']
            ext_view = dict_target_info['target']['view']

            if database_bind != '{DB_SASV}':
                raise Exception(f'SASVの外部表参照VIEWへの開局処理以外には対応していません。'
                                f'(database_bind: {database_bind}, ext_view: {ext_view})')
            if 'source' not in dict_target_info:
                raise Exception('VIEW参照先の外部表情報("source" key)が設定されていません。')

            # DDLを取得してVIEWを再作成
            source_database_bind = dict_target_info['source']['database']
            source_type = dict_target_info['source']['object_type']
            if source_type != 'TABLE(EXT)':
                raise Exception(f'ソースオブジェクトタイプは"TABLE(EXT)"である必要があります。'
                                f'(source_object_type: {source_type})')
            if source_database_bind == '{DB_NSDL}':
                target_schema = 'DL_COMMON'
            elif source_database_bind == '{DB_NSAUDIT}':
                target_schema = 'DL_AUDIT'
            else:
                target_schema = '{SCHEMA_NAME}'

            self.logger.info(f'[{grant_cnt}]{database_bind}.{target_schema}.{ext_view}を作成または再作成します。'
                             .format(**self.settings.SNOWFLAKE_BIND))

            ext_table_name = dict_target_info['source']['object_id']
            table_info_list = self._get_source_ext_table_columns(source_database_bind, ext_table_name)
            view_ddl = self._get_ddl_from_ext_table(source_database_bind, target_schema, ext_table_name, table_info_list)
                        
            # 対象がVIEWの場合、DDLにDB・スキーマ情報が含まれないため、DDL実行前にDB・スキーマを指定する
            if table_info_list['table_type'] == 'VIEW':
                query = f"USE {{DB_SASV}}.{target_schema};"
                query = query.format(**self.settings.SNOWFLAKE_BIND)
                self.client.execute_sql(query)

            try:
                self.client.execute_string(view_ddl)
            except Exception as e:
                self.logger.error(f'{database_bind}.{target_schema}.{ext_view}: GRANTのSQL実行中にエラーが発生しました。'
                                  .format(**self.settings.SNOWFLAKE_BIND))
                raise e

            # ステータス管理マスタにレコードが存在しない場合はレコードを追加する
            if database_bind == '{DB_SASV}' and ext_view not in dict_current_mst_table:
                lst_query = [
                    f"INSERT INTO {{DB_NSONLINET}}.{{SCHEMA_NAME}}.EXT_TABLE_STATUS_MST (",
                    f"     TBL_BTSR_ID",
                    f"    ,TBL_RNR",
                    f"    ,RRS",
                    f"    ,KEEP_INF",
                    f"    ,TBL_INF",
                    f"    ,KIK_KBN",
                    f"    ,CREATED_UID",
                    f"    ,UPDATED_UID",
                    f"    ,CREATED_YMDHMS",
                    f"    ,UPDATED_YMDHMS",
                    f")",
                    f"VALUES",
                    f"(",
                    f"     '{ext_view}'",
                    f"    ,''",
                    f"    ,''",
                    f"    ,''",
                    f"    ,'SASV'",
                    f"    ,1",
                    f"    ,'{self.client._username}'",
                    f"    ,'{self.client._username}'",
                    f"    ,CURRENT_TIMESTAMP()",
                    f"    ,CURRENT_TIMESTAMP()"
                    f");"
                ]
                self.logger.info(f'EXT_TABLE_STATUS_MSTに{ext_view}のレコードがないので追加します。')
                view_ddl = '\n'.join(lst_query).format(**self.settings.SNOWFLAKE_BIND)
                try:
                    self.client.execute_string(view_ddl)
                except Exception as e:
                    self.logger.error(f'{database_bind}.{target_schema}.{ext_view}: INSERTのSQL実行中にエラーが発生しました。'
                                      .format(**self.settings.SNOWFLAKE_BIND))
                    raise e

            elif database_bind == '{DB_SASV}' and ext_view in dict_current_mst_table:
                # EXT_TABLE_STATUS_MSTのカラムKIK_KBNの値を1(開局)にアップデート
                lst_query = [
                    f"UPDATE {{DB_NSONLINET}}.{{SCHEMA_NAME}}.EXT_TABLE_STATUS_MST",
                    f"SET",
                    f"     KIK_KBN = 1",
                    f"    ,UPDATED_UID = '{self.client._username}'",
                    f"    ,UPDATED_YMDHMS = CURRENT_TIMESTAMP()",
                    f"WHERE TBL_BTSR_ID = '{ext_view}'",
                    ";"
                ]
                view_ddl = '\n'.join(lst_query).format(**self.settings.SNOWFLAKE_BIND)
                self.logger.info(f'テーブルEXT_TABLE_STATUS_MSTのカラムKIK_KBNの値を1(開局)に更新します。: {ext_view}')
                # UPDATE文が複数競合すると処理が滞留してしまう場合があるので、リトライを入れる
                update_executed = False
                last_err = None
                # 10分(600秒)以上はリトライするように繰り上げ除算
                sleep_time = random.randint(self.random_sleep_min, self.random_sleep_max)
                retry_cnt = -(-600 // sleep_time)
                for i in range(retry_cnt):
                    try:
                        self.client.execute_string(view_ddl)
                    except Exception as e:
                        self.logger.warning('UPDATEのSQL実行中にエラーが発生しました。 %s' % e, cout=True)
                        last_err = e
                        if i != retry_cnt - 1:
                            self.logger.info(f'{sleep_time}秒後にリトライします。({i + 2}回目)', cout=True)
                            time.sleep(sleep_time)
                    else:
                        update_executed = True
                        break
                if update_executed is False:
                    self.logger.error(f'{database_bind}.{target_schema}.{ext_view}: '
                                      f'{retry_cnt}回試行しましたが、UPDATEのSQLを実行できませんでした。'
                                      .format(**self.settings.SNOWFLAKE_BIND))
                    raise last_err

        self.client.close()
        self.logger.info(f'{grant_cnt}件のGRANT実行に成功しました。')
