"""
ファイル・ディレクトリの転送・コピー処理
"""
import os
import tempfile

import pathlib
from batch_architecture.core.logic import _InputOutputLogic
from batch_architecture.core.settings import Settings
from batch_architecture.core.utils import get_file_id
from batch_architecture.core.table_logging import table_logging


class FileTransferLogic(_InputOutputLogic):
    """
    ファイル転送ロジック
    script_args:
        - input: 入力ファイルパス
        - output: 出力ファイルパス
        - overwrite: 上書きフラグ (デフォルト: false)
        - original_file_delete: 入力ファイル削除フラグ (デフォルト: false)
        - not_exist_ok: 入力ファイルなし可否フラグ (デフォルト: false)
        - run_following_logic: 入力ファイルなしのとき、後続ロジックをスキップせずに実行する (デフォルト: false)
    """

    _LOGGER_NAME = "batch_architecture.logic.file_transfer"
    _DISP_ATTR = ["input", "output"]

    # input の補完は BaseBusinessLogic にて実装

    def _init_logic(self, script, script_args):
        """
        FileTransfer 固有の初期化処理を行う
        """
        self.overwrite = script_args.get('overwrite', True)
        self.original_file_delete = script_args.get('original_file_delete', False)
        self.not_exist_ok = script_args.get('not_exist_ok', False)
        self.run_following_logic = script_args.get('run_following_logic', False)
        self.write_if_transfer_log = script_args.get('write_if_transfer_log', False)

    @property
    def output(self):
        if self._output is None:
            if self.next is None:
                # 自身が最後のロジックの場合はエラー
                msg = "出力 (output) が設定されていません。" "最後のロジックの出力は省略できません"
                raise ValueError(msg)
            else:
                self._output = self._infer_output()

        return super().output

    def _infer_output(self):
        """
        入力の種類 (ファイル/ディレクトリ) に応じて、テンポラリのファイル/ディレクトリを
        作成する
        """
        if Settings.TEMP_DIR is not None:
            try:
                temp_dir = tempfile.TemporaryDirectory(
                    dir=str(pathlib.Path(Settings.TEMP_DIR))
                ).name
            except FileNotFoundError:
                msg = "指定したテンポラリディレクトリが見つかりません。config.iniファイル内のTEMP_DIRを存在するパスに変更してください"
                raise FileNotFoundError(msg.format(self))
        else:
            temp_dir = tempfile.TemporaryDirectory().name

        if self.input is None:
            msg = "入力 (input) が設定されていないため、テンポラリの出力を作成できません"
            raise ValueError(msg)
        elif self.input.is_dir():
            temp_path = temp_dir
        elif self.input.is_file():
            temp_path = os.path.join(temp_dir, self.input.basename)
        else:
            # ファイルの存在は copy_toで実施されるべき
            msg = "入力元 {0} が存在しないため、テンポラリの出力を作成できません".format(self.input)
            raise ValueError(msg)

        from batch_architecture.io_target import LocalTarget

        return LocalTarget(temp_path)

    def _transfer(self):
        if self.not_exist_ok and not self.input.exists():
            msg = "%s が存在しないためスキップします。" % self._input
            self.logger.info(msg)
            return 'skip'

        try:
            self.logger.info(f"ファイル転送: {self._input} -> {self._output} を開始します。")
            self.input.copy_to(self.output)
            self.logger.info("ファイル転送を完了しました。")
            return
        except NotImplementedError:
            msg = "テンポラリファイルを経由して転送を行います"
            self.logger.info(msg)

            # ローカルにテンポラリファイルを作成
            temp = self._infer_output()

            self.input.copy_to(temp)
            try:
                temp.copy_to(self.output)
            except Exception:
                if temp.is_file():
                    temp.parent.delete()
                if temp.is_dir():
                    temp.delete()
                msg = "テンポラリーファイルからoutputへの転送に失敗しました。"
                raise ValueError(msg)

            if temp.is_file():
                temp.parent.delete()
            if temp.is_dir():
                temp.delete()

    def _write_if_transfer_log(self):
        """
        運用管理データベースのテーブルにファイル送信のログレコードを追加する
        """
        output_path = str(self.output.path).replace('\\', '/')
        file_name = output_path.split('/')[-1]
        file_id = get_file_id(file_name)
        object_class = self.output.__class__.__name__
        transfer_type = object_class.replace('Target', '').upper()
        if transfer_type == 'S3':
            transfer_path = f's3://{self.output._bucket_name}/{output_path}'
        elif transfer_type == 'FTP':
            transfer_path = f'ftp://{self.output._hostname}/{output_path}'
        else:
            transfer_path = output_path
        dict_if_transfer_info = {
            'batch_date': self.batch_date.batch_date,
            'file_id': file_id,
            'job_id': self.job_id,
            'sys_name': os.environ["ADT_RESOURCE"],
            'transfer_type': transfer_type,
            'transfer_path': transfer_path
        }
        table_logging.if_transfer_logging(dict_if_transfer_info)

    def _execute(self):
        """
        ファイル/ディレクトリ転送実行
        """
        if self.overwrite:
            retval = self._transfer()
            if retval == 'skip':
                if self.run_following_logic:
                    self.logger.info("後続ロジックを実行します。")
                    retval = None
                else:
                    self.logger.info("後続ロジックをスキップします。")
                return retval
            if self.original_file_delete is True:
                self.logger.info("元ファイルを削除します。{}".format(self.input))
                self.input.delete()
        else:
            if self.output.exists():
                msg = "転送先にファイルが存在するため、転送できません。転送時に上書きを許可する場合は、overwrite フラグを true に設定してください"
                raise FileExistsError(msg)
            else:
                retval = self._transfer()
                if retval == 'skip':
                    return retval if not self.run_following_logic else None
                if self.original_file_delete is True:
                    self.logger.info("元ファイルを削除します。{}".format(self.input))
                    self.input.delete()

        if self.write_if_transfer_log:
            self.logger.info('実行管理テーブルにファイル送信ログを書き込みます。')
            self._write_if_transfer_log()
