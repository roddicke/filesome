import re

from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.io_target import Target


class FileCreateLogic(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.file_create"

    def _init_logic(self, script, script_args):
        self.files = script_args['files']
        self.bind = script_args.pop('bind', {})

    def _execute(self):
        """
        ファイル作成処理
        """
        self.logger.info("ファイルの作成を開始します")
        for file in self.files:
            self.logger.info("----+" * 10)
            input_file = file["input"]
            output_file = file["output"]
            context = file["context"]

            # input_fileとoutput_fileのパース
            if input_file is not None:
                input_file = Target.parse(input_file)
                if not input_file.exists:
                    msg = "指定されたパス{0}は存在しません。".format(input_file)
                    raise FileNotFoundError(msg)
            output_file = Target.parse(output_file)

            # ファイル内に動的な内容を記載する場合の置換処理
            # 現状、置換処理対象の変数はjob_dateとfile_sizeとif_record_countのみの想定
            parameters = {
                'CR': '\r',
                'LF': '\n',
            }
            parameters.update(self.bind)
            if "{job_date}" in context:
                self.logger.info("ファイル内に書き込む{job_date}を置換します")
                job_date = self.batch_date.batch_date
                parameters["job_date"] = job_date
                self.logger.info(f"job_date: {job_date}")

            input_required_flag = False
            if re.search(r'{file_size(:.*\d+)?}', context):
                input_required_flag = True
                self.logger.info("ファイル内に書き込む{file_size}を置換します")
                self.logger.info(f"ファイルサイズ取得先: {input_file}")
                if input_file is None:
                    msg = "ファイルサイズを取得する場合、job定義にinputとなるファイルのパスを記載してください"
                    raise ValueError(msg)
                file_size = input_file.get_file_size()
                parameters["file_size"] = file_size
                self.logger.info(f"file_size : {file_size}")

            if re.search(r'{if_record_count(:.*\d+)?}', context):
                input_required_flag = True
                self.logger.info("ファイル内に書き込む{if_record_count}を置換します")
                self.logger.info(f"レコード数取得先: {input_file}")
                if input_file is None:
                    msg = "レコードサイズを取得する場合、job定義にinputとなるファイルのパスを記載してください"
                    raise ValueError(msg)
                if_record_count = input_file.get_record_count()
                parameters["if_record_count"] = if_record_count
                self.logger.info(f"if_record_count : {if_record_count}")

            if input_required_flag is False and input_file is not None:
                msg = "inputファイルを使わない場合は、'null'を設定してください"
                self.logger.warning(msg)

            context = context.format(**parameters)
            # ファイル出力
            output_file.write(context)
            self.logger.info(f"{output_file}の作成が完了しました")
        self.logger.info("----+" * 10)
