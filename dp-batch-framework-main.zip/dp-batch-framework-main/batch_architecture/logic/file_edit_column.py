import csv
import gzip

import pandas as pd

from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.io_target import Target


class FileEditColumnLogic(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.file_edit_column"

    def _init_logic(self, script, script_args):
        self.target = Target.parse(script_args['target'])
        self.logics = script_args['logics']
        self.delimiter = script_args['input_format'].get("delimiter")
        self.line_terminator = script_args['input_format'].get("lineterminator")
        self.encoding = script_args['input_format'].get("encoding")
        self.header_line = script_args['input_format'].get("header_line")
        self.quotechar = script_args['input_format'].get("quotechar")
        self.quoting = script_args['input_format'].get("quoting", "MINIMAL")
        self.escapechar = script_args['input_format'].get("escapechar")
        self.encoding_errors = script_args.get('read_options', {}).get('encoding_errors', 'strict')
        self.na_values = script_args.get('read_options', {}).get('na_values', [])

        if not self.target.exists:
            msg = "指定されたパス{0}は存在しません。"
            raise FileNotFoundError(msg)

    def _execute(self):
        if self.quotechar is None or self.quotechar == '':
            quotechar = '"'
        else:
            quotechar = self.quotechar
        quoting_dict = {
            "ALL": csv.QUOTE_ALL,
            "MINIMAL": csv.QUOTE_MINIMAL,
            "NONNUMERIC": csv.QUOTE_NONNUMERIC,
            "NONE": csv.QUOTE_NONE,
        }
        quoting = quoting_dict[self.quoting]

        # 読み込み時のheaderパラメータの設定
        if self.header_line == 0:
            header = None
        elif self.header_line == 1:
            header = self.header_line - 1
        else:
            header = list(range(0, self.header_line - 1))

        if self.target.get_file_size() == 0:
            self.logger.warning('ファイルサイズが0バイトなので、処理をスキップします')
            return

        if str(self.target._path).endswith('.gz'):
            with gzip.GzipFile(self.target._path, mode='rb') as gz:
                if gz.seek(1) == 0:
                    self.logger.warning('gz解凍後のファイルが空ファイルなので、処理をスキップします')
                    return

        # headerの有無に応じてファイルの読み込み方法を変更
        df = pd.read_csv(self.target._path,
                         encoding=self.encoding,
                         sep=self.delimiter,
                         header=header,
                         index_col=False,
                         quotechar=quotechar,
                         quoting=quoting,
                         escapechar=self.escapechar,
                         encoding_errors=self.encoding_errors,
                         # keep_default_na=False,
                         # na_values=self.na_values,
                         dtype=str)

        if len(df) == 0:
            self.logger.warning('0レコードなので、処理をスキップします')
            return

        for logic in self.logics:
            if logic["logic"] == "add_columns":
                df = self._add_columns(df, logic["columns"])
            elif logic["logic"] == "separate_columns":
                df = self._separate_columns(df, logic["columns"], logic["source_column_position"])
            elif logic["logic"] == "trim_columns":
                df = self._trim_columns(df, logic["columns"])
            else:
                msg = "logicパラメータは'add_columns'か'separate_columns'を指定してください"
                raise ValueError(msg)

        # 出力時のheaderパラメータの設定
        if self.header_line == 0:
            header = False
        else:
            header = True

        df.to_csv(self.target._path,
                  encoding=self.encoding,
                  sep=self.delimiter,
                  header=header,
                  index=False,
                  quotechar=quotechar,
                  quoting=quoting,
                  escapechar=self.escapechar,
                  line_terminator=self.line_terminator)

    @classmethod
    def _add_columns(cls, df, columns):
        """
        項目を追加して固定値で埋める処理を行うメソッド
        """
        # 追加するカラムの数だけ回す
        for dict_col in columns:
            # 追加するカラムの名前
            column_name = dict_col["column_name"]
            # 追加する固定値
            column_value = dict_col["column_value"]
            # 挿入する列番号
            position = dict_col["position"] - 1
            # 列挿入処理
            df.insert(position, column_name, column_value)

        return df

    @classmethod
    def _separate_columns(cls, df, columns, source_column_position: int):
        """
        項目分割を実施するメソッド
        1. dfを分割対象カラムの左側の列群(left)と右側の列群(right)に分割
        2. 間に挿入するための空df(mid)を作成する。
        3. midに分割後のカラムを挿入
        4. left・mid・rightを結合して返却
        """
        # ソースカラムの列番号
        source_column_no = source_column_position - 1
        # ソースカラムの左側の列群
        df_left = df.iloc[:, 0:source_column_no]
        # ソースカラムの右側の列群
        df_right = df.iloc[:, source_column_no + 1:df.shape[1]]
        # 分割後に生成するカラムを格納しておくためのDataFrameを新規作成
        lst_target_columns = [col['column_name'] for col in columns]
        df_mid = pd.DataFrame(index=df.index, columns=lst_target_columns)
        # 分割後に生成するカラムの数だけループ処理
        for dict_col in columns:
            target_column_name = dict_col['column_name']
            # ソース列の複製(最終列に追加)
            df_mid[target_column_name] = df.iloc[:, [source_column_no]]
            # ソース列の値からほしい文字数分だけスライスで取得
            if dict_col["sep_logic"] == "MID":
                start = dict_col["start_no"] - 1
                end = dict_col["char_num"]
                df_mid[target_column_name] = df_mid[target_column_name].astype(str).str[start:start + end]
            elif dict_col["sep_logic"] == "LEFT":
                end = dict_col["char_num"]
                df_mid[target_column_name] = df_mid[target_column_name].astype(str).str[:end]
            elif dict_col["sep_logic"] == "RIGHT":
                start = dict_col["char_num"] * -1
                df_mid[target_column_name] = df_mid[target_column_name].astype(str).str[start:]
            else:
                msg = "sep_logicパラメータは'LEFT'か'RIGHT'か'MID'を指定してください"
                raise ValueError(msg)
        df = pd.concat([df_left, df_mid, df_right], axis=1)

        return df

    @classmethod
    def _trim_columns(cls, df, columns):
        """
        TRIMして空白を削除するメソッド
        """
        for dict_col in columns:
            position = dict_col['position'] - 1
            df.iloc[:, position] = df.iloc[:, position].str.strip()

        return df
