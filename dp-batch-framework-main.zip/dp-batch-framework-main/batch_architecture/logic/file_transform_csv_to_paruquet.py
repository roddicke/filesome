"""
csv -> snappy.parquet形式に変換する
"""
import os
import json
import shutil
import decimal
import csv
import warnings
from io import StringIO
import pandas as pd

from pathlib import Path
from batch_architecture.core.logic import _InputOutputLogic


class FileTransformCsvToParquetLogic(_InputOutputLogic):
    """
    CSV-Parquet変換ロジック
    script_args:
        - config: Parquet定義ファイル名
        - input: 入力ファイルパス
        - output: 出力ファイルパス
        - input_format:
            - delimiter: デリミタ
            - encoding: 文字コード
            - escapechar: エスケープ文字
            - header_line: ヘッダ行番号 (0の場合はヘッダ無し)
            - quotechar: 括り文字 (デフォルト: ダブルクォート)
            - quoting: 括り文字設定 (デフォルト: MINIMAL)
        - read_options:
            - chunksize: 一括読み取り行数
            - encoding_errors: 文字コードエラー発生時の対応 (strict/ignore/replace)  (デフォルト: strict)
            - na_values:  NA/NaN として扱う文字のリスト (optional)
        - logics: カラム編集ロジック list(dict)
            - logic: 編集種別 (add_columns/separate_columns/trim_columns/null_replace)
            - columns: list(dict)
                - column_name: カラム名 (add_columns用)
                - column_value: 値 (add_columns用)
                - position: 列番号 (add_columns, trim_columns用)
                - sep_logic: 切り出し別 (LFET/MID/RIGHT) (separate_columns用)
                - start_no: オフセット番号 (separate_columns用)
                - char_num: 文字長 (separate_columns用)
            - source_column_position: 操作元列番号 (separate_columns用)
        - original_file_delete: 入力ファイル削除フラグ (デフォルト: false)
        - not_exist_ok: 入力ファイルなし可否フラグ (デフォルト: false)
        - run_following_logic: 入力ファイルなしのとき、後続ロジックをスキップせずに実行する (デフォルト: false)
    """

    _LOGGER_NAME = "batch_architecture.logic.file_transform_csv_to_parquet"

    def _init_logic(self, script, script_args) -> None:
        config_path = str(self.settings.RESOURCE_FILE_DEF_PARQUET_DIR) + "/" + script_args['config']
        if not Path(config_path).is_file():
            msg = "指定されたパス({0})は存在しません"
            raise FileNotFoundError(msg.format(config_path))
        with open(config_path, 'r') as f:
            dict_config = json.load(f)

        self._delimiter = script_args['input_format'].get("delimiter")
        self._encoding = script_args['input_format'].get("encoding")
        self._header_line = script_args['input_format'].get("header_line")
        self._quotechar = script_args['input_format'].get("quotechar")
        self._quoting = script_args['input_format'].get("quoting", "MINIMAL")
        self._escapechar = script_args['input_format'].get("escapechar")
        self._on_bad_lines = script_args['input_format'].get('on_bad_lines', 'error')
        self._chunksize = script_args['read_options']['chunksize']
        self._encoding_errors = script_args['read_options'].get('encoding_errors', 'strict')
        self._na_values = script_args['read_options'].get('na_values', [])
        self._logics = script_args.get('logics', [])

        self.original_file_delete = script_args.pop('original_file_delete', False)
        self.not_exist_ok = script_args.get('not_exist_ok', False)
        self.run_following_logic = script_args.get('run_following_logic', False)

        self._lst_columns = []
        self._dict_type_mapping = {
            "VARCHAR": "object",
            "FLOAT": "float32"
        }
        self._lst_decimal_cols = []
        self._lst_datetime_cols = []
        self._dtypes = {}
        for dict_col in dict_config['columns']:
            col_name = dict_col['name']
            self._lst_columns.append(col_name)
            col_type = dict_col['type'].upper()
            if col_type.startswith('VARCHAR'):
                col_type = "object"
            elif col_type.startswith('DECIMAL'):
                self._lst_decimal_cols.append(col_name)
                col_type = "object"
            elif col_type == 'DATETIME':
                self._lst_datetime_cols.append(col_name)
                col_type = "object"
            else:
                col_type = self._dict_type_mapping[col_type]
            self._dtypes[dict_col['name']] = col_type
        self._null_char_replace = script_args['read_options'].pop('null_char_replace', False)

    def _transform(self):
        if self.not_exist_ok and not self.input.exists():
            msg = "%s が存在しないためスキップします。" % self.input
            self.logger.info(msg)
            return 'skip'

        input_file = self.input._path
        output_file = self.output._path
        output_dir = os.path.dirname(str(self.output._path))
        if os.path.exists(output_dir) is False:
            os.makedirs(output_dir, exist_ok=True)
        if self._quotechar is None or self._quotechar == '':
            quotechar = '"'
        else:
            quotechar = self._quotechar
        quoting_dict = {
            "ALL": csv.QUOTE_ALL,
            "MINIMAL": csv.QUOTE_MINIMAL,
            "NONNUMERIC": csv.QUOTE_NONNUMERIC,
            "NONE": csv.QUOTE_NONE,
        }
        quoting = quoting_dict[self._quoting]

        # 読み込み時のheaderパラメータの設定
        if self._header_line == 0:
            header = None
        elif self._header_line == 1:
            header = self._header_line - 1
        else:
            header = list(range(0, self._header_line - 1))

        self.logger.info('Input csv: %s' % str(input_file))

        is_empty = True
        if 0 < self.input.get_file_size():
            try:
                # ヌル文字(\{00})が含まれているファイルを扱う場合、
                if self._null_char_replace is True:
                    self.logger.info("Input ファイルのNull文字を除去します。")
                    input_file = self._replace_null_char(input_file, self._encoding)

                df_itr = self._get_itr(input_file, header, quotechar, quoting)
                is_empty = False
            except pd.errors.EmptyDataError:
                pass
        else:
            pass

        if is_empty:
            self.logger.warning('ファイルサイズが0バイトなので、0レコードのファイルが作成されます。')
            df = pd.DataFrame(columns=self._lst_columns)
            df.to_parquet(str(output_file), compression='snappy')
            return

        decimal.getcontext().prec = 38

        i = 0
        for ii in range(2):  # Retry only once on error
            try:
                for j, df in enumerate(df_itr):
                    if j < i:
                        continue
                    for logic in self._logics:
                        if logic["logic"] == "add_columns":
                            df = self._add_columns(df, logic["columns"])
                        elif logic["logic"] == "separate_columns":
                            df = self._separate_columns(df, logic["columns"], logic["source_column_position"])
                        elif logic["logic"] == "trim_columns":
                            df = self._trim_columns(df, logic["columns"])
                        else:
                            msg = "logicパラメータは'add_columns'か'separate_columns'を指定してください"
                            raise ValueError(msg)

                    # ヘッダ数に合わせてカラムを追加
                    if len(df.columns) < len(self._lst_columns):
                        df2 = pd.DataFrame(
                            data={k: [None] * len(df) for k in self._lst_columns[len(df.columns):]})
                        df2.index = df.index
                        df = pd.concat([df, df2], axis=1)
                    elif len(self._lst_columns) < len(df.columns):
                        df = df.iloc[:, :len(self._lst_columns)]
                    df.columns = self._lst_columns

                    for col in self._lst_decimal_cols:
                        self.logger.info('Convert to Decimal: %s' % col)
                        df[col] = df[col].apply(lambda x: decimal.Decimal(x) if x is not None else None)
                    for col in self._lst_datetime_cols:
                        self.logger.info('Convert to Datetime: %s' % col)
                        # ToDo: HadoopのDATETIME型の出力フォーマットと合っているか確認
                        df[col] = pd.to_datetime(df[col], format='%Y-%m-%d %H:%M:%S')

                    output_file_add_suffix = str(output_file).replace(
                        '.snappy.parquet',
                        '_{suffix_no}.snappy.parquet'.format(suffix_no=str(i).zfill(6)))
                    self.logger.info('Output parquet: %s' % output_file_add_suffix)

                    # ヌル文字除去で発生した欠損値(Nan)を空文字に変換する。
                    if self._null_char_replace is True:
                        df = df.fillna('')

                    df.to_parquet(
                        output_file_add_suffix,
                        compression='snappy',
                        use_deprecated_int96_timestamps=True)
                    i += 1

                # success
                break
            except pd.errors.ParserError:
                if 0 < ii:
                    raise
                names = [i for i, _ in enumerate(self._lst_columns)]
                df_itr = self._get_itr(input_file, header, quotechar, quoting, names=names)

        # 単一ファイルの場合、リネームしてsuffixを削除
        if i == 1:
            output_file_add_suffix = str(output_file).replace('.snappy.parquet', '_000000.snappy.parquet')
            shutil.move(output_file_add_suffix, str(output_file))

    def _get_itr(self, input_file, header, quotechar, quoting, names=None):
        with warnings.catch_warnings(record=True) as w:
            df_itr = pd.read_csv(
                input_file,
                encoding=self._encoding,
                sep=self._delimiter,
                header=header,
                names=names,
                index_col=False,
                quotechar=quotechar,
                quoting=quoting,
                escapechar=self._escapechar,
                encoding_errors=self._encoding_errors,
                on_bad_lines=self._on_bad_lines,
                # keep_default_na=False,
                # na_values=self._na_values,
                dtype=str,
                engine=None if names is None else 'python',
                chunksize=self._chunksize)
            if w:
                self.logger.warning('[%s](%s:%s) %s' % (
                    w[-1].category.__name__, w[-1].filename, w[-1].lineno, w[-1].message))

            return df_itr

    @classmethod
    def _add_columns(cls, df, columns):
        """
        項目を追加して固定値で埋める処理を行うメソッド
        """
        # 追加するカラムの数だけ回す
        for dict_col in columns:
            # 追加するカラムの名前
            column_name = dict_col["column_name"]
            # 追加する固定値
            column_value = dict_col["column_value"]
            # 挿入する列番号
            position = dict_col["position"] - 1
            # 列挿入処理
            df.insert(position, column_name, column_value)

        return df

    @classmethod
    def _separate_columns(cls, df, columns, source_column_position: int):
        """
        項目分割を実施するメソッド
        1. dfを分割対象カラムの左側の列群(left)と右側の列群(right)に分割
        2. 間に挿入するための空df(mid)を作成する。
        3. midに分割後のカラムを挿入
        4. left・mid・rightを結合して返却
        """
        # ソースカラムの列番号
        source_column_no = source_column_position - 1

        for i, dict_col in enumerate(columns):
            # 列挿入処理
            target_column_name = dict_col['column_name']
            df.insert(source_column_no + i + 1, target_column_name, df.iloc[:, source_column_no])
            # スライス処理
            if dict_col["sep_logic"] == "MID":
                start = dict_col["start_no"] - 1
                end = dict_col["char_num"]
                df[target_column_name] = df[target_column_name].astype(str).str[start:start + end]
            elif dict_col["sep_logic"] == "LEFT":
                end = dict_col["char_num"]
                df[target_column_name] = df[target_column_name].astype(str).str[:end]
            elif dict_col["sep_logic"] == "RIGHT":
                start = dict_col["char_num"] * -1
                df[target_column_name] = df[target_column_name].astype(str).str[start:]
            else:
                msg = "sep_logicパラメータは'LEFT'か'RIGHT'か'MID'を指定してください"
                raise ValueError(msg)

        return df

    @classmethod
    def _trim_columns(cls, df, columns):
        """
        TRIMして空白を削除するメソッド
        """
        for dict_col in columns:
            position = dict_col['position'] - 1
            df.iloc[:, position] = df.iloc[:, position].str.strip()

        return df

    @classmethod
    def _replace_null_char(cls, input_file: str, encoding: str) -> StringIO:
        """
        ヌル文字を除去した上でメモリバッファを返す
        """
        with open(input_file, mode="rb") as f:
            i = f.read().replace(b'\x00', b'')
            input_file = StringIO(i.decode(encoding))
            return input_file

    def _execute(self) -> None:
        retval = self._transform()
        if retval == 'skip':
            if self.run_following_logic:
                self.logger.info("後続ロジックを実行します。")
                retval = None
            else:
                self.logger.info("後続ロジックをスキップします。")
            return retval
        if self.original_file_delete is True:
            self.logger.info("元ファイルを削除します。{}".format(self.input))
            self.input.delete()
        return
