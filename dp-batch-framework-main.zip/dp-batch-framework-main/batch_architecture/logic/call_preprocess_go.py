"""
olang前処理プログラムを実行アーキから実行します。
"""

from pathlib import Path

from batch_architecture.client import Shell
from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.core.resources import Resources
from batch_architecture.io_target.base import Target
from batch_architecture.io_target import S3Target


class CallPreprocessGoLogic(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.call_preprocess_go"

    def _init_logic(self, script, script_args) -> None:
        """
        Execute 固有の初期化処理を行う
        :param script_args['config']: 実行するスクリプトのパスとコマンドライン引数
        """
        self.config_path = self.settings.RESOURCE_FILE_DEF_PRE_DIR / script_args['config']
        self.go_module_path = self.settings.RESOURCE_GO_EXE_DIR / "pre_go.exe"
        self.input_target = Target.parse(script_args['input_key'])
        if not isinstance(self.input_target, S3Target):
            msg = "input_keyはs3://{バケット名}/xxxで指定してください"
            raise NotImplementedError(msg)
        self.output_target = Target.parse(script_args['output_key'])
        if not isinstance(self.output_target, S3Target):
            msg = "output_keyはs3://{バケット名}/xxxで指定してください"
            raise NotImplementedError(msg)
        self.input_bucket = self.input_target._bucket_name
        self.input_path = str(self.input_target._path)
        self.output_bucket = self.output_target._bucket_name
        # goに渡すパスは末尾が"csv"である必要があるのでgzを除く
        self.output_path = str(self.output_target._path).replace("csv.gz", "csv")
        self.split_num = script_args['split_num']
        self.original_file_delete = script_args.get('original_file_delete', False)

        if not self.config_path.is_file():
            msg = "指定されたパス({0})は存在しません"
            raise FileNotFoundError(msg.format(self.config_path))

        if not self.go_module_path.is_file():
            msg = "指定されたパスにGoバイナリ({0})が存在しません"
            raise FileNotFoundError(msg.format(self.go_module_path))

    def create_command(self) -> str:
        # bat以外のスクリプトの処理
        try:
            FMT = '"{path}" -c "{config}" -lb "{input_bucket}" -sb "{output_bucket}" -i "{input_path}" -o "{output_path}" -s "{split_num}"'
            return FMT.format(
                path=str(self.go_module_path),
                config=self.config_path,
                input_bucket=self.input_bucket,
                output_bucket=self.output_bucket,
                input_path=self.input_path,
                output_path=self.output_path,
                split_num=self.split_num,
            )
        except KeyError:
            msg = "指定されたファイル{0}は実行できません。"
            raise ValueError(msg.format(self.go_module_path))

    def _execute(self) -> None:
        cmd = self.create_command()
        self.logger.info(cmd)
        shell = Shell()
        return_code, out, err = shell.execute(cmd)
        self.logger.info(out)
        self.logger.info(err)
        if self.original_file_delete is True and return_code == 0:
            self.logger.info("元ファイルを削除します。{}".format(self.input_target))
            self.input_target.delete()
        return
