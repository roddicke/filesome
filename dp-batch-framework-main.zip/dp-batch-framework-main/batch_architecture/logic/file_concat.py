"""
ファイルを連結する。
"""
import os
import glob
import shutil

from batch_architecture.core.logic import _InputOutputLogic
from batch_architecture.io_target import LocalTarget
from batch_architecture.io_target import Target
from batch_architecture.client import Shell


class FileConcatLogic(_InputOutputLogic):
    """
    ファイル連結ロジック
    script_args:
        - input: 入力ファイルパス（アスタリスク使用可能）
        - output: 出力ファイルパス
        - original_file_delete: 入力ファイル削除フラグ（デフォルト: false）
    """
    _LOGGER_NAME = "batch_architecture.logic.file_concat"

    def _init_logic(self, script, script_args):
        self.original_file_delete = script_args.get('original_file_delete', False)

    def _execute(self):
        # 現在はローカルターゲットのみサポート
        if not isinstance(self.input, LocalTarget):
            msg = "入力 {} がローカルファイルではありません。"
            raise ValueError(msg.format(self.input))

        if not isinstance(self.output, LocalTarget):
            msg = "出力 {} がローカルファイルではありません。"
            raise ValueError(msg.format(self.output))

        # Windowsコマンドを実行(Windowsサーバを前提とした実装)
        cmd = "copy /b {input} {output}".format(
            input=str(self.input._path),
            output=str(self.output._path))
        self.logger.info("実行コマンド: {}".format(cmd))
        shell = Shell()
        _, out, err = shell.execute(cmd)

        msg = '\n'.join([out.strip(), err])
        self.logger.info("出力結果: \n{}".format(msg))

        if self.original_file_delete is True:
            input_dir = os.path.dirname(str(self.input._path))
            output_dir = os.path.dirname(str(self.output._path))
            if output_dir.startswith(input_dir):
                # outputファイルがinputと同フォルダ配下に出力されている場合、outputファイルを除いてinputファイルを削除
                lst_delete_target = list(glob.glob(str(self.input._path)))
                self.logger.info("元ファイルを削除します。{}".format(input_dir))
                for delete_target in lst_delete_target:
                    if delete_target == str(self.output._path):
                        continue
                    os.remove(delete_target)
            else:
                self.logger.info("元ファイルをフォルダごと削除します。{}".format(input_dir))
                target_input_dir = Target.parse(input_dir)
                target_input_dir.delete()


class FileConcatPyLogic(_InputOutputLogic):
    """
    ファイル連結ロジック
    script_args:
        - input: 入力ファイルパス（アスタリスク使用可能）
        - output: 出力ファイルパス
        - skip_rows: ヘッダスキップ数（デフォルト: 0）
        - original_file_delete: 入力ファイル削除フラグ（デフォルト: false）
    """
    _LOGGER_NAME = "batch_architecture.logic.file_concat_py"

    def _init_logic(self, script, script_args):
        self.skip_rows = script_args.get('skip_rows', 0)
        self.original_file_delete = script_args.get('original_file_delete', False)

    def _execute(self):
        # 現在はローカルターゲットのみサポート
        if not isinstance(self.input, LocalTarget):
            msg = "入力 {} がローカルファイルではありません。"
            raise ValueError(msg.format(self.input))

        if not isinstance(self.output, LocalTarget):
            msg = "出力 {} がローカルファイルではありません。"
            raise ValueError(msg.format(self.output))

        inputs = list(glob.glob(str(self.input._path)))
        output_dir = os.path.dirname(str(self.output._path))
        if os.path.exists(output_dir) is False:
            os.makedirs(output_dir, exist_ok=True)
        with open(str(self.output._path), "w+b") as fw:
            newline = b'\n'
            for i, path in enumerate(inputs):
                with open(path, "rb") as f:
                    # skip header
                    read = None
                    for _ in range(self.skip_rows):
                        read = f.readline()

                    # 1 line processing
                    s = f.readline()
                    if s.strip():
                        if 0 < i:
                            import io
                            # ログ書込用ファイルの最後尾ポインタが0の場合、改行有無の確認をスキップ
                            fw.seek(0, io.SEEK_END)
                            if fw.tell() > 0:
                                fw.seek(-1, io.SEEK_END)
                                if not fw.read().endswith(b'\n'):
                                    fw.write(newline)
                            else:
                                self.logger.info("ログ書込用ファイルサイズが0のため、改行の書込みをスキップします。")
                        fw.write(s)
                        read = read if read else s

                    if read.endswith(b'\r\n'):
                        newline = b'\r\n'
                    else:
                        newline = b'\n'

                    # burst processing the rest
                    shutil.copyfileobj(f, fw)

        if self.original_file_delete is True:
            input_dir = os.path.dirname(str(self.input._path))
            output_dir = os.path.dirname(str(self.output._path))
            if output_dir.startswith(input_dir):
                # outputファイルがinputと同フォルダ配下に出力されている場合、outputファイルを除いてinputファイルを削除
                lst_delete_target = list(glob.glob(str(self.input._path)))
                self.logger.info("元ファイルを削除します。{}".format(input_dir))
                for delete_target in lst_delete_target:
                    if delete_target == str(self.output._path):
                        continue
                    os.remove(delete_target)
            else:
                self.logger.info("元ファイルをフォルダごと削除します。{}".format(input_dir))
                target_input_dir = Target.parse(input_dir)
                target_input_dir.delete()
