import os
import pathlib
from datetime import datetime

from batch_architecture.client.snowflake_client import SnowflakeClient
from batch_architecture.core.logic import SQLBusinessLogic
from batch_architecture.core.table_logging import table_logging
from batch_architecture.io_target import Target


class SnowflakeSQLExecuteLogic(SQLBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake"

    def _init_logic(self, script, script_args):
        """
        SQL 固有の初期化処理を行う
        """
        self.script_bind = script_args.get("bind", {})
        self.env_bind = self.settings.SNOWFLAKE_BIND
        # script_bind内のDB変数({DB_NAME}など)の置換
        for k, v in self.script_bind.items():
            self.script_bind[k] = v.format(**self.env_bind)
        self.script_bind.update(self.env_bind)
        self.script_bind["CURRENT_DATE_SYORI"] = self.batch_date.batch_date
        self.warehouse_bind = self.settings.WAREHOUSE_BIND
        self.script_file = script
        self.script = Target.parse(
            str(self.settings.RESOURCE_SQL_DIR) + "/{}".format(script)
        )
        self.pk_check = script_args.get("pk_check")
        self.pk_check_tables = script_args.get("pk_check_tables")
        self.pk_check_conds = script_args.get("pk_check_conds")
        self.warehouse = script_args.get("warehouse").format(**self.warehouse_bind)
        self.end_file = script_args.get("end_file")
        self.switch_user = script_args.get("switch_user")
        if not self.script.is_file():
            msg = "実行する SQL スクリプト {} が見つかりません"
            raise FileNotFoundError(msg.format(self.script))

    @property
    def client(self):
        """
        Snowflakeへの接続
        """
        if getattr(self, "_client", None) is None:
            res_user = None
            if self.switch_user:
                res_user = os.environ["ADT_RESOURCE"]
                os.environ["ADT_RESOURCE"] = self.switch_user
            try:
                self._client = SnowflakeClient(warehouse=self.warehouse)
                self._client.connect()
            finally:
                if res_user:
                    os.environ["ADT_RESOURCE"] = res_user

        return self._client

    def _preset_query_parameter(self, query):
        """
        クエリの実行時の'?'をバインドする。
        :param query: ファイルから読み込んだSQL文そのもの。INSERTやDELETEなどのクエリ
        :return:
        """
        self.logger.info("----+" * 10)
        self.logger.info("SQL ? パラメータセット")

        lst_query_output = []
        # SQLを行単位で構文チェックし、みなし日を置換する
        for query_row in query.split("\n"):

            # コメントアウトされていない行で、SETでの宣言で、?が存在する行を対象に、変数識別
            if (
                    query_row.strip()[0:2] != "--"
                    and "SET" == query_row[:3]
                    and "?" in query_row
            ):
                # 行をスペース/タブで分割し、宣言文の構文解析
                lst_words = query_row.split()
                param_name = lst_words[1]  # 1:変数名(0:"SET")
                # 処理基準日
                if "targetDate" in query_row:
                    # シングルクォーテーションで囲む
                    var_batch_date = "'" + str(self.batch_date.batch_date) + "'"

                    self.logger.info(
                        "REPLACE: {n} = {v}".format(n="targetDate", v=var_batch_date)
                    )
                    lst_query_output.append(
                        query_row.replace("?", str(var_batch_date))
                    )

                # 処理基準月
                elif "targetMonth" in query_row:
                    # シングルクォーテーションで囲む
                    var_batch_month = "'" + str(self.batch_date.batch_month) + "'"
                    self.logger.info(
                        "REPLACE: {n} = {v}".format(n="targetMonth", v=var_batch_month)
                    )
                    lst_query_output.append(
                        query_row.replace("?", str(var_batch_month))
                    )

                # 処理基準日・処理基準月以外のパラメーターが指定された場合エラーにする
                else:
                    raise ValueError(
                        "SQL内で宣言された変数{s}は置換できません。'targetDate'もしくは'targetMonth'を宣言してください".format(
                            s=param_name
                        )
                    )
            else:
                lst_query_output.append(query_row)

        return "\n".join(lst_query_output)

    def _get_query(self):
        """
        SQLスクリプトからクエリを取得して置換処理を行ったのちクエリを返却
        """
        if getattr(self.script, "read", None) is None:
            sql_file = self.script.open(encoding="utf-8")
        else:
            sql_file = self.script

        try:
            # みなし日置換処理
            query = self._preset_query_parameter(sql_file.read())
            # _init_logicではまだJobインスタンスが作成されていないのでjob_idが参照できない
            self.script_bind.update({'JOB_ID': self.job_id})
            self.logger.info("snowflake バインド変数一覧: {}".format(self.script_bind))
            # バインド置換処理
            query = query.format(**self.script_bind)
            return query

        except FileNotFoundError as e:
            self.logger.error("SQLファイルが見つかりません。 %s" % e)
            raise e
        except Exception as e:
            self.logger.error("SQL内パラメータ変換処理中にエラーが発生しました。")
            raise e

    def _count_table_rows(self, select_query):
        query = f'SELECT COUNT(1) FROM ({select_query});'
        self.client.execute_sql(query)
        count = self.client.fetch_one()[0]
        return count

    def _count_stage_file_rows(self, stage_name, path, file_format=None):
        s = f', FILE_FORMAT => {file_format}' if file_format else ''
        query = f"SELECT COUNT(1) FROM {stage_name} (PATTERN => '{path}'{s});"
        self.client.execute_sql(query)
        count = self.client.fetch_one()[0]
        return count

    def _get_stage_files(self, stage_name, path):
        query = f'LIST {stage_name}/{path};'
        self.client.execute_sql(query)
        rows = self.client.fetch_all()
        files = [r[0] for r in rows]
        return files

    def _execute_query(self, query, **kwargs):
        # クエリ実行
        self.client.execute_string(query)
        # 処理件数の取得
        query_id = self._get_last_query_id()
        row_count = self._get_affected_rowcount(query_id)
        # 件数ロギング
        if kwargs.get('process_log_detail_id', None) is not None:
            table_logging.logging_row_count(
                row_count,
                process_log_detail_id=kwargs['process_log_detail_id'])

        return query_id, row_count

    def _execute(self) -> None:
        """
        Snowflake
        """
        self.logger.info("----+" * 10)
        self.logger.info("SQL[{s}]を実行します。".format(s=self.script))
        query = self._get_query()

        # ログテーブルに実行予定のクエリを記録する
        table_logging.logging_query(query, warehouse=self.warehouse)

        try:
            # sqlに--split_pointというコメントがあればブロック分けしてPK重複チェックを実行する。
            queries = [x.strip() for x in query.split("--split_point")]

            # pk_check=trueのとき、クエリがpk_check_tablesのテーブル数と合わないとエラーにする
            if self.pk_check and (not self.pk_check_tables or len(queries) != len(self.pk_check_tables)):
                msg = "PKチェック対象のtable名をジョブ定義のpk_check_tablesに記載してください"
                raise ValueError(msg)

            self.committed_databases = []
            self.committed_schemas = []
            self.committed_tables = []
            first_query_id = None
            for i, query in enumerate(queries):
                pk_check_table = None

                # SQL実行前処理
                if self.pk_check:
                    pk_check_table = self.pk_check_tables[i]
                    self._pre_operation(pk_check_table)

                # SQL実行処理
                @table_logging.sub_func_logging('sub_query_%d' % (i + 1), script_file=self.script_file)
                def execute_query(process_log_detail_id):
                    if process_log_detail_id is not None:
                        table_logging.logging_query(
                            query,
                            process_log_detail_id=process_log_detail_id)
                    query_id, _ = self._execute_query(
                        query, process_log_detail_id=process_log_detail_id)
                    return query_id

                query_id = execute_query()
                first_query_id = first_query_id if first_query_id else query_id

                # SQL実行後
                if self.pk_check:
                    # TimeTravelする時に必要なtableの情報をリストに格納しておく
                    self.committed_databases.append(self.database)
                    self.committed_schemas.append(self.schema)
                    self.committed_tables.append(pk_check_table)

                    # PK重複チェック
                    pk_check_cond = self.pk_check_conds[i] \
                        if self.pk_check_conds and i < len(self.pk_check_conds) else None
                    self._post_operation(pk_check_table, pk_check_cond, first_query_id)

            # PK重複しなかった場合、正常にpost_operationを抜ける。その後、end_fileが必要なら作成する
            if self.end_file is not None:
                self._make_end_file(self.end_file)
        except Exception as e:
            self.logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            raise
        finally:
            self.client.close()

    def _get_last_query_id(self):
        # 1つ前に実行したクエリIDの取得
        get_last_query_id_sql = "SELECT last_query_id();"
        self.client.execute_sql(get_last_query_id_sql)
        last_query_id = self.client.fetch_one()[0]

        return last_query_id

    def _get_affected_rowcount(self, last_query_id=None):
        """
        処理件数をログに出力するためのメソッド
        (INSERT・UPDATE・DELETE・COPY INTO文のみ有効)
        """
        last_query_id = last_query_id if last_query_id else self._get_last_query_id()
        try:
            affected_rowcount_sql = (
                "SELECT * FROM TABLE(RESULT_SCAN('{last_query_id}'))".format(last_query_id=last_query_id)
            )
            self.client.execute_sql(affected_rowcount_sql, {})

            # SELECT の場合
            affected_rows = self.client.rowcount
            # DELETE, UPDATE, INSERT の場合
            if affected_rows is None:
                res = self.client.fetch_one()
                affected_rows = sum(
                    res[i] for i, name in enumerate(self.client.column_names)
                    if name.startswith('number of rows '))

            self.logger.info("処理件数 : {}".format(affected_rows))
        # COPY INTO（LOAD)で0件の際はIndexErrorになる
        except IndexError:
            self.logger.info("処理件数 : 0")
            affected_rows = 0

        return affected_rows

    def _pre_operation(self, pk_check_table):
        """
        開始前処理
        PKが正しく設定されているかを確認する
        1 システムテーブルからPK情報を取得
        2 実行アーキ設定ファイルからPK情報を取得
        3 両者を突き合わせてあっていれば処理を続行する。PKの設定妥当性を担保する為に2つ突き合わせている。
        :param pk_check_table:
        :return:
        """
        # dp-xxx-batch/tab_defフォルダから定義を取得
        try:
            d = self.settings.parse_json_config(
                str(self.settings.RESOURCE_TABLE_DEF_DIR)
                + "/{}.json".format(pk_check_table)
            )
            self.primary_keys = d["primary_keys"]
            self.primary_keys = [p.upper() for p in self.primary_keys]
            self.schema = d["schema"]
            self.database = d["database"]
        except FileNotFoundError:
            msg = "ファイルが見つかりません: {}".format(
                str(self.settings.RESOURCE_TABLE_DEF_DIR)
                + "/{}.json".format(pk_check_table)
            )
            raise FileNotFoundError(msg)
        except Exception as e:
            raise e

        # snowflakeシステムテーブルからPKを取得
        sql = "SHOW PRIMARY KEYS IN TABLE {db}.{schema}.{table};".format(
            db=self.database, schema=self.schema, table=pk_check_table
        )
        self.client.execute_sql(sql, self.env_bind)
        sql = 'SELECT "column_name" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())) ORDER BY "key_sequence";'
        self.client.execute_sql(sql, {})
        sys_primary_keys = self.client.fetch_all()
        # sys_primary_keysの型がおかしいので整形
        sys_primary_keys = [pk[0] for pk in sys_primary_keys]
        self.logger.info("PK : " + ",".join(sys_primary_keys))

        # 処理を中止する
        if (set(self.primary_keys) == set(sys_primary_keys)) is False:
            msg = "{db}.{schema}.{table} のPK設定が異なります。SQL実行を中止します。" \
                  "実行アーキ側PK:{j} システムテーブル側PK:{s}".format(
                db=self.database, schema=self.schema, table=pk_check_table,
                j=self.primary_keys, s=sys_primary_keys
            )
            raise ValueError(msg)

    def _post_operation(self, pk_check_table, pk_check_cond, first_query_id=None) -> None:
        """
        終了後処理
        1 テーブルにPK重複値があるか確認する。
        2 あった場合は重複した断面でのエラーテーブルを保存する
        3 タイムトラベルでクエリ実行前の状態に復元する（複数クエリある場合は全て復元される）
        :param pk_check_table:
        :return: None
        """
        error_schema = self.settings.ERROR_SCHEMA
        group_by_sql = '\n'.join([
            "SELECT {cols}",
            "FROM {db}.{schema}.{table}{where_cond}",
            "GROUP BY {cols}"
        ])
        having_sql = ""
        for idx, pk in enumerate(self.primary_keys):
            if idx == 0:
                having_sql = "\nHAVING COUNT({}) > 1".format(pk)
                continue
            having_sql += " AND COUNT({}) > 1".format(pk)

        @table_logging.sub_func_logging('pk_check')
        def __is_pk_duplicated(process_log_detail_id) -> bool:
            """SQLを投げてPK重複値があるか確認する"""
            if len(self.primary_keys) == 0:
                self.logger.info("PKが設定されていないのでPK重複チェックをスキップし、処理を続行します。")
                return False
            # 重複チェック用SQLを作成
            duplicate_check_sql = (
                    group_by_sql.format(
                        db=self.database,
                        schema=self.schema,
                        table=pk_check_table,
                        cols=",".join(self.primary_keys),
                        where_cond=(' WHERE %s' % pk_check_cond) if pk_check_cond else ''
                    )
                    + having_sql + ';'
            )
            query = duplicate_check_sql.format(**self.script_bind)
            if process_log_detail_id is not None:
                table_logging.logging_query(
                    query,
                    process_log_detail_id=process_log_detail_id)
            self.client.execute_sql(query)
            if len(self.client.fetch_all()) > 0:
                return True
            return False

        # PK重複値の確認。重複発生時はTime travel機能を使ってテーブルを復元する。
        if __is_pk_duplicated() is True:
            self.logger.info("PK重複がありました。")

            error_table_name = pk_check_table + "_err_" + datetime.now().strftime("%Y%m%d%H%M%S")

            @table_logging.sub_func_logging('error_table')
            def exec_error_table(process_log_detail_id):
                # pkが重複している状態のテーブルをエラーテーブルとしてクローンしておく
                self.logger.info("テーブルをクローンしてエラーテーブルとして保存します。")
                error_table_sql = '\n'.join([
                    "CREATE OR REPlACE TABLE {db}.{error_schema}.{error_table}",
                    "CLONE {db}.{schema}.{table}"
                ]).format(db=self.database,
                          error_schema=error_schema,
                          error_table=error_table_name,
                          schema=self.schema,
                          table=pk_check_table)
                query = error_table_sql.format(**self.env_bind)
                self.logger.info('\n%s' % query)
                if process_log_detail_id is not None:
                    table_logging.logging_query(
                        query,
                        process_log_detail_id=process_log_detail_id)
                self.client.execute_sql(query)
                self.logger.info("エラーテーブルを保存しました。")

            exec_error_table()

            # 運用者向けにエラーテーブルから重複データを特定するためのクエリをログに出力する
            # クエリはPK重複チェックに利用したGROUP BY HAVINGを再利用
            self.logger.info("重複データの特定をするために下記のクエリを実行してください。")
            find_duplicate_data_sql = (
                    group_by_sql.format(
                        db=self.database,
                        schema=error_schema,
                        table=error_table_name,
                        cols=",".join(self.primary_keys),
                        where_cond=(' WHERE %s' % pk_check_cond) if pk_check_cond else ''
                    )
                    + having_sql + ';'
            )
            self.logger.info('\n%s' % find_duplicate_data_sql.format(**self.env_bind))

            @table_logging.sub_func_logging('rollback')
            def exec_restore(process_log_detail_id):
                # クエリ実行された全てのテーブルをロールバックする
                self.logger.info("テーブルをロールバックします。")
                for committed_database, committed_schema, committed_table in zip(
                        self.committed_databases, self.committed_schemas, self.committed_tables
                ):
                    rollback_sql = '\n'.join([
                        "TRUNCATE TABLE {db}.{schema}.{table};",
                        "INSERT INTO {db}.{schema}.{table}",
                        "SELECT * FROM {db}.{schema}.{table} BEFORE(statement => '{query_id}');"
                    ]).format(db=committed_database,
                              schema=committed_schema,
                              table=committed_table,
                              query_id=first_query_id)
                    if process_log_detail_id is not None:
                        table_logging.logging_query(
                            rollback_sql,
                            process_log_detail_id=process_log_detail_id)
                    self.client.execute_string(rollback_sql, self.env_bind)

            exec_restore()

            msg = "クエリ実行後のテーブルにPK重複を確認しました。テーブルロールバック完了。処理を中止します。"
            raise ValueError(msg)

    def _make_end_file(self, end_file):
        """ENDファイルを作成するメソッド"""
        self.logger.info("処理が正常に終了したのでエンドファイルを作成します。")
        # 将来的にFSxに格納するが、今は暫定的に"dp-batch-framework/end_file/"に格納するようにしている
        end_file_dir = pathlib.Path(self.settings.END_FILE_DIR) / end_file
        end_file_dir.touch()
        self.logger.info("ファイル名 : {}".format(end_file))
        self.logger.info("パス : {}".format(str(end_file_dir)))
        self.logger.info("エンドファイルを作成しました。")
