import time

from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.io_target import Target


class FilePollingRemoveLogic(BaseBusinessLogic):
    """
    ファイル監視ロジック
    対象パスが作成されるまで待機する。
    パスが作成されたら、削除して（デフォルト動作）リターンする。
    script_args:
        - target: 監視対象パス
        - max_polling_min: 最大待ち時間（分）
        - polling_interval_sec: ポーリング間隔（秒）
        - not_remove: 監視対象パスの削除を行わない場合は、True（デフォルト: False）
        - is_recursive: 監視対象パス削除時に、パスの配下を再帰的に削除する
    """
    _LOGGER_NAME = "batch_architecture.logic.file_polling_remove"

    def _init_logic(self, script, script_args):
        self.target = script_args['target']
        self.is_recursive = script_args.get('is_recursive', False)
        self.not_remove = script_args.get('not_remove', False)
        self.max_polling_min = int(script_args.get('max_polling_min', self.settings.MAX_FILE_POLLING_MIN))
        self.polling_interval_sec = int(script_args.get('polling_interval_sec',
                                                        self.settings.FILE_POLLING_INTERVAL_SEC))

    def _execute(self):
        has_executed = False
        # 繰り上げ除算
        max_attempts = -1 * (-60 * self.max_polling_min // self.polling_interval_sec)
        self.logger.info('ポーリングを開始します。')
        self.logger.info(f'MAX_POLLING_MIN: {self.max_polling_min}')
        self.logger.info(f'POLLING_INTERVAL_SEC: {self.polling_interval_sec}')
        for i in range(max_attempts + 1):
            target = Target.parse(self.target)
            if target.exists():
                self.logger.info(f'{str(target._path)} is found.')
                has_executed = True
                if not self.not_remove:
                    target.delete(recursive=self.is_recursive)
                    self.logger.info(f'{str(target._path)} has deleted.')
                break
            if i == max_attempts:
                break
            time.sleep(self.polling_interval_sec)
            polling_sec = self.polling_interval_sec * (i + 1)
            self.logger.info(f'Polling: {polling_sec}[sec]')

        if has_executed is False:
            raise Exception('最大ポーリング時間を超過しました。ファイルが見つかりません。')
