import os

from batch_architecture.core.logic import SQLBusinessLogic
from batch_architecture.client.snowflake_client import SnowflakeClient
from batch_architecture.core.schedule_utils import ScheduleUtils
from batch_architecture.cmd.windows_log import WindowsEventLog


class SnowflakeSQLExecuteGrantSelectExtTableAllLogic(SQLBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake_grant_select_view_ext_table"

    def _init_logic(self, script, script_args):
        """
        GrantSelectView 固有の初期化処理を行う
        """
        self.logger.info("snowflake バインド変数一覧: {}".format(self.settings.SNOWFLAKE_BIND))
        self.target_database_bind = script_args.get("target_database")
        self.warehouse = script_args.get('warehouse').format(**self.settings.WAREHOUSE_BIND)
        self.switch_user = script_args.get("switch_user")

    @property
    def client(self):
        """
        Snowflakeへの接続
        """
        if getattr(self, "_client", None) is None:
            res_user = None
            if self.switch_user:
                res_user = os.environ["ADT_RESOURCE"]
                os.environ["ADT_RESOURCE"] = self.switch_user
            try:
                self._client = SnowflakeClient(warehouse=self.warehouse)
                self._client.connect()
            finally:
                if res_user:
                    os.environ["ADT_RESOURCE"] = res_user

        return self._client

    def _get_current_mst_table_record(self) -> dict:
        query = "SELECT TBL_BTSR_ID, TBL_RNR FROM {DB_NSONLINET}.{SCHEMA_NAME}.EXT_TABLE_STATUS_MST;"
        query = query.format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info('現在のEXT_TABLE_STATUS_MSTに存在するテーブルの一覧を取得します。')
        self.client.execute_sql(query)
        dict_current_mst_table = {t[0]: t[1] for t in self.client.fetch_all()}
        return dict_current_mst_table

    def _execute(self) -> None:
        # VIEW一覧を取得する
        self.logger.info(f'view_update_schedule_mstテーブルから"{self.target_database_bind}"のVIEW一覧を取得します。')
        dict_ext_view_list = ScheduleUtils.get_view_list_from_ext_table_update_schedule_mst(self.target_database_bind)
        database = self.target_database_bind.format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info(f'Database: {database}, {len(dict_ext_view_list)}本')

        # 現在のEXT_TABLE_STATUS_MSTのテーブル一覧を取得
        dict_current_mst_table = self._get_current_mst_table_record()

        lst_err_msg = []
        grant_cnt = 0
        err_cnt = 0
        # EXT_TABLE_STATUS_MSTのカラムKIK_KBNの値を1(開局)にアップデートするクエリ
        lst_update_query = [
            f"UPDATE {{DB_NSONLINET}}.{{SCHEMA_NAME}}.EXT_TABLE_STATUS_MST",
            f"SET",
            f"     KIK_KBN = 1",
            f"    ,UPDATED_UID = '{self.client._username}'",
            f"    ,UPDATED_YMDHMS = CURRENT_TIMESTAMP()"
        ]
        lst_where_cond_tables = []
        for ext_view, dict_view_info in dict_ext_view_list.items():
            grant_cnt += 1
            self.logger.info(f'[{grant_cnt}]{database}.{{SCHEMA_NAME}}.{ext_view}へのSELECT権限のGRANT文を発行します。'
                             .format(**self.settings.SNOWFLAKE_BIND))
            # GRANT文を発行する
            if self.target_database_bind in ['{DB_SASPRD}', '{DB_SASMA}', '{DB_SASWK}']:
                role = '{SAS_OWNER_ROLE}'.format(**self.settings.SNOWFLAKE_ROLE_BIND)
            else:
                role = f'{database}_OWNER_ROLE'
            if dict_view_info['src_database_bind'] == '{DB_NSDL}':
                schema = 'DL_COMMON'
            elif dict_view_info['src_database_bind'] == '{DB_NSAUDIT}':
                schema = 'DL_AUDIT'
            else:
                schema = '{SCHEMA_NAME}'
            query = f"GRANT SELECT ON VIEW {database}.{schema}.{ext_view} TO ROLE {role};"
            query = query.format(**self.settings.SNOWFLAKE_BIND)
            try:
                self.client.execute_string(query)
            except Exception as e:
                err_cnt += 1
                self.logger.error('SQL実行中にエラーが発生しました。 %s' % e)
                lst_err_msg.append(f'[{err_cnt}]{database}.{schema}.{ext_view}: {e}')
                continue

            if ext_view not in lst_where_cond_tables:
                lst_where_cond_tables.append(f"'{ext_view}'")

            if self.target_database_bind == '{DB_SASV}' and ext_view not in dict_current_mst_table:
                # ステータス管理マスタにレコードが存在しない場合はレコードを追加する
                if ext_view not in dict_current_mst_table:
                    lst_query = [
                        f"INSERT INTO {{DB_NSONLINET}}.{{SCHEMA_NAME}}.EXT_TABLE_STATUS_MST (",
                        f"     TBL_BTSR_ID",
                        f"    ,TBL_RNR",
                        f"    ,RRS",
                        f"    ,KEEP_INF",
                        f"    ,TBL_INF",
                        f"    ,KIK_KBN",
                        f"    ,CREATED_UID",
                        f"    ,UPDATED_UID",
                        f"    ,CREATED_YMDHMS",
                        f"    ,UPDATED_YMDHMS",
                        f")",
                        f"VALUES",
                        f"(",
                        f"     '{ext_view}'",
                        f"    ,''",
                        f"    ,''",
                        f"    ,''",
                        f"    ,'SASV'",
                        f"    ,1",
                        f"    ,'{self.client._username}'",
                        f"    ,'{self.client._username}'",
                        f"    ,CURRENT_TIMESTAMP()",
                        f"    ,CURRENT_TIMESTAMP()"
                        f");"
                    ]
                    self.logger.info(f'EXT_TABLE_STATUS_MSTに{ext_view}のレコードがないので追加します。')
                    query = '\n'.join(lst_query).format(**self.settings.SNOWFLAKE_BIND)
                    try:
                        self.client.execute_string(query)
                    except Exception as e:
                        err_cnt += 1
                        self.logger.error('INSERTのSQL実行中にエラーが発生しました。 %s' % e)
                        lst_err_msg.append(f'[{err_cnt}]{database}.{{SCHEMA_NAME}}.{ext_view}: {e}')

        # GRANTを実行したVIEWのレコードのKIK_KBNの値を1(開局)に更新する
        where_cond_tables = '\n,'.join(lst_where_cond_tables)
        lst_update_query.append(f"WHERE TBL_BTSR_ID IN (\n{where_cond_tables}\n);")
        query = '\n'.join(lst_update_query).format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info(f'テーブルEXT_TABLE_STATUS_MSTのカラムKIK_KBNの値を1(開局)に更新します。')
        try:
            self.client.execute_string(query)
        except Exception as e:
            self.logger.error('EXT_TABLE_STATUS_MSTへのUPDATEのSQL実行中にエラーが発生しました。 %s' % e)
            lst_err_msg.append('EXT_TABLE_STATUS_MSTへのUPDATEのSQL実行中にエラーが発生しました。')

        self.client.close()

        self.logger.info(f'{grant_cnt - err_cnt}/{grant_cnt}件のGRANT文実行に成功しました。')
        if err_cnt > 0:
            self.logger.error(f'{err_cnt}件のエラーが発生しました。')
            err_msg_summary = f'個別開局リカバリ手動実行用プログラムアラート\n' \
                              f'JOB_ID: {self.job_id}\n' \
                              f'みなし日: {self.batch_date.batch_date}\n'\
                              + '\n'.join(lst_err_msg)
            self.logger.warning(f'Windowsイベントログに以下のWarningを出力します。\n{err_msg_summary}', cout=True)
            w = WindowsEventLog()
            w.output_event_log(err_msg_summary, 'Warning')
