"""
小出さんご謹製golang前処理プログラムを実行アーキから叩きます。
"""

from pathlib import Path
import shutil

from batch_architecture.client import Shell
from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.io_target.base import Target
from batch_architecture.io_target import S3Target


class CallPostProcessGoLogic(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.call_postprocess_go"

    def _init_logic(self, script, script_args) -> None:
        """
        Execute 固有の初期化処理を行う

        :param script_args['config']: 実行するスクリプトのパスとコマンドライン引数
        """
        self.config_path = self.settings.RESOURCE_FILE_DEF_POST_DIR / script_args['config']
        self.go_module_path = self.settings.RESOURCE_GO_EXE_DIR / "post_go.exe"
        self.input_target = Target.parse(script_args['input_key'])
        if not isinstance(self.input_target, S3Target):
            msg = "input_keyはs3://{バケット名}/xxxで指定してください"
            raise NotImplementedError(msg)
        self.output_target = Target.parse(script_args['output_key'])
        if not isinstance(self.output_target, S3Target):
            msg = "output_keyはs3://{バケット名}/xxxで指定してください"
            raise NotImplementedError(msg)
        self.input_bucket = self.input_target._bucket_name
        self.input_path = str(self.input_target._path)
        self.output_bucket = self.output_target._bucket_name
        self.output_path = str(self.output_target._path)
        # POST_GOのinputはIF名のフォルダ指定であるという共通ロジックより、一時ディレクトリを作成
        if_name = script_args['input_key'].split('/')[-1]
        self.temp_file_dir = Path(self.settings.POST_GO_TEMP_DIR) / if_name
        if self.temp_file_dir.exists() is False:
            self.temp_file_dir.mkdir(parents=True)
        self.original_file_delete = script_args.get('original_file_delete', False)

        if not self.config_path.is_file():
            msg = "指定されたパス({0})は存在しません"
            raise FileNotFoundError(msg.format(self.config_path))

        if not self.go_module_path.is_file():
            msg = "指定されたパスにGoバイナリ({0})が存在しません"
            raise FileNotFoundError(msg.format(self.go_module_path))

    def create_command(self) -> str:
        # bat以外のスクリプトの処理
        try:
            FMT = '"{path}" -c "{config}" -eb "{input_bucket}" -sb "{output_bucket}" -i "{input_path}" -o "{output_path}" -t "{temp_file_dir}"'
            return FMT.format(
                path=str(self.go_module_path),
                config=self.config_path,
                input_bucket=self.input_bucket,
                output_bucket=self.output_bucket,
                input_path=self.input_path,
                output_path=self.output_path,
                temp_file_dir=self.temp_file_dir,
            )
        except KeyError:
            msg = "指定されたファイル{0}は実行できません。"
            raise ValueError(msg.format(self.go_module_path))

    def _execute(self) -> None:
        cmd = self.create_command()
        self.logger.info(cmd)
        shell = Shell()
        try:
            return_code, out, err = shell.execute(cmd)
            self.logger.info(out)
            self.logger.info(err)
        except Exception as e:
            raise e
        finally:
            if self.temp_file_dir.exists():
                self.logger.info('ローカルの作業ディレクトリ(%s)を削除します' % str(self.temp_file_dir))
                shutil.rmtree(self.temp_file_dir)
        if self.original_file_delete is True and return_code == 0:
            self.logger.info("元ファイルを削除します。{}".format(self.input_target))
            self.input_target.delete()
        return return_code
