import os
import datetime

from batch_architecture.core.logic import SQLBusinessLogic
from batch_architecture.client.snowflake_client import SnowflakeClient
from batch_architecture.core.schedule_utils import ScheduleUtils
from batch_architecture.cmd.windows_log import WindowsEventLog


class SnowflakeSQLExecuteRevokeSelectViewLogic(SQLBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake_revoke_select_view"

    def _init_logic(self, script, script_args):
        """
        RevokeSelectView 固有の初期化処理を行う
        """
        self.target_database_bind = script_args.get('target_database')
        self.warehouse = script_args.get('warehouse').format(**self.settings.WAREHOUSE_BIND)
        self.switch_user = script_args.get("switch_user")

    @property
    def client(self):
        """
        Snowflakeへの接続
        """
        if getattr(self, "_client", None) is None:
            res_user = None
            if self.switch_user:
                res_user = os.environ["ADT_RESOURCE"]
                os.environ["ADT_RESOURCE"] = self.switch_user
            try:
                self._client = SnowflakeClient(warehouse=self.warehouse)
                self._client.connect()
            finally:
                if res_user:
                    os.environ["ADT_RESOURCE"] = res_user

        return self._client

    def _execute(self) -> None:
        # VIEW一覧を取得する
        self.logger.info(f'view_update_schedule_mstテーブルから"{self.target_database_bind}"のVIEW一覧を取得します。')
        dict_view_list = ScheduleUtils.get_view_list_from_view_update_schedule_mst(self.target_database_bind)
        database = self.target_database_bind.format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info(f'Database: {database}, {len(dict_view_list)}本')

        # 前日みなし日に起動するロジックなので、みなし日を+1日する
        self.logger.info('前日みなし日に起動するので、みなし日を+1日にします。')
        batch_date_datetime = datetime.datetime.strptime(self.batch_date.batch_date, '%Y%m%d')
        batch_date_datetime_upd = batch_date_datetime + datetime.timedelta(days=1)
        self.batch_date.set_batch_date(batch_date_datetime_upd.strftime('%Y%m%d'))
        self.logger.info(f'バッチ処理日付（修正後） : [{self.batch_date.batch_date}]')

        # 実行みなし日のカレンダー情報を取得
        self.logger.info('みなし日のカレンダー情報を取得します。')
        info = ScheduleUtils.get_batch_date_info()
        self.logger.info(
            f'みなし日情報（みなし日： {info["batch_date"]}, 週: {info["ymd_wk"]},'
            f' 曜日: {info["batch_date_week"]}, 営業日: {info["is_business_day"]}）')

        total_cnt = 0
        revoke_cnt = 0
        err_cnt = 0
        lst_err_msg = []
        # SK9ON018のカラムKIK_KBNの値を0(閉局)にアップデートするクエリ
        lst_update_query = [
            f"UPDATE {{DB_NSONLINET}}.{{SCHEMA_NAME}}.SK9ON018",
            f"SET",
            f"     KIK_KBN = 0",
            f"    ,UPDATED_UID = '{self.client._username}'",
            f"    ,UPDATED_YMDHMS = CURRENT_TIMESTAMP()"
        ]
        lst_where_cond_tables = []
        for view, dict_view_info in dict_view_list.items():
            total_cnt += 1
            schedule_id = dict_view_info['schedule_id']
            schedule_name = dict_view_info['schedule_name']
            src_database_bind = dict_view_info['src_database_bind']

            # みなし日がVIEW更新日であることを確認する
            is_view_update_date = ScheduleUtils.match_schedule(schedule_id)
            if is_view_update_date is False:
                self.logger.info(f'[{total_cnt}]{database}.{{SCHEMA_NAME}}.{view}は更新日ではないので処理をスキップします。'
                                 f' {schedule_id}({schedule_name})'.format(**self.settings.SNOWFLAKE_BIND))
                continue

            revoke_cnt += 1
            self.logger.info(f'[{total_cnt}]{database}.{{SCHEMA_NAME}}.{view}へのSELECT権限のREVOKE文を発行します。'
                             .format(**self.settings.SNOWFLAKE_BIND))
            # REVOKE文を発行する
            if self.target_database_bind in ['{DB_SASPRD}', '{DB_SASMA}', '{DB_SASWK}']:
                role = '{SAS_OWNER_ROLE}'.format(**self.settings.SNOWFLAKE_ROLE_BIND)
                query = f"REVOKE SELECT ON VIEW {database}.{{SCHEMA_NAME}}.{view} FROM ROLE {role};"
            elif self.target_database_bind in ['{DB_NSDCV_MASKED}', '{DB_NSDCV_SECURE}']:
                role = f'{database}.DB_ROLE'
                query = f"REVOKE SELECT ON VIEW {database}.{{SCHEMA_NAME}}.{view} FROM DATABASE ROLE {role};"
            else:
                role = f'{database}_OWNER_ROLE'
                query = f"REVOKE SELECT ON VIEW {database}.{{SCHEMA_NAME}}.{view} FROM ROLE {role};"
            query = query.format(**self.settings.SNOWFLAKE_BIND)
            try:
                self.client.execute_string(query)
            except Exception as e:
                err_cnt += 1
                self.logger.error('REVOKEのSQL実行中にエラーが発生しました。 %s' % e)
                lst_err_msg.append(f'[{err_cnt}]{database}.{{SCHEMA_NAME}}.{view}: {e}')
                continue

            lst_where_cond_tables.append(f"'{view}'")
            # NSDWHの場合は元テーブルのレコードがある場合がある
            if self.target_database_bind == '{DB_SASV}' and src_database_bind == '{DB_NAME}':
                org_table = view[1:]
                lst_where_cond_tables.append(f"'{org_table}'")

        # NSDCV_SECUREの場合は閉局対象が0件になる場合があるため、条件分岐
        if len(lst_where_cond_tables) == 0 and self.target_database_bind == '{DB_NSDCV_SECURE}':
            self.logger.info(f'閉局対象が0件のため、テーブルSK9ON018の更新をスキップします')
        else:
            where_cond_tables = '\n,'.join(lst_where_cond_tables)
            lst_update_query.append(f"WHERE TBL_BTSR_ID IN (\n{where_cond_tables}\n);")
            query = '\n'.join(lst_update_query).format(**self.settings.SNOWFLAKE_BIND)
            self.logger.info(f'テーブルSK9ON018のカラムKIK_KBNの値を0(閉局)に更新します。')
            try:
                self.client.execute_string(query)
            except Exception as e:
                self.logger.error('SK9ON018へのUPDATEのSQL実行中にエラーが発生しました。 %s' % e)
                lst_err_msg.append('SK9ON018へのUPDATEのSQL実行中にエラーが発生しました。')

        self.client.close()

        self.logger.info(f'{revoke_cnt - err_cnt}/{revoke_cnt}件のREVOKE文実行に成功しました。')
        if len(lst_err_msg) > 0:
            self.logger.error(f'{err_cnt}件のエラーが発生しました。')
            err_msg_summary = f'VIEW閉局プログラムアラート\n' \
                              f'JOB_ID: {self.job_id}\n' \
                              f'みなし日: {self.batch_date.batch_date}\n' \
                              + '\n'.join(lst_err_msg)
            self.logger.warning(f'Windowsイベントログに以下のWarningを出力します。\n{err_msg_summary}', cout=True)
            w = WindowsEventLog()
            w.output_event_log(err_msg_summary, 'Warning')
