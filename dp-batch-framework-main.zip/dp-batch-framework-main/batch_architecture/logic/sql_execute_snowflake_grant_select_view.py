import os
import random
import time

from batch_architecture.core.logic import SQLBusinessLogic
from batch_architecture.client.snowflake_client import SnowflakeClient


class SnowflakeSQLExecuteGrantSelectViewLogic(SQLBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake_grant_select_view"

    def _init_logic(self, script, script_args):
        """
        GrantSelectView 固有の初期化処理を行う
        """
        self.logger.info("snowflake バインド変数一覧: {}".format(self.settings.SNOWFLAKE_BIND))
        self.lst_target_view = script_args.get("target_views")
        self.warehouse = script_args.get('warehouse').format(**self.settings.WAREHOUSE_BIND)
        self.switch_user = script_args.get("switch_user")
        self.random_sleep_min = script_args.get('random_sleep_min', self.settings.RANDOM_SLEEP_MIN)
        self.random_sleep_max = script_args.get('random_sleep_max', self.settings.RANDOM_SLEEP_MAX)

    @property
    def client(self):
        """
        Snowflakeへの接続
        """
        if getattr(self, "_client", None) is None:
            res_user = None
            if self.switch_user:
                res_user = os.environ["ADT_RESOURCE"]
                os.environ["ADT_RESOURCE"] = self.switch_user
            try:
                self._client = SnowflakeClient(warehouse=self.warehouse)
                self._client.connect()
            finally:
                if res_user:
                    os.environ["ADT_RESOURCE"] = res_user

        return self._client

    def _get_ddl_from_view(self, source_database, source_id) -> str:
        get_ddl_query = f"SELECT GET_DDL('VIEW', '{source_database}.{{SCHEMA_NAME}}.{source_id}');"
        get_ddl_query = get_ddl_query.format(**self.settings.SNOWFLAKE_BIND)
        self.client.execute_sql(get_ddl_query)
        view_ddl = self.client.fetch_one()[0]
        use_query = f"USE {{DB_SASV}}.{{SCHEMA_NAME}};\n\n"
        use_query = use_query.format(**self.settings.SNOWFLAKE_BIND)
        return use_query + view_ddl

    def _get_ddl_from_base_table(self, source_database, source_id) -> str:
        if os.environ['ADT_RESOURCE'] == 'dwh' and source_database == '{DB_NAME}' and source_id == 'WL1SF001':
            lst_get_source_query = [
                f"SELECT TABLE_NAME FROM {source_database}.INFORMATION_SCHEMA.TABLES",
                f"WHERE TABLE_SCHEMA = '{{SCHEMA_NAME}}' AND TABLE_TYPE = 'BASE TABLE'",
                f"    AND TABLE_NAME LIKE '{source_id}%'",
                f"ORDER BY TABLE_NAME",
                ";"
            ]
            get_source_query = '\n'.join(lst_get_source_query).format(**self.settings.SNOWFLAKE_BIND)
            self.logger.info('VWL1SF001のソーステーブルを取得します。')
            self.client.execute_sql(get_source_query)
            lst_table_wl1sf001 = [t[0] for t in self.client.fetch_all()]
            lst_query = [
                f"CREATE OR REPLACE VIEW {{DB_SASV}}.{{SCHEMA_NAME}}.VWL1SF001 AS",
            ]
            for table_name in lst_table_wl1sf001:
                lst_query.append(f"SELECT * FROM {{DB_NAME}}.{{SCHEMA_NAME}}.{table_name}")
                lst_query.append("UNION ALL")
            lst_query[-1] = ";"
            query = '\n'.join(lst_query)
        else:
            query = '\n'.join([
                f"CREATE OR REPLACE VIEW {{DB_SASV}}.{{SCHEMA_NAME}}.V{source_id} AS",
                f"SELECT * FROM {source_database}.{{SCHEMA_NAME}}.{source_id};"
            ])
        return query

    def _get_ddl_from_ext_table(self, source_database, source_id) -> str:
        # GRANT対象として存在していないので未実装
        raise NotImplementedError

    def _get_current_mst_table_record(self) -> dict:
        query = "SELECT TBL_BTSR_ID, TBL_RNR FROM {DB_NSONLINET}.{SCHEMA_NAME}.SK9ON018;"
        query = query.format(**self.settings.SNOWFLAKE_BIND)
        self.logger.info('現在のSK9ON018に存在するテーブルの一覧を取得します。')
        self.client.execute_sql(query)
        dict_current_mst_table = {t[0]: t[1] for t in self.client.fetch_all()}
        return dict_current_mst_table

    def _get_table_name_jp_from_tab_def(self, table_name) -> str:
        # テーブル論理名をtab_defから取得する
        tab_def_path = str(self.settings.RESOURCE_TABLE_DEF_DIR) + f'/{table_name}.json'
        try:
            d = self.settings.parse_json_config(tab_def_path)
            table_name_jp = d['table_name_jp']
        except FileNotFoundError:
            msg = "ファイルが見つかりません: {}".format(
                str(self.settings.RESOURCE_TABLE_DEF_DIR)
                + f"/{table_name}.json"
            )
            self.logger.error(msg)
            table_name_jp = ''
        except KeyError:
            msg = 'Key "table_name_jp" がjson内に見つかりません: {}'.format(
                str(self.settings.RESOURCE_TABLE_DEF_DIR)
                + f"/{table_name}.json"
            )
            self.logger.error(msg)
            table_name_jp = ''
        except Exception as e:
            raise e
        return table_name_jp

    def _execute(self) -> None:
        grant_cnt = 0

        # 現在のSK9ON018のテーブル一覧を取得
        dict_current_mst_table = self._get_current_mst_table_record()

        for dict_target_info in self.lst_target_view:
            grant_cnt += 1
            database_bind = dict_target_info['target']['database']
            view = dict_target_info['target']['view']
            source_database = None
            if database_bind == '{DB_SASV}' and 'source' in dict_target_info:
                self.logger.info(f'[{grant_cnt}]{database_bind}.{{SCHEMA_NAME}}.{view}を作成または再作成します。'
                                 .format(**self.settings.SNOWFLAKE_BIND))
                # SASVのVIEWへのGRANTの場合、DDLを取得してVIEWを再作成
                source_database = dict_target_info['source']['database']
                source_type = dict_target_info['source']['object_type']
                source_id = dict_target_info['source']['object_id']
                if source_type == 'VIEW':
                    query = self._get_ddl_from_view(source_database, source_id)
                elif source_type == 'TABLE':
                    query = self._get_ddl_from_base_table(source_database, source_id)
                elif source_type == 'TABLE(EXT)':
                    query = self._get_ddl_from_ext_table(source_database, source_id)
                else:
                    raise Exception(f'ソースオブジェクトタイプはVIEW/TABLE/TABLE(EXT)のいずれかである必要があります。'
                                    f'(source_object_type: {source_type})')

            else:
                # SASVのVIEW以外はDBオーナーロールに対するGRANT文を発行する
                self.logger.info(f'[{grant_cnt}]{database_bind}.{{SCHEMA_NAME}}.{view}へのSELECT権限のGRANTを実行します。')
                if database_bind in ['{DB_SASPRD}', '{DB_SASMA}', '{DB_SASWK}', '{DB_CDM}']:
                    role = '{SAS_OWNER_ROLE}'.format(**self.settings.SNOWFLAKE_ROLE_BIND)
                    query = f"GRANT SELECT ON VIEW {database_bind}.{{SCHEMA_NAME}}.{view} TO ROLE {role};"
                elif database_bind in ['{DB_NSDCV_MASKED}', '{DB_NSDCV_SECURE}']:
                    role = f'{database_bind}.DB_ROLE'
                    query = f"GRANT SELECT ON VIEW {database_bind}.{{SCHEMA_NAME}}.{view} TO DATABASE ROLE {role};"
                else:
                    role = f'{database_bind}_OWNER_ROLE'
                    query = f"GRANT SELECT ON VIEW {database_bind}.{{SCHEMA_NAME}}.{view} TO ROLE {role};"
            query = query.format(**self.settings.SNOWFLAKE_BIND)
            try:
                self.client.execute_string(query)
            except Exception as e:
                self.logger.error(f'{database_bind}.{{SCHEMA_NAME}}.{view}: GRANTのSQL実行中にエラーが発生しました。'
                                  .format(**self.settings.SNOWFLAKE_BIND))
                raise e

            # NSDWHの1層テーブルを参照するSASVレコードが存在しない場合はレコードを追加する
            if database_bind == '{DB_SASV}' and source_database == '{DB_NAME}' and view not in dict_current_mst_table:
                org_table = view[1:]
                table_name_jp = self._get_table_name_jp_from_tab_def(org_table)
                lst_query = [
                    f"INSERT INTO {{DB_NSONLINET}}.{{SCHEMA_NAME}}.SK9ON018 (",
                    f"     TBL_BTSR_ID",
                    f"    ,TBL_RNR",
                    f"    ,RRS",
                    f"    ,KEEP_INF",
                    f"    ,TBL_INF",
                    f"    ,KIK_KBN",
                    f"    ,CREATED_UID",
                    f"    ,UPDATED_UID",
                    f"    ,CREATED_YMDHMS",
                    f"    ,UPDATED_YMDHMS",
                    f")",
                    f"VALUES",
                    f"(",
                    f"     '{view}'",
                    f"    ,'{table_name_jp}'",
                    f"    ,''",
                    f"    ,''",
                    f"    ,'SASV'",
                    f"    ,1",
                    f"    ,'{self.client._username}'",
                    f"    ,'{self.client._username}'",
                    f"    ,CURRENT_TIMESTAMP()",
                    f"    ,CURRENT_TIMESTAMP()"
                    f");"
                ]
                self.logger.info(f'SK9ON018に{view}のレコードがないので追加します。')
                query = '\n'.join(lst_query).format(**self.settings.SNOWFLAKE_BIND)
                try:
                    self.client.execute_string(query)
                except Exception as e:
                    self.logger.error(f'{database_bind}.{{SCHEMA_NAME}}.{view}: INSERTのSQL実行中にエラーが発生しました。'
                                      .format(**self.settings.SNOWFLAKE_BIND))
                    raise e

            # SK9ON018のカラムKIK_KBNの値を1(開局)にアップデート
            lst_query = [
                f"UPDATE {{DB_NSONLINET}}.{{SCHEMA_NAME}}.SK9ON018",
                f"SET",
                f"     KIK_KBN = 1",
                f"    ,UPDATED_UID = '{self.client._username}'",
                f"    ,UPDATED_YMDHMS = CURRENT_TIMESTAMP()",
                f"WHERE TBL_BTSR_ID = '{view}'",
                ";"
            ]
            # NSDWHの場合は元テーブルのレコードがある場合がある
            if database_bind == '{DB_SASV}' and source_database == '{DB_NAME}':
                org_table = view[1:]
                lst_query[-2] = f"WHERE TBL_BTSR_ID = '{view}' OR TBL_BTSR_ID = '{org_table}'"
            # NSTRKの場合は元テーブルのレコードがある場合がある
            if database_bind == '{DB_SASV}' and source_database == '{DB_NSTRK}':
                org_table = view[1:]
                lst_query[-2] = f"WHERE TBL_BTSR_ID = '{view}' OR TBL_BTSR_ID = '{org_table}'"
            query = '\n'.join(lst_query).format(**self.settings.SNOWFLAKE_BIND)
            self.logger.info(f'テーブルSK9ON018のカラムKIK_KBNの値を1(開局)に更新します。: {view}')
            # UPDATE文が複数競合すると処理が滞留してしまう場合があるので、リトライを入れる
            update_executed = False
            last_err = None
            # 10分(600秒)以上はリトライするように繰り上げ除算
            sleep_time = random.randint(self.random_sleep_min, self.random_sleep_max)
            retry_cnt = -(-600 // sleep_time)
            for i in range(retry_cnt):
                try:
                    self.client.execute_string(query)
                except Exception as e:
                    self.logger.warning('UPDATEのSQL実行中にエラーが発生しました。 %s' % e, cout=True)
                    last_err = e
                    if i != retry_cnt - 1:
                        self.logger.info(f'{sleep_time}秒後にリトライします。({i + 2}回目)', cout=True)
                        time.sleep(sleep_time)
                else:
                    update_executed = True
                    break
            if update_executed is False:
                self.logger.error(f'{database_bind}.{{SCHEMA_NAME}}.{view}: '
                                  f'{retry_cnt}回試行しましたが、UPDATEのSQLを実行できませんでした。'
                                  .format(**self.settings.SNOWFLAKE_BIND))
                raise last_err

        self.client.close()
        self.logger.info(f'{grant_cnt}件のGRANT実行に成功しました。')
