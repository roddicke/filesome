"""
ファイルの変換処理
"""
import math

from batch_architecture.core.logic import _InputOutputLogic
from batch_architecture.etl import transform


class FileTransformLogic(_InputOutputLogic):
    """
    ファイル分割ロジック
    script_args:
        - input: 入力ファイルパス
        - split: ファイル分割する行数
        - remove_header_line: 削除するヘッダ行数
        - input_format:
            - encoding: 文字コード
        - output_format:
            - encoding: 文字コード
    """

    _LOGGER_NAME = "batch_architecture.logic.file_transform"

    def _init_logic(self, script, script_args):
        """
        FileTransform 固有の初期化処理を行う
        :param split: ファイル分割する行数
        :param remove_header_line: 削除するヘッダ行数
        :param input_format: 入力ファイルのフォーマットを示す辞書
        :param output_format: 出力ファイルのフォーマットを示す辞書
        :return:
        """
        self.remove_header_line = script_args['remove_header_line']
        self.num_split = script_args['split']
        default_format = {
            "encoding": "utf-8",
            "delimiter": ",",
            "doublequote": True,
            "escapechar": None,
            "lineterminator": "\r\n",
            "quotechar": '"',
            "quoting": 0,
            "skipinitialspace": False,
            "strict": False,
        }
        if not script_args['input_format'].keys() <= default_format.keys():
            msg = "input_format に不正なキーワードが含まれています。ジョブ定義ファイル内のキーワードをcsv.Dialectモジュールのキーワードに合わせてください"
            raise ValueError(msg)
        if not script_args['output_format'].keys() <= default_format.keys():
            msg = "output_format に不正なキーワードが含まれています。ジョブ定義ファイル内のキーワードをcsv.Dialectモジュールのキーワードに合わせてください"
            raise ValueError(msg)

        self.input_format = script_args['input_format']
        self.output_format = script_args['output_format']
        self.original_file_delete = script_args.get('original_file_delete', False)

    @classmethod
    def _get_numbered_filename(cls, file, n):
        """
        指定したファイルパスの末尾(拡張子の前)に3桁で番号付けする
        """
        if n >= 100:
            msg = "番号付けする数に3桁以上の数が指定されています。2桁以下の数を指定してください"
            raise ValueError(msg)

        num = "_{:02}".format(n)
        stem = file.stem
        return file.parent / (stem + num + file.suffix)

    def _execute(self):
        # output先は指定できず、inputと同フォルダ配下への出力のみ対応
        with self.input.open(encoding=self.input_format['encoding']) as input:
            content_row = (
                    sum(1 for _ in input) - self.remove_header_line
            )
            input.seek(0)

            remove_header_gen = transform.remove_header(
                input=input, n=self.remove_header_line
            )
            row_count = math.ceil(content_row / self.num_split)
            file_split_gen = transform.file_split(
                input=remove_header_gen, row_count=row_count
            )

            for i, rows in enumerate(file_split_gen):
                path = self._get_numbered_filename(file=self.input, n=i)
                with path._path.open(
                        "w", encoding=self.output_format['encoding'], newline=self.output_format["lineterminator"]
                ) as f:
                    for j in rows:
                        f.write(j)

        if self.original_file_delete is True:
            self.logger.info("元ファイルを削除します。{}".format(self.input))
            self.input.delete()
