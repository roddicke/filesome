import json
import datetime

from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.client.postgresql_client import PostgresSQLClient
from batch_architecture.client.sqs_client import SqsClient


class NotifyS3Landing(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.notify_s3landing"

    def _init_logic(self, script, script_args):
        self._pg_client = PostgresSQLClient()
        self._pg_client.connect()

        self._sqs_client = SqsClient()

    def _execute(self):
        # 前日みなし日取得
        batch_datetime = datetime.datetime.strptime(self.batch_date.read_batch_date_file(), "%Y%m%d")
        before_day = batch_datetime - datetime.timedelta(days=1)
        before_day = before_day.strftime('%Y%m%d')

        # 滞留しているS3イベントを取得するSQL
        query = """
        SELECT id, bucket, s3_path from {schema}.if_watch_log
         WHERE status IN ('incomplete', 'limited', 'pending')
         AND deleted = false AND batch_date = '{sys_date}' AND sys_name = '{sys_name}'
         LIMIT 1;""" \
            .format(
            schema=self.settings.LOG_TABLE_SCHEMA,
            sys_date=before_day,
            sys_name=self.settings.SYS_NAME,
        )

        sqs_url = self.resources.get("sqs").job_queue

        self.logger.info("滞留されたファイル受信メッセージを再送します。前日: %s" % before_day)

        resend = set()
        while True:
            self._pg_client.execute_sql(query)
            row = self._pg_client.fetch_one()
            if not row:
                break

            iid, bucket, s3_path = row
            key = (bucket, s3_path)

            upd_query = """
            UPDATE %s.if_watch_log
            SET deleted = true, updated_at = CURRENT_TIMESTAMP WHERE id = %d
            """ % (self.settings.LOG_TABLE_SCHEMA, iid)
            self._pg_client.execute_sql(upd_query)

            try:
                if key not in resend:
                    message_body = {
                        "Records": [{
                            "eventSource": "aws:s3",
                            "s3": {
                                "bucket": {"name": bucket},
                                "object": {
                                    "key": s3_path,
                                }
                            }
                        }]
                    }
                    messages = [json.dumps(message_body)]

                    self.logger.info('ファイル受信メッセージを再送します。%s/%s' % (bucket, s3_path))
                    self._sqs_client.send_message_batch(sqs_url, messages, 3)
                    resend.add(key)

                self._pg_client.commit()
            except:
                self._pg_client.rollback()
                raise

        self.logger.info("滞留されたファイル受信メッセージの再送を完了しました。")
