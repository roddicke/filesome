import os
import json
import re

from batch_architecture.logic.sql_execute_snowflake import SnowflakeSQLExecuteLogic
from batch_architecture.core.table_logging import table_logging
from batch_architecture.io_target import S3Target


class SnowflakeSQLExecuteExportLogic(SnowflakeSQLExecuteLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake_export"

    def _init_logic(self, script, script_args):
        super()._init_logic(script, script_args)

        self.rowcount_validation = script_args.get("rowcount_validation", True)
        self.target_if = script_args.get("target_if", None)

        self.post_def_json = {}
        if self.target_if:
            name = os.path.splitext(self.target_if)[0]
            config_path = self.settings.RESOURCE_FILE_DEF_POST_DIR / (name + '.json')
            if os.path.isfile(config_path):
                with open(config_path, encoding='utf-8') as fp:
                    self.post_def_json = json.load(fp)
            else:
                self.logger.warning('[post_def_json](%s)のファイルが見つかりません。' % config_path)
        else:
            self.logger.warning('[script_args][target_if]が定義されていません。')

    def _get_query(self):
        """
        SQLスクリプトからクエリを取得して置換処理を行ったのちクエリを返却
        """
        if getattr(self.script, "read", None) is None:
            sql_file = self.script.open(encoding="utf-8")
        else:
            sql_file = self.script

        try:
            query = sql_file.read(encoding="utf-8")
            # _init_logicではまだJobインスタンスが作成されていないのでjob_idが参照できない
            self.script_bind.update({'JOB_ID': self.job_id})
            # バインド置換処理
            query = query.format(**self.script_bind)
            return query

        except FileNotFoundError as e:
            self.logger.error("SQLファイルが見つかりません。 %s" % e)
            raise
        except Exception as e:
            self.logger.error("SQL内パラメータ変換処理中にエラーが発生しました。")
            raise e

    def _execute(self) -> None:
        """
        Snowflake
        """
        self.logger.info("----+" * 10)
        self.logger.info("EXPORT[{s}]を実行します。".format(s=self.script))

        query = self._get_query()

        stage_name = self._extract_stage_name(query)
        output_s3_path = self._extract_file_path(query)
        single_export = self._check_export_single(query)
        if single_export is False or output_s3_path.endswith('/'):
            self.logger.info(f"出力先パス {stage_name}/{output_s3_path} に存在するファイルを削除します。")
            s3_files = self._get_stage_files(stage_name, output_s3_path)
            for file_path in s3_files:
                target = S3Target(file_path.replace('s3://', ''))
                target.delete()
            self.logger.info("出力先パスに存在するファイルの削除が完了しました。")

        # ログテーブルに実行予定のクエリを記録する
        table_logging.logging_query(query)

        self.client.execute_string(query)

        # 実行後処理
        self._post_operation_export(query)

    def _post_operation_export(self, query):
        """
        1.エクスポートの件数を取得する
        2.エクスポート件数が0件の場合snowflakeではファイルを出力してくれないため
        実行アーキで空ファイルを作成し対象パスに格納する
        3.エクスポート件数と対象テーブルのレコード数を突合して一致するか確認
        4.一致していなければ警告ログを出す。

        """
        if not self.rowcount_validation:
            self.logger.info(f'rowcount_validationがFalseなため、エクスポート後のvalidationをスキップします')
            return
        self.logger.info('export後のデータ検証を行います')

        select_query = self._extract_select_query(query)
        stage_name = self._extract_stage_name(query)
        output_s3_path = self._extract_file_path(query)
        format_name = self._extract_file_format_name(query)
        single_export = self._check_export_single(query)
        has_header = self.post_def_json['outputOption']['has_header'] if self.post_def_json else \
            True if re.search(r'HEADER\s+=\s+TRUE', query, re.IGNORECASE) else False

        exported_rowcount_sql = (
            "SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID(-1)))"
        )
        self.client.execute_sql(exported_rowcount_sql, {})
        exported_rows_res = self.client.fetch_all()
        # 注意:
        # query に DETAILED_OUTPUT = TRUE がある場合、exported_rows_res[:, -1]に処理件数が入る
        # query に DETAILED_OUTPUT = TRUE がない場合、exported_rows_res[:, 0]に処理件数が入る
        row_count = sum([x[-1] for x in exported_rows_res]) if exported_rows_res else 0

        # ログテーブルに件数を記録する
        table_logging.logging_row_count(row_count)

        # 出力件数が0件の場合は出力先に空ファイルを作成して処理を終わる
        if row_count == 0:
            self.logger.info("エクスポート件数が0件です。空データファイルを作成します")

            # エクスポート件数を後続のジョブに渡す
            self.job.next_job_args['exported_row_count'] = 0

            if self.target_if:
                if not output_s3_path.endswith(self.target_if):
                    output_s3_path += '/' + self.target_if

            bucket_resource = self.resources.get("s3_bucket")
            output_s3_path = '%s/%s' % (
                bucket_resource._temporary, output_s3_path
            )
            empty_file = S3Target(output_s3_path)
            if has_header:
                newline = {
                    'CRLF': '\r\n',
                    'CR': '\r',
                    'LF': '\n',
                }
                if self.post_def_json:
                    cols = [c['name'] for c in self.post_def_json['columns']]
                    row = self.post_def_json['outputOption']['delimiter'].join(cols)
                    empty_file.write("{}{}".format(
                        row, newline[self.post_def_json['outputOption']['newline']]
                    ))
                else:
                    self.logger.warning("後処理ファイル定義がないためヘッダ行を出力できません。")
                    empty_file.write("")
            else:
                empty_file.write("")
            self.logger.info("空データファイルを作成しました")
            self.logger.info("作成パス : {}".format(output_s3_path))
            return

        self.logger.info("エクスポート件数 : {}".format(row_count))
        # エクスポート件数を後続のジョブに渡す
        self.job.next_job_args['exported_row_count'] = row_count

        # エクスポート件数と行数の突合
        self.logger.info("対象テーブルの行数と出力ファイルの行数を突合します")
        """ テーブル行数取得 """
        table_count = self._count_table_rows(select_query)

        # SINGLE = TRUEがない場合は出力されるファイル名にsuffixがつくのでパス名を拡張する
        # また、出力先パスがディレクトリ指定の場合、ファイルが作成されるのでパス名を拡張する
        if single_export is False or output_s3_path.endswith('/'):
            output_s3_path = output_s3_path + '.*'
        """ ファイル行数取得 """
        stage_count = self._count_stage_file_rows(stage_name, output_s3_path, format_name)

        # HEADER = TRUEがある場合はHEADER分stage_countが1多いので-1して平仄とる
        # また、PARQUETの場合は調整の必要なし
        if has_header is True and 'FILE_FORMAT_SNAPPY_PARQUET' not in format_name:
            stage_count -= 1

        if table_count != stage_count:
            msg = "対象テーブルの行数と出力ファイルの行数が一致していません。\n" \
                  "対象テーブルの行数:%s 出力ファイル行数:%s" % (table_count, stage_count)
            raise ValueError(msg)
        self.logger.info("対象テーブルの行数と出力ファイルの行数の一致を確認しました")

    @staticmethod
    def _extract_select_query(query: str) -> str:
        m = re.search(r'FROM\s\(([\s\S]+?)\)\s+FILE_FORMAT', query)
        if m is None:
            raise ValueError('export queryから正規表現でselect句を取得できませんでした。'
                             'DMLが間違っているか正規表現が間違っている可能性があります。')
        return m.group(1)

    @staticmethod
    def _extract_stage_name(query: str) -> str:
        m = re.search(r'COPY\s+INTO\s+(@\S+?)/', query)
        if m is None:
            raise ValueError('export queryから正規表現でstage名を取得できませんでした。'
                             'DMLが間違っているか正規表現が間違っている可能性があります。')
        return m.group(1)

    @staticmethod
    def _extract_file_path(query: str) -> str:
        m = re.search(r'COPY\s+INTO\s+@\S+?/(\S+)', query)
        if m is None:
            raise ValueError('export queryから正規表現でfile pathを取得できませんでした。'
                             'DMLが間違っているか正規表現が間違っている可能性があります。')
        return m.group(1)

    @staticmethod
    def _extract_file_format_name(query: str) -> str:
        m = re.search(r'FILE_FORMAT\s+=\s+\(FORMAT_NAME\s+=\s+(\S+\.\S+\.\S+)\)', query)
        if m is None:
            raise ValueError('export queryから正規表現でfile format名を取得できませんでした。'
                             'DMLが間違っているか正規表現が間違っている可能性があります。')
        return m.group(1)

    @staticmethod
    def _check_export_single(query: str) -> str:
        m = re.search(
            r'COPY\s+INTO\s+(.*)\s+FROM\s+(.*)\s+SINGLE\s*=\s*TRUE', query, re.DOTALL)
        return m is not None
