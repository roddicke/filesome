import os
import datetime

from batch_architecture.core.logic import SQLBusinessLogic
from batch_architecture.core.schedule_utils import ScheduleUtils
from batch_architecture.client.postgresql_client import PostgresSQLClient
from batch_architecture.cmd.windows_log import WindowsEventLog


class FileLinkageDelayWarning(SQLBusinessLogic):
    """
    ファイル連携遅延警告ロジック
    実行ログを確認して、ファイルが到着していない場合はWindowsイベントログにWarningを出す。
    script_args:
        - target: 監視対象パス
    """
    _LOGGER_NAME = "batch_architecture.logic.file_linkage_delay_monitoring"

    def _init_logic(self, script, script_args):
        self.monitoring_time = script_args['monitoring_time']

    @property
    def client(self):
        """
        PostgresSQLへの接続
        """
        if getattr(self, "_client", None) is None:
            self._client = PostgresSQLClient()
            self._client.connect()

        return self._client

    def _get_monitoring_target_list_of_the_time(self) -> list:
        reference_table = 'if_watch_monitoring_time_mst'
        # monitoring_start_ymdがみなし日以降の場合、監視対象としない（遅延監視開始日付予約機能）
        query = f"SELECT if_type, file_id, if_file_name, if_file_name_jp, monitoring_file_name, schedule_id," \
                f" schedule_name, job_id, monitoring_start_ymd\n" \
                f"FROM {self.settings.LOG_TABLE_SCHEMA}.{reference_table}\n" \
                f"WHERE sys_name = '{os.environ['ADT_RESOURCE']}' AND limit_time = '{self.monitoring_time}'\n" \
                f"ORDER BY if_type, file_id\n;"
        try:
            self.client.execute_sql(query)
            rows = self.client.fetch_all()
        except Exception as e:
            self.logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            raise
        lst_target = []
        for i in range(len(rows)):
            dict_rows = {
                'if_type': rows[i][0],
                'file_id': rows[i][1],
                'if_file_name': rows[i][2],
                'if_file_name_jp': rows[i][3],
                'monitoring_file_name': rows[i][4],
                'schedule_id': rows[i][5],
                'schedule_name': rows[i][6],
                'job_id': rows[i][7],
                'monitoring_start_ymd': rows[i][8]
            }
            lst_target.append(dict_rows)
        return lst_target

    def _get_exists_execute_log(self, if_type, job_id) -> bool:
        if if_type == '受信':
            reference_table = 'if_watch_log'
            ext_where_condition = " AND status = 'processed';"
        else:
            reference_table = 'if_transfer_log'
            ext_where_condition = ";"
        lst_query = [
            f"SELECT job_id",
            f"FROM {self.settings.LOG_TABLE_SCHEMA}.{reference_table}",
            f"WHERE batch_date = '{self.batch_date.batch_date}'",
            f" AND sys_name = '{os.environ['ADT_RESOURCE']}' AND job_id = '{job_id}'",
            f"{ext_where_condition}"
        ]
        query = '\n'.join(lst_query)
        try:
            self.client.execute_sql(query)
            rows = self.client.fetch_all()
        except Exception as e:
            self.logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            raise
        if len(rows) == 0:
            return False
        else:
            return True

    def _execute(self):
        self.logger.info(f'遅延監視時刻: "{self.monitoring_time}"')

        # 監視時刻の監視対象一覧を取得する
        lst_monitoring_target = self._get_monitoring_target_list_of_the_time()
        self.logger.info(f'監視対象ファイル数: {len(lst_monitoring_target)}')

        # 実行みなし日のカレンダー情報
        info = ScheduleUtils.get_batch_date_info(self.batch_date.batch_date)
        self.logger.info(f'みなし日情報（みなし日： {info["batch_date"]}, 週: {info["ymd_wk"]},'
                         f' 曜日: {info["batch_date_week"]}, 営業日: {info["is_business_day"]}）')

        w = WindowsEventLog()
        lst_warn_target = []
        warn_cnt = 0
        for i, dict_target in enumerate(lst_monitoring_target):
            monitoring_target = dict_target['file_id']
            if_type = dict_target['if_type']
            job_id = dict_target['job_id']
            if_file_name_jp = dict_target['if_file_name_jp']
            monitoring_start_ymd = dict_target['monitoring_start_ymd']
            self.logger.info(f'[{i + 1}][{if_type}]{monitoring_target} IF論理名: {if_file_name_jp}')

            # みなし日が監視開始日より前である場合、遅延監視処理をスキップする
            if int(self.batch_date.batch_date) < monitoring_start_ymd:
                self.logger.info(f'[{i + 1}][{if_type}]{monitoring_target} '
                                 f'みなし日({self.batch_date.batch_date})が監視開始日({monitoring_start_ymd})より前なので、'
                                 f'処理をスキップします。')
                continue

            # 実行ログが存在するか確認
            exists_execute_log = self._get_exists_execute_log(if_type, job_id)
            if exists_execute_log:
                self.logger.info(f'[{i + 1}][{if_type}]{monitoring_target} 結果: IF{if_type}処理の実行ログが存在します。')
                continue
            # 実行みなし日にファイル連携があるか
            self.logger.info(f"[{i + 1}][{if_type}]{monitoring_target} 営業日カレンダー: "
                             f"{dict_target['schedule_id']}({dict_target['schedule_name']})")
            is_file_linkage_day = ScheduleUtils.match_schedule(dict_target['schedule_id'])
            if is_file_linkage_day is False:
                self.logger.info(f'[{i + 1}][{if_type}]{monitoring_target} 結果: '
                                 f'みなし日"{info["batch_date"]}"にはファイル連携がありません。')
                continue
            self.logger.info(f'[{i + 1}][{if_type}]{monitoring_target} 結果: '
                             f'監視対象ファイルが存在しません。WindowsイベントログにWarningを出力します。')
            warn_cnt += 1
            lst_warn_target.append(f'[{warn_cnt}][{if_type}]{monitoring_target}({if_file_name_jp})')
        if len(lst_warn_target) == 0:
            self.logger.info(f'受信/送信遅延しているファイルが存在しないので処理を終了します。')
            return
        lst_msg = [
                      f'ファイル送受信遅延監視アラート({os.environ["ADT_RESOURCE"]})',
                      f'JOB_ID: {self.job_id}',
                      f'みなし日: {self.batch_date.batch_date}',
                      f'{warn_cnt}件の監視対象ファイルが遅延監視時刻({self.monitoring_time})に存在しません。'
                  ] + lst_warn_target
        msg_summary = '\n'.join(lst_msg)
        self.logger.warning(f'Windowsイベントログに以下のWarningを出力します。\n{msg_summary}', cout=True)
        w.output_event_log(msg_summary, 'Warning')
