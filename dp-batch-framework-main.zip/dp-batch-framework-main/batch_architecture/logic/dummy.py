"""
ランダムの秒数Sleepして処理を終了する
"""
import random
import time

from batch_architecture.core.logic import BaseBusinessLogic


class DummyLogic(BaseBusinessLogic):
    """
    ダミーロジック
    script_args:
        - random_sleep_min: ランダムスリープ秒数最小値
        - random_sleep_max: ランダムスリープ秒数最大値
    """
    _LOGGER_NAME = "batch_architecture.logic.dummy"

    def _init_logic(self, script, script_args):
        self.random_sleep_min = script_args.get('random_sleep_min', self.settings.RANDOM_SLEEP_MIN)
        self.random_sleep_max = script_args.get('random_sleep_max', self.settings.RANDOM_SLEEP_MAX)

    def _execute(self):
        sleep_time = random.randint(self.random_sleep_min, self.random_sleep_max)
        self.logger.info(f"{sleep_time}秒待機します。", cout=True)
        time.sleep(sleep_time)
