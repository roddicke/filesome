import os
import datetime
from dateutil.relativedelta import relativedelta

from batch_architecture.client.snowflake_client import SnowflakeClient
from batch_architecture.core.logic import SQLBusinessLogic
from batch_architecture.core.table_logging import table_logging


class HandledDatabaseError(Exception):
    """
    エラーハンドリング済みのDBエラーに対し発生させる例外
    """

    def __init__(self, e=None):
        self._e = e

    def get_error_code(self):
        return self._e.args[0]


class RemoveErrorTableLogic(SQLBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.remove_error_table"

    def _init_logic(self):
        """
        SQL 固有の初期化処理を行う
        """

        pass

    @property
    def client(self):
        """
        Snowflakeへの接続
        """
        if getattr(self, "_client", None) is None:
            self._client = SnowflakeClient()
            self._client.connect()

        return self._client

    def _remove_error_table(self) -> None:
        """
        1.設定ファイルからシステムと環境に依存したデータベース名一覧を取得する
        2.データベースごとに先々月のエラーテーブルのリストを取得する
        3.対象のエラーテーブルのDROP文を実行する
        データベースの数だけ2と3を繰り返す
        """
        self.logger.info("----+" * 10)
        self.logger.info("前々月のエラーテーブルを一括削除します")
        self.logger.info("対象システム: " + os.environ["ADT_RESOURCE"])
        self.logger.info("----+" * 10)
        # 対象のデータベースを取得する。
        database_list = list(self.settings.SNOWFLAKE_BIND.values())[:-1]
        self.logger.info(f"検索対象DB一覧: {str(database_list)}")
        schema = self.settings.SNOWFLAKE_BIND.get("SCHEMA_NAME")
        # 先々月のYYYYmmを取得する
        today = datetime.date.today()
        month_before_last = (today - relativedelta(months=2)).strftime("%Y%m")
        self.logger.info(f"検索対象月: {month_before_last}")
        # databaseごとに先々月のエラーテーブルリストを取得する
        for database in database_list:
            self.logger.info("----+" * 10)
            self.logger.info(f"検索対象DB: {database}")
            get_err_table_list_sql = '\n'.join(
                [
                    f"SELECT table_name FROM {database}.INFORMATION_SCHEMA.TABLES",
                    f"WHERE table_name LIKE '%_ERR_{month_before_last}%';",
                ]
            )
            self.client.execute_sql(get_err_table_list_sql)
            err_table_list = self.client.fetch_all()
            # 型がおかしいので純粋なリストに整形
            err_table_list = [err_table[0] for err_table in err_table_list]
            err_table_count = len(err_table_list)
            self.logger.info(f"削除対象テーブル数: {err_table_count}")
            if err_table_count == 0:
                self.logger.info(f"{database}に削除対象テーブルは存在しません")
                continue
            # drop文の作成
            lst_drop_err_table_sql = []
            for err_table in err_table_list:
                drop_err_table_sql = f"DROP TABLE {database}.{schema}.{err_table};"
                lst_drop_err_table_sql.append(drop_err_table_sql)
            combined_sql = "\n".join(lst_drop_err_table_sql)
            self.logger.info("テーブルの削除を開始します")
            self.client.execute_string(combined_sql)
            self.logger.info("正常に削除されました")

    def _execute(self) -> None:
        """
        Snowflake
        """
        # ログテーブルに実行予定のクエリを記録する
        query = self._get_query()
        table_logging.logging_query(query.format(**self.bind))

        self._remove_error_table()
