import datetime

from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.client.postgresql_client import PostgresSQLClient


class DeleteS3Landing(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.delete_s3landing"

    def _init_logic(self, script, script_args):
        self._pg_client = PostgresSQLClient()
        self._pg_client.connect()

    def _execute(self):
        # 前日みなし日取得
        batch_datetime = datetime.datetime.strptime(self.batch_date.read_batch_date_file(), "%Y%m%d")
        before_day = batch_datetime - datetime.timedelta(days=1)
        before_day = before_day.strftime('%Y%m%d')

        # 滞留しているS3イベントを削除するSQL
        upd_query = "\n".join([
            "UPDATE {schema}.if_watch_log",
            "SET deleted = true, updated_at = CURRENT_TIMESTAMP",
            "WHERE status IN ('incomplete', 'limited', 'pending')",
            "AND deleted = false AND batch_date = '{sys_date}' AND sys_name = '{sys_name}'",
            ";"
        ]).format(
            schema=self.settings.LOG_TABLE_SCHEMA,
            sys_date=before_day,
            sys_name=self.settings.SYS_NAME
        )

        self.logger.info("滞留されたファイル受信ログを論理削除します。前日: %s" % before_day)

        try:
            self._pg_client.execute_sql(upd_query)
            self._pg_client.commit()
        except:
            self._pg_client.rollback()
            raise

        self.logger.info("滞留されたファイル受信ログの論理削除を完了しました。")
