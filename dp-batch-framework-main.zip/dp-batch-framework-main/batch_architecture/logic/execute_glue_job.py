"""
Glueジョブの実行
"""
import os
import time
from datetime import datetime

from batch_architecture.core.logic import BaseBusinessLogic
from batch_architecture.client.sts_client import STSClient
from batch_architecture.client.glue_client import GlueClient
from batch_architecture.client.logs_client import LogsClient
from batch_architecture.core.settings import Settings


class ExecuteGlueJobLogic(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.execute_glue_job"

    def _init_logic(self, script: str, script_args: dict):
        self.job_name_not_formatted = script_args['job_name']
        self.max_polling_min = int(script_args.get('max_polling_min', self.settings.MAX_GLUE_POLLING_MIN))
        self.polling_interval_sec = int(script_args.get('polling_interval', self.settings.GLUE_POLLING_INTERVAL_SEC))
        self.error_log_group_name = '/aws-glue/jobs/error'
        self.glue_client = None
        self.logs_client = None

    def _output_cloudwatch_logs(self, log_stream_name):
        # CloudWatchLogsのエラーログを出力する
        self.logger.info('CloudWatchLogsの内容を取得してログに書き出します。')
        response = self.logs_client.get_log_events(
            log_group_name=self.error_log_group_name,
            log_stream_name=log_stream_name
        )
        body = response['events']
        self.logger.info('---------- CloudWatchLogs Start ----------')
        for line in body:
            message = '[{}] {}'.format(datetime.fromtimestamp(int(str(line['timestamp'])[:10])),
                                       line['message'])
            self.logger.info(message.replace('\n', ''))
        self.logger.info('---------- CloudWatchLogs End   ----------')

    def _execute(self):
        # assume role
        if Settings.USE_ASSUME_ROLE:
            sts_client = STSClient()
            credentials = sts_client.get_credentials(Settings.ASSUME_ROLE_ARN, 'execute_glue_job')
            self.glue_client = GlueClient(credentials)
            self.logs_client = LogsClient(credentials)
        else:
            self.glue_client = GlueClient()
            self.logs_client = LogsClient()
        # MULTI_AZ_EXECUTEがTrueの時はAZ_Aで実行し、失敗したらAZ_Cでも実行する
        if Settings.MULTI_AZ_EXECUTE:
            lst_az = ['AZ_A', 'AZ_C']
        else:
            lst_az = ['AZ_A']
        self.logger.info(f'MULTI_AZ_EXECUTE: {Settings.MULTI_AZ_EXECUTE}')
        for az in lst_az:
            job_name = self.job_name_not_formatted.format(az=az, env=os.environ["ADT_ENV"].upper())
            # ジョブ再実行回数を取得
            dict_response = self.glue_client.get_job(job_name)
            max_retries = dict_response['Job']['MaxRetries']
            self.logger.info(f'{job_name}を実行します。')
            self.logger.info(f'最大リトライ回数: {max_retries}')
            dict_run_job: dict = self.glue_client.start_job_run(job_name)
            job_run_id = dict_run_job['JobRunId']
            log_stream_name = job_run_id
            # 初回実行+ジョブ再実行回数分、ジョブ実行をポーリングする
            end_status = self.glue_client.polling_job_run(job_name, job_run_id,
                                                          self.max_polling_min, self.polling_interval_sec)
            if Settings.OUTPUT_CLOUDWATCH_LOGS:
                self._output_cloudwatch_logs(log_stream_name)
            if end_status == 'SUCCEEDED':
                return
            for i in range(1, max_retries + 1):
                self.logger.info(f'{i}回目のリトライを実行します。')
                # ジョブ再実行に少し時間がかかるのでスリープを入れる
                time.sleep(30)
                retry_job_run_id = f'{job_run_id}_attempt_{i}'
                log_stream_name = retry_job_run_id
                end_status = self.glue_client.polling_job_run(job_name, retry_job_run_id,
                                                              self.max_polling_min, self.polling_interval_sec)
                if Settings.OUTPUT_CLOUDWATCH_LOGS:
                    self._output_cloudwatch_logs(log_stream_name)
                if end_status == 'SUCCEEDED':
                    return
            self.logger.warning(f'最大リトライ回数（{max_retries}回）を超過しました。')

        raise Exception(f'GLUEジョブの実行が異常終了しました。')
