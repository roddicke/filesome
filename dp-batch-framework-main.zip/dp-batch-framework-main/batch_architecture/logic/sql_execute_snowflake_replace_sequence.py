from batch_architecture.logic.sql_execute_snowflake import SnowflakeSQLExecuteLogic


class SnowflakeSQLExecuteReplaceSequenceLogic(SnowflakeSQLExecuteLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake_replace_sequence"

    def _init_logic(self, script, script_args):
        """
        ReplaceSequence 固有の初期化処理を行う
        """
        self.database = script_args.get('database')
        self.reference_table = script_args.get('reference_table')
        self.sequence_name = script_args.get('sequence_name')
        self.warehouse = script_args.get('warehouse').format(**self.settings.WAREHOUSE_BIND)
        self.switch_user = script_args.get("switch_user")
        self.logger.info("snowflake バインド変数一覧: {}".format(self.settings.SNOWFLAKE_BIND))

    def _get_current_value(self) -> int:
        query = f"SELECT SEQUENCE_VALUE FROM {self.database}.{{SCHEMA_NAME}}.{self.reference_table} " \
                f"WHERE SEQUENCE_MEI = '{self.sequence_name}';"
        query = query.format(**self.settings.SNOWFLAKE_BIND)
        try:
            self.client.execute_sql(query)
            rows = self.client.fetch_all()
        except Exception as e:
            self.logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            raise
        if len(rows) != 1:
            if len(rows) == 0:
                err_msg = f'テーブル"{self.reference_table}"に対象シークエンス"{self.sequence_name}"のレコードが存在しません。'
            else:
                err_msg = f'テーブル"{self.reference_table}"に重複したレコードがあります。'
            self.logger.error(err_msg)
            raise Exception(err_msg)
        return rows[0][0]

    def _execute(self) -> None:
        current_value = self._get_current_value()
        query = f"CREATE OR REPLACE SEQUENCE {self.database}.{{SCHEMA_NAME}}.{self.sequence_name} " \
                f"START WITH {current_value + 1} INCREMENT BY 1;"
        query = query.format(**self.settings.SNOWFLAKE_BIND)
        try:
            self._execute_query(query)
        except Exception as e:
            self.logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            raise
        finally:
            self.client.close()
