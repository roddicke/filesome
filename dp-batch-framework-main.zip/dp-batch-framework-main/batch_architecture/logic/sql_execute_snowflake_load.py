import re

from batch_architecture.core.table_logging import table_logging
from batch_architecture.logic.sql_execute_snowflake import SnowflakeSQLExecuteLogic


class SnowflakeSQLExecuteLoadLogic(SnowflakeSQLExecuteLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_snowflake_load"

    def _init_logic(self, script, script_args):
        super()._init_logic(script, script_args)

        self.rowcount_validation = script_args.get("rowcount_validation", True)

    def _preset_query_parameter(self, query):
        """
        クエリの実行時の'?'をバインドする。
        :param query: ファイルから読み込んだSQL文そのもの。INSERTやDELETEなどのクエリ
        :return:
        """
        self.logger.info("----+" * 10)
        self.logger.info("SQL ? パラメータセット")

        lst_query_output = []
        # SQLを行単位で構文チェックし、みなし日を置換する
        for query_row in query.split("\n"):

            # コメントアウトされていない行で、SETでの宣言で、?が存在する行を対象に、変数識別
            if (
                    query_row.strip()[0:2] != "--"
                    and "SET" in query_row
                    and "?" in query_row
            ):

                # 行をスペース/タブで分割し、宣言文の構文解析
                lst_words = query_row.split()
                param_name = lst_words[1]  # 1:変数名(0:"SET")
                # みなし日置換
                if "ifJshnYmd" in query_row:
                    # シングルクォーテーションで囲む
                    var_batch_date = "'" + str(self.batch_date.batch_date) + "'"

                    self.logger.info(
                        "REPLACE: {n} = {v}".format(n="ifJshnYmd", v=var_batch_date)
                    )
                    lst_query_output.append(
                        query_row.replace("?", str(var_batch_date))
                    )

                elif "shoriTaishoYmd" in query_row:
                    # シングルクォーテーションで囲む
                    var_batch_date = "'" + str(self.batch_date.batch_date) + "'"

                    self.logger.info(
                        "REPLACE: {n} = {v}".format(n="shoriTaishoYmd", v=var_batch_date)
                    )
                    lst_query_output.append(
                        query_row.replace("?", str(var_batch_date))
                    )

                # ifJshnYmd・shoriTaishoYmd以外のパラメーターが指定された場合エラーにする
                else:
                    raise ValueError(
                        "SQL内で宣言された変数{s}は置換できません。'ifJshnYmd'もしくは'shoriTaishoYmd'を宣言してください".format(
                            s=param_name
                        )
                    )
            else:
                lst_query_output.append(query_row)

        return "\n".join(lst_query_output)

    def _execute_query(self, query, **kwargs):
        target_table = stage_name = file_path = format_name = None
        if self.rowcount_validation:
            # ターゲットテーブル取得
            re_space = re.compile(r'\s+')
            re_comment = re.compile(r'/\*.*\*/')
            re_copy_into = re.compile(
                r'.*COPY INTO (.+) FROM .*\(.*SELECT .* FROM (\S+).*\).*'
                r"PATTERN\s*=\s*'(\S+)'.*"
                r"FILE_FORMAT\s*=\s*\(\s*FORMAT_NAME\s*=\s*(\S+)\s*\).*",
                re.IGNORECASE
            )
            s = query.replace("\t", " ")
            s = s.replace("\n", " ")
            s = re_space.sub(' ', s)
            s = re_comment.sub(' ', s)
            s = s.strip()
            m = re_copy_into.search(s)
            if m:
                target_table = m.group(1).split(' ', 1)[0]
                stage_name = m.group(2)
                file_path = m.group(3)
                format_name = m.group(4)
            else:
                s = "COPYクエリをパースできませんでした。\n----\n%s\n----" % query
                raise ValueError(s)

        # クエリ実行
        query_id, affected_count = super()._execute_query(query)

        # query_idを後続のジョブに渡す
        self.job.next_job_args['load_query_id'] = query_id

        # 件数ロギング
        if kwargs.get('process_log_detail_id', None) is not None:
            table_logging.logging_row_count(
                affected_count,
                process_log_detail_id=kwargs['process_log_detail_id'])

        if target_table is not None:
            self.logger.info("インポート件数とステージファイルの行数を突合します")
            stage_count = self._count_stage_file_rows(stage_name, file_path, format_name)
            if affected_count != stage_count:
                msg = "インポート件数とファイル行数が一致していません。\n" \
                      "インポート件数:%s ファイル行数:%s" % (affected_count, stage_count)
                raise ValueError(msg)
            self.logger.info("インポート件数とステージファイルの行数の一致を確認しました")

        return query_id, affected_count

    def _get_affected_rowcount(self, last_query_id=None):
        """
        ロード件数をログに出力するためのメソッド
        0ファイルロードだった場合、エラーログを出力
        """
        last_query_id = last_query_id if last_query_id else self._get_last_query_id()
        get_loaded_result_sql = (
            "SELECT * FROM TABLE(RESULT_SCAN('{last_query_id}'))".format(last_query_id=last_query_id)
        )
        self.client.execute_sql(get_loaded_result_sql, {})
        loaded_results = self.client.fetch_all()
        # ファイルが存在していなかった場合、APIのレスポンスは下記のようになるのでエラーにする
        if loaded_results[0][0] == "Copy executed with 0 files processed.":
            self.logger.info("Copy executed with 0 files processed.")
            msg = "ロード対象ファイルが存在しません。処理を中止します"
            raise FileNotFoundError(msg)

        total_rows = 0

        # 複数ファイルロードの場合もあるのでFor文で回してファイルに応じた処理件数を出力する。
        self.logger.info("ロードファイル数 :" + str(len(loaded_results)))
        for loaded_result in loaded_results:
            self.logger.info("----+" * 10)
            loaded_file_path = loaded_result[0]
            self.logger.info("ロードファイルパス : {}".format(loaded_file_path))
            loaded_rows = loaded_result[3]
            self.logger.info("ロード件数 : {}".format(loaded_rows))

            total_rows += loaded_rows

        return total_rows
