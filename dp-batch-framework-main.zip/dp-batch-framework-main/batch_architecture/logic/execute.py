"""
スクリプトの実行
"""
from batch_architecture.client import Shell
from batch_architecture.core.logic import BaseBusinessLogic


class ExecuteLogic(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.execute"
    EXTENSION2COMMAND = {".py": "python", ".ps1": "powershell", ".jar": "java -jar"}

    def _init_logic(self, script: str, script_args: dict):
        """
        Execute 固有の初期化処理を行う

        :param script: 実行するスクリプトのパス
        :param script_args: 実行するスクリプトのコマンドライン引数 (文字列)
        """
        self.script = None
        self.cmd = None
        script_dir = 'script'
        self.shell_execute = script_args.pop('shell_execute', False)
        self.go_execute = script_args.pop('go_execute', False)
        if self.shell_execute:
            self.cmd = script
        elif self.go_execute:
            args = script.strip().split(' ', 1)
            if len(args) == 1:
                go_exe, params = args[0], None
            else:
                go_exe, params = args[0], args[1]

            path = self.settings.RESOURCE_GO_EXE_DIR / go_exe
            if path.is_file() is False:
                msg = "指定されたパス {} にファイルがありません"
                raise FileNotFoundError(msg.format(path))

            if not params:
                self.cmd = str(path)
            else:
                self.cmd = ' '.join([str(path), params])
        else:
            path = self.settings.RESOURCE_DIR / script_dir / script
            self.script = path
            if self.script.is_file() is False:
                msg = "指定されたパス {} にファイルがありません"
                raise FileNotFoundError(msg.format(self.script))
        self.args = script_args

    def create_command(self):
        cmds = []
        if self.shell_execute or self.go_execute:
            cmds.append(self.cmd)
        else:
            # 実行スクリプトの拡張子を取得
            # 拡張子は大文字と小文字のどちらもあり得るため、小文字に統一する
            extension = self.script.suffix.lower()
            if extension in self.EXTENSION2COMMAND:
                cmds.append(self.EXTENSION2COMMAND[extension])
            cmds.append(str(self.script))

        cmds.extend([
            ('%s' % k) + (' %s' % v if v is not None else '') for k, v in self.args.items()
        ])

        return ' '.join(cmds)

    def _execute(self):
        cmd = self.create_command()
        self.logger.info("実行コマンド: {}".format(cmd))
        shell = Shell()
        _, out, err = shell.execute(cmd)

        self.logger.info(f'出力結果: {out}\n標準エラー: {err}')
        return
