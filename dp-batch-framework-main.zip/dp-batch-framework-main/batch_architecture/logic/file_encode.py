"""
ファイルの文字コード変換を行う
"""
import os

from batch_architecture.core.logic import _InputOutputLogic
from batch_architecture.io_target import LocalTarget


class FileEncodeLogic(_InputOutputLogic):

    _LOGGER_NAME = "batch_architecture.logic.file_encode"

    def _init_logic(self, script, script_args):
        self.input_encoding = script_args['input_encoding']
        self.output_encoding = script_args['output_encoding']
        self.with_bom = script_args.get('with_bom', False)
        self.original_file_delete = script_args.get('original_file_delete', False)

    def _execute(self):
        # 現在はローカルターゲットのみサポート
        if not isinstance(self.input, LocalTarget):
            msg = "入力 {} がローカルのファイルではありません。" "ローカルのファイル以外は展開できません。"
            raise ValueError(msg.format(self.input))

        if not isinstance(self.output, LocalTarget):
            msg = "出力 {} がローカルのファイルではありません。"
            raise ValueError(msg.format(self.output))

        if self.input.exists():
            output_dir = os.path.dirname(str(self.output._path))
            if os.path.exists(output_dir) is False:
                os.makedirs(output_dir, exist_ok=True)

            import batch_architecture.etl.encode as e

            e.convert_character_encoding(
                self.input._path,
                self.input_encoding,
                self.output._path,
                self.output_encoding,
                self.with_bom,
            )
            if self.original_file_delete is True:
                self.logger.info("元ファイルを削除します。{}".format(self.input))
                self.input.delete()

            return
        else:
            msg = "文字コード変換するファイル {0} が存在しません".format(self.input)
            raise FileNotFoundError(msg)
