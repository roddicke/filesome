import sys
import importlib.machinery as imm

from batch_architecture.core.logic import BaseBusinessLogic


class CallPythonScriptLogic(BaseBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.call_python_script"

    def _init_logic(self, script, script_args):
        try:
            script_dir = self.settings.RESOURCE_PYTHON_SCRIPT_DIR
            mod_path = str(script_dir.parent)
            mod_name = self.settings.RESOURCE_PYTHON_SCRIPT_DIR.name
            if mod_path not in sys.path:
                sys.path.insert(0, mod_path)
            self.python_module = imm.SourceFileLoader(
                "{}.{}".format(mod_name, script.split(".")[0]),
                "{}/{}".format(script_dir, script),
            ).load_module()
            print(self.python_module)
        except FileNotFoundError:
            msg = "指定されたpythonファイル({})がありません".format(
                "{}/python_script/{}".format(self.settings.RESOURCE_DIR, script)
            )
            raise FileNotFoundError(msg)
        self.script_args = script_args

    def _execute(self):
        self.logger.info("実行pythonファイル: {}".format(str(self.python_module.__name__)))
        Klass = getattr(self.python_module, "CustomScript")  # クラスの取得
        self.logger.info("実行引数: {}".format(self.script_args))
        script = Klass()
        script.set_job(self.job)
        retval = script.main(**self.script_args)
        return retval
