from batch_architecture.client.sqlserver_client import SQLServerClient
from batch_architecture.core.batch_date import BatchDate
from batch_architecture.core.logic import SQLBusinessLogic
from batch_architecture.core.table_logging import table_logging
from batch_architecture.io_target import Target


class HandledDatabaseError(Exception):
    """
    エラーハンドリング済みのDBエラーに対し発生させる例外
    """

    def __init__(self, e=None):
        self._e = e

    def get_error_code(self):
        return self._e.args[0]


class SQLServerSQLExecuteLogic(SQLBusinessLogic):
    _LOGGER_NAME = "batch_architecture.logic.sql_execute_sqlserver"

    def _init_logic(self, script, script_args):
        """
        SQL 固有の初期化処理を行う
        """
        self.script_bind = script_args.get("bind", {})
        self.env_bind = self.settings.SQLSERVER_BIND
        self.script_bind.update(self.env_bind)
        self.script_bind.update({"CURRENT_DATE_SYORI": self.batch_date.batch_date})
        self.script = Target.parse(
            str(self.settings.RESOURCE_SQL_SQLS_DIR) + "/{}".format(script)
        )
        if not self.script.is_file():
            msg = "実行する SQL スクリプト {} が見つかりません"
            raise FileNotFoundError(msg.format(self.script))

    @property
    def client(self):
        """
        SQLServerへの接続
        """
        if getattr(self, "_client", None) is None:
            self._client = SQLServerClient()
            self._client.connect()

        return self._client

    def _preset_query_parameter(self, query):
        """
        クエリの実行時の'?'をバインドする。
        :param query: ファイルから読み込んだSQL文そのもの。INSERTやDELETEなどのクエリ
        :return:
        """
        self.logger.info("----+" * 10)
        self.logger.info("SQL ? パラメータセット")

        lst_query_output = []
        # SQLを行単位で構文チェックし、みなし日を置換する
        for query_row in query.split("\n"):

            # コメントアウトされていない行で、DECLAREでの宣言で、?が存在する行を対象に、変数識別
            if (
                    query_row.strip()[0:2] != "--"
                    and "DECLARE" == query_row[:7]
                    and "?" in query_row
            ):
                # 行をスペース/タブで分割し、宣言文の構文解析
                lst_words = query_row.split()
                param_name = lst_words[1]  # 1:変数名(0:"DECLARE")
                # 処理基準日
                if "@targetDate" in query_row:
                    # シングルクォーテーションで囲む
                    var_batch_date = "'" + str(self.batch_date.batch_date) + "'"

                    self.logger.info(
                        "REPLACE: {n} = {v}".format(n="@targetDate", v=var_batch_date)
                    )
                    lst_query_output.append(
                        query_row.replace("?", str(var_batch_date))
                    )

                # 処理基準月
                elif "@targetMonth" in query_row:
                    # シングルクォーテーションで囲む
                    var_batch_month = "'" + str(self.batch_date.batch_month) + "'"
                    self.logger.info(
                        "REPLACE: {n} = {v}".format(n="@targetMonth", v=var_batch_month)
                    )
                    lst_query_output.append(
                        query_row.replace("?", str(var_batch_month))
                    )

                # 処理基準日・処理基準月以外のパラメーターが指定された場合エラーにする
                else:
                    raise ValueError(
                        "SQL内で宣言された変数{s}は置換できません。'@targetDate'もしくは'@targetMonth'を宣言してください".format(
                            s=param_name
                        )
                    )
            else:
                lst_query_output.append(query_row)

        return "\n".join(lst_query_output)

    def _get_query(self):
        """
        SQLスクリプトからクエリを取得
        """
        if getattr(self.script, "read", None) is None:
            sql_file = self.script.open(encoding="utf-8")
        else:
            sql_file = self.script

        try:
            query = self._preset_query_parameter(sql_file.read())
            # 前段のprogramでみなし日更新された場合_init_logicでは最新batch_dateを参照できない
            self.script_bind.update({"CURRENT_DATE_SYORI": BatchDate.read_batch_date_file()})
            self.logger.info("SQLServer バインド変数一覧: {}".format(self.script_bind))
            # バインド置換処理
            query = query.format(**self.script_bind)

        except FileNotFoundError as e:
            self.logger.error("SQLファイルが見つかりません。 %s" % e)
            raise
        return query

    def _execute_query(self, query):
        # クエリ実行
        self.client.execute_sql(query)
        # ToDo: 処理件数の取得
        # row_count = self._get_affected_rowcount(query_id)
        # return row_count
        return

    def _execute(self) -> None:
        self.logger.info("----+" * 10)
        self.logger.info("SQL[{s}]を実行します。".format(s=self.script))
        query = self._get_query()

        # ログテーブルに実行予定のクエリを記録する
        table_logging.logging_query(query)

        try:
            self._execute_query(query)
            self.client.commit()

            # 処理件数の取得
            row_count = self.client.get_affected_rows()
            if row_count >= 0:
                table_logging.logging_row_count(row_count=row_count)
                self.logger.info("処理件数 : {}".format(row_count))
        except Exception as e:
            self.logger.error('SQL実行中にエラーが発生しました。 %s' % e)
            self.client.rollback()
            raise
        finally:
            self.client.close()
