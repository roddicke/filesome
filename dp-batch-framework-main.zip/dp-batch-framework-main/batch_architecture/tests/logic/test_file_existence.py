from batch_architecture.testing import TestCase
from batch_architecture.logic import FileExistenceLogic
from batch_architecture.io_target import S3Target
from batch_architecture.io_target import LocalTarget
from batch_architecture.client import FTPClient


class FileExistenceLogicTestCase(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_ftp_server()

        ftp = FTPClient()
        ftp.connect(cls.FTP_HOST)
        assert ftp.pwd() == "/"

        # アップロードするファイルのパス
        testdata = cls.TEST_DATA
        ftp.mkdir("dir", cwd=False)
        ftp.upload(testdata / "upload.csv", "dir/upload.csv")

        cls.cleanup_s3_bucket()
        src = cls.TEST_DATA / "upload.csv"
        src = LocalTarget(src)
        dst = S3Target(cls.S3_BUCKET + "/dir/upload.csv")
        src.copy_to(dst)

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_ftp_server()
        cls.cleanup_s3_bucket()

    def setUp(self):
        self.s3 = "s3://" + self.S3_BUCKET + "/dir"
        self.local = str(self.TEST_DATA)
        self.ftp = "ftp://" + self.FTP_HOST + "/dir"

    def get_logic(self, target):
        logic = FileExistenceLogic(
            definition=dict(program_type="EXISTENCE", target=target)
        )
        return logic

    def test_execute(self):
        """
        チェック対象のファイルが存在する場合、正常実行できるかテストする。
        """
        logic1 = self.get_logic(self.s3 + "/upload.csv")
        logic1.execute()

        logic2 = self.get_logic(self.local + "/upload.csv")
        logic2.execute()

        logic3 = self.get_logic(self.ftp + "/upload.csv")
        logic3.execute()

    def test_execute_no_existence(self):
        """
        チェック対象のファイルが存在しない場合、
        期待通り FileNotFoundError が発生するかテストする。
        """
        logic1 = self.get_logic(self.s3 + "/no_existence.csv")
        with self.assertRaises(FileNotFoundError):
            logic1.execute()

        logic2 = self.get_logic(self.local + "/no_existence.csv")
        with self.assertRaises(FileNotFoundError):
            logic2.execute()

        logic3 = self.get_logic(self.ftp + "/no_existence.csv")
        with self.assertRaises(FileNotFoundError):
            logic3.execute()

    def test_execute_error_dir(self):
        """
        チェック対象がディレクトリの場合、
        期待通り FileExistsError が発生するかテストする。
        """
        logic1 = self.get_logic(self.s3)
        with self.assertRaises(FileExistsError):
            logic1.execute()

        logic2 = self.get_logic(self.local)
        with self.assertRaises(FileExistsError):
            logic2.execute()

        logic3 = self.get_logic(self.ftp)
        with self.assertRaises(FileExistsError):
            logic3.execute()
