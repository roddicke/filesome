from batch_architecture.testing import TestCase
from batch_architecture.logic.call_emr import EMRLogic
from batch_architecture.io_target.s3_target import S3Target
from batch_architecture.io_target.local_target import LocalTarget


class EMRLogicTestCase(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_s3_bucket()
        src1 = cls.TEST_DIR / "resources" / "emr_json"
        src1 = LocalTarget(src1)
        dst1 = S3Target(cls.S3_BUCKET + " /emr_json")
        src1.copy_to(dst1)

        src2 = cls.TEST_DIR / "resources" / "hive_sql"
        src2 = LocalTarget(src2)
        dst2 = S3Target(cls.S3_BUCKET + "/hive_sql")
        src2.copy_to(dst2)

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_s3_bucket()

    def setUp(self):
        self.s3 = "s3://" + self.S3_BUCKET + "/emr_json"
        self.local = self.TEST_DIR / "emr_json"
        self.output = self.S3_BUCKET + "/output/000000_0"
        self.target = "j-IC8JODK0ZRJV"

    def get_logic(self, script):
        logic = EMRLogic(
            definition=dict(
                program_type="EMR", target=self.target, script=script, interval=5.0
            )
        )
        return logic

    def test_init_interval(self):
        """
        EMR ロジックが正しく初期化できることをテストする。
        """
        # 正常系：intervalを指定しなかった場合、デフォルト値(10.0秒)が使用されることを確認
        logic1 = EMRLogic(
            definition=dict(
                program_type="EMR", target=self.target, script=self.local / "test.json"
            )
        )
        self.assertEqual(10.0, logic1.interval)

    def test_execute_from_s3_path(self):
        """
        S3 上の json 定義を利用して、EMR が実行できることをテストする。
        """
        logic = self.get_logic(self.s3 + "/test.json")
        logic.execute()
        o = S3Target(self.output)
        self.assertTrue(o.is_file())
        o.delete()

    def test_execute_from_local_path(self):
        """
        ローカルの json 定義を利用して、EMR が実行できることをテストする。
        """
        logic = self.get_logic(self.local / "test.json")
        logic.execute()
        o = S3Target(self.output)
        self.assertTrue(o.is_file())
        o.delete()

    def test_execute_from_s3_path_error(self):
        """
        S3 上の設定ファイルが不正な場合、期待通り Exception が発生するかテストする。
        """
        logic1 = self.get_logic(self.s3 + "/test_file_not_found_error.json")
        with self.assertRaises(Exception):
            logic1.execute()

        logic2 = self.get_logic(self.s3 + "/test_syntax_error.json.json")
        with self.assertRaises(Exception):
            logic2.execute()

    def test_execute_from_local_path_error(self):
        """
        ローカルの設定ファイルが不正な場合、期待通り Exception が発生するかテストする。
        """
        logic1 = self.get_logic(self.local / "test_file_not_found_error.json.json")
        with self.assertRaises(Exception):
            logic1.execute()

        logic2 = self.get_logic(self.local / "test_syntax_error.json.json")
        with self.assertRaises(Exception):
            logic2.execute()
