import os
import unittest

from batch_architecture.testing import TestCase
from batch_architecture.logic import ExecuteLogic
from batch_architecture import compat


class ExecuteLogicTestCase(TestCase):
    def get_logic(self, script):
        logic = ExecuteLogic(
            definition=dict(program_type="EXECUTE", program_name="dummy", script=script)
        )
        return logic

    def test_init(self):
        """
        指定されたスクリプトの拡張子を取得し、コマンドに変換されていることをテストする
        """
        logic1 = self.get_logic(self.TEST_RESOURCE / "r" / "execute_test2.r")
        cmd1 = logic1.create_command()
        self.assertTrue(cmd1.startswith("Rscript "))

        logic2 = self.get_logic(self.TEST_RESOURCE / "r" / "execute_test.R")
        cmd2 = logic2.create_command()
        self.assertTrue(cmd2.startswith("Rscript "))

    def test_init_error(self):
        """
        存在しないパスを指定した時、FileNotFoundErrorになることをテストする
        """
        with self.assertRaises(FileNotFoundError):
            self.get_logic(self.TEST_RESOURCE / "py" / "no_existence_path.py")

    def test_execute_py(self):
        """
        pythonスクリプトを実行した時、期待される値が返り値に含まれていることをテストする
        """
        logic1 = self.get_logic(self.TEST_RESOURCE / "py" / "execute_test.py")
        out1 = logic1.execute()
        self.assertEqual(b"hello world" + os.linesep.encode("utf-8"), out1[1])

    def test_execute_with_arg(self):
        """
        コマンドライン引数を与えてpythonスクリプトを実行した時、コマンドライン引数が格納されていることをテストする
        """
        logic1 = self.get_logic(
            self.TEST_RESOURCE / "py" / "execute_test_with_arg.py arg1 arg2"
        )
        out1 = logic1.execute()
        self.assertEqual(out1[1], b"arg1 arg2" + os.linesep.encode("utf-8"))

    def test_execute_with_space(self):
        """ファイル名に空白が含まれるスクリプトを実行した時、期待される値が返り値に含まれていることをテストする"""
        logic1 = self.get_logic(
            self.TEST_RESOURCE / "py" / "execute_test with_space.py"
        )
        out1 = logic1.execute()
        self.assertEqual(b"hello world" + os.linesep.encode("utf-8"), out1[1])

    @unittest.skipUnless(compat.IS_WINDOWS, "WINSOWS 環境ではないため、.bat ファイルのテストをスキップします")
    def test_execute_bat(self):
        """
        batスクリプトを実行した時、期待される値が返り値に含まれていることをテストする
        """
        logic2 = self.get_logic(self.TEST_RESOURCE / "bat" / "execute_test.bat")
        out2 = logic2.execute()
        self.assertTrue(bytes(b"hello world") in out2[1])

    @unittest.skipUnless(compat.IS_WINDOWS, "WINSOWS 環境ではないため、.ps1 ファイルのテストをスキップします")
    def test_execute_ps1(self):
        """
        powershellスクリプトを実行した時、期待される値が返り値に含まれていることをテストする
        """
        logic3 = self.get_logic(self.TEST_RESOURCE / "ps1" / "execute_test.ps1")
        out3 = logic3.execute()

        self.assertEqual(b"hello world\n", out3[1])

    @unittest.skipIf(compat.IS_WINDOWS, "WINSOWS 環境であるため、.sh ファイルのテストをスキップします")
    def test_execute_sh(self):
        """
        shellスクリプトを実行した時、期待される値が返り値に含まれていることをテストする
        """
        logic = self.get_logic(self.TEST_RESOURCE / "sh" / "execute_test.sh")
        out = logic.execute()
        self.assertTrue(bytes(b"hello world") in out[1])

    def test_execute_R(self):
        """
        rスクリプトを実行した時、期待される値が返り値に含まれていることをテストする
        """
        logic4 = self.get_logic(self.TEST_RESOURCE / "r" / "execute_test.R")
        out4 = logic4.execute()
        self.assertEqual(bytes(b"hello world"), out4[1])

    def test_execute_error(self):
        """
        登録されていない拡張子(bat,python,r,powershell以外)を実行した時、ValueErrorとなることをテストする
        """
        logic3 = self.get_logic(
            self.TEST_RESOURCE / "py" / "execute_unknown_extension.xxx"
        )
        with self.assertRaises(ValueError):
            logic3.execute()

    def test_execute_error_py(self):
        """
        構文エラーが含まれるpythonスクリプトを実行した時、SystemErrorとなることをテストする
        """
        logic = self.get_logic(self.TEST_RESOURCE / "py" / "execute_syntax_error.py")
        with self.assertRaises(SystemError):
            logic.execute()

    def test_execute_error_r(self):
        """
        構文エラーが含まれるRスクリプトを実行した時、SystemErrorとなることをテストする
        """
        logic = self.get_logic(self.TEST_RESOURCE / "r" / "execute_syntax_error.r")
        with self.assertRaises(SystemError):
            logic.execute()

    @unittest.skipUnless(compat.IS_WINDOWS, "WINSOWS 環境ではないため、.bat ファイルのテストをスキップします")
    def test_execute_error_bat(self):
        """
        構文エラーが含まれるbatスクリプトを実行した時、SystemErrorとなることをテストする
        """
        logic = self.get_logic(self.TEST_RESOURCE / "bat" / "execute_syntax_error.bat")
        with self.assertRaises(SystemError):
            logic.execute()

    @unittest.skipUnless(compat.IS_WINDOWS, "WINSOWS 環境ではないため、.ps1 ファイルのテストをスキップします")
    def test_execute_error_ps1(self):
        """
        構文エラーが含まれるpowershellスクリプトを実行した時、SystemErrorとなることをテストする
        """
        logic = self.get_logic(self.TEST_RESOURCE / "ps1" / "execute_syntax_error.ps1")
        with self.assertRaises(SystemError):
            logic.execute()
