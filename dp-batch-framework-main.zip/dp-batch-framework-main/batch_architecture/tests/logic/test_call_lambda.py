from batch_architecture.testing import TestCase
from batch_architecture.logic.call_lambda import CallLambdaLogic


class CallLambdaLogicTestCase(TestCase):

    LAMBDA_FUNC = "adt_lambda"

    def setUp(self):
        self.script = self.TEST_RESOURCE / "lambda" / "return_ok.zip"
        self.handler = "return_ok.lambda_handler"

    def tearDown(self):
        import boto3

        l = boto3.client("lambda")
        l.delete_function(FunctionName=self.LAMBDA_FUNC)

    def test_execute(self):
        """
        ローカルの Python ファイルを、正しく Lambda 上で実行できるか
        テストする。
        """
        params = {
            "function_name": self.LAMBDA_FUNC,
            "script": self.script,
            "handler": self.handler,
        }

        logic = CallLambdaLogic(params)
        res = logic.execute()

        self.assertEqual(res, b'"OK!!"')

    def test_repeat(self):
        """
        ローカルの Python ファイルを、繰り返し Lambda 上で実行できるか
        テストする。2回目以降はすでにアップロードされた関数定義が利用される。
        """
        params = {
            "function_name": self.LAMBDA_FUNC,
            "script": self.script,
            "handler": self.handler,
        }

        logic = CallLambdaLogic(params)
        res = logic.execute()
        self.assertEqual(res, b'"OK!!"')

        res = logic.execute()
        self.assertEqual(res, b'"OK!!"')
