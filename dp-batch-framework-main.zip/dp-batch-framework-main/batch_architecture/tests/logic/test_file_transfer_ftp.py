"""
FTP関連の転送テスト
"""
import pathlib
import tempfile

from batch_architecture.testing import TestCase
from batch_architecture.client import FTPClient
from batch_architecture.logic.file_transfer import FileTransferLogic


class FTPFileTransferTestCase(TestCase):
    def setUp(self):
        self.ftp = FTPClient()
        self.ftp.connect(self.FTP_HOST)

        # upload するファイルパス
        upload = self.TEST_DATA / "upload.csv"
        # FTPアップロード
        self.ftp.upload(upload, "test.txt")
        self.temp_dir = pathlib.Path(tempfile.mkdtemp())

    def tearDown(self):
        self.ftp.delete("test.txt")

        from batch_architecture.io_target import LocalTarget

        # ローカルの一時ディレクトリを削除
        LocalTarget(self.temp_dir).delete()

    def test_ftp_get(self):
        """
        FTP から ローカルへファイル転送できるかテストする。
        """
        download = self.temp_dir / "downloaded.txt"
        self.assertFalse(download.exists())

        definition = {
            "program_type": "TRANSFER",
            "program_name": "test_ftp_get",
            "comment": None,
            "input": "ftp://{0}/test.txt".format(self.FTP_HOST),
            "output": download,
        }
        logic = FileTransferLogic(definition=definition)
        logic.execute()

        self.assertTrue(download.is_file())
        with download.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        download.unlink()
        self.assertFalse(download.exists())

    def test_ftp_put(self):
        """
        ローカル から FTP へファイル転送できるかテストする。
        """
        upload = self.TEST_DATA / "upload.csv"
        self.assertTrue(upload.is_file())

        output = "ftp://{0}/test_upload.txt".format(self.FTP_HOST)
        definition = {
            "program_type": "TRANSFER",
            "program_name": "test_ftp_put",
            "comment": None,
            "input": upload,
            "output": output,
        }
        logic = FileTransferLogic(definition=definition)
        self.assertFalse(logic.output.is_file())

        logic.execute()
        self.assertTrue(logic.output.is_file())

        logic.output.delete()
        self.assertFalse(logic.output.exists())

    def test_ftp_overwrite(self):
        """
        ローカル から FTP へファイルを上書きできるかテストする。
        """
        # 中身が空のファイルを作成
        upload = self.temp_dir / "upload_test.csv"
        upload.touch()
        self.assertTrue(upload.is_file())
        with upload.open() as f:
            self.assertEqual(f.readline(), "")

        # FTPアップロード
        self.ftp.upload(upload, "test_upload.txt")

        # ローカルからFTPへ上書き
        input = self.TEST_DATA / "upload.csv"
        output = "ftp://{0}/test_upload.txt".format(self.FTP_HOST)
        definition = {
            "program_type": "TRANSFER",
            "program_name": "test_ftp_overwrite",
            "comment": None,
            "input": input,
            "output": output,
            "overwrite": True,
        }
        logic = FileTransferLogic(definition=definition)
        self.assertTrue(logic.output.is_file())

        logic.execute()
        self.assertTrue(logic.output.is_file())

        # 上書き済みファイルを FTP から ローカルへダウンロード
        download = self.temp_dir / "downloaded.txt"
        self.assertFalse(download.is_file())
        definition = {
            "program_type": "TRANSFER",
            "program_name": "test_ftp_overwrite",
            "comment": None,
            "input": output,
            "output": download,
        }
        logic = FileTransferLogic(definition=definition)
        logic.execute()

        # ファイルが上書きされていることを確認
        self.assertTrue(download.is_file())
        with download.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        download.unlink()
        self.assertFalse(download.exists())
        logic.input.delete()
        self.assertFalse(logic.input.exists())
