"""
ファイル圧縮のテスト
"""
import pathlib
import tempfile
import tarfile
import zipfile

from batch_architecture.testing import TestCase
from batch_architecture.io_target import LocalTarget
from batch_architecture.logic.file_archive_extract import (
    FileArchiveLogic,
    FileExtractLogic,
)


class _TestArchiveExtractBase(TestCase):
    def get_archive_logic(self, src, dst):
        return FileArchiveLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                input=str(src),
                output=str(dst),
            )
        )

    def get_extract_logic(self, src, dst):
        return FileExtractLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                input=str(src),
                output=str(dst),
            )
        )


class ZipFileArchiveExtractTestCase(_TestArchiveExtractBase):
    def setUp(self):
        # 一時ディレクトリを作成
        self.test_dir = pathlib.Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "source"
        self.src_dir.mkdir()

        # テスト用のファイルを作成
        self.test01 = self.src_dir / "test01.txt"
        self.test01.write_text("test01")
        self.test02 = self.src_dir / "test02.txt"
        self.test02.write_text("test02")

        subdir = self.src_dir / "sub_dir"
        subdir.mkdir()
        self.test03 = subdir / "test03.txt"
        self.test03.write_text("test03")

    def tearDown(self):
        # ローカルの一時ディレクトリを削除
        LocalTarget(self.test_dir).delete()

    def test_archive_file(self):
        """
        ファイルを zip 圧縮できるかテストする。
        """
        dst = self.test_dir / "archived.zip"
        self.assertFalse(dst.exists())

        logic = self.get_archive_logic(self.test01, dst)
        logic.execute()
        self.assertTrue(dst.exists())

        with zipfile.ZipFile(str(dst), "r") as z:
            namelist = z.namelist()
            self.assertEqual(len(namelist), 1)
            # ドライブレターをスキップ
            self.assertEqual(tuple(namelist[0].split("/")), self.test01.parts[-1:])

    def test_archive_directory(self):
        """
        ディレクトリを zip 圧縮できるかテストする。
        """
        path = self.test_dir / "archive_file.zip"

        # tempdir のパスは固定でないため、サブフォルダを作成
        temp = self.test_dir / "temp"
        temp.mkdir()

        (temp / "temp_1").mkdir()
        (temp / "temp_1" / "file_1.txt").touch()
        (temp / "temp_1" / "file_2.txt").touch()
        (temp / "temp_2").mkdir()
        (temp / "temp_2" / "file_3.txt").touch()

        logic = self.get_archive_logic(temp, path)

        logic.execute()
        self.assertTrue(path.exists())
        with zipfile.ZipFile(str(path), "r") as z:
            namelist = z.namelist()
            self.assertEqual(namelist[0], "temp_1/")
            self.assertEqual(namelist[1], "temp_2/")
            self.assertEqual(namelist[2], "temp_1/file_1.txt")
            self.assertEqual(namelist[3], "temp_1/file_2.txt")
            self.assertEqual(namelist[4], "temp_2/file_3.txt")

    def archive_directory(self, path):
        """
        ディレクトリを zip 圧縮できるかテストする。
        """
        self.assertFalse(path.exists())

        archive = self.get_archive_logic(self.src_dir, path)

        archive.execute()
        self.assertTrue(path.exists())
        with zipfile.ZipFile(str(path), "r") as z:
            namelist = z.namelist()
            self.assertEqual(namelist[0], "test01.txt")
            self.assertEqual(namelist[1], "test02.txt")
            self.assertEqual(namelist[3], "sub_dir/test03.txt")

    def test_extract_directory_target_exists(self):
        """
        zip ファイルを新規ディレクトリに展開できるかテストする。
        """
        path = self.test_dir / "archive_file.zip"
        self.archive_directory(path)

        extracted = self.test_dir / "extracted"
        # 既存のディレクトリに対して解凍
        extracted.mkdir()

        extract = self.get_extract_logic(path, extracted)

        extract.execute()
        self.assertTrue(extracted.exists())

        ext01 = extracted / "test01.txt"
        self.assertTrue(ext01.is_file())
        self.assertEqual(ext01.open().read(), "test01")

        ext02 = extracted / "test02.txt"
        self.assertTrue(ext02.is_file())
        self.assertEqual(ext02.open().read(), "test02")

        ext03 = extracted / "sub_dir" / "test03.txt"
        self.assertTrue(ext03.is_file())
        self.assertEqual(ext03.open().read(), "test03")

    def test_extract_directory_target_notexists(self):
        """
        zip ファイルを新規ディレクトリに展開できるかテストする。
        """
        path = self.test_dir / "archive_file.zip"
        self.archive_directory(path)

        extracted = self.test_dir / "extracted"
        # 存在しないディレクトリに対して解凍

        extract = self.get_extract_logic(path, extracted)

        extract.execute()
        self.assertTrue(extracted.exists())

        ext01 = extracted / "test01.txt"
        self.assertTrue(ext01.is_file())
        self.assertEqual(ext01.open().read(), "test01")

        ext02 = extracted / "test02.txt"
        self.assertTrue(ext02.is_file())
        self.assertEqual(ext02.open().read(), "test02")

        ext03 = extracted / "sub_dir" / "test03.txt"
        self.assertTrue(ext03.is_file())
        self.assertEqual(ext03.open().read(), "test03")


class GzipFileArchiveExtractTestCase(_TestArchiveExtractBase):
    def setUp(self):
        # 一時ディレクトリを作成
        self.test_dir = pathlib.Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "source"
        self.src_dir.mkdir()

        # テスト用のファイルを作成
        self.test01 = self.src_dir / "test01.txt"
        self.test01.write_text("test01")
        self.test02 = self.src_dir / "test02.txt"
        self.test02.write_text("test02")

        subdir = self.src_dir / "sub_dir"
        subdir.mkdir()
        self.test03 = subdir / "test03.txt"
        self.test03.write_text("test03")

    def tearDown(self):
        # ローカルの一時ディレクトリを削除
        LocalTarget(self.test_dir).delete()

    def test_archive_file(self):
        """
        ファイルを gz 圧縮・展開できるかテストする。
        """
        dst = self.test_dir / "archived.gz"
        self.assertFalse(dst.exists())

        archive = self.get_archive_logic(self.test01, dst)

        archive.execute()
        self.assertTrue(dst.exists())

        extracted = self.test_dir / "extracted.txt"
        # 既存のファイルに追加
        extracted.touch()
        extract = self.get_extract_logic(dst, extracted)

        extract.execute()
        self.assertTrue(extracted.is_file())

    def test_archive_file_notexists(self):
        """
        ファイルを gz 圧縮・展開できるかテストする。
        """
        dst = self.test_dir / "archived.gz"
        self.assertFalse(dst.exists())

        archive = self.get_archive_logic(self.test01, dst)

        archive.execute()
        self.assertTrue(dst.exists())

        extracted = self.test_dir / "extracted.txt"
        extract = self.get_extract_logic(dst, extracted)

        extract.execute()
        self.assertTrue(extracted.is_file())
        self.assertEqual(extracted.open().read(), "test01")

    def test_archive_file_tar_gz(self):
        """
        ファイルを tar.gz 圧縮できるかテストする。
        """
        dst = self.test_dir / "archived.tar.gz"
        self.assertFalse(dst.exists())

        archive = self.get_archive_logic(self.test01, dst)

        archive.execute()
        self.assertTrue(dst.exists())
        # ディレクトリを指定して解凍
        extracted = self.test_dir
        extract = self.get_extract_logic(dst, extracted)

        extract.execute()
        # ファイル名は圧縮前と同じ
        exp = extracted / "test01.txt"
        self.assertTrue(exp.is_file())
        self.assertEqual(exp.open().read(), "test01")

    def archive_directory(self, path):
        """
        ディレクトリを tar.gz 圧縮できるかテストする。
        """
        self.assertFalse(path.exists())

        archive = self.get_archive_logic(self.src_dir, path)

        archive.execute()
        self.assertTrue(path.exists())
        with tarfile.open(str(path), "r:gz") as t:
            namelist = t.getnames()
            self.assertEqual(namelist[0], "test01.txt")
            self.assertEqual(namelist[1], "test02.txt")
            self.assertEqual(namelist[2], "sub_dir")
            self.assertEqual(namelist[3], "sub_dir/test03.txt")

    def test_extract_directory_target_exists(self):
        """
        tar.gz ファイルを新規ディレクトリに展開できるかテストする。
        """
        path = self.test_dir / "archive_file.tar.gz"
        self.archive_directory(path)

        extracted = self.test_dir / "extracted"
        # 既存のディレクトリに対して解凍
        extracted.mkdir()

        extract = self.get_extract_logic(path, extracted)

        extract.execute()
        self.assertTrue(extracted.exists())

        ext01 = extracted / "test01.txt"
        self.assertTrue(ext01.is_file())
        self.assertEqual(ext01.open().read(), "test01")

        ext02 = extracted / "test02.txt"
        self.assertTrue(ext02.is_file())
        self.assertEqual(ext02.open().read(), "test02")

        ext03 = extracted / "sub_dir" / "test03.txt"
        self.assertTrue(ext03.is_file())
        self.assertEqual(ext03.open().read(), "test03")

    def test_extract_directory_target_notexists(self):
        """
        tar.gz ファイルを新規ディレクトリに展開できるかテストする。
        """
        path = self.test_dir / "archive_file.tar.gz"
        self.archive_directory(path)

        extracted = self.test_dir / "extracted"
        # 存在しないディレクトリに対して解凍

        extract = self.get_extract_logic(path, extracted)

        extract.execute()
        self.assertTrue(extracted.exists())

        ext01 = extracted / "test01.txt"
        self.assertTrue(ext01.is_file())
        self.assertEqual(ext01.open().read(), "test01")

        ext02 = extracted / "test02.txt"
        self.assertTrue(ext02.is_file())
        self.assertEqual(ext02.open().read(), "test02")

        ext03 = extracted / "sub_dir" / "test03.txt"
        self.assertTrue(ext03.is_file())
        self.assertEqual(ext03.open().read(), "test03")


class ArchiveExtractErrorTestCase(_TestArchiveExtractBase):
    """圧縮解凍のエラーケースをテストする。"""

    def test_archive_not_local_input(self):
        """
        入力がローカルのパスでない時、期待通り ValueError が発生するかテストする。
        """
        src = "ftp://" + self.FTP_HOST + "/target.txt"
        dst = "test_dir/archived.gz"

        archive = self.get_archive_logic(src, dst)

        with self.assertRaises(ValueError):
            archive.execute()

    def test_extract_not_local_input(self):
        """
        入力がローカルのパスでない時、期待通り ValueError が発生するかテストする。
        """
        src = "ftp://" + self.FTP_HOST + "/target.gz"
        dst = "test_dir/extracted.txt"

        extract = self.get_extract_logic(src, dst)

        with self.assertRaises(ValueError):
            extract.execute()

    def test_archive_not_local_output(self):
        """
        出力がローカルのパスでない時、期待通り ValueError が発生するかテストする。
        """
        src = "test_dir/target.txt"
        dst = "s3://" + self.S3_BUCKET + "/archived.gz"

        archive = self.get_archive_logic(src, dst)

        with self.assertRaises(ValueError):
            archive.execute()

    def test_extract_not_local_output(self):
        """
        出力がローカルのパスでない時、期待通り ValueError が発生するかテストする。
        """
        src = "test_dir/target.gz"
        dst = "s3://" + self.S3_BUCKET + "/extracted.txt"

        extract = self.get_extract_logic(src, dst)

        with self.assertRaises(ValueError):
            extract.execute()

    def test_archive_incorrect_suffix(self):
        """
        出力の拡張子がサポートされた圧縮形式のものでない時、
        期待通り ValueError が発生するかテストする。
        """
        src = "test_dir/target.txt"
        dst = "test_dir/archived.xxx"

        archive = self.get_archive_logic(src, dst)

        with self.assertRaises(ValueError):
            archive.execute()

    def test_extract_incorrect_suffix(self):
        """
        入力の拡張子がサポートされた圧縮形式のものでない時、
        期待通り ValueError が発生するかテストする。
        """
        src = "test_dir/target.xxx"
        dst = "test_dir/extracted.txt"

        extract = self.get_extract_logic(src, dst)

        with self.assertRaises(ValueError):
            extract.execute()
