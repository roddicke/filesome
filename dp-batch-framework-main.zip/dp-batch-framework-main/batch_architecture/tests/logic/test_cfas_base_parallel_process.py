import unittest

from logic.cfas_base_parallel_process import CFASBaseParallelProcessLogic


class TestCFASBaseParallelProcessLogic(unittest.TestCase):
    def test_create_s3_path_with_bucket(self):
        res = CFASBaseParallelProcessLogic.create_s3_path_with_bucket("bucket", "prefix", "table", "buten")
        self.assertEqual(res, "s3://bucket/prefix/table/buten/table")
