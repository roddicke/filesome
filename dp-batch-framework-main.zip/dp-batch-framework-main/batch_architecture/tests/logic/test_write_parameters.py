from batch_architecture.testing import TestCase
from batch_architecture.logic.write_parameters import WriteParametersLogic
from batch_architecture.core.settings import Settings
from batch_architecture.core.job import Job
from pathlib import Path
import os


class WriteParametersLogicTestCase(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_s3_bucket()

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_s3_bucket()

    def setUp(self):
        self.job_id = "job001_def"
        self.parameter_id = "job001_parameters"
        self.path = os.path.join("resource", "job_def", self.parameter_id + ".ini")

        # テスト結果確認のためにini内の日付を毎回更新
        config = Settings.parse_config(Path(self.path))
        config.set("config", "minashibi", "20300101")
        config.set("config", "minashibi2", "203001")

        with open(self.path, "w") as file:
            config.write(file)

    def get_logic_def(self, update, fmt):
        logic = WriteParametersLogic(
            definition=dict(program_type="WRITE_PARAMETERS", update=update, fmt=fmt)
        )
        return logic

    def test_init(self):
        """
        日付フォーマットの指定がない場合、デフォルトのフォーマット(dayは"%Y%m%d",monthは"%Y%m")が指定されることをテストする
        """
        update = {
            "minashibi": "day",
            "minashibi2": "month",
            "minashibi3": "day",
            "minashibi4": "month",
        }
        fmt = {"minashibi": "%Y-%m-%d", "minashibi2": "%y%m"}
        logic = self.get_logic_def(update, fmt)
        self.assertEqual(logic.fmt["minashibi"], "%Y-%m-%d")
        self.assertEqual(logic.fmt["minashibi2"], "%y%m")
        self.assertEqual(logic.fmt["minashibi3"], "%Y%m%d")
        self.assertEqual(logic.fmt["minashibi4"], "%Y%m")

    def test_init_error_unit(self):
        """
        day,month以外の更新ルールが指定された場合、ValueErrorになることをテストする
        """
        update = {"minashibhi": "day"}
        fmt = {"minashibi": "%Y%m%d"}
        logic = self.get_logic_def(update, fmt)
        with self.assertRaises(ValueError):
            logic.update_parameter("20300101", "no_register_unit", "%Y%m%d")

    def test_update_parameter_day(self):
        """
        指定された更新ルールがdayの場合、日付けが1日カウントアップされることをテストする
        """
        update = {"minashibhi": "day"}
        fmt = {"minashibi": "%Y%m%d"}
        logic = self.get_logic_def(update, fmt)

        new_date = logic.update_parameter("20300101", "day", "%Y%m%d")

        self.assertEqual(new_date, "20300102")

    def test_update_parameter_month(self):
        """
        指定された更新ルールがmonthの場合、日付けが1月カウントアップされることをテストする
        """
        update = {"minashibhi": "month"}
        fmt = {"minashibi": "%Y%m%d"}
        logic = self.get_logic_def(update, fmt)

        new_date = logic.update_parameter("20300101", "month", "%Y%m%d")
        self.assertEqual(new_date, "20300201")

    def test_update_parameter_with_fmt(self):
        """
        更新項目の日付フォーマットが指定された場合、指定されたフォーマットで日付がカウントアップされていることをテストする
        """
        logic = WriteParametersLogic(
            definition=dict(
                program_type="WRITE_PARAMETERS",
                update=dict(minashibi="day"),
                fmt=dict(minashibi="%y%m%d"),
            )
        )

        new_date = logic.update_parameter("300101", "day", "%y%m%d")
        self.assertEqual(new_date, "300102")

    def test_execute(self):
        """
        Job定義ファイル内の項目が、パラメータファイル内で指定に従い置換された後に、JOBが実行されることをテストする。
        """
        logics = Job.load_json(self.job_id, self.parameter_id)
        logics.execute()

        config = Settings.parse_config(Path(self.path))
        newdate = config["config"]["minashibi"]
        newdate2 = config["config"]["minashibi2"]

        self.assertEqual(newdate, "20300102")
        self.assertEqual(newdate2, "203002")

    def test_execute_with_format(self):
        """
        Job定義ファイル内の項目が、パラメータファイル内で指定に従い置換された後に、日付の更新が指定したフォーマットで実行されていることをテストする。
        """
        job_id = "write_param_date_format_test"
        parameter_id = "write_param_date_format"
        path = os.path.join("resource", "job_def", parameter_id + ".ini")

        logics = Job.load_json(job_id, parameter_id)
        logics.execute()

        config = Settings.parse_config(Path(path))
        newdate = config["config"]["minashibi"]
        newdate2 = config["config"]["minashibi2"]

        self.assertEqual(newdate, "2030-01-02")
        self.assertEqual(newdate2, "30-02")

        config.set("config", "minashibi", "2030-01-01")
        config.set("config", "minashibi2", "30-01")

        with open(path, "w") as file:
            config.write(file)

    def test_exeute_key_error(self):
        """
        ジョブ定義ファイル内で指定された更新項目がパラメータファイル内に存在しなかった場合、ValueErrorになることをテストする
        """
        job_id = self.TEST_RESOURCE / "json" / "writeparameter_no_exist_option.json"
        logics = Job.load_json(str(job_id), self.parameter_id)

        with self.assertRaises(ValueError):
            logics.execute()

    def test_execute_format_error(self):
        """
        パラメータファイル内の日付を変換できない日付フォーマットがジョブ定義ファイル内で指定された時、ValueErrorになることをテストする
        """
        job_id = self.TEST_RESOURCE / "json" / "writeparameter_format_error.json"
        parameter_id = self.TEST_RESOURCE / "ini" / "job_incorrect_date_format"
        logics = Job.load_json(str(job_id), str(parameter_id))

        with self.assertRaises(ValueError):
            logics.execute()

    def test_get_parameter_path(self):
        """
        Job実行時にパラメータファイルが入力されずにWRITE_PARAMETERを実行した場合、ValueErrorになることをテストする
        """
        logics = Job.load_json(self.job_id)
        with self.assertRaises(FileNotFoundError):
            logics.logics[-1].get_parameter_path()
