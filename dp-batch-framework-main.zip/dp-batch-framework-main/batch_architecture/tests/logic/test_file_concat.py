"""
ファイル連結のテスト
"""

import sys
import os
from batch_architecture.testing import TestCase
from batch_architecture.logic import FileConcatPyLogic


class FileConcatTestCase(TestCase):
    # テスト用IOフォルダの用意
    @classmethod
    def setUpClass(cls):
        """
        各種設定を用意
        """

    def setUp(self):
        """
        セットアップ
        """
        self.local = str(self.TEST_DATA)

    def getLogic(self, src, dst, skip_rows, original_file_delete):
        logic = FileConcatPyLogic(definition=dict(
            program_type="CONCAT_PY",
            script = "file_concat.py",
            script_args = {'input' : src,
            'original_file_delete' : original_file_delete,
            'output' : dst,
            'skip_rows' : skip_rows})
        )
        return logic

    # job_id：RQAJDIGCR0480をテスト
    def testExecuteRQAJDIGCR0480(self):
        """
        ファイルが結合されることをテスト
        """
        src = self.local + "/*_access_log.csv"
        dst = self.local + "/access_log.csv"
        skip_rows = 1
        # テスト時に再度利用するためdeleteはFalseに設定
        original_file_delete = False
        logic = self.getLogic(src, dst, skip_rows, original_file_delete)
        logic.execute()

    # job_id：RQAJDIGBD0010をテスト
    def testExecuteRQAJDIGBD0010(self):
        """
        ファイルが結合されることをテスト
        """

        # csvファイルを全て結合するため、差別化のために00をファイル先頭に追記
        src = self.local + "/00*.csv"
        dst = self.local + "/rmaxxx.csv"
        skip_rows = 1
        # テスト時に再度利用するためdeleteはFalseに設定
        original_file_delete = False
        logic = self.getLogic(src, dst, skip_rows, original_file_delete)
        logic.execute()