"""
S3関連の転送テスト
"""
import pathlib
import tempfile

from batch_architecture.testing import TestCase
from batch_architecture.logic.file_transfer import FileTransferLogic
from batch_architecture.io_target import S3Target


class S3FileTransferTestCase(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_s3_bucket()

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_s3_bucket()

    def setUp(self):
        self.temp_dir = pathlib.Path(tempfile.mkdtemp())

    def tearDown(self):
        # ローカルの一時ディレクトリを削除
        from batch_architecture.io_target import LocalTarget

        LocalTarget(self.temp_dir).delete()

    def get_send_logic(self, overwrite=False):
        input = self.TEST_DATA / "upload.csv"
        output = "s3://{0}/test.csv".format(self.S3_BUCKET)
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=input,
                output=output,
                overwrite=overwrite,
            )
        )
        return logic

    def get_get_logic(self, overwrite=False):
        input = "s3://{0}/test.csv".format(self.S3_BUCKET)
        output = self.temp_dir / "download.csv"
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=input,
                output=output,
                overwrite=overwrite,
            )
        )
        return logic

    def get_copy_logic(self, overwrite=False):
        input = "s3://{0}/test.csv".format(self.S3_BUCKET)
        output = "s3://{0}/copied.csv".format(self.S3_BUCKET)
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=input,
                output=output,
                overwrite=overwrite,
            )
        )
        return logic

    def test_s3_put(self):
        """ローカルからS3へファイル転送できるかテストする。"""
        send_logic = self.get_send_logic()
        self.assertFalse(send_logic.output.exists())

        send_logic.execute()
        self.assertTrue(send_logic.output.exists())
        # 書き込まれたファイルを削除
        send_logic.output.delete()
        self.assertFalse(send_logic.output.exists())

    def test_s3_get(self):
        """S3からローカルへファイル転送できるかテストする。"""
        # ファイルをアップロード
        send_logic = self.get_send_logic()
        send_logic.execute()
        self.assertTrue(send_logic.output.exists())

        # ファイルをダウンロード
        get_logic = self.get_get_logic()
        get_logic.execute()

        download = self.temp_dir / "download.csv"
        self.assertTrue(download.exists())
        # データはバイナリ転送される
        with download.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        # 書き込まれたファイルを削除
        send_logic.output.delete()
        self.assertFalse(send_logic.output.exists())

    def test_s3_copy(self):
        """S3同士でファイル転送できるかテストする。"""
        send_logic = self.get_send_logic()
        send_logic.execute()
        self.assertTrue(send_logic.output.exists())

        # ファイルをコピー
        copy_logic = self.get_copy_logic()
        self.assertTrue(copy_logic.input.exists())
        self.assertFalse(copy_logic.output.exists())

        copy_logic.execute()
        self.assertTrue(copy_logic.input.exists())
        self.assertTrue(copy_logic.output.exists())

        # 書き込まれたファイルを削除
        copy_logic.input.delete()
        copy_logic.output.delete()
        self.assertFalse(copy_logic.input.exists())
        self.assertFalse(copy_logic.output.exists())

    def test_s3_hierarchy(self):
        """ローカルからS3へ階層指定してファイル転送できるかテストする。"""
        input = self.TEST_DATA / "upload.csv"
        output = "s3://{0}/dir2/test.csv".format(self.S3_BUCKET)
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=input,
                output=output,
            )
        )
        self.assertFalse(logic.output.exists())

        logic.execute()
        self.assertTrue(logic.output.exists())
        self.assertTrue(logic.output.is_file())
        logic.output.delete()

    def test_s3_file_overwrite(self):
        """
        上書き属性がTrueでoutputファイルが存在する場合にファイルを転送した時、
        outputファイルが上書きされることをテストする。
        """
        send_logic = self.get_send_logic()
        send_logic.execute()
        self.assertTrue(send_logic.output.exists())

        t = S3Target(self.S3_BUCKET + "/test.csv")
        res = t.read()
        self.assertTrue(res, "")

        overwrite_logic = self.get_send_logic(overwrite=True)
        overwrite_logic.execute()
        res = t.read()
        self.assertTrue(res, "1,2,3\n")
        overwrite_logic.output.delete()
        self.assertFalse(overwrite_logic.output.exists())
