"""
リモートファイル同士の転送のテスト (内部ではテンポラリファイルを経由)
"""
from batch_architecture.testing import TestCase
from batch_architecture.client import FTPClient
from batch_architecture.client import SFTPClient
from batch_architecture.logic.file_transfer import FileTransferLogic


class RemoteTransferChainTestCase(TestCase):
    def test_ftp_to_s3(self):
        """
        FTP から S3 へファイル転送できるかテストする。
        """
        ftp = FTPClient()
        ftp.connect(self.FTP_HOST)
        # upload するファイルパス
        upload = self.TEST_DATA / "upload.csv"
        # FTPアップロード
        ftp.upload(upload, "test.txt")

        input = "ftp://{0}/test.txt".format(self.FTP_HOST)
        output = "s3://{0}/test.csv".format(self.S3_BUCKET)
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=input,
                output=output,
            )
        )
        self.assertTrue(logic.input.is_file())
        self.assertFalse(logic.output.exists())

        logic.execute()
        self.assertTrue(logic.input.is_file())
        self.assertTrue(logic.output.is_file())

        logic.input.delete()
        logic.output.delete()
        self.assertFalse(logic.input.exists())
        self.assertFalse(logic.output.exists())

    def test_ftp_to_s3_omit(self):
        """
        入力、出力を補完してFTP から S3 へファイル転送できるかテストする。
        """
        # 中間の入出力を省略
        ftp = FTPClient()
        ftp.connect("10.0.3.168")
        # upload するファイルパス
        upload = self.TEST_DATA / "upload.csv"
        # FTPアップロード
        ftp.upload(upload, "test.txt")

        input = "ftp://{0}/test.txt".format(self.FTP_HOST)
        output = "s3://{0}/test.csv".format(self.S3_BUCKET)
        logic01 = FileTransferLogic(
            definition=dict(program_type="dummy", program_name="dummy", input=input)
        )
        logic02 = FileTransferLogic(
            definition=dict(program_type="dummy", output=output)
        )
        # ロジックの紐付け
        logic02.set_prev(logic01)

        logic01.execute()
        logic02.execute()
        self.assertTrue(logic01.output.is_file())
        self.assertTrue(logic02.output.is_file())

        logic01.output.delete()
        logic02.output.delete()
        self.assertFalse(logic01.output.exists())
        self.assertFalse(logic02.output.exists())

    def test_chain_omit_error_input1(self):
        """
        最初のロジックに入力が存在しないとき、
        期待通り ValueError が発生するかテストする。
        """
        logic01 = FileTransferLogic(
            definition=dict(program_type="dummy", program_name="dummy", output="xxx")
        )
        logic02 = FileTransferLogic(
            definition=dict(program_type="dummy", input="xxx", output="xxx")
        )
        # ロジックの紐付け
        logic02.set_prev(logic01)
        with self.assertRaises(ValueError):
            logic01.input

    def test_chain_omit_error_output1(self):
        """
        最後のロジックに出力が存在しないとき、
        期待通り ValueError が発生するかテストする。
        """
        logic01 = FileTransferLogic(
            definition=dict(
                program_type="dummy", program_name="dummy", input="xxx", output="xxx"
            )
        )
        logic02 = FileTransferLogic(definition=dict(program_type="dummy", input="xxx"))
        # ロジックの紐付け
        logic02.set_prev(logic01)
        with self.assertRaises(ValueError):
            logic02.output

    def test_chain_omit_error_output2(self):
        """
        入力がファイル/ディレクトリどちらか判別できない場合、
        後段のロジックを省略すると期待通り ValueError が発生するかテストする。
        """
        logic01 = FileTransferLogic(
            definition=dict(program_type="dummy", program_name="dummy", input="xxx")
        )
        logic02 = FileTransferLogic(
            definition=dict(program_type="dummy", input="xxx", output="xxx")
        )
        # ロジックの紐付け
        logic02.set_prev(logic01)
        with self.assertRaises(ValueError):
            logic01.output

    def test_ftp_to_s3_overwrite(self):
        """
        FTP から S3 へファイルを上書きできるかテストする。
        """
        # 中身が空のファイルを作成しs3へアップロード
        upload = self.TEST_DATA / "upload_test.csv"
        upload.touch()
        output = "s3://{0}/test_upload.csv".format(self.S3_BUCKET)
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=upload,
                output=output,
            )
        )
        logic.execute()

        ftp = FTPClient()
        ftp.connect(self.FTP_HOST)
        # upload するファイルパス
        input_file = self.TEST_DATA / "upload.csv"
        # FTPアップロード
        ftp.upload(input_file, "test.txt")

        # FTP から s3 へファイルを上書き
        input = "ftp://{0}/test.txt".format(self.FTP_HOST)
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=input,
                output=output,
                overwrite=True,
            )
        )
        logic.execute()
        self.assertTrue(logic.input.is_file())
        self.assertTrue(logic.output.read(), "1,2,3\n")

        upload.unlink()
        logic.input.delete()
        logic.output.delete()
        self.assertFalse(upload.exists())
        self.assertFalse(logic.input.exists())
        self.assertFalse(logic.output.exists())

    def test_sftp_to_s3(self):
        """
        SFTP から S3 へファイル転送できるかテストする。
        """
        sftp = SFTPClient()
        sftp.connect(
            hostname=self.SFTP_HOST, user=self.SFTP_USER, port=22, passwd=self.SFTP_PASS
        )
        # upload するファイルパス
        upload = self.TEST_DATA / "upload.csv"
        # SFTPアップロード
        sftp.cwd(self.TEST_HOME_DIR)
        sftp.upload(str(upload), "test.txt")

        input = "sftp://{0}/{1}/test.txt".format(self.SFTP_HOST, self.TEST_HOME_DIR)
        output = "s3://{0}/test.csv".format(self.S3_BUCKET)
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=input,
                output=output,
            )
        )
        self.assertTrue(logic.input.is_file())
        self.assertFalse(logic.output.exists())

        logic.execute()
        self.assertTrue(logic.input.is_file())
        self.assertTrue(logic.output.is_file())

        logic.input.delete()
        logic.output.delete()
        self.assertFalse(logic.input.exists())
        self.assertFalse(logic.output.exists())

    def test_sftp_to_s3_overwrite(self):
        """
        SFTP から S3 へファイルを上書きできるかテストする。
        """
        # 中身が空のファイルを作成しs3へアップロード
        upload = self.TEST_DATA / "upload_test.csv"
        upload.touch()
        output = "s3://{0}/test_upload.csv".format(self.S3_BUCKET)
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=upload,
                output=output,
            )
        )
        logic.execute()

        sftp = SFTPClient()

        sftp.connect(
            hostname=self.SFTP_HOST, user=self.SFTP_USER, port=22, passwd=self.SFTP_PASS
        )
        # upload するファイルパス
        input_file = self.TEST_DATA / "upload.csv"
        # SFTPアップロード
        sftp.cwd(self.TEST_HOME_DIR)
        sftp.upload(str(input_file), "test.txt")

        # SFTP から s3 へファイルを上書き
        input = "sftp://{0}/{1}/test.txt".format(self.SFTP_HOST, self.TEST_HOME_DIR)
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=input,
                output=output,
                overwrite=True,
            )
        )
        logic.execute()
        self.assertTrue(logic.input.is_file())
        self.assertTrue(logic.output.read(), "1,2,3\n")

        upload.unlink()
        logic.input.delete()
        logic.output.delete()
        self.assertFalse(upload.exists())
        self.assertFalse(logic.input.exists())
        self.assertFalse(logic.output.exists())
