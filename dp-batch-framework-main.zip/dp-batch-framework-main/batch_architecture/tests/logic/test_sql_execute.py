import os
import psycopg2

from batch_architecture.testing import TestCase
from batch_architecture.logic.sql_execute import SQLExecuteLogic


class TestSQLExecuteLogic(TestCase):
    @property
    def default_script(self):
        return str(self.TEST_RESOURCE / "sql" / "script.sql")

    @property
    def default_target(self):
        from batch_architecture.aws.redshift import RedshiftTarget

        return RedshiftTarget(os.path.join("config", "redshift_config.ini"))

    @property
    def default_endpoint(self):
        return self.default_target.endpoint

    def get_logic(self, target=None, script=None):

        if target is None:
            target = self.default_endpoint

        if script is None:
            script = self.default_script

        return SQLExecuteLogic(
            definition=dict(program_type="SQL", target=target, script=str(script))
        )

    def get_endpoint(
        self,
        protocol="redshift",
        user=None,
        passwd=None,
        host=None,
        port=None,
        dbname=None,
    ):

        t = self.default_target

        if user is None:
            user = t._config["master_user_name"]
        if passwd is None:
            passwd = t._config["master_user_password"]
        if host is None:
            host, _ = t._get_host_port()
        if port is None:
            _, port = t._get_host_port()
        if dbname is None:
            dbname = t._config["db_name"]

        fmt = "{protocol}://{user}:{passwd}@{host}:{port}/{dbname}"
        return fmt.format(
            protocol=protocol,
            user=user,
            passwd=passwd,
            host=host,
            port=port,
            dbname=dbname,
        )

    def test_client_init_err(self):
        """
        ロジックの初期化方法が不正な場合、期待通り TypeError が発生するかテストする。
        """
        # job_id なし
        with self.assertRaises(TypeError):
            SQLExecuteLogic(
                definition=dict(
                    program_type="SQL",
                    target=self.default_endpoint,
                    script=self.default_script,
                )
            )

        # definition なし
        with self.assertRaises(TypeError):
            SQLExecuteLogic(job_id="dummy")

        # script なし
        with self.assertRaises(TypeError):
            SQLExecuteLogic(
                job_id="dummy",
                definition=dict(program_type="SQL", target=self.default_endpoint),
            )

    def test_connect(self):
        """
        ロジックから SQL クライアントを取得し、正しく接続先に接続できるかテストする。
        """
        t = self.default_target

        user = t._config["master_user_name"]
        dbname = t._config["db_name"]

        host, port = t._get_host_port()

        fmt = "RedshiftClient({user}@{host}:{port}/{dbname})[データベース接続完了]"
        exp = fmt.format(user=user, host=host, port=port, dbname=dbname)

        self.assertEqual(str(self.get_logic().client), exp)

    def test_connect_error_incorrect_protocol(self):
        """
        プロトコル指定が不正なとき、期待通り ValueError が発生するかテストする。
        """
        # redshift以外のプロトコル
        target = self.get_endpoint(protocol="incorrect_protocol")
        a = self.get_logic(target=target, script=self.default_script)

        with self.assertRaises(ValueError):
            a.client

        with self.assertRaises(ValueError):
            a.execute()

    def test_connect_error_incorrect_dbname(self):
        """
        DB名が不正なとき、期待通り OperationalError が発生するかテストする。
        """
        # 誤ったDB名
        target = self.get_endpoint(dbname="incorrect_dbname")
        a = self.get_logic(target=target, script=self.default_script)

        with self.assertRaises(psycopg2.OperationalError):
            a.client

        with self.assertRaises(psycopg2.OperationalError):
            a.execute()

    def test_connect_error_incorrect_fmt(self):
        """
        接続先指定が不正なとき、期待通り AttributeError が発生するかテストする。
        """
        # 誤ったtargetフォーマット
        a = self.get_logic(
            target="incorrect_target_pattern", script=self.default_script
        )

        # TODO: ValueError となるよう修正
        with self.assertRaises(AttributeError):
            a.client

        with self.assertRaises(AttributeError):
            a.execute()

    def test_sql_file_exists(self):
        """
        SQLファイルが存在しない場合、期待通り FileNotFoundError が発生するかテストする。
        """
        with self.assertRaises(FileNotFoundError):
            self.get_logic(script="incorrect_path.sql")

    def test_get_query(self):
        """
        ロジックが参照するSQLファイルの中身を正しく読み込めるかテストする。
        """
        self.assertEqual(
            str(self.get_logic()._get_query()), "create table test01(id int)"
        )

    def test_execute(self):
        """
        ロジックを実行し、SQLが正しく処理されるかテストする。
        """
        script01 = self.TEST_RESOURCE / "sql" / "insert_script.sql"
        a = self.get_logic(script=str(script01))
        a.execute()
        res = a.client.fetch_one()
        self.assertEqual(res, (3,))

        script02 = self.TEST_RESOURCE / "sql" / "drop_script.sql"
        b = self.get_logic(script=str(script02))
        b.execute()

    def test_execute_syntax_error(self):
        """
        SQLの文法が正しくないとき、期待通り ProgrammingError が発生するかテストする。
        """
        script = self.TEST_RESOURCE / "sql" / "syntax_error_script.sql"
        a = self.get_logic(script=str(script))

        with self.assertRaises(psycopg2.ProgrammingError):
            a.execute()

    def test_execute_table_error(self):
        """
        存在しないテーブルを指定して SELECT したとき、
        期待通り ProgrammingError が発生するかテストする。
        """
        script = self.TEST_RESOURCE / "sql" / "table_error_script.sql"
        a = self.get_logic(script=script)

        with self.assertRaises(psycopg2.ProgrammingError):
            a.execute()
