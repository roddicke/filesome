import unittest
from batch_architecture.testing import TestCase


class TestGenerateDummyData(TestCase):
    def setUp(self):
        pass

    def test_something(self):
        self.assertEqual(True, False)


if __name__ == "__main__":
    unittest.main()
