"""
ローカルの転送テスト
"""
import pathlib
import tempfile
import json

from batch_architecture.testing import TestCase
from batch_architecture.logic.file_transfer import FileTransferLogic


class LocalFileTransferTestCase(TestCase):
    def setUp(self):
        # 一時ディレクトリを作成
        self.test_dir = pathlib.Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "source"
        self.src_dir.mkdir()

        # テスト用のファイルを作成
        self.test01 = self.src_dir / "test01.txt"
        self.test01.touch()
        with open(str(self.test01), "w") as f:
            f.write("test")
        self.test02 = self.src_dir / "test02.txt"
        self.test02.touch()

    def get_logic(self, input, output, overwrite=False):
        return FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=input,
                output=output,
                overwrite=overwrite,
            )
        )

    def tearDown(self):
        # ローカルの一時ディレクトリを削除
        from batch_architecture.io_target import LocalTarget

        LocalTarget(self.test_dir).delete()

    def test_copy_file(self):
        """
        上書き属性がFalseでoutputファイルが存在しない場合にファイルを転送した時、
        inputファイルが転送されることをテストする。
        """
        dst = self.test_dir / "copied.txt"
        self.assertFalse(dst.exists())
        logic = self.get_logic(input=str(self.test01), output=str(dst))
        logic.execute()
        self.assertTrue(dst.exists())

    def test_copy_dir(self):
        """
        ローカルパス同士でディレクトリ転送 (コピー) できるかテストする。
        """
        dst = self.test_dir / "dst"
        self.assertFalse(dst.exists())
        logic = FileTransferLogic(
            definition=dict(
                program_type="dummy",
                program_name="dummy",
                comment="dummy",
                input=str(self.src_dir),
                output=str(dst),
            )
        )
        logic.execute()
        self.assertTrue(dst.exists())
        self.assertTrue((dst / "test01.txt").exists())
        self.assertTrue((dst / "test02.txt").exists())

    def test_overwrite_file(self):
        """
        上書き属性がTrueでoutputファイルと同名のファイルがすでに存在する場合にファイルを転送した時、
        outputファイルが上書きされることをテストする。
        """
        dst = self.test_dir / "copied.txt"
        self.assertFalse(dst.exists())
        dst.touch()
        self.assertTrue(dst.exists())

        with open(str(dst), "r") as f:
            contents = f.read()
        self.assertEqual(contents, "")

        logic = self.get_logic(input=str(self.test01), output=str(dst), overwrite=True)
        logic.execute()

        with open(str(dst), "r") as f:
            contents = f.read()
        self.assertEqual(contents, "test")

    def test_overwrite_non_exists_file(self):
        """
        上書き属性がTrueでoutputファイルが存在しない場合にファイルを転送した時、
        期待通りFileNotFoundErrorが発生することをテストする。
        """
        dst = self.test_dir / "copied.txt"
        self.assertFalse(dst.exists())
        logic = self.get_logic(input=str(self.test01), output=str(dst), overwrite=True)
        with self.assertRaises(FileNotFoundError):
            logic.execute()

    def test_overwrite_file_false(self):
        """
        上書き属性がFalseでoutputファイルと同名のファイルがすでに存在する場合にファイルを転送した時、
        期待通りFileExistsErrorが発生することをテストする。
        """
        dst = self.test_dir / "copied.txt"
        self.assertFalse(dst.exists())
        dst.touch()
        self.assertTrue(dst.exists())
        logic = self.get_logic(input=str(self.test01), output=str(dst), overwrite=False)
        with self.assertRaises(FileExistsError):
            logic.execute()

    def test_copy_dir_noexist(self):
        """
        上書き属性がFalseでoutputディレクトリが存在しない場合にディレクトリを転送した時、
        inputディレクトリが転送されることをテストする。
        """
        dst = self.test_dir / "dst"
        self.assertFalse(dst.exists())
        logic = self.get_logic(input=str(self.src_dir), output=str(dst))
        logic.execute()
        self.assertTrue(dst.exists())
        self.assertTrue((dst / "test01.txt").exists())
        self.assertTrue((dst / "test02.txt").exists())

    def test_overwrite_dir_exists(self):
        """
        上書き属性がTrueでoutputファイルと同名のファイルがすでに存在する場合にディレクトリを転送した時、
        outputディレクトリが上書きされることをテストする。
        """
        dst = self.test_dir / "dst"
        dst.mkdir()
        self.assertTrue(dst.exists())
        dst_file01 = dst / "test01.txt"
        dst_file02 = dst / "test02.txt"
        dst_file01.touch()
        dst_file02.touch()
        self.assertTrue(dst_file01.exists())
        self.assertTrue(dst_file02.exists())

        with open(str(dst_file01), "r") as f:
            contents = f.read()
        self.assertEqual(contents, "")

        logic = self.get_logic(input=str(self.src_dir), output=str(dst), overwrite=True)
        logic.execute()
        self.assertTrue(dst.exists())
        self.assertTrue((dst / "test01.txt").exists())
        self.assertTrue((dst / "test02.txt").exists())

        with open(str(dst_file01), "r") as f:
            contents = f.read()
        self.assertEqual(contents, "test")

    def test_overwrite_dir_non_match(self):
        """
        上書き属性がTrueでinputディレクトリとoutputディレクトリの中身が一致しない場合にディレクトリを転送した時、
        期待通りFileNotFoundErrorが発生することをテストする。
        """
        dst = self.test_dir / "dst"
        dst.mkdir()
        self.assertTrue(dst.exists())
        dst_file01 = dst / "test01.txt"
        dst_file02 = dst / "test02.txt"
        dst_file01.touch()
        self.assertTrue(dst_file01.exists())
        self.assertFalse(dst_file02.exists())

        logic = self.get_logic(input=str(self.src_dir), output=str(dst), overwrite=True)
        with self.assertRaises(FileNotFoundError):
            logic.execute()

    def test_overwrite_non_exists_dir(self):
        """
        上書き属性がTrueでoutputディレクトリが存在しない場合にディレクトリを転送した時、
        期待通りFileNotFoundErrorが発生することをテストする。
        """
        dst = self.test_dir / "dst"
        self.assertFalse(dst.exists())
        logic = self.get_logic(input=str(self.src_dir), output=str(dst), overwrite=True)
        with self.assertRaises(FileNotFoundError):
            logic.execute()

    def test_overwrite_dir_false(self):
        """
        上書き属性がFalseでoutputディレクトリと同名のディレクトリがすでに存在する場合にディレクトリを転送した時、
        期待通りFileExistsErrorが発生することをテストする。
        """
        dst = self.test_dir / "dst"
        self.assertFalse(dst.exists())
        dst.touch()
        self.assertTrue(dst.exists())
        logic = self.get_logic(
            input=str(self.src_dir), output=str(dst), overwrite=False
        )
        with self.assertRaises(FileExistsError):
            logic.execute()

    def test_load_json(self):
        """
        JSONをパースして上書き属性を指定した時、ファイルの上書きが正しく行われていることをテストする。
        """
        definitions = json.loads(
            '{"program_type": "TRANSFER",'
            ' "program_name": "dummy",'
            ' "comment": "dummy",'
            ' "input": "batch_architecture/tests/testdata/upload.csv",'
            ' "output": "batch_architecture/tests/testdata/upload_test.csv",'
            ' "overwrite": true}'
        )
        assert isinstance(definitions, dict)
        output = pathlib.Path(definitions["output"])
        output.touch()
        self.assertTrue(output.is_file())

        logic = self.get_logic(
            input=definitions["input"],
            output=definitions["output"],
            overwrite=definitions["overwrite"],
        )
        logic.execute()
        self.assertTrue(logic.output.read(), "1,2,3\n")
        logic.output.delete()
        self.assertFalse(output.exists())

    """
    def test_load_json_error(self):
        with self.assertRaises(json.decoder.JSONDecodeError):
            definitions = json.loads('{"program_type": "TRANSFER",'
                                     ' "program_name": "dummy",'
                                     ' "comment": "dummy",'
                                     ' "input": "batch_architecture/tests/testdata/upload.csv",'
                                     ' "output": "batch_architecture/tests/testdata/upload_test.csv",'
                                     ' "overwrite": True}')
    """
