"""
ファイル変換処理テスト
"""
import pathlib
from batch_architecture.testing import TestCase
from batch_architecture.logic.file_transform import FileTransformLogic


class TestFileTransformLogic(TestCase):

    input = TestCase.TEST_DATA / "transform_test_input_data.csv"
    output = TestCase.TEST_DATA / "transform_test_output_data.csv"

    def get_logic(
        self, header_line, footer_line, replace, split, input_format, output_format
    ):
        logic = FileTransformLogic(
            definition=dict(
                program_type="TRANSFORM",
                input=str(self.input),
                output=str(self.output),
                remove_header=header_line,
                remove_footer=footer_line,
                replace=replace,
                split=split,
                input_format=input_format,
                output_format=output_format,
            )
        )
        return logic

    def readlines(self, input):
        """
        指定したinputファイルのリストを返す
        """
        lines = []
        with open(input, "r") as input:
            for i in input:
                lines.append(i)
        return lines

    def test_init_logic(self):
        """
        input_format, output_format に不正なキーワードが含まれていた時、期待通り ValueError が発生することをテストする。
        """
        with self.assertRaises(ValueError):
            logic = self.get_logic(
                header_line=2,
                footer_line=2,
                replace={"\n": "\r"},
                split=3,
                input_format={"incorrect_key": "\n"},
                output_format={"lineterminator": "\n"},
            )
        with self.assertRaises(ValueError):
            logic = self.get_logic(
                header_line=2,
                footer_line=2,
                replace={"\n": "\r"},
                split=3,
                input_format={"lineterminator": "\n"},
                output_format={"incorrect_key": "\n"},
            )

    def test_get_numbered_filename(self):
        """
        ファイル拡張子の前に"_"と"3桁番号"を結合させたファイル名を正しく返すかどうかテストする。
        """
        logic = self.get_logic(
            header_line=2,
            footer_line=2,
            replace={"\n": "\r"},
            split=3,
            input_format={"lineterminator": "\n"},
            output_format={"lineterminator": "\n"},
        )
        self.assertEqual(
            str(logic._get_numbered_filename(self.input, 1)),
            str(TestCase.TEST_DATA / "transform_test_input_data_01.csv"),
        )
        self.assertEqual(
            str(logic._get_numbered_filename(self.input, 10)),
            str(TestCase.TEST_DATA / "transform_test_input_data_10.csv"),
        )
        with self.assertRaises(ValueError):
            logic._get_numbered_filename(self.input, 100)

    def test_execute(self):
        """
        ファイル変換処理(ヘッダー・フッター削除、文字列置換、ファイル分割)をした時、以下3点をテストする。
        ・指定した行数分ヘッダー・フッターが削除されている
        ・指定した文字列が置換されている
        ・指定した行数のoutputファイルが作成されている
        """
        logic = self.get_logic(
            header_line=2,
            footer_line=2,
            replace={"\n": "aa\n"},
            split=3,
            input_format={"lineterminator": "\n"},
            output_format={"lineterminator": "\n"},
        )
        logic.execute()

        begin_value = self.readlines(input=str(self.input))[2].replace("\n", "aa\n")
        end_value = self.readlines(input=str(self.input))[-3].replace("\n", "aa\n")
        begin_file = logic._get_numbered_filename(file=self.output, n=0)
        end_file = logic._get_numbered_filename(file=self.output, n=2)
        self.assertEqual(self.readlines(input=str(begin_file))[0], begin_value)
        self.assertEqual(self.readlines(input=str(end_file))[-1], end_value)

        stem = logic.output.stem
        output_splitted = list(
            pathlib.Path(logic.output._path.parent).glob(stem + "_*")
        )
        self.assertEqual(len(self.readlines(input=str(output_splitted[0]))), 3)

        for i in output_splitted:
            i.unlink()

    def test_execute_no_split(self):
        """
        ファイル行数以上でファイル分割を行った時、出力ファイルは分割されず、ファイル名も番号付されないことをテストする。
        """
        logic = self.get_logic(
            header_line=2,
            footer_line=2,
            replace={"\n": "aa\n"},
            split=10,
            input_format={"lineterminator": "\n"},
            output_format={"lineterminator": "\n"},
        )
        logic.execute()
        self.assertEqual(len(self.readlines(str(self.output))), 8)

        stem = logic.output.stem
        output_splitted = list(
            pathlib.Path(logic.output._path.parent).glob(stem + "_*")
        )
        self.assertEqual(len(output_splitted), 0)
        self.output.unlink()

    def test_execute_input_exists_error(self):
        """
        inputファイル名に番号付けしたものと同名のファイルが既に存在する場合にファイルのフォーマット変換をした時、
        期待通り FileExistsError が発生することをテストする。
        """
        input = TestCase.TEST_DATA / "transform_test_input_data_00.csv"
        input.touch()
        self.assertTrue(input.exists())

        logic = self.get_logic(
            header_line=2,
            footer_line=2,
            replace={"\n": "\r"},
            split=3,
            input_format={"lineterminator": "\n"},
            output_format={"lineterminator": "\n"},
        )
        with self.assertRaises(FileExistsError):
            logic.execute()

        input.unlink()
        self.assertFalse(input.exists())
