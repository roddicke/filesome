"""
SFTP関連の転送テスト
"""
import pathlib
import tempfile

from batch_architecture.testing import TestCase
from batch_architecture.client import SFTPClient
from batch_architecture.logic.file_transfer import FileTransferLogic


class SFTPFileTransferTestCase(TestCase):
    def setUp(self):
        self.sftp = SFTPClient()
        self.sftp.connect(
            hostname=self.SFTP_HOST, user=self.SFTP_USER, port=22, passwd=self.SFTP_PASS
        )

        # upload するファイルパス
        upload = self.TEST_DATA / "upload.csv"
        # SFTPアップロード
        self.sftp.cwd(self.TEST_HOME_DIR)
        self.sftp.upload(str(upload), "test.txt")
        self.temp_dir = pathlib.Path(tempfile.mkdtemp())

    def tearDown(self):
        self.sftp.cwd(self.TEST_HOME_DIR)
        self.sftp.delete("test.txt")

        from batch_architecture.io_target import LocalTarget

        # ローカルの一時ディレクトリを削除
        LocalTarget(self.temp_dir).delete()

    def test_sftp_get(self):
        """
        SFTP から ローカルへファイル転送できるかテストする。
        """
        download = self.temp_dir / "downloaded.txt"
        self.assertFalse(download.exists())

        definition = {
            "program_type": "TRANSFER",
            "program_name": "test_sftp_get",
            "comment": None,
            "input": "sftp://{0}/{1}/test.txt".format(
                self.SFTP_HOST, self.TEST_HOME_DIR
            ),
            "output": download,
        }
        logic = FileTransferLogic(definition=definition)
        logic.execute()

        self.assertTrue(download.is_file())
        with download.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        download.unlink()
        self.assertFalse(download.exists())

    def test_sftp_put(self):
        """
        ローカル から SFTP へファイル転送できるかテストする。
        """
        upload = self.TEST_DATA / "upload.csv"
        self.assertTrue(upload.is_file())

        output = "sftp://{0}/{1}/test_upload.txt".format(
            self.SFTP_HOST, self.TEST_HOME_DIR
        )
        definition = {
            "program_type": "TRANSFER",
            "program_name": "test_ftp_put",
            "comment": None,
            "input": upload,
            "output": output,
        }
        logic = FileTransferLogic(definition=definition)
        self.assertFalse(logic.output.is_file())

        logic.execute()
        self.assertTrue(logic.output.is_file())

        logic.output.delete()
        self.assertFalse(logic.output.exists())

    def test_sftp_overwrite(self):
        """
        ローカル から SFTP へファイルを上書きできるかテストする。
        """
        # 中身が空のファイルを作成
        upload = self.temp_dir / "upload_test.csv"
        upload.touch()
        self.assertTrue(upload.is_file())
        with upload.open() as f:
            self.assertEqual(f.readline(), "")

        # SFTPアップロード
        self.sftp.cwd(self.TEST_HOME_DIR)
        self.sftp.upload(upload, "test_upload.txt")

        # ローカルからSFTPへ上書き
        input = self.TEST_DATA / "upload.csv"
        output = "sftp://{0}/{1}/test_upload.txt".format(
            self.SFTP_HOST, self.TEST_HOME_DIR
        )
        definition = {
            "program_type": "TRANSFER",
            "program_name": "test_sftp_overwrite",
            "comment": None,
            "input": input,
            "output": output,
            "overwrite": True,
        }
        logic = FileTransferLogic(definition=definition)
        self.assertTrue(logic.output.is_file())

        logic.execute()
        self.assertTrue(logic.output.is_file())

        # 上書き済みファイルを SFTP から ローカルへダウンロード
        download = self.temp_dir / "downloaded.txt"
        self.assertFalse(download.is_file())
        definition = {
            "program_type": "TRANSFER",
            "program_name": "test_sftp_overwrite",
            "comment": None,
            "input": output,
            "output": download,
        }
        logic = FileTransferLogic(definition=definition)
        logic.execute()

        # ファイルが上書きされていることを確認
        self.assertTrue(download.is_file())
        with download.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        download.unlink()
        self.assertFalse(download.exists())
        logic.input.delete()
        self.assertFalse(logic.input.exists())
