import boto3
import subprocess
import os

from nose.plugins.attrib import attr
from batch_architecture.aws.emr import EMRTarget
from batch_architecture.testing import TestCase


class EMRTestCase(TestCase):
    """
    EMR テスト

    * 起動テスト実行 `nosetests -a start`

      クラスタ停止中に実行。テスト終了後、クラスタは起動状態になる。

    * 通常テスト実行 `nosetests -a normal`

      クラスタ起動中に実行。テスト終了後、クラスタは起動状態のまま。
      通常の実行テストはここに書く。

    * 終了テスト実行 `nosetests -a terminate`

      クラスタ起動中に実行。テスト終了後、クラスタは停止状態になる。
    """

    path = os.path.join("config", "emr_config.ini")

    def setUp(self):
        self.config = dict(
            name="pre-datalake-data-processing-cluster-test",
            release_label="emr-5.3.0",
            applications="Hadoop,Hive,Spark,Hue,Tez",
            master_instance_type="m1.large",
            master_ebs_size="100",
            master_market="ON_DEMAND",
            master_instance_count="1",
            core_instance_type="m1.large",
            core_ebs_size="100",
            core_market="ON_DEMAND",
            core_instance_count="3",
            log_uri="s3://pre-nomura-dmp-datalake-oplogs/emr/data-processing/",
            name_tag="pre-emr",
            subnet_id="subnet-3e3b4e48",
            key_name="PreKey",
            service_access_sg="sg-75d83512",
            master_sg="sg-77d83510",
            core_sg="sg-76d83511",
            polling_sleep_time="120",
            retry_count="3",
            boot_step_job_flows_file="config/emr_start_job_flows.json",
        )

    @attr("start")
    def test_start(self):
        """EMR 設定ファイルを読み込み、EMR クラスタが起動できるかテストする。"""
        t = EMRTarget(self.path)
        self.assertFalse(t.is_started())
        self.assertEqual(repr(t), "EMR[未起動]")

        # commadのテスト
        cmd = "adt aws emr start"
        self.assertEqual(subprocess.call(cmd, shell=True), 0)

        self.assertTrue(t.is_started())
        self.assertEqual(repr(t), "EMR[id:{0}]".format(t._cluster_id))

        # 同じ名前のクラスターが既に起動していた場合、そのクラスターのIDを取得できることを確認
        t2 = EMRTarget(self.path)
        self.assertEqual(t._cluster_id, t2.cluster_id)
        self.assertTrue(t2.is_started())

        # 起動済みのClusterを起動する
        with self.assertRaises(ValueError):
            t2.start()

    @attr("terminate")
    def test_terminate(self):
        """EMR クラスタが終了できるかテストする。"""
        t = EMRTarget(self.path)
        self.assertTrue(t.is_started())

        # commandのテスト
        cmd = "adt aws emr stop"
        self.assertEqual(subprocess.call(cmd, shell=True), 0)
        self.assertFalse(t.is_started())

    @attr("normal")
    def test_get_node_options(self):
        """EMR 設定に基づき、正しく EMR 作成要求が生成できるかテストする。"""
        t = EMRTarget(self.config)

        self.assertEqual(
            t._get_node_options("master"),
            dict(
                Name="master-1",
                Market="ON_DEMAND",
                InstanceRole="MASTER",
                InstanceType="m1.large",
                InstanceCount=1,
                EbsConfiguration=dict(
                    EbsBlockDeviceConfigs=[
                        dict(VolumeSpecification=dict(VolumeType="gp2", SizeInGB=100))
                    ]
                ),
            ),
        )

        self.assertEqual(
            t._get_node_options("core"),
            dict(
                Name="core-1",
                Market="ON_DEMAND",
                InstanceRole="CORE",
                InstanceType="m1.large",
                InstanceCount=3,
                EbsConfiguration=dict(
                    EbsBlockDeviceConfigs=[
                        dict(VolumeSpecification=dict(VolumeType="gp2", SizeInGB=100))
                    ]
                ),
            ),
        )

    @attr("normal")
    def test_get_node_options_error(self):
        """
        master,core以外のノードタイプを指定した場合、想定通りValueErrorになることをテストする。
        """
        t = EMRTarget(self.config)
        with self.assertRaises(ValueError):
            t._get_node_options("wrong_node_type")

    @attr("normal")
    def test_load_config(self):
        """EMR 設定ファイルが正しく読み込めるかテストする。"""
        t = EMRTarget(self.path)
        self.assertEqual(t._config["name"], "pre-datalake-data-processing-cluster-test")

    @attr("normal")
    def test_get_master_node_instance_id(self):
        """
        EMRのマスターノードIDを正しく取得できるかテストする。
        """
        t = EMRTarget(self.path)
        instance_id = t.get_master_node_instance_id()

        ec2 = boto3.resource("ec2")
        instances = ec2.instances.filter(
            Filters=[{"Name": "instance-state-name", "Values": ["running"]}]
        )
        ids = [instance.id for instance in instances]
        self.assertTrue(instance_id in ids)
