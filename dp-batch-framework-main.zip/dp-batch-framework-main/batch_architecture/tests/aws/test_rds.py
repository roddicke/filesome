from nose.plugins.attrib import attr

from batch_architecture.aws.rds import RDSTarget
from batch_architecture.testing import TestCase


class RDSTestBase(TestCase):
    """
    RDS テスト

    * 起動テスト実行 `nosetests -a start`

      RDS 停止中に実行。テスト終了後、RDS は起動状態になる。

    * 通常テスト実行 `nosetests -a normal`

      RDS 起動中に実行。テスト終了後、RDS は起動状態のまま。
      通常の実行テストはここに書く。

    * 終了テスト実行 `nosetests -a terminate`

      RDS 起動中に実行。テスト終了後、RDS は停止状態になる。
    """

    DBInstanceIdentifier = None
    Engine = None

    DBName = "db1"
    Port = 5500
    MasterUsername = "sa"
    MasterUserPassword = "abcdEFGH1234"

    DBInstanceClass = "db.m4.large"
    StorageEncrypted = True

    def get_rds(self):
        if self.Engine is None:
            import nose

            raise nose.SkipTest("Baseクラスのためスキップ")

        return RDSTarget(
            DBInstanceIdentifier=self.DBInstanceIdentifier,
            Engine=self.Engine,
            DBName=self.DBName,
            Port=self.Port,
            MasterUsername=self.MasterUsername,
            MasterUserPassword=self.MasterUserPassword,
            DBInstanceClass=self.DBInstanceClass,
            StorageEncrypted=self.StorageEncrypted,
        )

    @attr("start")
    def test_start(self):
        """RDS が起動できるかテストする。"""
        rds = self.get_rds()

        self.assertFalse(rds.is_started())
        self.assertEqual(str(rds), "RDS[未起動]")

        # 起動処理開始
        rds.start()
        self.assertFalse(rds.is_started())

        # 起動待ち
        rds.wait_available()
        self.assertTrue(rds.is_started())
        self.assertEqual(str(rds), "RDS[id:{}]".format(self.DBInstanceIdentifier))

    @attr("terminate")
    def test_terminate(self):
        """RDS が終了できるかテストする。"""
        rds = self.get_rds()
        self.assertTrue(rds.is_started())
        self.assertEqual(str(rds), "RDS[id:{}]".format(self.DBInstanceIdentifier))

        # 停止処理開始
        rds.terminate()
        # 停止待ち
        rds.wait_terminated()
        self.assertFalse(rds.is_started())


class RDSMSSQLTestCase(RDSTestBase):

    DBInstanceIdentifier = "sqlservertest"
    Engine = "sqlserver-ex"
    DBName = ""

    # MS SQL Express doesn't support encryption
    DBInstanceClass = "db.t2.micro"
    StorageEncrypted = False

    @attr("normal")
    def test_invalid_dbname_rds(self):
        # MS SQL doesn't support DBName
        with self.assertRaises(ValueError):
            RDSTarget(
                DBInstanceIdentifier=self.DBInstanceIdentifier,
                Engine=self.Engine,
                DBName="xxx",
                Port=self.Port,
                MasterUsername=self.MasterUsername,
                MasterUserPassword=self.MasterUserPassword,
                DBInstanceClass=self.DBInstanceClass,
                StorageEncrypted=self.StorageEncrypted,
            )


class RDSMySQLTestCase(RDSTestBase):

    DBInstanceIdentifier = "mysqltest"
    Engine = "mysql"


class RDSPostgreSQLTestCase(RDSTestBase):

    DBInstanceIdentifier = "postgrestest"
    Engine = "postgres"
