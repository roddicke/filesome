from batch_architecture.aws.elb import ELBTarget
from batch_architecture.testing import TestCase


class ELBTestCase(TestCase):
    """
    ELBのテスト
    """

    ELB_NAME = "pre-datalake-elb-test"
    INSTANCE_ID = "i-0b0b7f0cffebc9bc9"

    def test_init(self):
        """ELB インスタンスが正しく初期化できるかをテストする。"""
        elb = ELBTarget(self.ELB_NAME)
        self.assertTrue(elb.exists())

    def test_repr(self):
        """
        ELB インスタンスが正しく表示されるかテストする。存在する ELB / 存在しない ELB
        両方をテストする。
        """

        t = ELBTarget(self.ELB_NAME)
        self.assertEqual(repr(t), "ELB({})[起動済]".format(self.ELB_NAME))

        t = ELBTarget("xxx")
        self.assertEqual(repr(t), "ELB(xxx)[存在しない]".format(self.ELB_NAME))

    def test_children(self):
        """
        ELB に登録されている EC2 インスタンスの一覧が取得できるかテストする。
        存在しない ELB に対しては期待通りに ValueError が発生することをテストする。
        """

        t = ELBTarget(self.ELB_NAME)
        self.assertEqual(t.children, [])

        t = ELBTarget("xxx")
        with self.assertRaises(ValueError):
            t.children

    def test_register_remove(self):
        """
        ELB への EC2 インスタンス登録、削除が正しく行えるかテストする。
        """

        t = ELBTarget(self.ELB_NAME)
        t.register(self.INSTANCE_ID)

        self.assertEqual(t.children, [self.INSTANCE_ID])

        # t.wait_available(self.INSTANCE_ID)
        t.delete(self.INSTANCE_ID)

    def test_register_remove_notexists(self):
        """
        ELB へ、存在しない EC2 インスタンスを登録した場合、登録されていない
        EC2 インスタンスを削除した場合に、期待通りに Exeption が発生するかテストする。
        """

        t = ELBTarget(self.ELB_NAME)

        # botocore.errorfactory.InvalidEndPointException
        # がファクトリにて生成されて発生
        with self.assertRaises(Exception):
            t.register("id-not-exists")

        with self.assertRaises(Exception):
            t.delete("id-not-exists")
