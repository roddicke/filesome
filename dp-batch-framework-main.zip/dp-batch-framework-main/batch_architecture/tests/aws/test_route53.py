import unittest

from nose.plugins.attrib import attr
from batch_architecture.testing import TestCase
from batch_architecture.aws.route53 import Route53Target, HostedZoneSettings
from datetime import datetime
import boto3


class Route53TestCase(TestCase):
    """
    Route53テストクラス
    """

    _TEST_HOSTEDZONE_ID = "ZB62GXZCR2LWM"
    _TEST_NAME = "unit-test.datalake.local"
    _TEST_TYPE = "CNAME"
    _TEST_VALUE = "batch_architecture.unit-test-{}.com"

    def setUp(self):
        self._route53_cli = boto3.client("route53")
        pass

    def tearDown(self):
        pass

    def test_edit_record_set(self):
        """
        DNSレコード更新テスト

        :return:
        """
        v = datetime.now().strftime("%Y%m%d-%H%M%S")
        settings = HostedZoneSettings(
            hosted_zone_id=self._TEST_HOSTEDZONE_ID,
            name=self._TEST_NAME,
            record_type=self._TEST_TYPE,
        )
        route53 = Route53Target(settings)
        route53.edit_record_set(self._TEST_VALUE.format(v))

        res = self._route53_cli.list_resource_record_sets(
            HostedZoneId=self._TEST_HOSTEDZONE_ID,
            StartRecordName=self._TEST_NAME,
            StartRecordType=self._TEST_TYPE,
            MaxItems="1000",
        )
        a = res["ResourceRecordSets"][0]["ResourceRecords"][0]["Value"]
        self.assertEqual(a, self._TEST_VALUE.format(v))


if __name__ == "__main__":
    unittest.main()
