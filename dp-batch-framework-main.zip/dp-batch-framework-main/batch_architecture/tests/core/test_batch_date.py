import os
import datetime
import unittest

from batch_architecture.tests.test_setup import TestSettings  # noqa
from batch_architecture.core.settings import Settings
from batch_architecture.core.batch_date import BatchDate


class TestBatchDate(unittest.TestCase):
    def setUp(self):
        path = os.path.join(Settings.RESOURCE_BATCH_DATE_DIR, "batch_date.txt")
        with open(path) as f:
            batch_date = f.read().strip()
        self.batch_date = batch_date

    def tearDown(self):
        # Reset batch_date
        BatchDate.read_batch_date_file()

    def test_001_001_batch_date(self):
        self.assertEqual(self.batch_date, BatchDate.batch_date)

    def test_002_001_read_batch_date_file(self):
        batch_date = BatchDate.read_batch_date_file()
        self.assertEqual(self.batch_date, batch_date)

    def test_009_001_set_batch_date(self):
        batch_date = '20220421'

        BatchDate.set_batch_date(batch_date)
        self.assertEqual(batch_date, BatchDate.batch_date)
        self.assertTrue(isinstance(BatchDate.batch_datetime, datetime.datetime))
        self.assertEqual(batch_date, BatchDate.batch_datetime.strftime("%Y%m%d"))
        self.assertEqual('202204', BatchDate.batch_month)
        self.assertEqual('y=2022/m=04/d=21', BatchDate.partition_ymd)
