from batch_architecture.testing import TestCase
import boto3
from batch_architecture.client.hive_client import HiveClient


class TestHiveClient(TestCase):

    host = "10.0.4.79"
    access_key = boto3.Session().get_credentials().access_key
    secret_key = boto3.Session().get_credentials().secret_key

    @classmethod
    def setUpClass(cls):
        cls.client = HiveClient(host=cls.host)

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_run_query(self):
        query = "show tables"
        self.client.run_query(query)
