import os

from batch_architecture.testing import TestCase
from batch_architecture.client import Shell


class ShellTestCase(TestCase):
    def setUp(self):
        self.cmd = Shell()

    def test_execute(self):
        """
        シェルコマンドが実行できるかテストする。
        """
        status, std, err = self.cmd.execute("cd .")
        self.assertEqual(status, 0)
        self.assertEqual(std, b"")
        self.assertEqual(err, b"")

    def test_execut_err(self):
        """
        不正なシェルコマンドを実行したとき、期待通り SystemError が発生するか
        テストする。
        """
        with self.assertRaises(SystemError):
            self.cmd.execute("asdfas")

    def test_stdin_4096(self):
        """
        入力されるコマンドと結果(標準出力)が 4096byte 以上の場合も
        正しく実行できるか (デッドロックしないか) テストする。
        """
        cmd = "echo %s" % ("1" * 4097)
        status, std, err = self.cmd.execute(cmd)
        self.assertEqual(status, 0)
        self.assertEqual(std, b"1" * 4097 + os.linesep.encode())
        self.assertEqual(err, b"")
