import pathlib
import tempfile

from batch_architecture.testing import TestCase
from batch_architecture.client import FTPClient


class TestFTPClient(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_ftp_server()

        ftp = FTPClient()
        ftp.connect(cls.FTP_HOST)
        assert ftp.pwd() == "/"

        # アップロードするファイルのパス
        testdata = cls.TEST_DATA

        ftp.upload(testdata / "upload.csv", "data.csv")

        ftp.mkdir("dir1", cwd=False)
        ftp.upload(testdata / "data_sjis.csv", "dir1/data_sjis.csv")
        ftp.upload(testdata / "data_utf8.csv", "dir1/data_utf8.csv")

    def setUp(self):
        self.upload_file = self.TEST_DATA / "upload.csv"

        self.download_dir = pathlib.Path(tempfile.mkdtemp())
        self.download_file = self.download_dir / "download.csv"

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_ftp_server()

    def tearDown(self):
        from batch_architecture.io_target import LocalTarget

        LocalTarget(self.download_dir).delete()
        self.assertFalse(self.download_file.exists())

    def get_ftp(self):
        ftp = FTPClient()
        return ftp.connect(self.FTP_HOST)

    def test_parse(self):
        """
        URL 中のユーザ名、パスワード、ポートを正しくパースできるかテストする。
        """
        h, p, u, ps = FTPClient.parse("hostname")
        self.assertEqual(h, "hostname")
        self.assertEqual(p, 21)
        self.assertIsNone(u)
        self.assertIsNone(ps)

        h, p, u, ps = FTPClient.parse("hostname:10021")
        self.assertEqual(h, "hostname")
        self.assertEqual(p, 10021)
        self.assertIsNone(u)
        self.assertIsNone(ps)

        h, p, u, ps = FTPClient.parse("user:pass@hostname")
        self.assertEqual(h, "hostname")
        self.assertEqual(p, 21)
        self.assertEqual(u, "user")
        self.assertEqual(ps, "pass")

    def test_mkdir(self):
        """
        FTP サーバ上にディレクトリを作成できるかテストする。
        """
        ftp = self.get_ftp()
        self.assertEqual(ftp.pwd(), "/")

        # 作成前
        self.assertFalse(ftp.exists("test_dir"))
        self.assertFalse(ftp.is_dir("test_dir"))
        self.assertFalse(ftp.is_file("test_dir"))

        # ディレクトリ作成
        ftp.mkdir("test_dir", cwd=False)
        self.assertEqual(ftp.pwd(), "/")
        self.assertTrue(ftp.exists("test_dir"))
        self.assertTrue(ftp.is_dir("test_dir"))
        self.assertFalse(ftp.is_file("test_dir"))

        # ディレクトリ削除
        ftp.delete("test_dir")
        self.assertFalse(ftp.exists("test_dir"))
        self.assertFalse(ftp.is_dir("test_dir"))
        self.assertFalse(ftp.is_file("test_dir"))

    def test_mkdir_multilevel(self):
        """
        FTP サーバ上に複数階層のディレクトリを作成した時、既定では期待通り
        FileNotFoundError が発生することをテストする。
        引数として parents=True を指定した場合、複数階層のディレクトリが
        作成できることをテストする。
        """
        ftp = self.get_ftp()

        # 作成前
        self.assertFalse(ftp.exists("test_dirA/test_dirB"))
        self.assertFalse(ftp.is_dir("test_dirA/test_dirB"))
        self.assertFalse(ftp.is_file("test_dirA/test_dirB"))

        # ディレクトリ作成
        with self.assertRaises(FileNotFoundError):
            ftp.mkdir("test_dirA/test_dirB")

        # ディレクトリ作成
        ftp.mkdir("test_dirA/test_dirB", parents=True)
        self.assertEqual(ftp.pwd(), "/test_dirA/test_dirB")
        ftp.cwd("/")
        self.assertTrue(ftp.exists("test_dirA/test_dirB"))
        self.assertTrue(ftp.is_dir("test_dirA/test_dirB"))
        self.assertFalse(ftp.is_file("test_dirA/test_dirB"))

        ftp.cwd("test_dirA")
        ftp.delete("test_dirB")
        ftp.cwd("/")
        ftp.delete("test_dirA")

    def test_delete_multilevel(self):
        """
        FTP サーバ上のディレクトリが削除できることをテストする。
        """

        ftp = self.get_ftp()

        # ディレクトリ作成
        ftp.mkdir("test_dirA/test_dirB", parents=True)
        self.assertEqual(ftp.pwd(), "/test_dirA/test_dirB")
        ftp.cwd("/")
        self.assertTrue(ftp.exists("test_dirA/test_dirB"))
        self.assertTrue(ftp.is_dir("test_dirA/test_dirB"))
        self.assertFalse(ftp.is_file("test_dirA/test_dirB"))

        # test_dirBを削除
        ftp.delete("test_dirA/test_dirB")
        self.assertFalse(ftp.exists("test_dirA/test_dirB"))
        self.assertTrue(ftp.exists("test_dirA"))
        # test_dirAを削除
        ftp.delete("test_dirA")
        self.assertFalse(ftp.exists("test_dirA"))

    def test_delete_recursive(self):
        """
        FTP サーバ上のディレクトリが再帰的に削除できることをテストする。
        """
        ftp = self.get_ftp()

        ftp.mkdir("test_delete_dir", cwd=False)
        ftp.upload(self.TEST_DATA / "data_sjis.csv", "test_delete_dir/data_sjis.csv")
        ftp.upload(self.TEST_DATA / "data_utf8.csv", "test_delete_dir/data_utf8.csv")

        with self.assertRaises(Exception):
            ftp.delete("test_delete_dir", recursive=False)

        ftp.delete("test_delete_dir")
        self.assertFalse(ftp.exists("test_delete_dir"))

    def test_connect_upload_files(self):
        """
        FTP サーバにファイルをアップロード / ダウンロードできることをテストする。
        """
        ftp = self.get_ftp()

        # upload するファイルパス
        upload_path = "uploaded.txt"
        self.assertFalse(ftp.exists(upload_path))
        self.assertFalse(ftp.is_dir(upload_path))
        self.assertFalse(ftp.is_file(upload_path))

        # FTPアップロード
        ftp.upload(self.upload_file, upload_path)
        self.assertTrue(ftp.exists(upload_path))
        self.assertFalse(ftp.is_dir(upload_path))
        self.assertTrue(ftp.is_file(upload_path))

        # FTPダウンロード
        ftp.download(upload_path, self.download_file)

        self.assertTrue(self.download_file.exists())
        with self.download_file.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        ftp.delete(upload_path)
        self.assertFalse(ftp.exists(upload_path))
        self.assertFalse(ftp.is_dir(upload_path))
        self.assertFalse(ftp.is_file(upload_path))

    def test_cwd_multilevel(self):
        """
        FTP サーバ上でのワーキングディレクトリを指定通りに
        移動できることをテストする。
        """
        ftp = self.get_ftp()

        # test_dir1/test_dir2 の階層を作成
        self.assertFalse(ftp.exists("test_dir1/test_dir2"))
        self.assertFalse(ftp.is_dir("test_dir1/test_dir2"))
        self.assertFalse(ftp.is_file("test_dir1/test_dir2"))

        ftp.mkdir("test_dir1")
        self.assertEqual(ftp.pwd(), "/test_dir1")
        ftp.mkdir("test_dir2")
        self.assertEqual(ftp.pwd(), "/test_dir1/test_dir2")
        # ルートディレクトリに戻る
        ftp.cwd("/")
        self.assertEqual(ftp.pwd(), "/")

        # ルートからみて階層が存在するか
        self.assertTrue(ftp.exists("test_dir1/test_dir2"))
        self.assertTrue(ftp.is_dir("test_dir1/test_dir2"))
        self.assertFalse(ftp.is_file("test_dir1/test_dir2"))

        # test_dir1からみて階層が存在するか
        ftp.cwd("test_dir1")
        self.assertTrue(ftp.exists("test_dir2"))
        self.assertTrue(ftp.is_dir("test_dir2"))
        self.assertFalse(ftp.is_file("test_dir2"))
        ftp.cwd("/")

        # cwd の引数をリストで指定
        ftp.cwd(["test_dir1", "test_dir2"])
        self.assertEqual(ftp.pwd(), "/test_dir1/test_dir2")
        ftp.cwd("/")
        self.assertEqual(ftp.pwd(), "/")

        # ディレクトリ削除
        ftp.cwd("test_dir1")
        ftp.delete("test_dir2")

        ftp.cwd("/")
        ftp.delete("test_dir1")

        self.assertFalse(ftp.exists("test_dir1/test_dir2"))
        self.assertFalse(ftp.is_dir("test_dir1/test_dir2"))
        self.assertFalse(ftp.is_file("test_dir1/test_dir2"))

    def test_upload_multilevel(self):
        """
        FTP サーバに複数階層のファイルをアップロード / ダウンロードできることをテストする。
        """
        ftp = self.get_ftp()

        # test_dir1/test_dir2/test.txt の階層を作成

        self.assertFalse(ftp.exists("test_dir1/test_dir2/test.txt"))
        self.assertFalse(ftp.is_dir("test_dir1/test_dir2/test.txt"))
        self.assertFalse(ftp.is_file("test_dir1/test_dir2/test.txt"))

        ftp.mkdir("test_dir1/test_dir2", cwd=False, parents=True)

        # ファイルのアップロード
        ftp.upload(self.upload_file, "test_dir1/test_dir2/test.txt")
        self.assertTrue(ftp.exists("test_dir1/test_dir2/test.txt"))
        self.assertFalse(ftp.is_dir("test_dir1/test_dir2/test.txt"))
        self.assertTrue(ftp.is_file("test_dir1/test_dir2/test.txt"))

        # FTPダウンロード
        ftp.download("test_dir1/test_dir2/test.txt", self.download_file)
        self.assertTrue(self.download_file.exists())

        with self.download_file.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        self.clean_multifiles()

    def upload_multifiles(self):
        ftp = self.get_ftp()

        # test_dir1/test_dir2/test_XX.txt の階層を作成
        ftp.mkdir("test_dir1/test_dir2", parents=True)
        self.assertEqual(ftp.pwd(), "/test_dir1/test_dir2")

        # ルートディレクトリに戻る
        ftp.cwd("/")
        self.assertEqual(ftp.pwd(), "/")

        # ファイルのアップロード
        ftp.upload(self.upload_file, "test_dir1/test_dir2/test_01.txt")
        ftp.upload(self.upload_file, "test_dir1/test_dir2/test_02.txt")
        ftp.upload(self.upload_file, "test_dir1/test_dir2/test_03.txt")

        self.assertTrue(ftp.exists("test_dir1/test_dir2/test_01.txt"))
        self.assertFalse(ftp.is_dir("test_dir1/test_dir2/test_01.txt"))
        self.assertTrue(ftp.is_file("test_dir1/test_dir2/test_01.txt"))

    def clean_multifiles(self):
        ftp = self.get_ftp()
        self.assertEqual(ftp.pwd(), "/")
        ftp.delete("test_dir1")
        self.assertFalse(ftp.exists("test_dir1/"))

    def test_upload_multilevel_multifiles(self):
        """
        FTP サーバ上の階層構造を保持してディレクトリをダウンロードできることをテストする。
        """
        ftp = self.get_ftp()

        self.upload_multifiles()

        # ダウンロード用ディレクトリを作成
        download_dir = self.download_dir / "dldir"
        download_dir.mkdir()

        # FTPダウンロード
        with self.assertRaises(FileExistsError):
            ftp.download("test_dir1/test_dir2", download_dir)

        self.clean_multifiles()

    def test_upload_multilevel_multifiles_mkdir(self):
        """
        FTP サーバ上の階層構造を保持してディレクトリをダウンロードできることをテストする。
        ダウンロード先のディレクトリは新規作成する。
        """
        ftp = self.get_ftp()

        self.upload_multifiles()

        # ダウンロード用ディレクトリに存在しないディレクトリを指定
        download_dir = self.download_dir / "dldir"
        self.assertFalse(download_dir.exists())

        # FTPダウンロード
        with self.assertRaises(FileExistsError):
            ftp.download("test_dir1/test_dir2", download_dir)

        self.clean_multifiles()

    def test_upload_multilevel_notexists(self):
        """
        FTP サーバに新規ディレクトリを作成してファイルをアップロードできることを
        テストする。
        """
        ftp = self.get_ftp()
        # アップロード先のディレクトリが存在しない場合は作成
        ftp.upload(self.upload_file, "test_dir1/test.txt")
        self.assertTrue(ftp.is_file("test_dir1/test.txt"))
        ftp.delete("test_dir1")

    def test_download_multilevel_notexists(self):
        """
        FTP サーバのダウンロード対象が存在しないとき、期待通り
        FileNotFoundError が発生するかテストする。
        """
        ftp = self.get_ftp()

        # ダウンロード元のファイルが存在しない場合はダウンロードできない
        with self.assertRaises(FileNotFoundError):
            ftp.download("test_dir1/not_exists.txt", self.download_file)

    def test_ls(self):
        """
        FTP サーバのカレントディレクトリに含まれるファイル、ディレクトリの
        一覧を取得できるかテストする。
        """
        ftp = self.get_ftp()
        self.assertEqual(ftp.pwd(), "/")

        res = ftp.ls()
        self.assertEqual(sorted(res), sorted(["data.csv", "dir1"]))

        res = ftp.ls("dir1")
        self.assertEqual(sorted(res), sorted(["data_sjis.csv", "data_utf8.csv"]))
