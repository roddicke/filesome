from batch_architecture.testing import TestCase
import snowflake
from batch_architecture.client.snowflake_client import SnowflakeClient


class TestSnowflakeClient(TestCase):

    host = "10.0.4.79"
    access_key = boto3.Session().get_credentials().access_key
    secret_key = boto3.Session().get_credentials().secret_key

    @classmethod
    def setUpClass(cls):
        cls.client = SnowflakeClient(host=cls.host)

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_run_query(self):
        query = "show tables"
        self.client.run_query(query)
