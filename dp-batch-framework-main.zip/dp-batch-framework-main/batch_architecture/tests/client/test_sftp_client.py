import pathlib
import tempfile

from batch_architecture.testing import TestCase
from batch_architecture.client import SFTPClient


class TestSFTPClient(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_sftp_server()

        sftp = SFTPClient()
        sftp.connect(
            hostname=cls.SFTP_HOST, user=cls.SFTP_USER, port=22, passwd=cls.SFTP_PASS
        )
        assert sftp.pwd() == "/"

        # アップロードするファイルのパス
        testdata = cls.TEST_DATA
        sftp.cwd(cls.TEST_HOME_DIR)

        sftp.upload(str(testdata / "upload.csv"), "data.csv")

        sftp.mkdir("dir1", cwd=False)
        sftp.upload(str(testdata / "data_sjis.csv"), "dir1/data_sjis.csv")
        sftp.upload(str(testdata / "data_utf8.csv"), "dir1/data_utf8.csv")

    def setUp(self):
        self.upload_file = self.TEST_DATA / "upload.csv"

        self.download_dir = pathlib.Path(tempfile.mkdtemp())
        self.download_file = self.download_dir / "download.csv"

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_sftp_server()

    def tearDown(self):
        from batch_architecture.io_target import LocalTarget

        LocalTarget(self.download_dir).delete()
        self.assertFalse(self.download_file.exists())

    def get_sftp(self):
        sftp = SFTPClient()
        return sftp.connect(
            hostname=self.SFTP_HOST, user=self.SFTP_USER, port=22, passwd=self.SFTP_PASS
        )

    def test_parse(self):
        """
        URL 中のユーザ名、パスワード、ポートを正しくパースできるかテストする。
        """
        h, p, u, ps = SFTPClient.parse("hostname")
        self.assertEqual(h, "hostname")
        self.assertEqual(p, 22)
        self.assertIsNone(u)
        self.assertIsNone(ps)

        h, p, u, ps = SFTPClient.parse("hostname:10021")
        self.assertEqual(h, "hostname")
        self.assertEqual(p, 10021)
        self.assertIsNone(u)
        self.assertIsNone(ps)

        h, p, u, ps = SFTPClient.parse("user:pass@hostname")
        self.assertEqual(h, "hostname")
        self.assertEqual(p, 22)
        self.assertEqual(u, "user")
        self.assertEqual(ps, "pass")

    def test_mkdir(self):
        """
        SFTP サーバ上にディレクトリを作成できるかテストする。
        """
        sftp = self.get_sftp()
        self.assertEqual(sftp.pwd(), "/")
        sftp.cwd(self.TEST_HOME_DIR)

        # 作成前
        self.assertFalse(sftp.exists("test_dir"))
        self.assertFalse(sftp.is_dir("test_dir"))
        self.assertFalse(sftp.is_file("test_dir"))

        # ディレクトリ作成
        sftp.mkdir("test_dir", cwd=False)
        self.assertTrue(sftp.exists("test_dir"))
        self.assertTrue(sftp.is_dir("test_dir"))
        self.assertFalse(sftp.is_file("test_dir"))

        # ディレクトリ削除
        sftp.delete("test_dir")
        self.assertFalse(sftp.exists("test_dir"))
        self.assertFalse(sftp.is_dir("test_dir"))
        self.assertFalse(sftp.is_file("test_dir"))

    def test_mkdir_multilevel(self):
        """
        SFTP サーバ上に複数階層のディレクトリを作成した時、既定では期待通り
        FileNotFoundError が発生することをテストする。
        引数として parents=True を指定した場合、複数階層のディレクトリが
        作成できることをテストする。
        """
        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)

        # 作成前
        self.assertFalse(sftp.exists("test_dirA/test_dirB"))
        self.assertFalse(sftp.is_dir("test_dirA/test_dirB"))
        self.assertFalse(sftp.is_file("test_dirA/test_dirB"))

        # ディレクトリ作成
        with self.assertRaises(FileNotFoundError):
            sftp.mkdir("test_dirA/test_dirB")

        # ディレクトリ作成
        sftp.mkdir("test_dirA/test_dirB", parents=True)
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR + "/test_dirA/test_dirB")
        sftp.cwd(self.TEST_HOME_DIR)
        self.assertTrue(sftp.exists(self.TEST_HOME_DIR + "/test_dirA/test_dirB"))
        self.assertTrue(sftp.is_dir(self.TEST_HOME_DIR + "/test_dirA/test_dirB"))
        self.assertFalse(sftp.is_file(self.TEST_HOME_DIR + "/test_dirA/test_dirB"))

        sftp.cwd("test_dirA")
        sftp.delete("test_dirB")
        sftp.cwd(self.TEST_HOME_DIR)
        sftp.delete("test_dirA")

    def test_delete_multilevel(self):
        """
        SFTP サーバ上のディレクトリが削除できることをテストする。
        """

        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)

        # ディレクトリ作成
        sftp.mkdir("test_dirA/test_dirB", parents=True)
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR + "/test_dirA/test_dirB")
        sftp.cwd(self.TEST_HOME_DIR)
        self.assertTrue(sftp.exists("test_dirA/test_dirB"))
        self.assertTrue(sftp.is_dir("test_dirA/test_dirB"))
        self.assertFalse(sftp.is_file("test_dirA/test_dirB"))

        # test_dirBを削除
        sftp.delete("test_dirA/test_dirB")
        self.assertFalse(sftp.exists("test_dirA/test_dirB"))
        self.assertTrue(sftp.exists("test_dirA"))
        # test_dirAを削除
        sftp.delete("test_dirA")
        self.assertFalse(sftp.exists("test_dirA"))

    def test_delete_recursive(self):
        """
        SFTP サーバ上のディレクトリが再帰的に削除できることをテストする。
        """
        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)

        sftp.mkdir("test_delete_dir", cwd=False)
        sftp.upload(self.TEST_DATA / "data_sjis.csv", "test_delete_dir/data_sjis.csv")
        sftp.upload(self.TEST_DATA / "data_utf8.csv", "test_delete_dir/data_utf8.csv")

        with self.assertRaises(Exception):
            sftp.delete("test_delete_dir", recursive=False)

        sftp.delete("test_delete_dir")
        self.assertFalse(sftp.exists("test_delete_dir"))

    def test_connect_upload_files(self):
        """
        SFTP サーバにファイルをアップロード / ダウンロードできることをテストする。
        """
        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)

        # upload するファイルパス
        upload_path = "uploaded.txt"
        self.assertFalse(sftp.exists(upload_path))
        self.assertFalse(sftp.is_dir(upload_path))
        self.assertFalse(sftp.is_file(upload_path))

        # SFTPアップロード
        sftp.upload(self.upload_file, upload_path)
        self.assertTrue(sftp.exists(upload_path))
        self.assertFalse(sftp.is_dir(upload_path))
        self.assertTrue(sftp.is_file(upload_path))

        # SFTPダウンロード
        sftp.download(upload_path, str(self.download_file))

        self.assertTrue(self.download_file.exists())
        with self.download_file.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        sftp.delete(upload_path)
        self.assertFalse(sftp.exists(upload_path))
        self.assertFalse(sftp.is_dir(upload_path))
        self.assertFalse(sftp.is_file(upload_path))

    def test_cwd_multilevel(self):
        """
        SFTP サーバ上でのワーキングディレクトリを指定通りに
        移動できることをテストする。
        """
        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)

        # test_dir1/test_dir2 の階層を作成
        self.assertFalse(sftp.exists("test_dir1/test_dir2"))
        self.assertFalse(sftp.is_dir("test_dir1/test_dir2"))
        self.assertFalse(sftp.is_file("test_dir1/test_dir2"))

        sftp.mkdir("test_dir1")
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR + "/test_dir1")
        sftp.mkdir("test_dir2")
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR + "/test_dir1/test_dir2")
        # ルートディレクトリに戻る
        sftp.cwd(self.TEST_HOME_DIR)
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR)

        # ルートからみて階層が存在するか
        self.assertTrue(sftp.exists("test_dir1/test_dir2"))
        self.assertTrue(sftp.is_dir("test_dir1/test_dir2"))
        self.assertFalse(sftp.is_file("test_dir1/test_dir2"))

        # test_dir1からみて階層が存在するか
        sftp.cwd("test_dir1")
        self.assertTrue(sftp.exists("test_dir2"))
        self.assertTrue(sftp.is_dir("test_dir2"))
        self.assertFalse(sftp.is_file("test_dir2"))
        sftp.cwd(self.TEST_HOME_DIR)

        # cwd の引数をリストで指定
        sftp.cwd(["test_dir1", "test_dir2"])
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR + "/test_dir1/test_dir2")
        sftp.cwd(self.TEST_HOME_DIR)
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR)

        # ディレクトリ削除
        sftp.cwd("test_dir1")
        sftp.delete("test_dir2")

        sftp.cwd(self.TEST_HOME_DIR)
        sftp.delete("test_dir1")

        self.assertFalse(sftp.exists("test_dir1/test_dir2"))
        self.assertFalse(sftp.is_dir("test_dir1/test_dir2"))
        self.assertFalse(sftp.is_file("test_dir1/test_dir2"))

    def test_upload_multilevel(self):
        """
        SFTP サーバに複数階層のファイルをアップロード / ダウンロードできることをテストする。
        """
        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)

        # test_dir1/test_dir2/test.txt の階層を作成

        self.assertFalse(sftp.exists("test_dir1/test_dir2/test.txt"))
        self.assertFalse(sftp.is_dir("test_dir1/test_dir2/test.txt"))
        self.assertFalse(sftp.is_file("test_dir1/test_dir2/test.txt"))

        sftp.mkdir("test_dir1/test_dir2", cwd=False, parents=True)

        # ファイルのアップロード
        sftp.upload(self.upload_file, "test_dir1/test_dir2/test.txt")
        self.assertTrue(sftp.exists("test_dir1/test_dir2/test.txt"))
        self.assertFalse(sftp.is_dir("test_dir1/test_dir2/test.txt"))
        self.assertTrue(sftp.is_file("test_dir1/test_dir2/test.txt"))

        # SFTPダウンロード
        sftp.download("test_dir1/test_dir2/test.txt", self.download_file)
        self.assertTrue(self.download_file.exists())

        with self.download_file.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        self.clean_multifiles()

    def upload_multifiles(self):
        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)

        # test_dir1/test_dir2/test_XX.txt の階層を作成
        sftp.mkdir("test_dir1/test_dir2", parents=True)
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR + "/test_dir1/test_dir2")

        # ルートディレクトリに戻る
        sftp.cwd(self.TEST_HOME_DIR)
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR)

        # ファイルのアップロード
        sftp.upload(self.upload_file, "test_dir1/test_dir2/test_01.txt")
        sftp.upload(self.upload_file, "test_dir1/test_dir2/test_02.txt")
        sftp.upload(self.upload_file, "test_dir1/test_dir2/test_03.txt")

        self.assertTrue(sftp.exists("test_dir1/test_dir2/test_01.txt"))
        self.assertFalse(sftp.is_dir("test_dir1/test_dir2/test_01.txt"))
        self.assertTrue(sftp.is_file("test_dir1/test_dir2/test_01.txt"))

    def clean_multifiles(self):
        sftp = self.get_sftp()
        self.assertEqual(sftp.pwd(), "/")
        sftp.cwd(self.TEST_HOME_DIR)
        sftp.delete("test_dir1")
        self.assertFalse(sftp.exists("test_dir1/"))

    def test_upload_multilevel_multifiles(self):
        """
        SFTP サーバ上の階層構造を保持してディレクトリをダウンロードできることをテストする。
        """
        sftp = self.get_sftp()

        self.upload_multifiles()

        # ダウンロード用ディレクトリを作成
        download_dir = self.download_dir / "dldir"
        download_dir.mkdir()

        # SFTPダウンロード
        with self.assertRaises(FileExistsError):
            sftp.download("test_dir1/test_dir2", download_dir)

        self.clean_multifiles()

    def test_upload_multilevel_multifiles_mkdir(self):
        """
        SFTP サーバ上の階層構造を保持してディレクトリをダウンロードできることをテストする。
        ダウンロード先のディレクトリは新規作成する。
        """
        sftp = self.get_sftp()

        self.upload_multifiles()

        # ダウンロード用ディレクトリに存在しないディレクトリを指定
        download_dir = self.download_dir / "dldir"
        self.assertFalse(download_dir.exists())

        # FTPダウンロード
        with self.assertRaises(FileExistsError):
            sftp.download("test_dir1/test_dir2", download_dir)

        self.clean_multifiles()

    def test_upload_multilevel_notexists(self):
        """
        SFTP サーバに新規ディレクトリを作成してファイルをアップロードできることを
        テストする。
        """
        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)
        # アップロード先のディレクトリが存在しない場合は作成
        sftp.upload(self.upload_file, "test_dir1/test.txt")
        self.assertTrue(sftp.is_file("test_dir1/test.txt"))
        sftp.delete("test_dir1")

    def test_download_multilevel_notexists(self):
        """
        SFTP サーバのダウンロード対象が存在しないとき、期待通り
        FileNotFoundError が発生するかテストする。
        """
        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)

        # ダウンロード元のファイルが存在しない場合はダウンロードできない
        with self.assertRaises(FileNotFoundError):
            sftp.download("test_dir1/not_exists.txt", self.download_file)

    def test_ls(self):
        """
        SFTP サーバのカレントディレクトリに含まれるファイル、ディレクトリの
        一覧を取得できるかテストする。
        """
        sftp = self.get_sftp()
        sftp.cwd(self.TEST_HOME_DIR)
        self.assertEqual(sftp.pwd(), self.TEST_HOME_DIR)

        res = sftp.ls()
        self.assertEqual(sorted(res), sorted(["data.csv", "dir1"]))

        res = sftp.ls("dir1")
        self.assertEqual(sorted(res), sorted(["data_sjis.csv", "data_utf8.csv"]))
