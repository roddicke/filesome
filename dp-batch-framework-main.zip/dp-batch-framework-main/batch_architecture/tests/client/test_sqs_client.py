import unittest

from client.sqs_client import SqsClient


class TestSqsClient(unittest.TestCase):
    def setUp(self) -> None:
        self.client = SqsClient()
        self.url = 'https://sqs.ap-northeast-1.amazonaws.com/369459746403/test-queue-for-cfas-export'

    def test_send_message(self):
        self.skipTest("this test accesses sqs, so skip in unit test")
        bodies = [str(i) for i in range(10)]
        res = self.client.send_message_batch(self.url, bodies)
        self.assertEqual(len(res['successful']), 10)

    def test_send_message_batch_over(self):
        self.skipTest("this test accesses sqs, so skip in unit test")
        bodies = [str(i) for i in range(11)]
        with self.assertRaises(ValueError):
            self.client.send_message_batch(self.url, bodies)
