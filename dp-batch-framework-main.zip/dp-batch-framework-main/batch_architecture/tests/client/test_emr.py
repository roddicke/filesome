import os
import nose

from batch_architecture.testing import TestCase
from batch_architecture.client.emr import EMRClient
from batch_architecture.io_target.s3_target import S3Target
from batch_architecture.io_target.local_target import LocalTarget
from batch_architecture.aws.emr import EMRTarget


class EMRTestCase(TestCase):
    """
    EMR テスト
    """

    @classmethod
    def setUpClass(cls):
        cls.cleanup_s3_bucket()
        src1 = cls.TEST_RESOURCE / "emr_json"
        src1 = LocalTarget(src1)
        dst1 = S3Target(cls.S3_BUCKET + "/emr_json")
        src1.copy_to(dst1)

        src2 = cls.TEST_RESOURCE / "hive_sql"
        src2 = LocalTarget(src2)
        dst2 = S3Target(cls.S3_BUCKET + "/hive_sql")
        src2.copy_to(dst2)

        config = os.path.join("config", "emr_config.ini")
        cls.client = EMRTarget(config)

        if not cls.client.is_started():
            raise nose.SkipTest("EMRクラスタを起動してください")

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_s3_bucket()

    def setUp(self):
        self.s3path = "s3://" + self.S3_BUCKET + "/emr_json"
        self.localpath = self.TEST_RESOURCE / "emr_json"
        self.output = self.S3_BUCKET + "/output/000000_0"

    @property
    def cluster_id(self):
        return self.client.cluster_id

    def get_client(self, path):
        client = EMRClient(path=path, cluster_id=self.cluster_id, interval=5.0)
        return client

    def test_init(self):
        """
        EMR クライアントが正しく初期化できるかテストする。
        """
        setting = [
            {
                "Name": "Sample Script",
                "ActionOnFailure": "CANCEL_AND_WAIT",
                "HadoopJarStep": {
                    "Jar": "command-runner.jar",
                    "Args": [
                        "/usr/share/aws/emr/scripts/hive-script",
                        "--run-hive-script",
                        "--args",
                        "-f",
                        "s3://adt-develop/hive_sql/test_script.sql",
                    ],
                },
            }
        ]
        # 正常系：S3上のPathを指定
        e1 = self.get_client(self.s3path + "/test.json")
        self.assertEqual(self.cluster_id, e1.cluster_id)
        self.assertEqual(setting, e1.job_flow_steps)

        # 正常系：ローカル上のPathを指定
        e2 = self.get_client(self.localpath / "test.json")
        self.assertEqual(self.cluster_id, e2.cluster_id)
        self.assertEqual(setting, e2.job_flow_steps)

    def test_init_s3_path_failure(self):
        """
        EMR クライアントの設定ファイルのS3上のパスが不正な場合、
        期待通り ValueError / FileNotFoundError が発生するかテストする
        """
        # 異常系：バケットのみを指定
        with self.assertRaises(ValueError):
            self.get_client("s3://" + self.S3_BUCKET)

        # 異常系：ディレクトリのパスのみを指定
        with self.assertRaises(FileNotFoundError):
            self.get_client(self.s3path)

        # 異常系：存在しないJSONファイルを指定
        with self.assertRaises(FileNotFoundError):
            self.get_client(self.s3path + "/no_exist_json")

        # 異常系：Bucketが存在しない
        with self.assertRaises(ValueError):
            self.get_client("s3://no_exisit_bucket/test.json")

    def test_init_local_path_failure(self):
        """
        EMR クライアントの設定ファイルのローカルパスが不正な場合、
        期待通り ValueError / FileNotFoundError が発生するかテストする
        """
        # 異常系：存在しないパスを指定
        with self.assertRaises(FileNotFoundError):
            self.get_client("no_exisit_path")

        # 異常系：ファイルではなくディレクトリを指定
        with self.assertRaises(FileNotFoundError):
            self.get_client(self.localpath)

    def test_init_cluster_id_failure(self):
        """
        EMR のクラスタIDとして不正な ID を指定した場合、期待通り
        ValueError が発生するかテストする。
        """
        # 異常系：ClusterIDがEMR上に存在しない
        with self.assertRaises(Exception):
            EMRClient(self.s3path, "no_exisit_cluster_id", interval=5.0)
        # 異常系：ClusterがActiveな状態ではない
        with self.assertRaises(Exception):
            non_active_id = "j-3ORAJ96VQ5MQ7"
            EMRClient(self.s3path, non_active_id, interval=5.0)

    def test_init_interval(self):
        """
        EMR の初期化時に、ポーリングを行う間隔が正しく設定されるかテストする。
        """
        logic = EMRClient(self.localpath / "test.json", self.cluster_id)
        self.assertEqual(10.0, logic.interval)

    def test_execute_from_s3_path(self):
        """
        EMR を S3 上の設定ファイルを使って初期化し、実行できることをテストする。
        """
        e1 = self.get_client(self.s3path + "/test.json")
        e1.execute()
        # TODO:Outputフォルダも修正
        # 設定したフォルダに結果が出力されていることを確認
        o = S3Target(self.output)
        self.assertTrue(o.is_file())
        o.delete()

    def test_execute_form_local_path(self):
        """
        EMR を ローカルの設定ファイルを使って初期化し、実行できることをテストする。
        """
        e1 = self.get_client(self.localpath / "test.json")
        e1.execute()

        # 設定したフォルダに結果が出力されていることを確認
        o = S3Target(self.output)
        self.assertTrue(o.is_file())
        o.delete()

    def test_execute_from_s3_path_error(self):
        """
        S3 上の設定ファイルが不正な場合、期待通り Exception が発生するかテストする。
        """
        # 異常系：JSONファイル内で指定する実行スクリプトのパスが存在しない
        e1 = self.get_client(self.s3path + "/test_file_not_found_error.json")
        with self.assertRaises(Exception):
            e1.execute()

        # 異常系：JSONファイル内で指定する実行スクリプトのパスは存在するが、スクリプト内にエラーが存在する
        e2 = self.get_client(self.s3path + "/test_syntax_error.json")
        with self.assertRaises(Exception):
            e2.execute()

    def test_execute_from_local_path_error(self):
        """
        ローカルの設定ファイルが不正な場合、期待通り Exception が発生するかテストする。
        """
        # 異常系：JSONファイル内で指定する実行スクリプトのパスが存在しない
        e1 = self.get_client(self.localpath / "test_file_not_found_error.json")
        with self.assertRaises(Exception):
            e1.execute()

        # 異常系：JSONファイル内で指定する実行スクリプトのパスは存在するが、スクリプト内にエラーが存在する
        e2 = self.get_client(self.localpath / "test_syntax_error.json")
        with self.assertRaises(Exception):
            e2.execute()
