import os

SET_ENV = 'acp'
SET_SYSTEM = 'dwh'

os.environ["ADT_ENV"] = SET_ENV
os.environ["ADT_RESOURCE"] = SET_SYSTEM


def setup():
    from batch_architecture.core.log import Logger
    from batch_architecture.core.settings import Settings

    Logger.set_handler("test", "local")
    Settings.EXEC_MODE = 'VERBOSE'


class _TestSettings(object):
    def __init__(self):
        setup()


TestSettings = _TestSettings()
