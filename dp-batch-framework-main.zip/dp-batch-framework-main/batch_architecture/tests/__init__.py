import sys
import os
# settings.py読込み
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../')
