
$ErrorActionPreference = "Stop"
$rc = 0

Write-Host $Args[0]
Write-Host $Args[1]
Write-Host $Args[2]

try{
    $err = Copy-Item "C:\temp\adt4t" "C:\temp\adt4t2"
    Write-Host "success"
}catch [Exception]{
    Write-Host "copy error!!!!!!!!!"

    $rc = 1
}

exit $rc