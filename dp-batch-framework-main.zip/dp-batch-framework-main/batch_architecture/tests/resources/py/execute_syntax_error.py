prin('hello world')
