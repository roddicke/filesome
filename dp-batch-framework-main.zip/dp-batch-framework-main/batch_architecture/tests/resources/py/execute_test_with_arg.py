import sys
args = sys.argv
print(args[1], args[2])