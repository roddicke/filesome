echo 123
echo test
dir
