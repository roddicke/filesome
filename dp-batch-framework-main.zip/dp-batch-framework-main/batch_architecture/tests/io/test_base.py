"""
uri_util test case
"""
import pathlib
import tempfile

from batch_architecture.testing import TestCase
from batch_architecture.io_target import (
    Target,
    TargetType,
    LocalTarget,
    FTPTarget,
    S3Target,
    HTTPTarget,
)


class BaseTargetTestCase(TestCase):
    def test_protocol_type(self):
        """
        プロトコル指定したパスから、対象のプロトコルが判別できるかテストする。
        """
        self.assertEqual(Target.get_type("ftp://xxx"), TargetType.ftp)
        self.assertEqual(Target.get_type("s3://xxx"), TargetType.s3)
        self.assertEqual(Target.get_type("C:\\xxx"), TargetType.local)
        self.assertEqual(Target.get_type("/xxx"), TargetType.local)
        self.assertEqual(Target.get_type("https://xxx"), TargetType.http)
        self.assertEqual(Target.get_type("http://xxx"), TargetType.http)

    def test_parse(self):
        """
        プロトコル指定したパスから、対応する Target サブクラスを初期化できるか
        テストする。
        """
        self.assertEqual(Target.get_type("ftp://server/dir/test.txt"), TargetType.ftp)
        self.assertEqual(
            Target.get_type("s3://adt-develop/dir/test.txt"), TargetType.s3
        )
        self.assertEqual(Target.get_type("C:\\dir\\test.txt"), TargetType.local)
        self.assertEqual(
            Target.get_type("https://ja.wikipedia.org/wiki/Python"), TargetType.http
        )
        self.assertEqual(
            Target.get_type("http://ja.wikipedia.org/wiki/Python"), TargetType.http
        )

        res = Target.parse("ftp://server/dir/test.txt")
        self.assertTrue(isinstance(res, FTPTarget))
        self.assertEqual(res._hostname, "server")
        self.assertEqual(res._path, pathlib.PurePosixPath("dir/test.txt"))

        res = Target.parse("s3://adt-develop/dir/test.txt")
        self.assertTrue(isinstance(res, S3Target))
        self.assertEqual(res._bucket_name, "adt-develop")
        self.assertEqual(res._path, pathlib.PurePosixPath("dir/test.txt"))

        res = Target.parse("C:\\dir\\test.txt")
        self.assertTrue(isinstance(res, LocalTarget))
        self.assertEqual(res._path, pathlib.Path("C:\\dir\\test.txt"))

        res = Target.parse("https://ja.wikipedia.org/wiki/Python")
        self.assertTrue(isinstance(res, HTTPTarget))
        self.assertEqual(
            res._path, pathlib.PurePosixPath("ja.wikipedia.org/wiki/Python")
        )

    def test_div(self):
        """
        Target クラスのパスを / オペレータで連結できるかテストする。
        """
        p = LocalTarget("dir01/dir02")
        self.assertEqual(p / "test.txt", LocalTarget("dir01/dir02/test.txt"))

        p = FTPTarget("ftpserver/dir01/dir02")
        self.assertEqual(p / "test.txt", FTPTarget("ftpserver/dir01/dir02/test.txt"))

        p = S3Target("adt-develop/dir01/dir02")
        self.assertEqual(p / "test.txt", S3Target("adt-develop/dir01/dir02/test.txt"))

        p = HTTPTarget("test.com/dir01")
        self.assertEqual(p / "test.txt", HTTPTarget("test.com/dir01/test.txt"))

    def test_basename(self):
        """
        Target クラスから、最下層の名前を取得できるかテストする。
        """
        p = LocalTarget("dir01/dir02")
        self.assertEqual(p.basename, "dir02")

        p = FTPTarget("ftpserver/dir01/dir02")
        self.assertEqual(p.basename, "dir02")

        p = S3Target("adt-develop/dir01/dir02")
        self.assertEqual(p.basename, "dir02")

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python")
        self.assertEqual(p.basename, "Python")

        p = LocalTarget("dir01/dir02/")
        self.assertEqual(p.basename, "dir02")

        p = FTPTarget("ftpserver/dir01/dir02/")
        self.assertEqual(p.basename, "dir02")

        p = S3Target("adt-develop/dir01/dir02/")
        self.assertEqual(p.basename, "dir02")

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python/")
        self.assertEqual(p.basename, "Python")

    def test_parent(self):
        """
        Target クラスから、親下層の名前を取得できるかテストする。
        """
        p = LocalTarget("dir01/dir02")
        self.assertEqual(p.parent, LocalTarget("dir01"))

        p = FTPTarget("ftpserver/dir01/dir02")
        self.assertEqual(p.parent, FTPTarget("ftpserver/dir01"))

        p = S3Target("adt-develop/dir01/dir02")
        self.assertEqual(p.parent, S3Target("adt-develop/dir01"))

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python")
        self.assertEqual(
            str(p.parent), str(HTTPTarget("https://ja.wikipedia.org/wiki"))
        )

        p = LocalTarget("dir01/dir02/")
        self.assertEqual(p.parent, LocalTarget("dir01"))

        p = FTPTarget("ftpserver/dir01/dir02/")
        self.assertEqual(p.parent, FTPTarget("ftpserver/dir01"))

        p = S3Target("adt-develop/dir01/dir02/")
        self.assertEqual(p.parent, S3Target("adt-develop/dir01"))

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python/")
        self.assertEqual(
            str(p.parent), str(HTTPTarget("https://ja.wikipedia.org/wiki"))
        )

        p = LocalTarget("dir01")
        self.assertEqual(p.parent, LocalTarget("."))

        p = LocalTarget("")
        self.assertEqual(p.parent, LocalTarget("."))

        p = FTPTarget("ftpserver/")
        self.assertEqual(p.parent, p)

        p = S3Target("adt-develop/")
        self.assertEqual(p.parent, p)

    def test_filenames(self):
        """
        Target クラスから、ファイル名、拡張子を取得できるかテストする。
        """
        p = LocalTarget("dir01/test.txt")
        self.assertEqual(p.basename, "test.txt")
        self.assertEqual(p.stem, "test")
        self.assertEqual(p.suffix, ".txt")

        p = FTPTarget("ftpserver/dir01/test.txt")
        self.assertEqual(p.basename, "test.txt")
        self.assertEqual(p.stem, "test")
        self.assertEqual(p.suffix, ".txt")

        p = S3Target("adt-develop/dir01/test.txt")
        self.assertEqual(p.basename, "test.txt")
        self.assertEqual(p.stem, "test")
        self.assertEqual(p.suffix, ".txt")

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python.txt")
        self.assertEqual(p.basename, "Python.txt")
        self.assertEqual(p.stem, "Python")
        self.assertEqual(p.suffix, ".txt")

        p = LocalTarget("dir01/dir02")
        self.assertEqual(p.basename, "dir02")
        self.assertEqual(p.stem, "dir02")
        self.assertEqual(p.suffix, "")

        p = FTPTarget("ftpserver/dir01/dir02")
        self.assertEqual(p.basename, "dir02")
        self.assertEqual(p.stem, "dir02")
        self.assertEqual(p.suffix, "")

        p = S3Target("adt-develop/dir01/dir02")
        self.assertEqual(p.basename, "dir02")
        self.assertEqual(p.stem, "dir02")
        self.assertEqual(p.suffix, "")

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python")
        self.assertEqual(p.basename, "Python")
        self.assertEqual(p.stem, "Python")
        self.assertEqual(p.suffix, "")

    def test_check_path(self):
        """
        対象パスが指定した条件を満たしているかチェックする内部用メソッドが
        期待通り動作するかテストする。
        """
        temp_dir = pathlib.Path(tempfile.mkdtemp())

        # ディレクトリ
        t = LocalTarget(temp_dir / "check_dir")
        t.mkdir()
        res = t._check_path(allow_dir=True)
        self.assertEqual(res, t)

        with self.assertRaises(FileExistsError):
            t._check_path(allow_none=True)

        with self.assertRaises(FileExistsError):
            t._check_path(allow_file=True)

        # ファイル
        t = LocalTarget(temp_dir / "check_dir.txt")
        t.touch()
        res = t._check_path(allow_file=True)
        self.assertEqual(res, t)

        with self.assertRaises(FileExistsError):
            t._check_path(allow_none=True)

        with self.assertRaises(FileExistsError):
            t._check_path(allow_dir=True)

        # 存在しないパスのテスト
        t = LocalTarget(temp_dir / "not_exist")
        res = t._check_path(allow_none=True)
        self.assertEqual(res, t)

        with self.assertRaises(FileNotFoundError):
            t._check_path(allow_file=True)

        with self.assertRaises(FileNotFoundError):
            t._check_path(allow_dir=True)

        LocalTarget(temp_dir).delete()

    def test_parts(self):
        """
        Target クラスのパスを階層ごとに分割して取得できるかテストする。
        """
        p = LocalTarget("dir01/test.txt")
        self.assertEqual(p.parts, ("dir01", "test.txt"))

        p = FTPTarget("ftpserver/dir01/test.txt")
        self.assertEqual(p.parts, ("dir01", "test.txt"))

        p = S3Target("horikoshi/dir01/test.txt")
        self.assertEqual(p.parts, ("dir01", "test.txt"))

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python")
        self.assertEqual(p.parts, ("ja.wikipedia.org", "wiki", "Python"))

    def test_suffix(self):
        """
        Target クラスのパスの拡張子を取得できるかテストする。
        """
        p = LocalTarget("dir01/test.txt")
        self.assertEqual(p.suffix, ".txt")

        p = FTPTarget("ftpserver/dir01/test.txt")
        self.assertEqual(p.suffix, ".txt")

        p = S3Target("horikoshi/dir01/test.txt")
        self.assertEqual(p.suffix, ".txt")

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python.txt")
        self.assertEqual(p.suffix, ".txt")

    def test_suffixes(self):
        """
        tar.gz のように パスの拡張子に複数のドットが含まれる場合、
        それらをまとめて取得できるかテストする。
        """
        p = LocalTarget("dir01/test.tar.gz")
        self.assertEqual(p.suffix, ".gz")
        self.assertEqual(p.suffixes, [".tar", ".gz"])

        p = FTPTarget("ftpserver/dir01/test.tar.gz")
        self.assertEqual(p.suffix, ".gz")
        self.assertEqual(p.suffixes, [".tar", ".gz"])

        p = S3Target("horikoshi/dir01/test.tar.gz")
        self.assertEqual(p.suffix, ".gz")
        self.assertEqual(p.suffixes, [".tar", ".gz"])

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python.tar.gz")
        self.assertEqual(p.suffix, ".gz")
        self.assertEqual(p.suffixes, [".tar", ".gz"])

    def test_stem(self):
        """
        Target クラスのパスのファイル名部分のみ(拡張子除く)を取得できるかテストする。
        """
        p = LocalTarget("dir01/test.txt")
        self.assertEqual(p.stem, "test")

        p = FTPTarget("ftpserver/dir01/test")
        self.assertEqual(p.stem, "test")

        p = S3Target("horikoshi/dir01/test.txt")
        self.assertEqual(p.stem, "test")

        p = HTTPTarget("https://ja.wikipedia.org/wiki/Python.txt")
        self.assertEqual(p.stem, "Python")

    def test_joinpath(self):
        """
        Target クラスののパスを正しく結合できるかテストする。
        """
        # LocalTarget
        p1 = LocalTarget("dir01")
        exp = LocalTarget("dir01/y.txt")
        self.assertEqual(p1.joinpath("y.txt"), exp)

        exp = LocalTarget("dir01/x/y.txt")
        self.assertEqual(p1.joinpath("x", "y.txt"), exp)

        # FTPTarget
        p1 = FTPTarget(self.FTP_HOST + "/dir01")
        exp = FTPTarget(self.FTP_HOST + "/dir01/y.txt")
        self.assertEqual(p1.joinpath("y.txt"), exp)

        exp = FTPTarget(self.FTP_HOST + "/dir01/x/y.txt")
        self.assertEqual(p1.joinpath("x", "y.txt"), exp)

        # S3Target
        p1 = S3Target(self.S3_BUCKET + "/dir01")
        exp = S3Target(self.S3_BUCKET + "/dir01/y.txt")
        self.assertEqual(p1.joinpath("y.txt"), exp)

        exp = S3Target(self.S3_BUCKET + "/dir01/x/y.txt")
        self.assertEqual(p1.joinpath("x", "y.txt"), exp)

        # HTTPTarget
        p1 = HTTPTarget("test-server/dir01")
        exp = HTTPTarget("test-server/dir01/y.txt")
        self.assertEqual(p1.joinpath("y.txt"), exp)

        exp = HTTPTarget("test-server/dir01/x/y.txt")
        self.assertEqual(p1.joinpath("x", "y.txt"), exp)
