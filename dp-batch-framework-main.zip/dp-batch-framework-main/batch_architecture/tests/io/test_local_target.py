import os
import pathlib
import tempfile

from batch_architecture import compat
from batch_architecture.testing import TestCase
from batch_architecture.io_target import LocalTarget


class TestLocaltarget(TestCase):
    def setUp(self):
        # 一時ディレクトリを作成
        self.test_dir = pathlib.Path(tempfile.mkdtemp())
        # テスト用のファイルを作成
        self.test_file = self.test_dir / "test.tempfile"
        self.test_file.touch()

    def tearDown(self):
        # 一時ディレクトリを削除
        LocalTarget(self.test_dir).delete()
        self.assertFalse(self.test_dir.exists())

    def test_basename(self):
        """
        LocalTarget のパスから、最下層の名前を正しく取得できるかテストする。
        """
        # os.path.basename と同一の結果になるかテスト
        p = LocalTarget(os.path.join("test_dir", "test.txt"))
        self.assertEqual(p.basename, "test.txt")
        self.assertEqual(p.basename, os.path.basename(str(p._path)))

        p = LocalTarget("test.txt")
        self.assertEqual(p.basename, "test.txt")
        self.assertEqual(p.basename, os.path.basename(str(p._path)))

        p = LocalTarget("test_dir" + os.sep)
        self.assertEqual(p.basename, "test_dir")
        self.assertEqual(p.basename, os.path.basename(str(p._path)))

        p = LocalTarget("test_dir")
        self.assertEqual(p.basename, "test_dir")
        self.assertEqual(p.basename, os.path.basename(str(p._path)))

        p = LocalTarget(os.path.join("test_dir", "test_dir2"))
        self.assertEqual(p.basename, "test_dir2")
        self.assertEqual(p.basename, os.path.basename(str(p._path)))

    def test_existence_file(self):
        """
        LocalTarget インスタンスがファイルの場合、対象が存在するか・ディレクトリか・ファイルか、
        をチェックするメソッドが期待通り動作するかテストする。

        - 存在するか (exists): True
        - ディレクトリか (is_dir): False
        - ファイルか (is_file): True
        """
        self.assertTrue(LocalTarget(self.test_dir).exists())
        self.assertTrue(LocalTarget(self.test_dir).is_dir())
        self.assertFalse(LocalTarget(self.test_dir).is_file())

    def test_existence_dir(self):
        """
        LocalTarget インスタンスがディレクトリの場合、対象が存在するか・ディレクトリか・ファイルか、
        をチェックするメソッドが期待通り動作するかテストする。

        - 存在するか (exists): True
        - ディレクトリか (is_dir): True
        - ファイルか (is_file): False
        """
        self.assertTrue(LocalTarget(self.test_file).exists())
        self.assertFalse(LocalTarget(self.test_file).is_dir())
        self.assertTrue(LocalTarget(self.test_file).is_file())

    def test_existence_none(self):
        """
        LocalTarget インスタンスが存在しないパスを指す場合、対象が存在するか・ディレクトリか・ファイルか、
        をチェックするメソッドが期待通り動作するかテストする。

        - 存在するか (exists): False
        - ディレクトリか (is_dir): False
        - ファイルか (is_file): False
        """
        notexists = self.test_dir / "notexists.file"
        self.assertFalse(LocalTarget(notexists).exists())
        self.assertFalse(LocalTarget(notexists).is_dir())
        self.assertFalse(LocalTarget(notexists).is_file())

    def test_repr(self):
        """
        LocalTarget の表示名が期待通りかテストする。
        """
        exp = "LocalTarget({0})[ディレクトリ]".format(str(self.test_dir))
        self.assertEqual(str(LocalTarget(self.test_dir)), exp)

        exp = "LocalTarget({0})[ファイル]".format(str(self.test_file))
        self.assertEqual(str(LocalTarget(self.test_file)), exp)

        notexists = self.test_dir / "notexists.txt"
        exp = "LocalTarget({0})[存在しない]".format(str(notexists))
        self.assertEqual(str(LocalTarget(notexists)), exp)

    def test_eq(self):
        """
        LocalTarget インスタンスの同値性が正しくチェックできるかテストする。
        """
        p = LocalTarget(os.path.join("xx", "test.txt"))
        self.assertTrue(p == os.path.join("xx", "test.txt"))
        self.assertTrue(p == pathlib.Path(os.path.join("xx", "test.txt")))

        self.assertFalse(p == pathlib.Path(os.path.join("x1", "test.txt")))

    def test_mkdir(self):
        """
        LocalTarget が指定するパスにディレクトリを作成できるかテストする。
        """
        test_dir = self.test_dir / "test_create_directory"
        LocalTarget(test_dir).mkdir()
        # ディレクトリが存在するかどうかチェック
        self.assertTrue(test_dir.is_dir())

    def test_mkdir_already_exists_file(self):
        """
        作成対象ディレクトリに同名のファイルがすでに存在する場合、
        期待通り FileExistsError が発生するかテストする。
        """
        path = self.test_dir / "test.txt"
        path.touch()
        with self.assertRaises(FileExistsError):
            LocalTarget(path).mkdir()

    def test_mkdir_already_exists_dir(self):
        """
        作成対象ディレクトリに同名のディレクトリがすでに存在する場合、
        期待通り FileExistsError が発生するかテストする。
        """
        path = self.test_dir / "created_dir"
        path.mkdir()
        with self.assertRaises(FileExistsError):
            LocalTarget(path).mkdir()

    def test_mkdir_current_dir(self):
        """
        作成対象ディレクトリとしてカレントディレクトリを指定した場合、
        期待通り FileExistsError が発生するかテストする。
        """
        with self.assertRaises(FileExistsError):
            LocalTarget("").mkdir()

    def test_mkdir_options(self):
        """
        作成対象ディレクトリの親ディレクトリが存在しない場合、
        期待通り FileNotFoundError が発生するかテストする。

        parents=True を指定した時、親ディレクトリも含めて作成されることを
        テストする。
        """
        t = LocalTarget(self.test_dir / "A" / "B")
        self.assertFalse(t.exists())
        with self.assertRaises(FileNotFoundError):
            t.mkdir()

        t.mkdir(parents=True)
        self.assertTrue(t.exists())

        # すでに対象ディレクトリが存在する
        with self.assertRaises(FileExistsError):
            t.mkdir()

        t.mkdir(exist_ok=True)
        self.assertTrue(t.exists())

    def test_touch(self):
        """
        LocalTarget が指定するパスにファイルを作成できるかテストする。
        """
        path = self.test_dir / "created.file"
        LocalTarget(path).touch()
        self.assertTrue(path.is_file())

    def test_touch_already_exists_file(self):
        """
        作成対象ファイルに同名のファイルがすでに存在する場合、
        期待通り FileExistsError が発生するかテストする。
        """
        path = self.test_dir / "test.txt"
        path.touch()
        with self.assertRaises(FileExistsError):
            LocalTarget(path).touch()

    def test_touch_already_exists_dir(self):
        """
        作成対象ファイルに同名のディレクトリがすでに存在する場合、
        期待通り FileExistsError が発生するかテストする。
        """
        path = self.test_dir / "created_dir"
        path.mkdir()
        with self.assertRaises(FileExistsError):
            LocalTarget(path).touch()

    def test_touch_current_dir(self):
        """
        作成対象ファイルとしてカレントディレクトリを指定した場合、
        期待通り FileExistsError が発生するかテストする。
        """
        with self.assertRaises(FileExistsError):
            LocalTarget("").touch()

    def test_delete(self):
        """
        LocalTarget が指定するディレクトリを削除できるかテストする。
        """
        test_file01 = self.test_dir / "test_01.txt"
        test_file01.touch()

        test_file02 = self.test_dir / "test_02.txt"
        test_file02.touch()

        LocalTarget(test_file01).delete()
        self.assertFalse(test_file01.exists())

        test_dir = self.test_dir / "test"
        test_dir.mkdir()
        test_file03 = test_dir / "test_03.txt"
        test_file03.touch()

        LocalTarget(test_dir).delete()
        self.assertFalse(test_dir.exists())
        self.assertFalse(test_file03.exists())

    def test_delete_file(self):
        """
        LocalTarget が指定するファイルを削除できるかテストする。
        """
        LocalTarget(self.test_file).delete()
        # ファイルが消えているか確認
        self.assertFalse(self.test_file.exists())

    def test_delete_file_err(self):
        """
        削除対象のパスが存在しない場合、
        期待通り FileNotFoundError が発生するかテストする。
        """
        with self.assertRaises(FileNotFoundError):
            LocalTarget(self.test_dir / "not_exists").delete()

    def test_delete_dir_err(self):
        """
        削除対象ファイルとしてカレントディレクトリを指定した場合、
        期待通り ValueError が発生するかテストする。
        """
        with self.assertRaises(ValueError):
            LocalTarget("").delete()

    def test_copy_file(self):
        """
        LocalTarget が指定するファイルを存在しないファイルに対してコピーした時、
        指定したコピー先にファイルが作成されていることをテストする。
        """
        temp_dir = self.test_dir / "dir01"
        temp_dir.mkdir()

        test_file01 = temp_dir / "test_01.txt"
        test_file01.touch()

        # コピー先のパス
        test_file02 = temp_dir / "test_02.txt"

        src = LocalTarget(test_file01)
        dst = LocalTarget(test_file02)

        src.copy_to(dst)

        self.assertTrue(src.exists())
        self.assertTrue(dst.exists())

    def test_copy_file_to_exists_file(self):
        """
        LocalTarget が指定するファイルと同名のファイルがすでに存在する場合、
        指定したコピー先のファイルが上書きされていることをテストする。
        """
        temp_dir = self.test_dir / "dir01"
        temp_dir.mkdir()

        test_file01 = temp_dir / "test_01.txt"
        test_file01.touch()
        with open(str(test_file01), "w") as f:
            f.write("test")

        # コピー先のパス
        test_file02 = temp_dir / "test_02.txt"
        test_file02.touch()

        src = LocalTarget(test_file01)
        dst = LocalTarget(test_file02)

        src.copy_to(dst)

        self.assertTrue(src.exists())
        with open(str(test_file02), "r") as f:
            contents = f.read()
        self.assertEqual(contents, "test")

    def test_copy_dir(self):
        """
        LocalTargetが指定するディレクトリを存在しないディレクトリに対してコピーした時、
        指定したコピー先にディレクトリとディレクトリ内のファイルが作成されていることをテストする。
        """
        temp_dir = self.test_dir / "dir01"
        temp_dir.mkdir()

        test_file01 = temp_dir / "test_01.txt"
        test_file01.touch()
        test_file02 = temp_dir / "test_02.txt"
        test_file02.touch()

        # ディレクトリを作成してコピー
        copied = self.test_dir / "copied_notexists"
        src = LocalTarget(temp_dir)
        dst = LocalTarget(copied)
        src.copy_to(dst)
        copied_file01 = copied / "test_01.txt"
        copied_file02 = copied / "test_02.txt"
        self.assertTrue(copied_file01)
        self.assertTrue(copied_file02)

    def test_copy_dir_to_exists_dir(self):
        """
        LocalTarget が指定するディレクトリと同名のディレクトリがすでに存在する場合、
        指定したコピー先ディレクトリ内にファイルが作成されていることをテストする。
        """
        temp_dir = self.test_dir / "dir01"
        temp_dir.mkdir()

        test_file01 = temp_dir / "test_01.txt"
        test_file01.touch()
        with open(str(test_file01), "w") as f:
            f.write("test")
        test_file02 = temp_dir / "test_02.txt"
        test_file02.touch()

        # 既存のディレクトリにコピー
        copied = self.test_dir / "copied_created"
        copied.mkdir()
        src = LocalTarget(temp_dir)
        dst = LocalTarget(copied)
        src.copy_to(dst)
        self.assertTrue(LocalTarget(copied / "test_01.txt").exists())
        self.assertTrue(LocalTarget(copied / "test_02.txt").exists())
        with open(str(copied / "test_01.txt"), "r") as f:
            contents = f.read()
        self.assertEqual(contents, "test")

    def test_copy_file_to_dir_failue(self):
        """
        ファイルのコピー先ディレクトリと同名のディレクトリがすでに存在する場合、
        期待通り FileExistsError が発生するかテストする。
        """
        temp_dir = self.test_dir / "dir01"
        temp_dir.mkdir()
        test_file01 = temp_dir / "test_01.txt"
        test_file01.touch()

        dst_dir = self.test_dir / "dst"
        dst_dir.mkdir()

        src = LocalTarget(test_file01)
        dst = LocalTarget(temp_dir)

        with self.assertRaises(FileExistsError):
            src.copy_to(dst)

    def test_copy_dir_to_file_failue(self):
        """
        ディレクトリのコピー先ファイルと同名のファイルがすでに存在する場合、
        期待通り FileExistsError が発生するかテストする。
        """
        temp_dir = self.test_dir / "dir01"
        temp_dir.mkdir()
        test_file01 = temp_dir / "test_01.txt"
        test_file01.touch()

        dst_file = self.test_dir / "dst.txt"
        dst_file.touch()

        src = LocalTarget(temp_dir)
        dst = LocalTarget(dst_file)

        with self.assertRaises(FileExistsError):
            src.copy_to(dst)

    def test_copy_directory_err1(self):
        """
        コピー元のパスが存在しない場合、
        期待通り FileNotFoundError が発生するかテストする。
        """
        src = LocalTarget(self.test_dir / "src2")
        dst = LocalTarget(self.test_dir / "dst2")

        # コピー元が存在しないケース
        with self.assertRaises(FileNotFoundError):
            src.copy_to(dst)

    def test_copy_multi_hierarchical_dir(self):
        """
        LocalTargetが指定するディレクトリが複数階層(ディレクトリ内にディレクトリ)になっており、存在しないディレクトリに対してコピーした時、
        指定したコピー先にディレクトリとディレクトリ内のファイルが作成されていることをテストする。
        """
        temp_dir01 = self.test_dir / "dir01"
        temp_dir02 = temp_dir01 / "dir02"
        temp_dir01.mkdir()
        temp_dir02.mkdir()

        test_file01 = temp_dir01 / "test_01.txt"
        test_file01.touch()
        test_file02 = temp_dir02 / "test_02.txt"
        test_file02.touch()

        # ディレクトリを作成してコピー
        copied = self.test_dir / "copied_notexists"
        src = LocalTarget(temp_dir01)
        dst = LocalTarget(copied)
        src.copy_to(dst)
        copied_file01 = copied / "test_01.txt"
        copied_file02 = copied / "dir02" / "test_02.txt"
        self.assertTrue(copied_file01.exists())
        self.assertTrue(copied_file02.exists())

    def test_children(self):
        """
        LocalTarget から、子階層のファイルを正しく取得できるかテストする。
        """
        self.test_dir = pathlib.Path(tempfile.mkdtemp())
        # os.path.basename と同一の結果になるかテスト
        (self.test_dir / "dir01_01").mkdir()
        (self.test_dir / "dir01_02").mkdir()
        (self.test_dir / "dir01_01" / "dir02_01").mkdir()

        (self.test_dir / "dir01_01" / "test01.txt").touch()
        (self.test_dir / "dir01_02" / "test02.txt").touch()
        (self.test_dir / "dir01_01" / "dir02_01" / "test03.txt").touch()

        p = LocalTarget(self.test_dir)
        res = sorted(p.children)

        exp = [
            LocalTarget(self.test_dir / "dir01_01" / "test01.txt"),
            LocalTarget(self.test_dir / "dir01_02" / "test02.txt"),
            LocalTarget(self.test_dir / "dir01_01" / "dir02_01" / "test03.txt"),
        ]
        self.assertEqual(res, sorted(exp))

    def test_children_empty(self):
        """
        LocalTarget から、子階層のファイルを正しく取得できるかテストする。
        """
        self.test_dir = pathlib.Path(tempfile.mkdtemp())
        (self.test_dir / "dir01_01").mkdir()
        (self.test_dir / "dir01_02").mkdir()
        (self.test_dir / "dir01_01" / "dir02_01").mkdir()

        p = LocalTarget(self.test_dir)
        res = sorted(p.children)

        exp = []
        self.assertEqual(res, sorted(exp))

    def test_relative_to(self):
        """
        LocalTarget 同士の相対パスを正しく取得できるかテストする。
        """
        p1 = LocalTarget(self.test_dir / "dir01_01" / "test01.txt")
        p2 = LocalTarget(self.test_dir)
        self.assertEqual(p1.relative_to(p2), pathlib.Path("dir01_01", "test01.txt"))

        p1 = LocalTarget(self.test_dir / "dir01_01" / "dir02_01" / "test03.txt")
        self.assertEqual(
            p1.relative_to(p2), pathlib.Path("dir01_01", "dir02_01", "test03.txt")
        )

    def test_relative_to_raises(self):
        """
        LocalTarget 同士の相対パスが算出できない場合 (ディレクトリが異なる)
        に期待通り ValueError が発生するかテストする。
        """
        p1 = LocalTarget(self.test_dir / "dir01_01" / "test01.txt")
        p2 = LocalTarget(self.test_dir)
        with self.assertRaises(ValueError):
            p2.relative_to(p1)

    def test_joinpath(self):
        """
        LocalTarget のパスを正しく結合できるかテストする。
        """
        p1 = LocalTarget("dir01")
        exp = LocalTarget("dir01/x/y.txt")
        self.assertEqual(p1.joinpath("x", "y.txt"), exp)

    def test_md5(self):
        """
        LocalTarget のMD5ハッシュ値が正しく取得できるかテストする。
        """
        res = LocalTarget(self.TEST_DATA / "upload.csv").md5
        if compat.IS_WINDOWS:
            self.assertEqual(res, "b2904b2053a65acddd13df280545e45c")
        else:
            self.assertEqual(res, "c8263e8422925b0872ee1fb7c953742a")

    def test_md5_not_files(self):
        """
        LocalTarget の対象がディレクトリ、もしくは存在しない場合に、
        期待通り FileNotFoundError が発生するかテストする。
        """
        with self.assertRaises(FileNotFoundError):
            LocalTarget(self.TEST_DATA).md5

        with self.assertRaises(FileNotFoundError):
            LocalTarget("notexists").md5

    def test_glob(self):
        """
        LocalTarget のパス内にあるファイルのうち、指定したパターンに一致するすべてのファイルを正しく取得できるかテストする。
        """
        test_file = self.test_dir / "test.txt"
        test_file01 = self.test_dir / "test_001.txt"
        test_file02 = self.test_dir / "test_002.txt"
        test_file03 = self.test_dir / "test_003.txt"
        test_file.touch()
        test_file01.touch()
        test_file02.touch()
        test_file03.touch()

        self.assertEqual(
            tuple(LocalTarget(self.test_dir).glob("test_*")),
            tuple(
                [
                    LocalTarget(test_file01),
                    LocalTarget(test_file02),
                    LocalTarget(test_file03),
                ]
            ),
        )
        self.assertEqual(
            tuple(LocalTarget(self.test_dir).glob("*.txt")),
            tuple(
                [
                    LocalTarget(test_file),
                    LocalTarget(test_file01),
                    LocalTarget(test_file02),
                    LocalTarget(test_file03),
                ]
            ),
        )
