import pathlib
import tempfile
from threading import Thread
import time

from batch_architecture.testing import TestCase
from batch_architecture.client import FTPClient
from batch_architecture.io_target import LocalTarget, FTPTarget


class TestFTPtarget(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_ftp_server()

        ftp = FTPClient()
        ftp.connect(cls.FTP_HOST)
        assert ftp.pwd() == "/"

        # アップロードするファイルのパス
        testdata = cls.TEST_DATA

        ftp.upload(testdata / "upload.csv", "data.csv")

        ftp.mkdir("dir1", cwd=False)
        ftp.upload(testdata / "data_sjis.csv", "dir1/data_sjis.csv")
        ftp.upload(testdata / "data_utf8.csv", "dir1/data_utf8.csv")

    def setUp(self):
        self.upload_file = self.TEST_DATA / "upload.csv"

        self.download_dir = pathlib.Path(tempfile.mkdtemp())
        self.download_file = self.download_dir / "download.csv"

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_ftp_server()

    def tearDown(self):
        LocalTarget(self.download_dir).delete()
        self.assertFalse(self.download_file.exists())

    def test_init(self):
        """FTPTarget インスタンスが正しく初期化できるかテストする。"""
        p = FTPTarget(self.FTP_HOST + "/test_dir")
        self.assertEqual(p._hostname, self.FTP_HOST)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir"))

        with self.assertRaises(ValueError):
            FTPTarget("test_dir")

    def test_init_args(self):
        """
        FTPTarget インスタンスにオプショナル引数を
        指定して正しく初期化できるかテストする。
        """
        p = FTPTarget("/test_dir", hostname=self.FTP_HOST)
        self.assertEqual(p._hostname, self.FTP_HOST)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir"))

        p = FTPTarget("test_dir", hostname=self.FTP_HOST)
        self.assertEqual(p._hostname, self.FTP_HOST)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir"))

    def test_init_path(self):
        """
        FTPTarget インスタンスを Path インスタンスから正しく初期化できるかテストする。
        """
        p = FTPTarget(pathlib.PurePosixPath(self.FTP_HOST + "/test_dir"))
        self.assertEqual(p._hostname, self.FTP_HOST)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir"))

    def test_basename(self):
        """
        FTPTarget のパスから、最下層の名前を正しく取得できるかテストする。
        """
        p = FTPTarget(self.FTP_HOST + "/test_dir/test.txt")
        self.assertEqual(p.basename, "test.txt")

        p = FTPTarget(self.FTP_HOST + "/test.txt")
        self.assertEqual(p.basename, "test.txt")

        p = FTPTarget(self.FTP_HOST + "/test_dir/")
        self.assertEqual(p.basename, "test_dir")

        p = FTPTarget(self.FTP_HOST + "/test_dir")
        self.assertEqual(p.basename, "test_dir")

    def test_repr(self):
        """
        FTPTarget の表示名が期待通りかテストする。
        """
        dir_path = self.FTP_HOST + "/dir1"
        exp = "FTPTarget({0})[ディレクトリ]".format(dir_path)
        self.assertEqual(str(FTPTarget(dir_path)), exp)

        file_path = self.FTP_HOST + "/data.csv"
        exp = "FTPTarget({0})[ファイル]".format(file_path)
        self.assertEqual(str(FTPTarget(file_path)), exp)

        file_path = self.FTP_HOST + "/dir1/data_sjis.csv"
        exp = "FTPTarget({0})[ファイル]".format(file_path)
        self.assertEqual(str(FTPTarget(file_path)), exp)

        notexists = self.FTP_HOST + "/notexists.txt"
        exp = "FTPTarget({0})[存在しない]".format(notexists)
        self.assertEqual(str(FTPTarget(notexists)), exp)

        notexists = "not_server/notexists.txt"
        exp = "FTPTarget({0})[サーバ接続不可]".format(notexists)
        self.assertEqual(str(FTPTarget(notexists)), exp)

    def test_mkdir(self):
        """
        FTPTarget が指定するパスにディレクトリを作成できるかテストする。
        """
        # 作成前
        p = FTPTarget(self.FTP_HOST + "/test_dir")
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        # ディレクトリ作成
        p.mkdir()
        self.assertEqual(p.client.pwd(), "/")
        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        # ディレクトリ削除
        p.delete()
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

    def test_mkdir_multilevel(self):
        """
        作成対象ディレクトリの親ディレクトリが存在しない場合、
        parents=True を指定すると親ディレクトリも含めて作成されることを
        テストする。
        """
        # 作成前
        p = FTPTarget(self.FTP_HOST + "/test_dirA/test_dirB")
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        # ディレクトリ作成
        p.mkdir(parents=True)
        self.assertEqual(p.client.pwd(), "/")
        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        p.delete()
        self.assertFalse(p.exists())

        p = FTPTarget(self.FTP_HOST + "/test_dirA")
        p.delete()
        self.assertFalse(p.exists())

    def test_mkdir_error_multilevel(self):
        """
        作成対象ディレクトリの親ディレクトリが存在しない場合、
        期待通り FileNotFoundErrorが発生することをテストする。
        """
        # パスに存在しない複数階層を指定したケース
        t = FTPTarget(self.FTP_HOST + "/A/B")
        self.assertFalse(t.exists())
        with self.assertRaises(FileNotFoundError):
            t.mkdir(parents=False)

    def test_mkdir_error_exists(self):
        """
        作成対象ディレクトリと同名のディレクトリがすでに存在する場合、
        期待通り FileExistsErrorが発生することをテストする。
        """
        # パスに存在しない複数階層を指定したケース
        t = FTPTarget(self.FTP_HOST + "/A/B")
        self.assertFalse(t.exists())

        t.mkdir(parents=True)
        self.assertTrue(t.exists())

        # すでに対象ディレクトリが存在する
        with self.assertRaises(FileExistsError):
            t.mkdir()

        t.mkdir(exist_ok=True)
        self.assertTrue(t.exists())

        p = FTPTarget(self.FTP_HOST + "/A")
        p.delete()

    def test_delete_multilevel(self):
        """
        複数階層のディレクトリを一度に削除できることをテストする。
        """
        # ディレクトリ作成
        p = FTPTarget(self.FTP_HOST + "/test_dirA/test_dirB")
        p.mkdir(parents=True)
        self.assertEqual(p.client.pwd(), "/")

        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        parent = FTPTarget(self.FTP_HOST + "/test_dirA")
        self.assertTrue(parent.exists())
        parent.delete()
        self.assertFalse(parent.exists())

    def test_connect_upload_files(self):
        """
        ローカル・FTP間でファイル転送できるかテストする。
        """
        # upload するファイルパス
        p = FTPTarget(self.FTP_HOST + "/test.txt")

        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        # FTPアップロード
        LocalTarget(self.upload_file).copy_to(p)
        self.assertTrue(p.exists())
        self.assertFalse(p.is_dir())
        self.assertTrue(p.is_file())

        # FTPダウンロード
        p.copy_to(LocalTarget(self.download_file))

        self.assertTrue(self.download_file.exists())
        with self.download_file.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        p.delete()
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        self.download_file.unlink()
        self.assertFalse(self.download_file.exists())

    def test_upload_multilevel(self):
        """
        ローカル・FTP間で、複数階層下のファイル転送ができるかテストする。
        """
        # test_dir1/test_dir2/test.txt の階層を作成
        ftp_path = FTPTarget(self.FTP_HOST + "/test_dir1/test_dir2/test.txt")
        self.assertFalse(ftp_path.exists())
        self.assertFalse(ftp_path.is_dir())
        self.assertFalse(ftp_path.is_file())

        ftp_dir = FTPTarget(self.FTP_HOST + "/test_dir1/test_dir2")
        ftp_dir.mkdir(parents=True)
        self.assertEqual(ftp_dir.client.pwd(), "/")

        # ファイルのアップロード
        src = LocalTarget(self.upload_file)
        src.copy_to(ftp_path)

        # 処理後はルートディレクトリに戻っているため、再度CWD
        self.assertTrue(ftp_path.exists())
        self.assertFalse(ftp_path.is_dir())
        self.assertTrue(ftp_path.is_file())

        # FTPダウンロード
        dst = LocalTarget(self.download_file)
        ftp_path.copy_to(dst)
        self.assertTrue(dst.exists())

        with dst._path.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        # 処理後はルートディレクトリに戻っている)
        FTPTarget(self.FTP_HOST + "/test_dir1").delete()

        self.assertFalse(ftp_path.exists())
        self.assertFalse(ftp_path.is_dir())
        self.assertFalse(ftp_path.is_file())

    def upload_multifiles(self):
        # test_dir1/test_dir2/test_XX.txt の階層を作成
        ftp_path = FTPTarget(self.FTP_HOST + "/test_dir1/test_dir2")
        ftp_path.mkdir(parents=True)
        self.assertEqual(ftp_path.client.pwd(), "/")

        # ファイルのアップロード
        src = LocalTarget(self.upload_file)

        f1 = FTPTarget(self.FTP_HOST + "/test_dir1/test_dir2/test_01.txt")
        f2 = FTPTarget(self.FTP_HOST + "/test_dir1/test_dir2/test_02.txt")
        f3 = FTPTarget(self.FTP_HOST + "/test_dir1/test_dir2/test_03.txt")
        src.copy_to(f1)
        src.copy_to(f2)
        src.copy_to(f3)

        for f in [f1, f2, f3]:
            self.assertTrue(f.exists())
            self.assertFalse(f.is_dir())
            self.assertTrue(f.is_file())

    def clean_multifiles(self):
        # 処理後はルートディレクトリに戻っている
        d = FTPTarget(self.FTP_HOST + "/test_dir1")
        d.delete()
        self.assertFalse(d.exists())

    def test_upload_multilevel_multifiles(self):
        """
        ローカル・FTP間で、複数階層下のディレクトリ転送ができるかテストする。
        """
        self.upload_multifiles()

        # ダウンロード用ディレクトリを作成
        download_dir = self.download_dir / "dldir"
        download_dir.mkdir(parents=True)

        # FTPダウンロード
        ftp_path = FTPTarget(self.FTP_HOST + "/test_dir1/test_dir2")
        self.assertTrue(ftp_path.is_dir())
        ftp_path.copy_to(LocalTarget(download_dir))

        downloaded = [
            download_dir / "test_01.txt",
            download_dir / "test_02.txt",
            download_dir / "test_03.txt",
        ]

        for d in downloaded:
            self.assertTrue(d.exists())
            with d.open() as data:
                self.assertEqual(data.readline(), "1,2,3\n")

        self.clean_multifiles()

        # ダウンロード用ディレクトリ削除
        LocalTarget(download_dir).delete()
        self.assertFalse(download_dir.exists())

    def test_upload_multilevel_multifiles_mkdir(self):
        """
        ローカル・FTP間で、複数階層下のディレクトリ転送ができるかテストする。
        FTP からのダウンロードの際に存在しないディレクトリを指定すると、そのディレクトリを
        新規作成してダウンロードできることをテストする。
        """
        self.upload_multifiles()

        # ダウンロード用ディレクトリに存在しないディレクトリを指定
        download_dir = self.download_dir / "dldir"
        self.assertFalse(download_dir.exists())

        # FTPダウンロード
        FTPTarget(self.FTP_HOST + "/test_dir1/test_dir2").copy_to(
            LocalTarget(download_dir)
        )

        downloaded = [
            download_dir / "test_01.txt",
            download_dir / "test_02.txt",
            download_dir / "test_03.txt",
        ]

        for d in downloaded:
            self.assertTrue(d.exists())
            with d.open() as data:
                self.assertEqual(data.readline(), "1,2,3\n")

        self.clean_multifiles()

    def test_upload_multilevel_notexists(self):
        """
        ローカルからFTPへ、ディレクトリを新規作成して
        ファイルがアップロードできることをテストする。
        """
        # アップロード先のディレクトリが存在しない場合は作成する
        src = LocalTarget(self.upload_file)
        dst = FTPTarget(self.FTP_HOST + "/test_dir1/test.txt")
        self.assertFalse(dst.exists())

        src.copy_to(dst)
        self.assertTrue(dst.is_file())
        FTPTarget(self.FTP_HOST + "/test_dir1").delete()

    def test_download_multilevel_notexists(self):
        """
        FTP からローカルへファイルをダウンロードするとき、
        ダウンロード元のファイルが存在しない場合 期待通り
        FileNotFoundError が発生することをテストする。
        """
        # ダウンロード元のファイルが存在しない場合はダウンロードできない
        src = FTPTarget(self.FTP_HOST + "/test_dir1/not_exists.txt")
        dst = LocalTarget(self.download_file)
        self.assertFalse(src.exists())

        with self.assertRaises(FileNotFoundError):
            src.copy_to(dst)

    def test_copy_to_temporary_file(self):
        """
        FTP からローカルへ、一時ファイルを作成してファイルをダウンロードできるかテストする。
        """
        # ダウンロード するファイルパス
        p = FTPTarget(self.FTP_HOST + "/test.txt")
        LocalTarget(self.upload_file).copy_to(p)
        self.assertTrue(p.exists())
        self.assertFalse(p.is_dir())
        self.assertTrue(p.is_file())

        # FTPダウンロード
        res = p.copy_to_temporary()
        self.assertTrue(res.exists())
        self.assertFalse(res.is_dir())
        self.assertTrue(res.is_file())

        self.assertEqual(res.basename, p.basename)
        with res._path.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        p.delete()
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        res.delete()
        self.assertFalse(res.exists())

    def test_copy_to_temporary_dir(self):
        """
        FTP からローカルへ、一時ディレクトリを作成してディレクトリをダウンロードできるかテストする。
        """
        self.upload_multifiles()

        # FTPダウンロード
        res = FTPTarget(self.FTP_HOST + "/test_dir1/test_dir2").copy_to_temporary()
        self.assertTrue(res.exists())
        self.assertTrue(res.is_dir())
        self.assertFalse(res.is_file())

        downloaded = [
            res._path / "test_01.txt",
            res._path / "test_02.txt",
            res._path / "test_03.txt",
        ]

        for d in downloaded:
            self.assertTrue(d.exists())
            with d.open() as data:
                self.assertEqual(data.readline(), "1,2,3\n")

        self.clean_multifiles()
        res.delete()
        self.assertFalse(res.exists())

    def test_children(self):
        """
        FTPTarget から、子階層のファイルを正しく取得できるかテストする。
        """
        ftp = FTPClient()
        res = ftp.connect(self.FTP_HOST)
        assert ftp.pwd() == "/"

        # アップロードするファイルのパス
        testdata = self.TEST_DATA

        ftp.mkdir("temp/dir01_01/dir02_01", cwd=False, parents=True)
        ftp.mkdir("temp/dir01_02", cwd=False, parents=True)

        ftp.upload(testdata / "upload.csv", "temp/dir01_01/test01.txt")
        ftp.upload(testdata / "upload.csv", "temp/dir01_02/test02.txt")
        ftp.upload(testdata / "upload.csv", "temp/dir01_01/dir02_01/test03.txt")

        p = FTPTarget(self.FTP_HOST + "/temp")
        res = sorted(p.children)

        exp = [
            FTPTarget(self.FTP_HOST + "/temp/dir01_01/test01.txt"),
            FTPTarget(self.FTP_HOST + "/temp/dir01_02/test02.txt"),
            FTPTarget(self.FTP_HOST + "/temp/dir01_01/dir02_01/test03.txt"),
        ]
        self.assertEqual(res, sorted(exp))

    def test_relative_to(self):
        """
        FTPTarget 同士の相対パスを正しく取得できるかテストする。
        """
        p1 = FTPTarget(self.FTP_HOST + "/dir01/test01.txt")
        p2 = FTPTarget(self.FTP_HOST + "/dir01")
        self.assertEqual(p1.relative_to(p2), pathlib.Path("test01.txt"))

        p3 = FTPTarget(self.FTP_HOST + "/")
        self.assertEqual(p1.relative_to(p3), pathlib.Path("dir01/test01.txt"))

    def test_relative_to_raises(self):
        """
        FTPTarget 同士の相対パスが算出できない場合 (ディレクトリが異なる、
        バケットが異なる) に期待通り ValueError が発生するかテストする。
        """
        p1 = FTPTarget(self.FTP_HOST + "/dir01/test01.txt")
        p2 = FTPTarget(self.FTP_HOST + "/dir02")
        with self.assertRaises(ValueError):
            p2.relative_to(p1)

        p3 = FTPTarget("different_ftp_server/dir01")
        with self.assertRaises(ValueError):
            p3.relative_to(p1)

        p4 = LocalTarget("dir01")
        with self.assertRaises(ValueError):
            p4.relative_to(p1)

    def test_md5(self):
        """
        FTPTarget のMD5ハッシュ値を取得したとき、
        期待通り NotImplementedError が発生することをテストする。
        """
        with self.assertRaises(NotImplementedError):
            FTPTarget("data.csv", hostname=self.FTP_HOST).md5

        with self.assertRaises(FileNotFoundError):
            FTPTarget("dir1", hostname=self.FTP_HOST).md5

        with self.assertRaises(FileNotFoundError):
            FTPTarget("notexists", hostname=self.FTP_HOST).md5


class FTPThread(Thread):
    """
    FTPサーバを実行するスレッド
    """

    def run(self):
        import pyftpdlib.authorizers
        import pyftpdlib.handlers
        import pyftpdlib.servers

        # ユーザー追加
        authorizer = pyftpdlib.authorizers.DummyAuthorizer()
        path = "batch_architecture/tests/testdata"
        authorizer.add_user("myuser", "mypasswd", path, perm="elradfmw")

        # サーバ起動
        handler = pyftpdlib.handlers.FTPHandler
        handler.authorizer = authorizer
        server = pyftpdlib.servers.FTPServer(("127.0.0.1", 10021), handler)
        server.serve_forever()


class TestFTPAuth(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.thread = FTPThread()
        cls.thread.daemon = True
        cls.thread.start()
        time.sleep(0.1)

    def test_ftp_auth(self):
        """
        認証付きのFTPサーバに正しく接続できるかテストする。
        """
        t = FTPTarget("myuser:mypasswd@127.0.0.1:10021/")
        exp = "FTPTarget({0})[ディレクトリ]".format("127.0.0.1/.")
        self.assertEqual(str(t), exp)

        # ユーザ名が間違っている場合は接続できない
        t = FTPTarget("incorrect:mypasswd@127.0.0.1:10021/")
        exp = "FTPTarget({0})[サーバ接続不可]".format("127.0.0.1/.")
        self.assertEqual(str(t), exp)

        # ユーザ名が間違っている場合は接続できない
        t = FTPTarget("127.0.0.1:10021/")
        exp = "FTPTarget({0})[サーバ接続不可]".format("127.0.0.1/.")
        self.assertEqual(str(t), exp)
