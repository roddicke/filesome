import os
import pathlib
import tempfile
import urllib.request

from batch_architecture.testing import TestCase
from batch_architecture.io_target import LocalTarget, HTTPTarget


class TestHTTPTarget(TestCase):

    # 正しく接続されるURL
    url = "https://ja.wikipedia.org/wiki/Python"
    # ファイルが存在しないURL
    not_found_url = "https://ja.wikipedia.org/wiki2/Python"
    # サーバエラーが発生するURL
    server_error_url = "https://ja.wikipedia.org2/wiki/Python"

    def test_init(self):
        """HTTPTarget インスタンスが正しく初期化できるかテストする。"""
        b = HTTPTarget(path=self.url)
        self.assertEqual(b._url, self.url)

        with self.assertRaises(ValueError):
            HTTPTarget("")

    def test_eq(self):
        """
        HTTPTarget インスタンスの同値性が正しくチェックできるかテストする。
        """
        b1 = HTTPTarget(path=self.url)
        self.assertTrue(b1 == b1)

        b2 = HTTPTarget(path=self.url)
        self.assertTrue(b1 == b2)

        # 正しいURL(2個目)を指定
        b3 = HTTPTarget(path="https://docs.python.jp/3.5/")
        self.assertFalse(b1 == b3)

    def test_existence_file(self):
        """
        HTTPTarget インスタンスがファイルの場合、対象が存在するか・ディレクトリか・ファイルか、
        をチェックするメソッドが期待通り動作するかテストする。

        - 存在するか (exists): True
        - ディレクトリか (is_dir): False
        - ファイルか (is_file): True
        """
        p = HTTPTarget(path=self.url)
        self.assertTrue(p.exists())
        self.assertFalse(p.is_dir())
        self.assertTrue(p.is_file())

    def test_existence_not_found(self):
        """
        HTTPTarget インスタンスが存在しない場合、対象が存在するか・ディレクトリか・ファイルか、
        をチェックするメソッドが期待通り動作するかテストする。

        - 存在するか (exists): False
        - ディレクトリか (is_dir): False
        - ファイルか (is_file): False
        """

        p = HTTPTarget(path=self.not_found_url)
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        p = HTTPTarget(path=self.server_error_url)
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

    def test_repr(self):
        """
        HTTPTarget の表示名が期待通りかテストする。
        """
        exp = "HTTPTarget({0})[ファイル]".format(self.url)
        self.assertEqual(str(HTTPTarget(path=self.url)), exp)

        exp = "HTTPTarget({0})[存在しない]".format(self.not_found_url)
        self.assertEqual(str(HTTPTarget(self.not_found_url)), exp)

        exp = "HTTPTarget({0})[サーバ接続不可]".format(self.server_error_url)
        self.assertEqual(str(HTTPTarget(self.server_error_url)), exp)

    def test_children(self):
        """
        HTTPTarget から、子階層のファイルを取得した場合、
        期待通り NotImplementedError が発生するかテストする。
        """
        with self.assertRaises(NotImplementedError):
            HTTPTarget(self.url).children

    def test_delete(self):
        """
        delete
        """
        p = HTTPTarget(self.url)
        with self.assertRaises(NotImplementedError):
            p.delete()

    def test_download_file(self):
        """
        HTTPTarget を削除しようとした場合、
        期待通り NotImplementedError が発生するかテストする。
        """
        src = HTTPTarget(self.url)

        path = os.path.join(tempfile.mkdtemp(), "test01.txt")
        dst = LocalTarget(path)

        src.copy_to(dst)
        self.assertTrue(dst.exists())
        self.assertFalse(dst.is_dir())
        self.assertTrue(dst.is_file())

        dst.delete()
        self.assertFalse(dst.exists())

    def test_upload_file(self):
        """
        HTTPTarget へファイルをアップロードしようとした場合、
        期待通り NotImplementedError が発生するかテストする。
        """
        src = pathlib.Path(tempfile.mkdtemp()) / "test.txt"
        src.touch()

        src = LocalTarget(src)
        dst = HTTPTarget(self.url)

        with self.assertRaises(NotImplementedError):
            src.copy_to(dst)

        src.delete()

    def test_copy_to_temporary_file(self):
        """
        HTTP からローカルへ、一時ファイルを作成してファイルをダウンロードできるかテストする。
        """
        src = HTTPTarget(self.url)

        res = src.copy_to_temporary()
        self.assertTrue(res.exists())
        self.assertFalse(res.is_dir())
        self.assertTrue(res.is_file())

        res.delete()
        self.assertFalse(res.exists())

    def test_read(self):
        """
        HTTP 上のファイルの中身が正しく読み込めるかテストする。
        """
        t = HTTPTarget(self.url)
        res1 = t.read()
        resp2 = urllib.request.urlopen(self.url)
        res2 = resp2.read()
        self.assertEqual(res1, res2)
