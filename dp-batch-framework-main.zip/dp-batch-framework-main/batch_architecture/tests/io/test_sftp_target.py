import pathlib
import tempfile
from threading import Thread
import time

from batch_architecture.testing import TestCase
from batch_architecture.client import SFTPClient
from batch_architecture.io_target import LocalTarget, SFTPTarget


class TestSFTPtarget(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_sftp_server()

        sftp = SFTPClient()
        sftp.connect(
            hostname=cls.SFTP_HOST, user=cls.SFTP_USER, port=22, passwd=cls.SFTP_PASS
        )
        assert sftp.pwd() == "/"

        # アップロードするファイルのパス
        testdata = cls.TEST_DATA
        sftp.cwd(cls.TEST_HOME_DIR)

        sftp.upload(str(testdata / "upload.csv"), "data.csv")

        sftp.mkdir("dir1", cwd=False)
        sftp.upload(str(testdata / "data_sjis.csv"), "dir1/data_sjis.csv")
        sftp.upload(str(testdata / "data_utf8.csv"), "dir1/data_utf8.csv")

    def setUp(self):
        self.upload_file = self.TEST_DATA / "upload.csv"

        self.download_dir = pathlib.Path(tempfile.mkdtemp())
        self.download_file = self.download_dir / "download.csv"

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_sftp_server()

    def tearDown(self):
        LocalTarget(self.download_dir).delete()
        self.assertFalse(self.download_file.exists())

    def test_init(self):
        """SFTPTarget インスタンスが正しく初期化できるかテストする。"""
        p = SFTPTarget(self.SFTP_HOST + "/test_dir")
        self.assertEqual(p._hostname, self.SFTP_HOST)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir"))

        with self.assertRaises(ValueError):
            SFTPTarget("test_dir")

    def test_init_args(self):
        """
        SFTPTarget インスタンスにオプショナル引数を
        指定して正しく初期化できるかテストする。
        """
        p = SFTPTarget("/test_dir", hostname=self.SFTP_HOST)
        self.assertEqual(p._hostname, self.SFTP_HOST)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir"))

        p = SFTPTarget("test_dir", hostname=self.SFTP_HOST)
        self.assertEqual(p._hostname, self.SFTP_HOST)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir"))

    def test_init_path(self):
        """
        SFTPTarget インスタンスを Path インスタンスから正しく初期化できるかテストする。
        """
        p = SFTPTarget(pathlib.PurePosixPath(self.SFTP_HOST + "/test_dir"))
        self.assertEqual(p._hostname, self.SFTP_HOST)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir"))

    def test_basename(self):
        """
        SFTPTarget のパスから、最下層の名前を正しく取得できるかテストする。
        """
        p = SFTPTarget(self.SFTP_HOST + "/test_dir/test.txt")
        self.assertEqual(p.basename, "test.txt")

        p = SFTPTarget(self.SFTP_HOST + "/test.txt")
        self.assertEqual(p.basename, "test.txt")

        p = SFTPTarget(self.SFTP_HOST + "/test_dir/")
        self.assertEqual(p.basename, "test_dir")

        p = SFTPTarget(self.SFTP_HOST + "/test_dir")
        self.assertEqual(p.basename, "test_dir")

    def test_repr(self):
        """
        SFTPTarget の表示名が期待通りかテストする。
        """
        dir_path = self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/dir1"
        exp = "SFTPTarget({0})[ディレクトリ]".format(dir_path)
        self.assertEqual(str(SFTPTarget(dir_path)), exp)

        file_path = self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/data.csv"
        exp = "SFTPTarget({0})[ファイル]".format(file_path)
        self.assertEqual(str(SFTPTarget(file_path)), exp)

        file_path = self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/dir1/data_sjis.csv"
        exp = "SFTPTarget({0})[ファイル]".format(file_path)
        self.assertEqual(str(SFTPTarget(file_path)), exp)

        notexists = self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/notexists.txt"
        exp = "SFTPTarget({0})[存在しない]".format(notexists)
        self.assertEqual(str(SFTPTarget(notexists)), exp)

        notexists = "not_server/notexists.txt"
        exp = "SFTPTarget({0})[サーバ接続不可]".format(notexists)
        self.assertEqual(str(SFTPTarget(notexists)), exp)

    def test_mkdir(self):
        """
        SFTPTarget が指定するパスにディレクトリを作成できるかテストする。
        """
        # 作成前
        p = SFTPTarget(self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dir")
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        # ディレクトリ作成
        p.mkdir()
        p.client.cwd(self.TEST_HOME_DIR)
        self.assertEqual(p.client.pwd(), self.TEST_HOME_DIR)
        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        # ディレクトリ削除
        p.delete()
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

    def test_mkdir_multilevel(self):
        """
        作成対象ディレクトリの親ディレクトリが存在しない場合、
        parents=True を指定すると親ディレクトリも含めて作成されることを
        テストする。
        """
        # 作成前
        p = SFTPTarget(
            self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dirA/test_dirB"
        )
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        # ディレクトリ作成
        p.mkdir(parents=True)
        p.client.cwd(self.TEST_HOME_DIR)
        self.assertEqual(p.client.pwd(), self.TEST_HOME_DIR)
        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        p.delete()
        self.assertFalse(p.exists())

        p = SFTPTarget(self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dirA")
        p.delete()
        self.assertFalse(p.exists())

    def test_mkdir_error_multilevel(self):
        """
        作成対象ディレクトリの親ディレクトリが存在しない場合、
        期待通り FileNotFoundErrorが発生することをテストする。
        """
        # パスに存在しない複数階層を指定したケース
        t = SFTPTarget(self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/A/B")
        self.assertFalse(t.exists())
        with self.assertRaises(FileNotFoundError):
            t.mkdir(parents=False)

    def test_mkdir_error_exists(self):
        """
        作成対象ディレクトリと同名のディレクトリがすでに存在する場合、
        期待通り FileExistsErrorが発生することをテストする。
        """
        # パスに存在しない複数階層を指定したケース
        t = SFTPTarget(self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/A/B")

        t.mkdir(parents=True)
        self.assertTrue(t.exists())

        # すでに対象ディレクトリが存在する
        with self.assertRaises(FileExistsError):
            t.mkdir()

        t.mkdir(exist_ok=True)
        self.assertTrue(t.exists())

        p = SFTPTarget(self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/A")
        p.delete()

    def test_delete_multilevel(self):
        """
        複数階層のディレクトリを一度に削除できることをテストする。
        """
        # ディレクトリ作成
        p = SFTPTarget(
            self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dirA/test_dirB"
        )
        p.mkdir(parents=True)
        self.assertEqual(p.client.pwd(), "/")

        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        parent = SFTPTarget(self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dirA")
        self.assertTrue(parent.exists())
        parent.delete()
        self.assertFalse(parent.exists())

    def test_connect_upload_files(self):
        """
        ローカル・SFTP間でファイル転送できるかテストする。
        """
        # upload するファイルパス
        p = SFTPTarget(self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test.txt")

        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        # SFTPアップロード
        LocalTarget(self.upload_file).copy_to(p)
        self.assertTrue(p.exists())
        self.assertFalse(p.is_dir())
        self.assertTrue(p.is_file())

        # SFTPダウンロード
        p.copy_to(LocalTarget(self.download_file))

        self.assertTrue(self.download_file.exists())
        with self.download_file.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        p.delete()
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        self.download_file.unlink()
        self.assertFalse(self.download_file.exists())

    def test_upload_multilevel(self):
        """
        ローカル・SFTP間で、複数階層下のファイル転送ができるかテストする。
        """
        # test_dir1/test_dir2/test.txt の階層を作成
        sftp_path = SFTPTarget(
            self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dir1/test_dir2/test.txt"
        )
        self.assertFalse(sftp_path.exists())
        self.assertFalse(sftp_path.is_dir())
        self.assertFalse(sftp_path.is_file())

        sftp_dir = SFTPTarget(
            self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dir1/test_dir2"
        )
        sftp_dir.mkdir(parents=True)
        self.assertEqual(sftp_dir.client.pwd(), "/")

        # ファイルのアップロード
        src = LocalTarget(self.upload_file)
        src.copy_to(sftp_path)

        # 処理後はルートディレクトリに戻っているため、再度CWD
        self.assertTrue(sftp_path.exists())
        self.assertFalse(sftp_path.is_dir())
        self.assertTrue(sftp_path.is_file())

        # SFTPダウンロード
        dst = LocalTarget(self.download_file)
        sftp_path.copy_to(dst)
        self.assertTrue(dst.exists())

        with dst._path.open() as data:
            self.assertEqual(data.readline(), "1,2,3\n")

        # 処理後はルートディレクトリに戻っている)
        SFTPTarget(self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dir1").delete()

        self.assertFalse(sftp_path.exists())
        self.assertFalse(sftp_path.is_dir())
        self.assertFalse(sftp_path.is_file())

    def upload_multifiles(self):
        # test_dir1/test_dir2/test_XX.txt の階層を作成
        sftp_path = SFTPTarget(
            self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dir1/test_dir2"
        )
        sftp_path.mkdir(parents=True)
        self.assertEqual(sftp_path.client.pwd(), "/")

        # ファイルのアップロード
        src = LocalTarget(self.upload_file)

        f1 = SFTPTarget(
            self.SFTP_HOST
            + "/"
            + self.TEST_HOME_DIR
            + "/test_dir1/test_dir2/test_01.txt"
        )
        f2 = SFTPTarget(
            self.SFTP_HOST
            + "/"
            + self.TEST_HOME_DIR
            + "/test_dir1/test_dir2/test_02.txt"
        )
        f3 = SFTPTarget(
            self.SFTP_HOST
            + "/"
            + self.TEST_HOME_DIR
            + "/test_dir1/test_dir2/test_03.txt"
        )
        src.copy_to(f1)
        src.copy_to(f2)
        src.copy_to(f3)

        for f in [f1, f2, f3]:
            self.assertTrue(f.exists())
            self.assertFalse(f.is_dir())
            self.assertTrue(f.is_file())

    def clean_multifiles(self):
        # 処理後はルートディレクトリに戻っている
        d = SFTPTarget(self.SFTP_HOST + "/" + self.TEST_HOME_DIR + "/test_dir1")
        d.delete()
        self.assertFalse(d.exists())

    def test_upload_multilevel_multifiles_mkdir(self):
        """
        ローカル・SFTP間で、複数階層下のディレクトリ転送ができるかテストする。
        SFTP からのダウンロードの際に存在しないディレクトリを指定すると、そのディレクトリを
        新規作成してダウンロードできることをテストする。
        """
        self.upload_multifiles()

        # ダウンロード用ディレクトリに存在しないディレクトリを指定
        download_dir = self.download_dir / "dldir"
        self.assertFalse(download_dir.exists())

        # SFTPダウンロード
        SFTPTarget(
            self.SFTP_HOST + self.TEST_HOME_DIR + "/test_dir1/test_dir2"
        ).copy_to(LocalTarget(download_dir))

        downloaded = [
            download_dir / "test_01.txt",
            download_dir / "test_02.txt",
            download_dir / "test_03.txt",
        ]

        for d in downloaded:
            self.assertTrue(d.exists())
            with d.open() as data:
                self.assertEqual(data.readline(), "1,2,3\n")

        self.clean_multifiles()

    def test_upload_multilevel_notexists(self):
        """
        ローカルからSFTPへ、ディレクトリを新規作成して
        ファイルがアップロードできることをテストする。
        """
        # アップロード先のディレクトリが存在しない場合は作成する
        src = LocalTarget(self.upload_file)
        dst = SFTPTarget(self.SFTP_HOST + self.TEST_HOME_DIR + "/test_dir1/test.txt")
        self.assertFalse(dst.exists())

        src.copy_to(dst)
        self.assertTrue(dst.is_file())
        SFTPTarget(self.SFTP_HOST + self.TEST_HOME_DIR + "/test_dir1").delete()

    def test_download_multilevel_notexists(self):
        """
        SFTP からローカルへファイルをダウンロードするとき、
        ダウンロード元のファイルが存在しない場合 期待通り
        FileNotFoundError が発生することをテストする。
        """
        # ダウンロード元のファイルが存在しない場合はダウンロードできない
        src = SFTPTarget(
            self.SFTP_HOST + self.TEST_HOME_DIR + "/test_dir1/not_exists.txt"
        )
        dst = LocalTarget(self.download_file)
        self.assertFalse(src.exists())

        with self.assertRaises(FileNotFoundError):
            src.copy_to(dst)

    def test_children(self):
        """
        SFTPTarget から、子階層のファイルを正しく取得できるかテストする。
        """
        sftp = SFTPClient()
        res = sftp.connect(
            hostname=self.SFTP_HOST, user=self.SFTP_USER, port=22, passwd=self.SFTP_PASS
        )
        assert sftp.pwd() == "/"

        # アップロードするファイルのパス
        testdata = self.TEST_DATA

        sftp.cwd(self.TEST_HOME_DIR)
        sftp.mkdir("temp/dir01_01/dir02_01", cwd=False, parents=True)
        sftp.mkdir("temp/dir01_02", cwd=False, parents=True)

        sftp.upload(testdata / "upload.csv", "temp/dir01_01/test01.txt")
        sftp.upload(testdata / "upload.csv", "temp/dir01_02/test02.txt")
        sftp.upload(testdata / "upload.csv", "temp/dir01_01/dir02_01/test03.txt")

        p = SFTPTarget(self.SFTP_HOST + self.TEST_HOME_DIR + "/temp")
        res = sorted(p.children)

        exp = [
            SFTPTarget(
                self.SFTP_HOST + self.TEST_HOME_DIR + "/temp/dir01_01/test01.txt"
            ),
            SFTPTarget(
                self.SFTP_HOST + self.TEST_HOME_DIR + "/temp/dir01_02/test02.txt"
            ),
            SFTPTarget(
                self.SFTP_HOST
                + self.TEST_HOME_DIR
                + "/temp/dir01_01/dir02_01/test03.txt"
            ),
        ]
        self.assertEqual(res, sorted(exp))

    def test_relative_to(self):
        """
        SFTPTarget 同士の相対パスを正しく取得できるかテストする。
        """
        p1 = SFTPTarget(self.SFTP_HOST + self.TEST_HOME_DIR + "/dir01/test01.txt")
        p2 = SFTPTarget(self.SFTP_HOST + self.TEST_HOME_DIR + "/dir01")
        self.assertEqual(p1.relative_to(p2), pathlib.PurePosixPath("test01.txt"))

        p3 = SFTPTarget(self.SFTP_HOST + "/")
        self.assertEqual(
            p1.relative_to(p3), pathlib.PurePosixPath("home/ec2-user/dir01/test01.txt")
        )

    def test_relative_to_raises(self):
        """
        SFTPTarget 同士の相対パスが算出できない場合 (ディレクトリが異なる、
        バケットが異なる) に期待通り ValueError が発生するかテストする。
        """
        p1 = SFTPTarget(self.SFTP_HOST + self.TEST_HOME_DIR + "/dir01/test01.txt")
        p2 = SFTPTarget(self.SFTP_HOST + self.TEST_HOME_DIR + "/dir02")
        with self.assertRaises(ValueError):
            p2.relative_to(p1)

        p3 = SFTPTarget("different_ftp_server/dir01")
        with self.assertRaises(ValueError):
            p3.relative_to(p1)

        p4 = LocalTarget("dir01")
        with self.assertRaises(ValueError):
            p4.relative_to(p1)

    def test_md5(self):
        """
        SFTPTarget のMD5ハッシュ値を取得したとき、
        期待通り NotImplementedError が発生することをテストする。
        """
        with self.assertRaises(NotImplementedError):
            SFTPTarget(self.TEST_HOME_DIR + "/data.csv", hostname=self.SFTP_HOST).md5

        with self.assertRaises(FileNotFoundError):
            SFTPTarget("dir1", hostname=self.SFTP_HOST).md5

        with self.assertRaises(FileNotFoundError):
            SFTPTarget("notexists", hostname=self.SFTP_HOST).md5
