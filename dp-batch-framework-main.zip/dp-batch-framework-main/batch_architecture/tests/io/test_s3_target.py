import datetime
import os
import pathlib
import tempfile
import time

import dateutil

from batch_architecture.testing import TestCase
from batch_architecture.io_target import LocalTarget, S3Target, BucketTarget


class TestS3Target(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_s3_bucket()

        # テスト用ファイルをローカルに作成
        cls.test_dir = pathlib.Path(tempfile.mkdtemp())
        cls.test01 = cls.test_dir / "test01.txt"
        with open(str(cls.test01), "w") as f:
            f.write("A,B,C")
        cls.test02 = cls.test_dir / "test02.txt"
        with open(str(cls.test02), "w") as f:
            f.write("1,2,3")

        cls.test_obj = S3Target(cls.S3_BUCKET + "/test.txt")
        cls.test_obj.object.upload_file(
            str(cls.test01),
            ExtraArgs=cls.test_obj._get_bucket_option(bucket=cls.test_obj),
        )

        cls.test_obj2 = S3Target(cls.S3_BUCKET + "/dir/test01.txt")
        cls.test_obj2.object.upload_file(
            str(cls.test01),
            ExtraArgs=cls.test_obj2._get_bucket_option(bucket=cls.test_obj2),
        )

        cls.test_obj3 = S3Target(cls.S3_BUCKET + "/dir/test02.txt")
        cls.test_obj3.object.upload_file(
            str(cls.test02),
            ExtraArgs=cls.test_obj3._get_bucket_option(bucket=cls.test_obj3),
        )

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_s3_bucket()

    def test_init(self):
        """S3Target インスタンスが正しく初期化できるかテストする。"""
        b = S3Target(self.S3_BUCKET + "/dir/test01.txt")
        self.assertEqual(b._bucket_name, self.S3_BUCKET)
        self.assertEqual(b._path, pathlib.PurePosixPath("dir/test01.txt"))

        with self.assertRaises(ValueError):
            S3Target(self.S3_BUCKET)

    def test_init_args(self):
        """
        S3Target インスタンスにオプショナル引数を
        指定して正しく初期化できるかテストする。
        """
        b = S3Target("/test_dir", bucket=self.S3_BUCKET)
        self.assertEqual(b._bucket_name, self.S3_BUCKET)
        self.assertEqual(b._path, pathlib.PurePosixPath("test_dir"))

        b = S3Target("test_dir/", bucket=self.S3_BUCKET)
        self.assertEqual(b._bucket_name, self.S3_BUCKET)
        self.assertEqual(b._path, pathlib.PurePosixPath("test_dir"))

        b = S3Target("/test_dir/test.txt", bucket=self.S3_BUCKET)
        self.assertEqual(b._bucket_name, self.S3_BUCKET)
        self.assertEqual(b._path, pathlib.PurePosixPath("test_dir/test.txt"))

        b = S3Target("test_dir/test.txt", bucket=self.S3_BUCKET)
        self.assertEqual(b._bucket_name, self.S3_BUCKET)
        self.assertEqual(b._path, pathlib.PurePosixPath("test_dir/test.txt"))

    def test_init_path(self):
        """
        S3Target インスタンスを Path インスタンスから正しく初期化できるかテストする。
        """
        p = S3Target(pathlib.PurePosixPath(self.S3_BUCKET + "/test_dir"))
        self.assertEqual(p._bucket_name, self.S3_BUCKET)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir"))

        p = S3Target(pathlib.PurePosixPath(self.S3_BUCKET + "/test_dir/test.txt"))
        self.assertEqual(p._bucket_name, self.S3_BUCKET)
        self.assertEqual(p._path, pathlib.PurePosixPath("test_dir/test.txt"))

    def test_eq(self):
        """
        S3Target インスタンスの同値性が正しくチェックできるかテストする。
        """
        b1 = S3Target("/test_dir", bucket=self.S3_BUCKET)
        self.assertTrue(b1 == b1)

        b2 = S3Target("test_dir", bucket=self.S3_BUCKET)
        self.assertTrue(b1 == b2)

        b3 = S3Target(self.S3_BUCKET + "/test_dir")
        self.assertTrue(b1 == b3)

        b4 = S3Target(self.S3_BUCKET + "/test_dir1")
        self.assertFalse(b1 == b4)

        b5 = S3Target(self.S3_BUCKET_BACKUP + "/test_dir1")
        self.assertFalse(b1 == b5)
        self.assertFalse(b4 == b5)

    def test_existence_file(self):
        """
        S3Target インスタンスがファイルの場合、対象が存在するか・ディレクトリか・ファイルか、
        をチェックするメソッドが期待通り動作するかテストする。

        - 存在するか (exists): True
        - ディレクトリか (is_dir): False
        - ファイルか (is_file): True
        """
        p = S3Target(self.S3_BUCKET + "/test.txt")
        self.assertTrue(p.exists())
        self.assertFalse(p.is_dir())
        self.assertTrue(p.is_file())

        p = S3Target(self.S3_BUCKET + "/not_exists.txt")
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        p = S3Target(self.S3_BUCKET + "/dir/test01.txt")
        self.assertTrue(p.exists())
        self.assertFalse(p.is_dir())
        self.assertTrue(p.is_file())

    def test_existence_dir(self):
        """
        S3Target インスタンスがディレクトリの場合、対象が存在するか・ディレクトリか・ファイルか、
        をチェックするメソッドが期待通り動作するかテストする。

        - 存在するか (exists): True
        - ディレクトリか (is_dir): True
        - ファイルか (is_file): False
        """
        p = S3Target(self.S3_BUCKET + "/dir/")
        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        p = S3Target(self.S3_BUCKET + "/dir")
        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        # ディレクトリの一部部分だけならディレクトリと判定しない
        p = S3Target(self.S3_BUCKET + "/di")
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

        p = S3Target(self.S3_BUCKET + "/di/")
        self.assertFalse(p.exists())
        self.assertFalse(p.is_dir())
        self.assertFalse(p.is_file())

    def test_repr(self):
        """
        S3Target の表示名が期待通りかテストする。
        """
        exp = "S3Target({0})[ディレクトリ]".format(self.S3_BUCKET + "/dir")
        self.assertEqual(str(S3Target(self.S3_BUCKET + "/dir")), exp)

        exp = "S3Target({0})[ディレクトリ]".format(self.S3_BUCKET + "/dir")
        self.assertEqual(str(S3Target(self.S3_BUCKET + "/dir/")), exp)

        exp = "S3Target({0})[ファイル]".format(self.S3_BUCKET + "/dir/test01.txt")
        self.assertEqual(str(S3Target(self.S3_BUCKET + "/dir/test01.txt")), exp)

        exp = "S3Target({0})[存在しない]".format(self.S3_BUCKET + "/notexists.txt")
        self.assertEqual(str(S3Target(self.S3_BUCKET + "/notexists.txt")), exp)

    def test_children(self):
        """
        S3Target から、子階層のファイルを正しく取得できるかテストする。
        """
        p = S3Target(self.S3_BUCKET + "/dir")
        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        for child in p.children:
            self.assertTrue(isinstance(child, S3Target))
            self.assertTrue(child.exists())
            self.assertFalse(child.is_dir())
            self.assertTrue(child.is_file())

    def test_children2(self):
        """
        S3Target から、孫階層のファイルを正しく取得できるかテストする。
        """
        import boto3
        from botocore.client import Config

        self.resource = boto3.resource("s3", config=Config(signature_version="s3v4"))
        self.bucket = self.resource.Bucket(self.S3_BUCKET)
        obj1 = S3Target(self.S3_BUCKET + "/temp/dir01_01/test01.txt")
        obj1.object.upload_file(
            str(self.test01), ExtraArgs=obj1._get_bucket_option(bucket=obj1)
        )
        obj2 = S3Target(self.S3_BUCKET + "/temp/dir01_02/test02.txt")
        obj2.object.upload_file(
            str(self.test01), ExtraArgs=obj2._get_bucket_option(bucket=obj2)
        )
        obj3 = S3Target(self.S3_BUCKET + "/temp/dir01_01/dir02_01/test03.txt")
        obj3.object.upload_file(
            str(self.test01), ExtraArgs=obj3._get_bucket_option(bucket=obj3)
        )

        p = S3Target(self.S3_BUCKET + "/temp")

        exp = [
            S3Target(self.S3_BUCKET + "/temp/dir01_01/test01.txt"),
            S3Target(self.S3_BUCKET + "/temp/dir01_02/test02.txt"),
            S3Target(self.S3_BUCKET + "/temp/dir01_01/dir02_01/test03.txt"),
        ]

        self.assertEqual(sorted(p.children), sorted(exp))
        p.delete()

    def test_relative_to(self):
        """
        S3Target 同士の相対パスを正しく取得できるかテストする。
        """
        p1 = S3Target(self.S3_BUCKET + "/dir01/test01.txt")
        p2 = S3Target(self.S3_BUCKET + "/dir01")
        self.assertEqual(p1.relative_to(p2), pathlib.PurePosixPath("test01.txt"))

        p3 = S3Target(self.S3_BUCKET + "/")
        self.assertEqual(p1.relative_to(p3), pathlib.PurePosixPath("dir01/test01.txt"))

    def test_relative_to_raises(self):
        """
        S3Target 同士の相対パスが算出できない場合 (ディレクトリが異なる、
        バケットが異なる) に期待通り ValueError が発生するかテストする。
        """
        p1 = S3Target(self.S3_BUCKET + "/dir01/test01.txt")
        p2 = S3Target(self.S3_BUCKET + "/dir02")
        with self.assertRaises(ValueError):
            p2.relative_to(p1)

        p3 = S3Target(self.S3_BUCKET_BACKUP + "/dir01")
        with self.assertRaises(ValueError):
            p3.relative_to(p1)

        p4 = LocalTarget("dir01")
        with self.assertRaises(ValueError):
            p4.relative_to(p1)

    def test_basename(self):
        """
        S3Target のパスから、最下層の名前を正しく取得できるかテストする。
        """
        p = S3Target(self.S3_BUCKET + "/test.txt")
        self.assertEqual(p.basename, "test.txt")

        p = S3Target(self.S3_BUCKET + "/dir/test01.txt")
        self.assertEqual(p.basename, "test01.txt")

        p = S3Target(self.S3_BUCKET + "/")
        self.assertEqual(p.basename, "")

        p = S3Target(self.S3_BUCKET + "/dir")
        self.assertEqual(p.basename, "dir")

    def test_delete(self):
        """
        S3Target のファイル、ディレクトリを正しく削除できるかテストする。
        """
        src_01 = S3Target(self.S3_BUCKET + "/test_dir/test01.txt")
        src_01.object.upload_file(
            str(self.test02), ExtraArgs=src_01._get_bucket_option(bucket=src_01)
        )

        src_02 = S3Target(self.S3_BUCKET + "/test_dir/test02.txt")
        src_02.object.upload_file(
            str(self.test02), ExtraArgs=src_02._get_bucket_option(bucket=src_02)
        )

        p = S3Target(self.S3_BUCKET + "/test_dir/")
        self.assertTrue(p.exists())
        self.assertTrue(p.is_dir())
        self.assertFalse(p.is_file())

        # ディレクトリを削除した時、ディレクトリとその下層のファイルが削除されているか
        p.delete()
        self.assertFalse(S3Target(self.S3_BUCKET + "/test_dir/test01.txt").exists())
        self.assertFalse(S3Target(self.S3_BUCKET + "/test_dir/test02.txt").exists())
        self.assertFalse(S3Target(self.S3_BUCKET + "/test_dir").exists())

    def test_copy_file(self):
        """
        S3Target のファイルを正しくコピーできるかテストする。
        """
        src = S3Target(self.S3_BUCKET + "/dir/test01.txt")

        dst = S3Target(self.S3_BUCKET + "/dir2/test.txt")
        self.assertFalse(dst.exists())
        self.assertFalse(dst.is_dir())
        self.assertFalse(dst.is_file())

        src.copy_to(dst)
        self.assertTrue(dst.exists())
        self.assertFalse(dst.is_dir())
        self.assertTrue(dst.is_file())

        dst.delete()
        self.assertFalse(dst.exists())

    def test_copy_dir(self):
        """
        S3Target のディレクトリを正しくコピーできるかテストする。
        """
        src = S3Target(self.S3_BUCKET + "/dir/")
        dst = S3Target(self.S3_BUCKET + "/dir2/")

        src.copy_to(dst)
        self.assertTrue(dst.exists())
        self.assertTrue(dst.is_dir())
        self.assertFalse(dst.is_file())

        dst_01 = S3Target(self.S3_BUCKET + "/dir2/test01.txt")
        self.assertTrue(dst_01.is_file())
        dst_02 = S3Target(self.S3_BUCKET + "/dir2/test02.txt")
        self.assertTrue(dst_02.is_file())

        # ディレクトリを削除した時、その下層のファイルが削除されているか
        dst.delete()
        self.assertFalse(S3Target(self.S3_BUCKET + "/dir2/test01.txt").exists())
        self.assertFalse(S3Target(self.S3_BUCKET + "/dir2/test02.txt").exists())

    def test_copy_dir_without_delim(self):
        """
        S3Target のディレクトリを正しくコピーできるかテストする。名前として末尾のデリミタ
        を指定しなかった場合も、正しくディレクトリとして判別して
        """
        # パスが末尾のデリミタを含まない場合の処理
        src = S3Target(self.S3_BUCKET + "/dir")
        dst = S3Target(self.S3_BUCKET + "/dir2")

        src.copy_to(dst)
        self.assertTrue(dst.exists())
        self.assertTrue(dst.is_dir())
        self.assertFalse(dst.is_file())

        dst_01 = S3Target(self.S3_BUCKET + "/dir2/test01.txt")
        self.assertTrue(dst_01.is_file())
        dst_02 = S3Target(self.S3_BUCKET + "/dir2/test02.txt")
        self.assertTrue(dst_02.is_file())

        # ディレクトリを削除した時、その下層のファイルが削除されているか
        dst.delete()
        self.assertFalse(S3Target(self.S3_BUCKET + "/dir2/test01.txt").exists())
        self.assertFalse(S3Target(self.S3_BUCKET + "/dir2/test02.txt").exists())

    def test_download_file(self):
        """
        S3Target からローカルへ正しくファイルがダウンロードできるかテストする。
        """
        src = S3Target(self.S3_BUCKET + "/dir/test01.txt")

        path = os.path.join(tempfile.mkdtemp(), "test01.txt")
        dst = LocalTarget(path)

        src.copy_to(dst)
        self.assertTrue(dst.exists())
        self.assertFalse(dst.is_dir())
        self.assertTrue(dst.is_file())

        dst.delete()
        self.assertFalse(dst.exists())

    def test_download_dir(self):
        """
        S3 からローカルへ正しくディレクトリとその中身がダウンロードできるかテストする。
        """
        src = S3Target(self.S3_BUCKET + "/dir")

        path = os.path.join(tempfile.mkdtemp())
        dst = LocalTarget(path)

        src.copy_to(dst)
        self.assertTrue(os.path.exists(os.path.join(path, "test01.txt")))
        self.assertTrue(os.path.exists(os.path.join(path, "test02.txt")))

        dst.delete()
        self.assertFalse(dst.exists())

    def test_download_dir_recursive(self):
        """
        S3 からローカルへ複数階層のディレクトリがダウンロードできるかテストする。
        """
        test_obj01 = S3Target(self.S3_BUCKET + "/temp/temp2/test01.txt")
        test_obj01.object.upload_file(
            str(self.test01), ExtraArgs=test_obj01._get_bucket_option(bucket=test_obj01)
        )
        test_obj02 = S3Target(self.S3_BUCKET + "/temp/temp2/test02.txt")
        test_obj02.object.upload_file(
            str(self.test01), ExtraArgs=test_obj02._get_bucket_option(bucket=test_obj02)
        )
        test_obj03 = S3Target(self.S3_BUCKET + "/temp/test03.txt")
        test_obj03.object.upload_file(
            str(self.test01), ExtraArgs=test_obj03._get_bucket_option(bucket=test_obj03)
        )

        src = S3Target(self.S3_BUCKET + "/temp")

        path = pathlib.Path(tempfile.mkdtemp()) / "download"
        dst = LocalTarget(path)

        src.copy_to(dst)
        self.assertTrue((path / "temp2" / "test01.txt").is_file())
        self.assertTrue((path / "temp2" / "test02.txt").is_file())
        self.assertTrue((path / "test03.txt").is_file())
        src.delete()
        dst.delete()

    def test_upload_file(self):
        """
        ローカルから S3 へ正しくファイルがアップロードできるかテストする。
        """
        src = pathlib.Path(tempfile.mkdtemp()) / "test.txt"
        src.touch()

        src = LocalTarget(src)
        dst = S3Target(self.S3_BUCKET + "/dir/upload.txt")
        self.assertFalse(dst.exists())
        self.assertFalse(dst.is_dir())
        self.assertFalse(dst.is_file())

        src.copy_to(dst)
        self.assertTrue(dst.exists())
        self.assertFalse(dst.is_dir())
        self.assertTrue(dst.is_file())

        src.delete()
        self.assertFalse(src.exists())

        dst.delete()
        self.assertFalse(dst.exists())

    def test_upload_dir(self):
        """
        ローカルから S3 へ正しくディレクトリがアップロードできるかテストする。
        """
        src = pathlib.Path(tempfile.mkdtemp())
        src01 = src / "test01.txt"
        src01.touch()
        src02 = src / "test02.txt"
        src02.touch()

        src = LocalTarget(src)
        dst = S3Target(self.S3_BUCKET + "/dir2")

        src.copy_to(dst)
        self.assertTrue(dst.exists())
        self.assertTrue(dst.is_dir())
        self.assertFalse(dst.is_file())

        self.assertTrue(S3Target(self.S3_BUCKET + "/dir2/test01.txt").is_file())
        self.assertTrue(S3Target(self.S3_BUCKET + "/dir2/test02.txt").is_file())

        src.delete()
        self.assertFalse(src.exists())
        dst.delete()

    def test_upload_dir_recursive(self):
        """
        ローカルから S3 へ複数階層のディレクトリがアップロードできるかテストする。
        """
        src = pathlib.Path(tempfile.mkdtemp())
        (src / "test_dir").mkdir()
        src01 = src / "test_dir" / "test01.txt"
        src01.touch()
        src02 = src / "test_dir" / "test02.txt"
        src02.touch()
        src03 = src / "test03.txt"
        src03.touch()

        src = LocalTarget(src)
        dst = S3Target(self.S3_BUCKET + "/dir2")

        src.copy_to(dst)
        self.assertTrue(dst.exists())
        self.assertTrue(dst.is_dir())
        self.assertFalse(dst.is_file())

        self.assertTrue(
            S3Target(self.S3_BUCKET + "/dir2/test_dir/test01.txt").is_file()
        )
        self.assertTrue(
            S3Target(self.S3_BUCKET + "/dir2/test_dir/test02.txt").is_file()
        )
        self.assertTrue(S3Target(self.S3_BUCKET + "/dir2/test03.txt").is_file())

        src.delete()
        self.assertFalse(src.exists())
        dst.delete()

    def test_copy_to_temporary_file(self):
        """
        S3 からローカルへ、一時ファイルを作成してファイルをダウンロードできるかテストする。
        """
        src = S3Target(self.S3_BUCKET + "/dir/test01.txt")

        res = src.copy_to_temporary()
        self.assertTrue(res.exists())
        self.assertFalse(res.is_dir())
        self.assertTrue(res.is_file())

        res.delete()
        self.assertFalse(res.exists())

    def test_copy_to_temporary_dir(self):
        """
        S3 からローカルへ、一時ディレクトリを作成してディレクトリをダウンロードできるかテストする。
        """
        src = S3Target(self.S3_BUCKET + "/dir")

        res = src.copy_to_temporary()
        self.assertTrue((res._path / "test01.txt").is_file())
        self.assertTrue((res._path / "test02.txt").is_file())

        res.delete()
        self.assertFalse(res.exists())

    def test_md5(self):
        """
        S3Target のMD5ハッシュ値が正しく取得できるかテストする。
        """
        src = LocalTarget(self.TEST_DATA / "upload.csv")
        dst = S3Target(self.S3_BUCKET + "/temp/upload.csv")

        src.copy_to(dst)
        self.assertEqual(src.md5, "b2904b2053a65acddd13df280545e45c")

    def test_md5_not_files(self):
        """
        LocalTarget の対象がディレクトリ、もしくは存在しない場合に、
        期待通り FileNotFoundError が発生するかテストする。
        """
        with self.assertRaises(FileNotFoundError):
            S3Target("dir", bucket=self.S3_BUCKET).md5

        with self.assertRaises(FileNotFoundError):
            S3Target("notexists", bucket=self.S3_BUCKET).md5

    def test_read_write(self):
        t = S3Target(self.S3_BUCKET + "/write.txt")
        t.write("テスト")

        res = t.read()
        self.assertEqual(res, "テスト")
        t.delete()

    def test_read_write_multilines(self):
        t = S3Target(self.S3_BUCKET + "/write.txt")
        t.write(
            """テスト1
テスト2
テスト3"""
        )

        res = t.read()
        self.assertEqual(
            res,
            """テスト1
テスト2
テスト3""",
        )
        t.delete()

    def test_copy_not_exists_bucket(self):
        """
        存在しないバケットを転送元か転送先に指定した時、
        期待通り ClientError が発生することをテストする。
        """
        src = pathlib.Path(tempfile.mkdtemp()) / "test.txt"
        src.touch()
        src = LocalTarget(src)

        dst = S3Target("not_exists/dir/test.txt")

        import botocore.exceptions

        with self.assertRaises(botocore.exceptions.ClientError):
            src.copy_to(dst)

        with self.assertRaises(botocore.exceptions.ClientError):
            dst.copy_to(src)

        src.delete()
        self.assertFalse(src.exists())


class TestBucketTarget(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cleanup_s3_bucket()

        cls.test_dir = pathlib.Path(tempfile.mkdtemp())
        cls.test01 = cls.test_dir / "test01.txt"
        with open(str(cls.test01), "w") as f:
            f.write("A,B,C")
        cls.test02 = cls.test_dir / "test02.txt"
        with open(str(cls.test02), "w") as f:
            f.write("1,2,3")

        import boto3
        from botocore.client import Config

        cls.resource = boto3.resource("s3", config=Config(signature_version="s3v4"))
        cls.bucket = cls.resource.Bucket(cls.S3_BUCKET)

        cls.test_obj = S3Target(cls.S3_BUCKET + "/test.txt")
        cls.test_obj.object.upload_file(
            str(cls.test01),
            ExtraArgs=cls.test_obj._get_bucket_option(bucket=cls.test_obj),
        )

        cls.test_obj2 = S3Target(cls.S3_BUCKET + "/dir/test01.txt")
        cls.test_obj2.object.upload_file(
            str(cls.test01),
            ExtraArgs=cls.test_obj2._get_bucket_option(bucket=cls.test_obj2),
        )

        cls.test_obj3 = S3Target(cls.S3_BUCKET + "/dir/test02.txt")
        cls.test_obj3.object.upload_file(
            str(cls.test02),
            ExtraArgs=cls.test_obj3._get_bucket_option(bucket=cls.test_obj3),
        )

    @classmethod
    def tearDownClass(cls):
        cls.cleanup_s3_bucket()

    def test_init(self):
        """BucketTarget インスタンスが正しく初期化できるかテストする。"""
        b = BucketTarget(self.S3_BUCKET)
        self.assertEqual(b._bucket_name, self.S3_BUCKET)

        with self.assertRaises(ValueError):
            BucketTarget(self.S3_BUCKET + "/dir/test01.txt")

    def test_repr(self):
        """
        BucketTarget の表示名が期待通りかテストする。
        """
        exp = "BucketTarget({0})".format(self.S3_BUCKET)
        self.assertEqual(str(BucketTarget(self.S3_BUCKET)), exp)

    def test_key_modified_dates(self):
        """
        Bucket 中の、キーとその最終更新日付が正しく取得できるかテストする。
        """
        b = BucketTarget(self.S3_BUCKET)
        res = b._get_key_modified_dates()
        self.assertTrue(isinstance(res, dict))

        ts = res["dir/test01.txt"]
        self.assertTrue(isinstance(ts, datetime.datetime))
        now = datetime.datetime.now(tz=dateutil.tz.tzutc())
        self.assertTrue(now - ts < datetime.timedelta(minutes=5))

    def test_copy_to(self):
        """
        Bucket 同士の中身全体のコピーが正しく行えるかテストする。
        """
        src = BucketTarget(self.S3_BUCKET)
        dst = BucketTarget(self.S3_BUCKET_BACKUP)

        exp = S3Target(self.S3_BUCKET_BACKUP + "/dir/test01.txt")

        src.copy_to(dst)
        self.assertTrue(exp.is_file())

        S3Target(self.S3_BUCKET_BACKUP + "/test.txt").delete()
        S3Target(self.S3_BUCKET_BACKUP + "/dir/").delete()
        self.assertFalse(exp.exists())

    def test_copy_to_repeated(self):
        """
        Bucket 同士の中身全体のコピーが正しく行えるかテストする。
        コピーを2回繰り返し、すでにコピー済みのファイルは上書きされることをテストする。
        """
        src = BucketTarget(self.S3_BUCKET)
        dst = BucketTarget(self.S3_BUCKET_BACKUP)

        exp = S3Target(self.S3_BUCKET_BACKUP + "/dir/test01.txt")
        # self.assertFalse(exp.exists())

        src.copy_to(dst)
        self.assertTrue(exp.is_file())
        before01 = dst.bucket.Object("test.txt").last_modified
        before02 = dst.bucket.Object("dir/test01.txt").last_modified

        time.sleep(1)

        # コピーの繰り返しでエラーが発生しないこと
        src.copy_to(dst)
        self.assertTrue(exp.is_file())
        after01 = dst.bucket.Object("test.txt").last_modified
        after02 = dst.bucket.Object("dir/test01.txt").last_modified
        # コピーでタイムスタンプが更新されていること
        self.assertTrue(before01 < after01)
        self.assertTrue(before02 < after02)

        S3Target(self.S3_BUCKET_BACKUP + "/test.txt").delete()
        S3Target(self.S3_BUCKET_BACKUP + "/dir/").delete()
        self.assertFalse(exp.exists())

    def test_copy_only_updated(self):
        """
        Bucket 同士の中身全体のコピーが正しく行えるかテストする。
        コピーを2回繰り返し、すでにコピー済みのファイルはタイムスタンプが新しい場合のみ
        上書きされることをテストする。
        """
        src = BucketTarget(self.S3_BUCKET)
        dst = BucketTarget(self.S3_BUCKET_BACKUP)

        exp = S3Target(self.S3_BUCKET_BACKUP + "/dir/test01.txt")

        src.copy_updated_only(dst)
        self.assertTrue(exp.is_file())
        before01 = dst.bucket.Object("test.txt").last_modified
        before02 = dst.bucket.Object("dir/test01.txt").last_modified

        time.sleep(1)

        # コピー 2回目
        src.copy_updated_only(dst)
        self.assertTrue(exp.is_file())
        after01 = dst.bucket.Object("test.txt").last_modified
        after02 = dst.bucket.Object("dir/test01.txt").last_modified
        # コピーでタイムスタンプが更新されていないこと
        self.assertTrue(before01 == after01)
        self.assertTrue(before02 == after02)

        time.sleep(1)

        # コピー 3回目
        src_obj = S3Target(self.S3_BUCKET + "/test.txt")
        src_obj.object.upload_file(
            str(self.test01), ExtraArgs=src_obj._get_bucket_option(bucket=src_obj)
        )

        src.copy_updated_only(dst)
        self.assertTrue(exp.is_file())
        after01 = dst.bucket.Object("test.txt").last_modified
        after02 = dst.bucket.Object("dir/test01.txt").last_modified
        # 更新したファイルのみタイムスタンプが更新されていること
        self.assertTrue(before01 < after01)
        self.assertTrue(before02 == after02)

        S3Target(self.S3_BUCKET_BACKUP + "/test.txt").delete()
        S3Target(self.S3_BUCKET_BACKUP + "/dir/").delete()
        self.assertFalse(exp.exists())
