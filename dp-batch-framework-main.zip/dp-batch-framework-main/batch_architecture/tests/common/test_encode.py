from batch_architecture.testing import TestCase
from batch_architecture.core import encode


class TestEncode(TestCase):
    def test_enccode(self):
        """
        ある文字列を Base64 でエンコードできるかテストする。
        """
        self.assertEqual(encode.b64encode("test_password"), "dGVzdF9wYXNzd29yZA==")

    def test_decode(self):
        """
        ある文字列を Base64 でデコードできるかテストする。
        """
        self.assertEqual(encode.b64decode("dGVzdF9wYXNzd29yZA=="), "test_password")
