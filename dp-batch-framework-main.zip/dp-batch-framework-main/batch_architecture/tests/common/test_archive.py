import gzip
import pathlib
import tarfile
import shutil
import tempfile
import zipfile

from batch_architecture.testing import TestCase
from batch_architecture.core import archive


class ZipTestCase(TestCase):
    def setUp(self):
        # 一時ディレクトリを作成
        self.temp_dir = pathlib.Path(tempfile.mkdtemp())

        # テスト用のファイルを作成
        self.test_src = self.temp_dir / "test_file.txt"
        self.test_src.write_text("testAAA")

        self.test_src_a = self.temp_dir / "test_a.txt"
        self.test_src_a.touch()

    def tearDown(self):
        # 一時ディレクトリを削除
        shutil.rmtree(str(self.temp_dir))

    def test_archive_file(self):
        """
        zip ファイルが正しく生成できるか、生成された zip ファイルの中身が正しいかテストする。
        """
        path = self.temp_dir / "archive_file.zip"
        archive.archive_file(self.test_src, path)

        # zipファイルが作成されているか
        self.assertTrue(path.is_file())

        with zipfile.ZipFile(str(path), "r") as z:
            namelist = z.namelist()
            self.assertTrue(isinstance(namelist, list))
            self.assertEqual(len(namelist), 1)
            self.assertEqual(namelist[0], "test_file.txt")

            # 対象のファイルを圧縮できているか
            a = z.read(namelist[0])
            self.assertEqual(a, bytes(b"testAAA"))

    def test_archive_file_include_path(self):
        """
        内部階層付きの zip ファイルが正しく生成できるか、
        生成された zip ファイルの内部階層、中身が正しいかテストする。
        """
        path = self.temp_dir / "archive_file.zip"

        archive.archive_file(self.test_src, path, include_path=True)
        # ディレクトリ構造がアーカイブされているか
        with zipfile.ZipFile(str(path), "r") as z:
            namelist = z.namelist()
            self.assertTrue(isinstance(namelist, list))
            self.assertEqual(len(namelist), 1)
            self.assertTrue(namelist[0] != "test_file.txt")
            self.assertTrue(namelist[0].endswith("test_file.txt"))

    def test_archive_file_err(self):
        """
        圧縮元としてカレントディレクトリ全体を指定した時、
        期待通り FileExistsError が発生することをテストする。
        """
        path = self.temp_dir / "archive_file.zip"

        with self.assertRaises(FileExistsError):
            archive.archive_file("", path)

    def test_archive_file_err_2(self):
        """
        圧縮先としてカレントディレクトリ全体を指定した時、
        期待通り FileExistsError が発生することをテストする。
        """
        with self.assertRaises(FileExistsError):
            archive.archive_file(self.test_src, "")

    def test_archive_file_err_3(self):
        """
        圧縮先のファイル名がすでに存在するディレクトリと重複している時、
        期待通り FileExistsError が発生することをテストする。
        """
        target = self.temp_dir / "exists"
        target.mkdir()

        with self.assertRaises(FileExistsError):
            archive.archive_file(self.test_src, target)

    def test_archive_file_incorrect_ext(self):
        """
        圧縮先のファイル名としてサポートされていない拡張子を指定した時、、
        期待通り ValueError が発生することをテストする。
        """
        path = self.temp_dir / "archive_file.xxx"
        with self.assertRaises(ValueError):
            archive.archive_file(self.test_src, path)

    def test_archive_dir(self):
        """
        ディレクトリ全体を zip ファイルとして正しく圧縮できるか、
        生成された zip ファイルの中身が正しいかテストする。
        """
        path = self.temp_dir / "archive_file.zip"
        archive.archive_dir(self.temp_dir, path)
        # zipファイルが作成されているか
        self.assertTrue(path.exists())

        with zipfile.ZipFile(str(path), "r") as z:
            namelist = z.namelist()
            self.assertEqual(namelist[0], "test_a.txt")
            self.assertEqual(namelist[1], "test_file.txt")

    def test_archive_dir_structure(self):
        """
        複数階層を持つディレクトリ全体を zip ファイルとして正しく圧縮できるか、
        生成された zip ファイルの中身が正しいかテストする。
        生成した圧縮ファイルを展開した時、階層構造を保って展開できるかテストする。
        """
        path = self.temp_dir / "archive_file.zip"

        # tempdir のパスは固定でないため、サブフォルダを作成
        temp = self.temp_dir / "temp"
        temp.mkdir()

        (temp / "temp_1").mkdir()
        (temp / "temp_1" / "file_1.txt").touch()
        (temp / "temp_1" / "file_2.txt").touch()
        (temp / "temp_2").mkdir()
        (temp / "temp_2" / "file_3.txt").touch()

        # 圧縮
        archive.archive_dir(temp, path)

        self.assertTrue(path.exists())
        with zipfile.ZipFile(str(path), "r") as z:
            namelist = z.namelist()
            self.assertEqual(namelist[0], "temp_1/")
            self.assertEqual(namelist[1], "temp_2/")
            self.assertEqual(namelist[2], "temp_1/file_1.txt")
            self.assertEqual(namelist[3], "temp_1/file_2.txt")
            self.assertEqual(namelist[4], "temp_2/file_3.txt")

        dst = self.temp_dir / "extract"
        dst.mkdir()

        # 解凍
        archive.extract(path, dst)
        extracted = [
            dst / "temp_1" / "file_1.txt",
            dst / "temp_1" / "file_2.txt",
            dst / "temp_2" / "file_3.txt",
        ]
        for e in extracted:
            self.assertTrue(e.is_file())

    def test_archive_dir_err(self):
        """
        圧縮元のディレクトリが存在しない時、
        期待通り FileNotFoundError が発生することをテストする。
        """
        zip_file_path = self.temp_dir / "archive_file.zip"

        with self.assertRaises(FileNotFoundError):
            archive.archive_dir("TEST", zip_file_path)

    def test_archive_dir_err_2(self):
        """
        圧縮先のディレクトリとしてカレントディレクトリを指定した時、
        期待通り FileExistsError が発生することをテストする。
        """
        with self.assertRaises(FileExistsError):
            archive.archive_dir(self.temp_dir, "")

    def test_archive_files(self):
        """
        圧縮元として複数のファイルを指定した時、正しく圧縮できるかテストする。
        """

        """ 複数ファイル圧縮テスト """
        zip_file_path = self.temp_dir / "archive_file.zip"
        archive.archive_files([self.test_src, self.test_src_a], dst=zip_file_path)

    def test_archive_files_structure(self):
        """
        複数階層を持つ複数のファイルを zip ファイルとして正しく圧縮できるか、
        生成された zip ファイルの中身が正しいかテストする。
        生成した圧縮ファイルを展開した時、階層構造を保って展開できるかテストする。
        """
        path = self.temp_dir / "archive_file.zip"

        (self.temp_dir / "temp_1").mkdir()
        (self.temp_dir / "temp_1" / "file_1.txt").touch()
        (self.temp_dir / "temp_1" / "file_2.txt").touch()
        (self.temp_dir / "temp_2").mkdir()
        (self.temp_dir / "temp_2" / "file_3.txt").touch()

        files = [
            self.temp_dir / "temp_1" / "file_1.txt",
            self.temp_dir / "temp_1" / "file_2.txt",
            self.temp_dir / "temp_2" / "file_3.txt",
        ]

        # 圧縮
        archive.archive_files(files, path)

        self.assertTrue(path.exists())
        with zipfile.ZipFile(str(path), "r") as z:
            namelist = z.namelist()
            self.assertEqual(namelist[0], "file_1.txt")
            self.assertEqual(namelist[1], "file_2.txt")
            self.assertEqual(namelist[2], "file_3.txt")

        dst = self.temp_dir / "extract"
        dst.mkdir()

        # 解凍
        archive.extract(path, dst)
        # archive_files では ファイルの basename のみがディレクトリ構造として保持される
        extracted = [dst / "file_1.txt", dst / "file_2.txt", dst / "file_3.txt"]
        for e in extracted:
            self.assertTrue(e.is_file())

    def test_extract_file(self):
        """
        生成した zip ファイルを、指定したディレクトリ上に正しく展開できるかテストする。
        """
        path = self.temp_dir / "archive_file.zip"
        archive.archive_file(self.test_src, path)

        # zipファイルが作成されているか
        self.assertTrue(path.is_file())

        with zipfile.ZipFile(str(path), "r") as z:
            namelist = z.namelist()
            self.assertTrue(isinstance(namelist, list))
            self.assertEqual(len(namelist), 1)
            self.assertEqual(namelist[0], "test_file.txt")

        dst = self.temp_dir / "extract"
        dst.mkdir()

        archive.extract(path, dst)
        extracted = dst / "test_file.txt"
        self.assertTrue(extracted.is_file())

    def test_extract_file_dir_not_exists(self):
        """
        生成した zip ファイルを、存在しないディレクトリ上に正しく展開できるかテストする。
        ディレクトリは新しく作成される。
        """
        path = self.temp_dir / "archive_file.zip"
        archive.archive_file(self.test_src, path)

        # zipファイルが作成されているか
        self.assertTrue(path.is_file())

        with zipfile.ZipFile(str(path), "r") as z:
            namelist = z.namelist()
            self.assertTrue(isinstance(namelist, list))
            self.assertEqual(len(namelist), 1)
            self.assertEqual(namelist[0], "test_file.txt")

        # 存在しないディレクトリに解凍
        dst = self.temp_dir / "extract"

        archive.extract(path, dst)
        extracted = dst / "test_file.txt"
        self.assertTrue(extracted.is_file())


class GzipTestCase(TestCase):
    def setUp(self):
        # 一時ディレクトリを作成
        self.temp_dir = pathlib.Path(tempfile.mkdtemp())

        # テスト用のファイルを作成
        self.test_src01 = self.temp_dir / "test_file_01.txt"
        self.test_src01.write_text("testAAA")
        self.test_src02 = self.temp_dir / "test_file_02.txt"
        self.test_src02.write_text("testBBB")

    def tearDown(self):
        # 一時ディレクトリを削除
        shutil.rmtree(str(self.temp_dir))

    def test_archive_file(self):
        """
        gz ファイルが正しく生成できるか、生成された gz ファイルの中身が正しいかテストする。
        """
        path = self.temp_dir / "archive_file.gz"
        archive.archive_file(self.test_src01, path)

        # zipファイルが作成されているか
        self.assertTrue(path.is_file())
        with gzip.open(str(path), "r") as t:
            self.assertEqual(t.read(), bytes(b"testAAA"))

    def test_archive_file_err_from_current(self):
        """
        圧縮元としてカレントディレクトリ全体を指定した時、
        期待通り FileExistsError が発生することをテストする。
        """
        path = self.temp_dir / "archive_file.gz"

        with self.assertRaises(FileExistsError):
            archive.archive_file("", path)

    def test_archive_file_err_to_current(self):
        """
        圧縮先としてカレントディレクトリ全体を指定した時、
        期待通り FileExistsError が発生することをテストする。
        """
        with self.assertRaises(FileExistsError):
            archive.archive_file(self.test_src01, "")

    def test_archive_file_err_already_exists(self):
        """
        圧縮先としてすでに存在するディレクトリを指定した時、
        期待通り FileExistsError が発生することをテストする。
        """
        target = self.temp_dir / "exists"
        target.mkdir()

        with self.assertRaises(FileExistsError):
            archive.archive_file(self.test_src01, target)

    def test_archive_dir(self):
        """
        tar.gz ファイルが正しく生成できるか、
        生成された gz ファイルの中身が正しいかテストする。
        """
        path = self.temp_dir / "archive_file.tar.gz"
        archive.archive_dir(self.temp_dir, path)

        # tar.gzファイルが作成されているか
        self.assertTrue(path.is_file())
        with tarfile.open(str(path), "r:gz") as t:
            namelist = t.getnames()
            self.assertEqual(namelist[0], "test_file_01.txt")
            self.assertEqual(namelist[1], "test_file_02.txt")

    def test_archive_dir_structure(self):
        """
        内部階層付きの tar.gz ファイルが正しく生成できるか、
        生成された tar.gz ファイルの内部階層、中身が正しいかテストする。
        """
        path = self.temp_dir / "archive_file.tar.gz"

        # tempdir のパスは固定でないため、サブフォルダを作成
        temp = self.temp_dir / "temp"
        temp.mkdir()

        (temp / "temp_1").mkdir()
        (temp / "temp_1" / "file_1.txt").touch()
        (temp / "temp_1" / "file_2.txt").touch()
        (temp / "temp_2").mkdir()
        (temp / "temp_2" / "file_3.txt").touch()

        # 圧縮
        archive.archive_dir(temp, path)

        self.assertTrue(path.exists())
        with tarfile.open(str(path), "r:gz") as t:
            namelist = t.getnames()
            self.assertEqual(namelist[0], "temp_1")
            self.assertEqual(namelist[1], "temp_1/file_1.txt")
            self.assertEqual(namelist[2], "temp_1/file_2.txt")
            self.assertEqual(namelist[3], "temp_2")
            self.assertEqual(namelist[4], "temp_2/file_3.txt")

        dst = self.temp_dir / "extract"
        dst.mkdir()

        # 解凍
        archive.extract(path, dst)
        extracted = [
            dst / "temp_1" / "file_1.txt",
            dst / "temp_1" / "file_2.txt",
            dst / "temp_2" / "file_3.txt",
        ]
        for e in extracted:
            self.assertTrue(e.is_file())

    def test_archive_dir_err(self):
        """
        圧縮対象として存在しないディレクトリを指定した時、
        期待通り FileNotFoundError が発生することをテストする。
        """
        path = self.temp_dir / "archive_file.gz"

        with self.assertRaises(FileNotFoundError):
            archive.archive_dir("NOT_EXISTS", path)

    def test_archive_dir_err_2(self):
        """ "
        圧縮先としてカレントディレクトリ全体を指定した時、
        期待通り FileExistsError が発生することをテストする。
        """
        with self.assertRaises(FileExistsError):
            archive.archive_dir(self.temp_dir, "")

    def test_archive_files(self):
        """
        圧縮元として複数のファイルを指定した時、正しく圧縮できるかテストする。
        """
        path = self.temp_dir / "archive_file.tar.gz"
        archive.archive_files([self.test_src01, self.test_src02], dst=path)

    def test_archive_files_structure(self):
        """
        複数階層を持つ複数のファイルを tar.gz ファイルとして正しく圧縮できるか、
        生成された tar.gz ファイルの中身が正しいかテストする。
        生成した圧縮ファイルを展開した時、階層構造を保って展開できるかテストする。
        """
        path = self.temp_dir / "archive_file.tar.gz"

        (self.temp_dir / "temp_1").mkdir()
        (self.temp_dir / "temp_1" / "file_1.txt").touch()
        (self.temp_dir / "temp_1" / "file_2.txt").touch()
        (self.temp_dir / "temp_2").mkdir()
        (self.temp_dir / "temp_2" / "file_3.txt").touch()

        files = [
            self.temp_dir / "temp_1" / "file_1.txt",
            self.temp_dir / "temp_1" / "file_2.txt",
            self.temp_dir / "temp_2" / "file_3.txt",
        ]

        # 圧縮
        archive.archive_files(files, path)

        self.assertTrue(path.exists())
        with tarfile.open(str(path), "r:gz") as t:
            namelist = t.getnames()
            self.assertEqual(namelist[0], "file_1.txt")
            self.assertEqual(namelist[1], "file_2.txt")
            self.assertEqual(namelist[2], "file_3.txt")

        dst = self.temp_dir / "extract"
        dst.mkdir()

        # 解凍
        archive.extract(path, dst)
        # archive_files では ファイルの basename のみがディレクトリ構造として保持される
        extracted = [dst / "file_1.txt", dst / "file_2.txt", dst / "file_3.txt"]
        for e in extracted:
            self.assertTrue(e.is_file())

    def test_archive_dir_structure_incorrect_ext(self):
        """
        ディレクトリを .tar.gz ではなく .gz 拡張子を指定して
        圧縮した場合、期待通り ValueError が発生することをテストする。
        """
        path = self.temp_dir / "archive_file.gz"

        # tempdir のパスは固定でないため、サブフォルダを作成
        temp = self.temp_dir / "temp"
        temp.mkdir()

        (temp / "temp_1").mkdir()
        (temp / "temp_1" / "file_1.txt").touch()
        (temp / "temp_1" / "file_2.txt").touch()
        (temp / "temp_2").mkdir()
        (temp / "temp_2" / "file_3.txt").touch()

        # 圧縮
        with self.assertRaises(ValueError):
            archive.archive_dir(temp, path)

    def test_archive_files_structure_incorrect_ext(self):
        """
        複数ファイルを .tar.gz ではなく .gz 拡張子を指定して
        圧縮した場合、期待通り ValueError が発生することをテストする。
        """
        path = self.temp_dir / "archive_file.gz"

        (self.temp_dir / "temp_1").mkdir()
        (self.temp_dir / "temp_1" / "file_1.txt").touch()
        (self.temp_dir / "temp_1" / "file_2.txt").touch()
        (self.temp_dir / "temp_2").mkdir()
        (self.temp_dir / "temp_2" / "file_3.txt").touch()

        files = [
            self.temp_dir / "temp_1" / "file_1.txt",
            self.temp_dir / "temp_1" / "file_2.txt",
            self.temp_dir / "temp_2" / "file_3.txt",
        ]

        with self.assertRaises(ValueError):
            archive.archive_files(files, path)

    def test_extract_file(self):
        """
        生成した gz ファイルを、指定した既存のファイルに正しく展開できるかテストする。
        """
        path = self.temp_dir / "archive_file.gz"
        archive.archive_file(self.test_src01, path)

        # ファイルが作成されているか
        self.assertTrue(path.is_file())

        with gzip.open(str(path), "r") as t:
            self.assertEqual(t.read(), bytes(b"testAAA"))

        dst = self.temp_dir / "extract.txt"
        dst.touch()

        archive.extract(path, dst)
        self.assertTrue(dst.is_file())

        with dst.open(mode="r") as t:
            self.assertEqual(t.read(), "testAAA")

    def test_extract_file_not_exists(self):
        """
        生成した gz ファイルを、指定したファイルを新たに作成して展開できるかテストする。
        """

        path = self.temp_dir / "archive_file.gz"
        archive.archive_file(self.test_src01, path)

        # ファイルが作成されているか
        self.assertTrue(path.is_file())

        with gzip.open(str(path), "r") as t:
            self.assertEqual(t.read(), bytes(b"testAAA"))

        # 存在しないファイルに解凍
        dst = self.temp_dir / "extract.csv"

        archive.extract(path, dst)
        self.assertTrue(dst.is_file())

        with dst.open(mode="r") as t:
            self.assertEqual(t.read(), "testAAA")

        # ディレクトリのみ指定して解凍
        dst = self.temp_dir
        archive.extract(path, dst)
        # ファイル名は解凍前のファイルから拡張子を除いたもの
        res = dst / "archive_file"
        self.assertTrue(res.is_file())

        with res.open(mode="r") as t:
            self.assertEqual(t.read(), "testAAA")
