from batch_architecture.testing import TestCase
from batch_architecture.etl import transform


class TestTransform(TestCase):

    file01 = TestCase.TEST_DATA / "transform_test_input_data.csv"
    output = TestCase.TEST_DATA / "transform_test_output_data.tsv"
    header_line = 3
    footer_line = 2

    def get_lists(self):
        """
        ファイルをリストとして取得
        """
        lists = []
        with self.file01.open("r") as input:
            for i in input:
                lists.append(i)
        return lists

    def test_remove_header(self):
        """
        ファイルの先頭からn行を削除した時、削除前のn+1行目と削除後の1行目が一致することをテストする。
        """
        with self.file01.open("r") as input:
            gen = transform.remove_header(input=input, n=self.header_line)
            output = list(gen)

        self.assertEqual(output[0], self.get_lists()[self.header_line])

    def test_remove_footer(self):
        """
        ファイルの末尾からn行を削除した時、削除前の末尾からn+1行目と削除後の最終行が一致することをテストする。
        """
        with self.file01.open("r") as input:
            gen = transform.remove_footer(input=input, n=self.footer_line)
            output = list(gen)

        self.assertEqual(output[-1], self.get_lists()[-self.footer_line - 1])

    def test_replace_line_sep(self):
        """
        特定の文字列を指定した文字列に置換した時、置換後の文字列と指定した文字列が一致することをテストする。
        """
        sep_before = "\n"
        sep_after = "\r"
        with self.file01.open("r") as input:
            gen = transform.replace_line_sep(
                input=input, sep_before=sep_before, sep_after=sep_after
            )
            output = list(gen)

        self.assertEqual(str(output[0])[-1], sep_after)

    def test_file_split(self):
        """
        指定した行数でファイルを分割した時、分割後の行数と指定した行数が一致することをテストする。
        """
        split = 5
        with self.file01.open("r") as input:
            gen = transform.file_split(input=input, split=split)
            output = list(gen)
        self.assertEqual(len(output[0]), split)
        self.assertEqual(len(output[-1]), len(self.get_lists()) % split)

    def test_file_split_divisible(self):
        """
        ファイル行数に対して割り切れる行数を指定してファイルを分割した時、分割後の行数と指定した行数が一致することをテストする。
        """
        split = 3
        with self.file01.open("r") as input:
            gen = transform.file_split(input=input, split=split)
            output = list(gen)
        self.assertEqual(len(output[0]), split)
        self.assertEqual(len(output[-1]), split)

    def test_file_split_larger_lines(self):
        """
        ファイル行数よりも大きい行数を指定してファイルを分割した時、ファイルが分割されていないことをテストする。
        """
        split = 15
        with self.file01.open("r") as input:
            gen = transform.file_split(input=input, split=split)
            output = list(gen)
        self.assertEqual(len(output), 1)

    def test_remove_header_footer(self):
        """
        ファイルの先頭n行と末尾m行を同時に削除した時、削除後の行数が元ファイルの行数より(n+m)行短くなっていることをテストする。
        """
        with self.file01.open("r") as input:
            gen = transform.remove_footer(
                input=transform.remove_header(input=input, n=self.header_line),
                n=self.footer_line,
            )
            length = len(list(gen))

        self.assertEqual(
            len(self.get_lists()) - self.header_line - self.footer_line, length
        )

    def test_input_file_error(self):
        """
        ファイルの先頭からn行を削除する場合にinputにfile-likeオブジェクト以外(ファイルパス等)を指定した時、
        期待通りTypeErrorが発生することをテストする。
        """
        gen = transform.remove_header(input=self.file01, n=self.header_line)
        with self.assertRaises(TypeError):
            list(gen)

    def test_input_num_error(self):
        """
        ファイルの先頭からn行を削除する場合に削除する行数に数値以外を指定した時、
        期待通りTypeErrorが発生することをテストする。
        """
        with self.file01.open("r") as input:
            gen = transform.remove_header(input=input, n="a")
            with self.assertRaises(TypeError):
                list(gen)

    def test_convert_csv_format_to_tsv(self):
        """
        csvファイルをtsvファイルに変換した時に、カンマがタブに変換されていることをテストする。
        """
        file02 = TestCase.TEST_DATA / "transform_test_input_data02.csv"
        input_format = {"delimiter": ",", "lineterminator": "\n"}
        output_format = {"delimiter": "\t", "lineterminator": "\n"}
        transform.convert_csv_format(
            input=str(file02),
            output=str(self.output),
            input_format=input_format,
            output_format=output_format,
        )
        with self.output.open("r") as out:
            tran = out.readline()
        self.assertEqual(tran, "1\t 2\t 3\t 4\t 5\n")
        self.output.unlink()

    def test_convert_csv_format(self):
        """
        ファイルのフォーマット変換を行った時、以下の項目に関して正しく変換が行われていることをテストする。
        ・delimiterを","から"\t"へ変換
        ・escapechar("*")がファイル内のquotechar("'")の前に置かれている
        ・lineterminatorを"\n"から"x\n"へ変換
        ・文字コードを"utf-8"から"shift-jis"へ変換
        """
        file03 = TestCase.TEST_DATA / "transform_test_input_data03.csv"
        input_format = {"skipinitialspace": True}
        output_format = {
            "delimiter": "\t",
            "doublequote": False,
            "escapechar": "*",
            "lineterminator": "x\n",
            "quotechar": "'",
            "quoting": 0,
            "encoding": "shift-jis",
        }
        transform.convert_csv_format(
            input=str(file03),
            output=str(self.output),
            input_format=input_format,
            output_format=output_format,
        )
        with self.output.open("r") as out:
            output_line1 = out.readline()
            output_line2 = out.readline()

        self.assertEqual(output_line1, "1*'\t2*'\t3*'\t4*'\t5*'x\n")
        self.assertEqual(output_line2, "あ\tい\tう\tえ\tおx\n")
        self.output.unlink()

    def test_convert_csv_format_file_exists_error(self):
        """
        変換先のファイルと同名のファイルが既に存在する場合にファイルのフォーマット変換をした時、
        期待通り FileExistsError が発生することをテストする。
        """
        self.output.touch()
        self.assertTrue(self.output.exists())
        input_format = {"delimiter": ",", "lineterminator": "\n"}
        output_format = {"delimiter": "\t", "lineterminator": "\n"}
        with self.assertRaises(FileExistsError):
            transform.convert_csv_format(
                input=str(self.file01),
                output=str(self.output),
                input_format=input_format,
                output_format=output_format,
            )
        self.output.unlink()

    def test_convert_csv_format_encode_error(self):
        """
        文字コードがUTF-8のinputファイルをasciiコードのoutputファイルに変換した時に、
        期待通りUnicodeEncodeErrorが発生することをテストする。
        """
        input = TestCase.TEST_DATA / "data_utf8.csv"
        input_format = {"delimiter": ",", "lineterminator": "\n", "encoding": "utf-8"}
        output_format = {"delimiter": "\t", "lineterminator": "\n", "encoding": "ascii"}
        with self.assertRaises(UnicodeError):
            transform.convert_csv_format(
                input=str(input),
                output=str(self.output),
                input_format=input_format,
                output_format=output_format,
            )

    def test_convert_csv_format_decode_error(self):
        """
        文字コードがShift-JISのinputファイルをUTF-8のファイルとして読み取った時に、
        期待通りUnicodeDecodeErrorが発生することをテストする。
        """
        input = TestCase.TEST_DATA / "data_sjis.csv"
        input_format = {"delimiter": ",", "lineterminator": "\n"}
        output_format = {"delimiter": "\t", "lineterminator": "\n"}
        with self.assertRaises(UnicodeError):
            transform.convert_csv_format(
                input=str(input),
                output=str(self.output),
                input_format=input_format,
                output_format=output_format,
            )

    def test_convert_csv_format_unknown_encoding_error(self):
        """
        encodingに無効な値を設定した時に、期待通りLookupErrorが発生することをテストする。
        """
        input_format = {
            "delimiter": ",",
            "lineterminator": "\n",
            "encoding": "unknown_encoding",
        }
        output_format = {"delimiter": "\t", "lineterminator": "\n", "encoding": "utf-8"}
        with self.assertRaises(LookupError):
            transform.convert_csv_format(
                input=str(self.file01),
                output=str(self.output),
                input_format=input_format,
                output_format=output_format,
            )
