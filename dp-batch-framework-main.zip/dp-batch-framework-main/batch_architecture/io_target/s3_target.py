"""
S3上のファイル・ディレクトリに対する入出力制御クラス
"""
import time
import pathlib
from datetime import datetime
import random
import botocore.exceptions

from batch_architecture.core.resources import Resources
from batch_architecture.core.log import Logger
from batch_architecture.io_target.base import _RemoteTarget
from batch_architecture.io_target.local_target import LocalTarget
from batch_architecture.client.aws_client import _BotoMixin

MAX_RETRY = 5
BASE_RETRY_DELAY = 5


class Retry:
    concurrent = 0

    @classmethod
    def get_retry_delay_sec(cls, retry_count):
        """
        リトライ間隔を取得する。リトライ回数に応じて指数関数的に増加させる。
        同時リトライを分散させるため5~10秒ランダムでずらす。

        :param retry_count: リトライ回数
        :return: リトライ間隔
        """
        return retry_count ** 2 * BASE_RETRY_DELAY + random.randint(5, 10)


    @classmethod
    def catch(cls, func):
        def wrapper(*args, **kwargs):
            for i in range(MAX_RETRY + 1):
                try:
                    cls.concurrent += 1
                    result = func(*args, **kwargs)
                    return result
                except (
                        botocore.exceptions.NoCredentialsError,
                        botocore.exceptions.EndpointConnectionError
                ) as e:
                    if 1 < cls.concurrent:
                        raise
                    logger = Logger.get_logger(__file__)
                    logger.warning('IN {}\n{}'.format(func.__name__, e))
                    if i == MAX_RETRY:
                        logger.error("最大リトライ回数を超えました。")
                        raise
                    logger.warning("リトライします。: {}回目".format(i + 1))
                    retry_delay = cls.get_retry_delay_sec(i + 1)
                    logger.warning("リトライ間隔: {}秒".format(retry_delay))
                    time.sleep(retry_delay)
                finally:
                    cls.concurrent -= 1

        return wrapper


class _S3Target(_RemoteTarget, _BotoMixin):
    """
    S3Target, BucketTarget 共通の処理を含む基底クラス
    """

    _KEY = "s3"
    _SEP = "/"
    _LOGGER_NAME = "batch_architecture.io_target.s3_target"

    @property
    def bucket(self):
        if getattr(self, "_bucket", None) is None:
            self._bucket = self.resource(self._bucket_name).Bucket(self._bucket_name)
        return self._bucket

    @Retry.catch
    def list_objects_all(self):
        return [obj.key for obj in self.bucket.objects.all()]

    @Retry.catch
    def list_buckets(self):
        return self.resource(self._bucket_name).buckets


class S3Target(_S3Target):
    """
    S3 上のキーを扱うターゲット
    """

    def __init__(self, path, bucket=None, parallel=True):
        if isinstance(path, pathlib.PurePath):
            path = str(path)

        path = self._replace_bucket_placeholder(path)

        if bucket is None:
            if self._SEP not in path:
                msg = 'URIは "{バケット名}/パス..." の形式で指定してください'
                raise ValueError(msg)
            bucket, path = path.split(sep=self._SEP, maxsplit=1)
        else:
            if path.startswith(self._SEP):
                path = path.split(sep=self._SEP, maxsplit=1)[1]

        self._bucket_name = bucket
        self._path = pathlib.PurePosixPath(path)
        self._parallel = parallel

    @property
    def object(self):
        if getattr(self, "_object", None) is None:
            self._object = self.bucket.Object(str(self._path))
        return self._object

    def __str__(self):
        try:
            if self.is_dir():
                kind = "ディレクトリ"
            elif self.is_file():
                kind = "ファイル"
            else:
                kind = "存在しない"
        except botocore.exceptions.ClientError:
            kind = "バケット接続不可"

        fmt = "S3Target({bucket}/{path})[{kind}]"
        return fmt.format(bucket=self._bucket_name, path=self._path, kind=kind)

    def __eq__(self, other):
        if isinstance(other, str):
            other = self.parse(other)
            if not isinstance(other, S3Target):
                return False
        return self._bucket_name == other._bucket_name and self._path == other._path

    def __lt__(self, other):
        if isinstance(other, str):
            other = S3Target(other)
        if self._bucket_name != other._bucket_name:
            return self._bucket_name < other._bucket_name
        else:
            return self._path < other._path

    def __truediv__(self, other):
        if isinstance(other, str):
            return S3Target(self._path / other, bucket=self._bucket_name)
        else:
            return NotImplemented

    def _assert_response(self, response):
        # TODO: call this method after all requests
        code = response["ResponseMetadata"]["HTTPStatusCode"]
        if code != 200:
            msg = "S3へのリクエストでエラーが発生しました: {0}"
            raise ValueError(msg.format(response))

    @Retry.catch
    def list_objects(self):
        return [obj.key for obj in self.bucket.objects.filter(Prefix=str(self._path))]

    @property
    def parent(self):
        return S3Target(self._path.parent, bucket=self._bucket_name)

    @property
    def _maybe_dirname(self):
        """
        自身のパスの末尾にデリミタをつける。自身のパスがディレクトリかチェックするために利用。
        パスの実体がファイルであってもエラーとはならない
        """
        return str(self._path) + self._SEP

    def exists(self):
        """
        対象のパスが存在するかどうか調べる。

        :return: bool
        """
        return self.is_file() or self.is_dir()

    def is_dir(self):
        """
        対象のパスがディレクトリかどうか調べる。

        :return: bool
        """
        path = self._maybe_dirname
        return any(obj.startswith(path) for obj in self.list_objects())

    def is_file(self):
        """
        対象のパスがファイルかどうか調べる。

        :return: bool
        """
        return str(self._path) in self.list_objects()

    @Retry.catch
    def read(self, encoding="utf-8"):
        if not self.is_file():
            msg = "読み込み元 {0} はファイルではありません"
            raise FileNotFoundError(msg.format(self))

        res = self.object.get()
        self._assert_response(res)

        result = res["Body"].read()
        return result.decode(encoding)

    @Retry.catch
    def write(self, buf, encoding="utf-8"):
        if self.is_dir():
            # 存在しない場合は .put で作成されるため、ディレクトリかどうかだけを
            # チェックすればよい
            msg = "書き込み先 {0} はファイルではありません"
            raise FileNotFoundError(msg.format(self))

        if not isinstance(buf, bytes):
            buf = bytes(buf, encoding=encoding)

        res = self.object.put(Body=buf)
        self._assert_response(res)

    @Retry.catch
    def get_file_size(self):
        if not self.is_file():
            msg = "読み込み元 {0} はファイルではありません"
            raise FileNotFoundError(msg.format(self))
        file_size = self.object.get()["ContentLength"]

        return file_size

    def get_record_count(self):
        if not self.is_file():
            msg = "読み込み元 {0} はファイルではありません"
            raise FileNotFoundError(msg.format(self))
        response = self.read()
        record_count = sum([1 for x in response.split("\n") if x.strip()])
        return record_count

    @classmethod
    def _get_bucket_option(cls, bucket):
        if isinstance(bucket, S3Target) is False:
            return {}

        if bucket._bucket_name in Resources._resources:
            account_id = Resources.get(bucket._bucket_name)._account_id
            kms_key_id = Resources.get(bucket._bucket_name)._kms_key_id

            if kms_key_id is not None:
                arn = "arn:aws:kms:ap-northeast-1:" + account_id + ":key/" + kms_key_id
                return {
                    "ACL": "bucket-owner-full-control",
                    "ServerSideEncryption": "aws:kms",
                    "SSEKMSKeyId": arn,
                }

        return {"ACL": "bucket-owner-full-control"}

    @classmethod
    @Retry.catch
    def _transfer_file(cls, src, dst):
        """
        単一ファイルの転送を行う
        """
        if isinstance(src, S3Target):
            if isinstance(dst, S3Target):
                # S3上のコピー
                src_params = {"Bucket": src._bucket_name, "Key": str(src._path)}
                # 転送実行
                return dst.object.copy(
                    src_params, ExtraArgs=cls._get_bucket_option(bucket=dst)
                )
            elif isinstance(dst, LocalTarget):
                # S3からローカルへのダウンロード
                if not dst.parent.exists():
                    # ダウンロード先の親ディレクトリが存在しない場合は作成
                    try:
                        # other thread may create already
                        dst.parent.mkdir(parents=True)
                    except FileExistsError:
                        pass
                return src.object.download_file(str(dst._path))

        elif isinstance(src, LocalTarget) and isinstance(dst, S3Target):
            # ローカルからS3へのアップロード
            return dst.object.upload_file(
                str(src._path), ExtraArgs=cls._get_bucket_option(bucket=dst)
            )

        raise NotImplementedError

    @classmethod
    def _check_transfer_result(cls, src, dst):

        # todo ローカルでは動くが、開発環境では正常に動かないので一旦コメント。動くようにしたい。
        # _RemoteTarget._check_transfer_result(src, dst)
        # if 'SSEKMSKeyId' in cls._get_bucket_option(bucket=src):
        #     if src.md5 == dst.md5:
        #         msg = ('入力 {src} と出力 {dst} で md5 ハッシュが一致します。'
        #                'KMS 暗号化が正しく行われていない可能性があります。'
        #                '入力: {src_md5} 出力: {dst_md5}')
        #         raise Exception(msg.format(src=src, dst=dst,
        #                                    src_md5=src.md5,
        #                                    dst_md5=dst.md5))
        #
        # if 'SSEKMSKeyId' in cls._get_bucket_option(bucket=dst):
        #     if src.md5 == dst.md5:
        #         msg = ('入力 {src} と出力 {dst} で md5 ハッシュが一致します。'
        #                'KMS 暗号化が正しく行われていない可能性があります。'
        #                '入力: {src_md5} 出力: {dst_md5}')
        #         raise Exception(msg.format(src=src, dst=dst,
        #                                    src_md5=src.md5,
        #                                    dst_md5=dst.md5))
        #
        # if src.md5 != dst.md5:
        #     msg = ('入力 {src} と出力 {dst} で md5 ハッシュが異なります。'
        #            'ファイルが破損している可能性があります。'
        #            '入力: {src_md5} 出力: {dst_md5}')
        #     raise Exception(msg.format(src=src, dst=dst,
        #                                src_md5=src.md5,
        #                                dst_md5=dst.md5))
        return dst

    # delete は冪等的に使えるべきである
    # なぜなら delete を使う側は指定されたパスにオブジェクトが存在しないことしか期待しないため、
    # 元々オブジェクトが存在しなかったことなど興味の範疇外になるため
    # base の delete は冪等的に使えないので override する。そのため不要な recursive flag をつける
    def delete(self, recursive=True):
        """
        ターゲットのファイル・ディレクトリを削除する。
        ファイルが存在しない場合は何もせずに終了する。

        :param recursive: 対象がファイル、サブディレクトリを含む時、再帰的に削除するかどうか
        """
        self._delete()

    # こちらも override のため、不要な recursive flag をつける
    @Retry.catch
    def _delete(self, recursive=True):
        """
        ターゲットのファイル・ディレクトリを削除する。
        """
        if self.is_dir():
            for child in self.children:
                self.logger.info("{}/{} を削除しています".format(self._bucket_name, child._path))
                self.logger.info("aws s3 rm s3://{}/{}".format(self._bucket_name, child._path))
                child.object.delete()

        elif self.is_file():
            self.logger.info("{}/{} を削除しています".format(self._bucket_name, self._path))
            self.logger.info("aws s3 rm s3://{}/{}".format(self._bucket_name, self._path))
            self.object.delete()

        else:
            # ファイルが存在しない場合はなにもしない
            self.logger.warning(
                "{}/{} にファイルが存在しなかったため削除処理をしませんでした".format(
                    self._bucket_name, self._path))
            pass

    @property
    @Retry.catch
    def children(self):
        """
        現在のパスの下にあるディレクトリ、ファイルを取得する。

        :return: サブディレクトリ、ファイルの一覧
        :rtype: list of Target
        """
        if self.is_dir():
            path = self._maybe_dirname
            resources = [key.key for key in self.bucket.objects.filter(Prefix=path)]
            return [
                S3Target(r, bucket=self._bucket_name) for r in resources if r != path
            ]
        else:
            msg = "指定されたパス {0} はディレクトリではありません".format(self._path)
            raise FileNotFoundError(msg)

    def relative_to(self, other):
        if isinstance(other, type(self)):
            if self._bucket_name == other._bucket_name:
                return self._path.relative_to(other._path)
            else:
                msg = "パス {0} と {1} のホスト名が異なるため、" "相対パスを見つけられません"
                raise ValueError(msg.format(self, other))
        else:
            msg = "パス {0} と {1} の種類が異なるため、相対パスを見つけられません"
            raise ValueError(msg.format(self, other))

    def joinpath(self, *other):
        return S3Target(self._path.joinpath(*other), bucket=self._bucket_name)

    @property
    @Retry.catch
    def md5(self):
        if self.is_file():
            # e_tag は前後にダブルクオーテーションを含む
            return self.object.e_tag[1:-1]
        else:
            msg = "指定されたパス {0} はファイルではありません".format(self)
            raise FileNotFoundError(msg)

    # バケットの環境差異を吸収
    def _replace_bucket_placeholder(self, path: str):
        bucket_resource = self.resources.get("s3_bucket")
        params = dict(
            landing_internal=bucket_resource._landing_internal,
            landing_external=bucket_resource._landing_external,
            backup=bucket_resource._backup,
            staging=bucket_resource._staging,
            datalake=bucket_resource._datalake,
            audit=bucket_resource._audit,
            temporary=bucket_resource._temporary,
            export=bucket_resource._export,
            migration=bucket_resource._migration,
            rcs_bucket=bucket_resource._rcs_bucket,
            # みなし日置換
            batch_date=self.batch_date.batch_date,
            partition_ymd=self.batch_date.partition_ymd,
            YYYYMMDD=self.batch_date.batch_date,
            YYYY=self.batch_date.batch_date[:4],
            MM=self.batch_date.batch_date[4:6],
            DD=self.batch_date.batch_date[6:],
            # タイムスタンプ
            timestamp=datetime.now().strftime('%Y%m%d_%H%M%S')
        )
        path = path.replace('{', '{{').replace('}', '}}')
        for k in params.keys():
            path = path.replace('{{%s}}' % k, '{%s}' % k)
        path = path.format(**params)
        return path


class BucketTarget(_S3Target):
    def __init__(self, path):
        if self._SEP in path:
            msg = "バケット名 {0} に / が含まれています"
            raise ValueError(msg.format(path))
        self._bucket_name = path

    def __str__(self):
        fmt = "BucketTarget({bucket})"
        return fmt.format(bucket=self._bucket_name)

    @Retry.catch
    def _get_key_modified_dates(self):
        return {a.key: a.last_modified for a in self.bucket.objects.all()}

    @Retry.catch
    def copy_to(self, dst):
        assert isinstance(dst, BucketTarget), dst

        src_resources = self._get_key_modified_dates()
        for s in src_resources:
            # TODO: 並列処理
            copy_source = {"Bucket": self._bucket_name, "Key": s}
            dst.bucket.Object(s).copy(copy_source)
        return dst

    @Retry.catch
    def copy_updated_only(self, dst):
        """
        バケットのうち、以下いずれかの条件に該当するキーのみをコピーする。

        - 送信先バケットに同一のキーが存在しない
        - 送信先バケットの同一のキーよりも更新日が新しい
        """
        assert isinstance(dst, BucketTarget), dst

        src_resources = self._get_key_modified_dates()
        dst_resources = dst._get_key_modified_dates()
        for s, t in src_resources.items():
            # コピー対象のキーが送信先にない or このバケットのタイムスタンプの方が新しい
            if s not in dst_resources or t > dst_resources[s]:
                # TODO: 並列処理
                copy_source = {"Bucket": self._bucket_name, "Key": s}
                dst.bucket.Object(s).copy(copy_source)
        return dst
