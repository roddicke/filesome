import pathlib
import urllib.request
from urllib.error import HTTPError, URLError

from batch_architecture.io_target.base import _RemoteTarget
from batch_architecture.io_target.local_target import LocalTarget


class HTTPTarget(_RemoteTarget):
    def __init__(self, path):
        """
        初期化メソッド。
        """
        if isinstance(path, pathlib.PurePath):
            path = str(path)

        if path == "":
            msg = "URLを指定してください"
            raise ValueError(msg)

        if path.startswith("https://"):
            self.protocol = "https://"
        else:
            self.protocol = "http://"
        self._path = pathlib.PurePosixPath(path.replace(self.protocol, ""))

    @property
    def _url(self):
        return self.protocol + str(self._path)

    def __str__(self):
        """
        オブジェクトを文字列型に変換し、指定したものがディレクトリorファイルor存在しないor接続不可か判定。
        """
        try:
            self._open()
            kind = "ファイル"
        except HTTPError:
            kind = "存在しない"
        except URLError:
            kind = "サーバ接続不可"

        fmt = "HTTPTarget({url})[{kind}]"
        return fmt.format(url=self._url, kind=kind)

    def _open(self):
        """
        対象のURLを開く。
        """
        return urllib.request.urlopen(self._url)

    def exists(self):
        """
        対象のURLが存在するかどうか調べる。
        :return: bool
        """
        return self.is_file() or self.is_dir()

    def is_dir(self):
        """
        対象のURLがディレクトリかどうか調べる。
        :return: bool
        """
        return False

    def is_file(self):
        """
        対象のURLが存在するかどうか調べる。
        HTTPError:指定したURLが開けない場合
        ex)‘404’(page not found),‘403’(request forbidden),‘401’(authentication required)
        URLError:ネットワーク接続が無い場合や、指定したサーバが無い場合
        :return: bool
        """
        try:
            self._open()
            return True
        except HTTPError:
            return False
        except URLError:
            return False

    def read(self):
        """
        対象のURLを読み込む。
        """
        try:
            resp = self._open()
            return resp.read()
        except (URLError, HTTPError):
            msg = "読み込み元 {0} はファイルではありません"
            raise FileNotFoundError(msg.format(self))

    @classmethod
    def _transfer_file(cls, src, dst):
        """
        単一ファイルの転送を行う。
        """
        if isinstance(src, HTTPTarget):
            if isinstance(dst, LocalTarget):
                resp = urllib.request.urlopen(src._url)
                with dst._path.open("wb") as f:
                    f.write(resp.read())
                return dst._path
        raise NotImplementedError

    @property
    def parent(self):
        parent_url = self.protocol + str(self._path.parent)
        return HTTPTarget(parent_url)

    def _delete(self, recursive=True):
        """
        対象のファイル・ディレクトリを削除する。
        """
        raise NotImplementedError

    def joinpath(self, *other):
        """
        urlの結合。
        """
        join_url = self.protocol + str(self._path.joinpath(*other))
        return HTTPTarget(join_url)
