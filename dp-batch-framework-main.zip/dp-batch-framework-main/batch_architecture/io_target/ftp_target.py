"""
FTP上のファイル・ディレクトリに対する入出力制御クラス
"""
import time
import ftplib
import pathlib
import socket
from datetime import datetime

from batch_architecture.io_target.base import _RemoteTarget
from batch_architecture.io_target.local_target import LocalTarget


class FTPTarget(_RemoteTarget):
    # TODO: client の CWD が常にルートとなるようチェックする

    _SEP = "/"

    def __init__(self, path, hostname=None, parallel=True):
        if isinstance(path, pathlib.PurePath):
            path = str(path)
        path = path.format(ifgw_local=self.settings.IFGW_LOCAL,
                           batch_date=self.batch_date.batch_date,
                           YYYYMMDD=self.batch_date.batch_date,
                           YYYY=self.batch_date.batch_date[:4],
                           MM=self.batch_date.batch_date[4:6],
                           DD=self.batch_date.batch_date[6:],
                           timestamp=datetime.now().strftime('%Y%m%d_%H%M%S'))

        if hostname is None:
            if self._SEP not in path:
                msg = 'URIは "論理ホスト名/パス..." の形式で指定してください'
                raise ValueError(msg)
            hostname, path = path.split(sep=self._SEP, maxsplit=1)
        else:
            if path.startswith(self._SEP):
                path = path.split(sep=self._SEP, maxsplit=1)[1]

        # URL 中のユーザ名、パスワード相当部分をパース
        from batch_architecture.client import FTPClient

        self._hostname, self._port, self._user, self._passwd = FTPClient.parse(hostname)

        self._client = None
        self._last_time = None

        self._path = pathlib.PurePosixPath(path)
        self._parallel = parallel

    @property
    def client(self):
        if self._last_time is not None:
            # セッションタイムアウト対策のため、前回アクセスより60秒以上経過していた場合はセッションを作り直す
            if self._last_time + 60 < time.time() and self._client is not None:
                self._client.close()
                self._client = None

        if self._client is None:
            from batch_architecture.client import FTPClient
            self._client = FTPClient()

            self._client.connect(
                self._hostname, port=self._port, user=self._user, passwd=self._passwd
            )

        self._last_time = time.time()

        return self._client

    def __str__(self):
        try:
            if self.is_dir():
                kind = "ディレクトリ"
            elif self.is_file():
                kind = "ファイル"
            else:
                kind = "存在しない"
        except (socket.gaierror, ftplib.error_perm):
            kind = "サーバ接続不可"

        fmt = "FTPTarget({hostname}/{path})[{kind}]"
        return fmt.format(hostname=self._hostname, path=self._path, kind=kind)

    def __eq__(self, other):
        if isinstance(other, str):
            other = FTPTarget(other)
        return self._hostname == other._hostname and self._path == other._path

    def __lt__(self, other):
        if isinstance(other, str):
            other = FTPTarget(other)
        if self._hostname != other._hostname:
            return self._hostname < other._hostname
        else:
            return self._path < other._path

    def __truediv__(self, other):
        if isinstance(other, str):
            return FTPTarget(self._path / other, hostname=self._hostname)
        else:
            return NotImplemented

    @property
    def parent(self):
        return FTPTarget(self._path.parent, hostname=self._hostname)

    def exists(self):
        """
        対象のパスが存在するかどうか調べる。

        :return: bool
        """
        return self.client.exists(str(self._path))

    def is_dir(self):
        """
        対象のパスがディレクトリかどうか調べる。

        :return: bool
        """
        return self.client.is_dir(str(self._path))

    def is_file(self):
        """
        対象のパスがファイルかどうか調べる。

        :return: bool
        """
        return self.client.is_file(str(self._path))

    def mkdir(self, parents=False, exist_ok=False):
        """
        対象のディレクトリを作成する。

        :param parents: 親ディレクトリが存在しない場合に作成するかどうか
        :param exist_ok: 対象のディレクトリがすでに存在する場合にエラーとするかどうか
        """
        return self.client.mkdir(
            str(self._path), cwd=False, parents=parents, exist_ok=exist_ok
        )

    @classmethod
    def _transfer_file(cls, src, dst):
        """
        単一ファイルの転送を行う
        """
        if isinstance(src, FTPTarget):
            if isinstance(dst, FTPTarget):
                # FTP上のコピー
                raise NotImplementedError

            elif isinstance(dst, LocalTarget):
                # FTPからローカルへのダウンロード
                if not dst.parent.exists():
                    # ダウンロード先の親ディレクトリが存在しない場合は作成
                    try:
                        # other thread may create already
                        dst.parent._path.mkdir(parents=True)
                    except FileExistsError:
                        pass
                src.client.download(str(src._path), str(dst._path))
                return cls._check_transfer_result(src, dst)

        elif isinstance(src, LocalTarget):
            if isinstance(dst, FTPTarget):
                # ローカルからFTPへのアップロード
                dst.client.upload(str(src._path), str(dst._path))
                return cls._check_transfer_result(src, dst)

        raise NotImplementedError

    def _delete(self, recursive=True):
        """
        ターゲットのファイル・ディレクトリを削除する。

        :param recursive: 対象がファイル、サブディレクトリを含む時、再帰的に削除するかどうか
        """
        self.client.delete(str(self._path), recursive=recursive)

    @property
    def children(self):
        """
        現在のパスの下にあるディレクトリ、ファイルを取得する。

        :return: サブディレクトリ、ファイルの一覧
        :rtype: list of Target
        """
        if self.is_dir():
            res = []
            for child in self.client.ls(str(self._path)):
                p = self / child
                if p.is_file():
                    res.append(p)
                else:
                    res.extend(p.children)
            return res
        else:
            msg = "指定されたパス {0} はディレクトリではありません".format(self)
            raise FileNotFoundError(msg)

    def relative_to(self, other):
        if isinstance(other, type(self)):
            if self._hostname == other._hostname:
                return self._path.relative_to(other._path)
            else:
                msg = "パス {0} と {1} のホスト名が異なるため、" "相対パスを見つけられません"
                raise ValueError(msg.format(self, other))
        else:
            msg = "パス {0} と {1} の種類が異なるため、相対パスを見つけられません"
            raise ValueError(msg.format(self, other))

    def joinpath(self, *other):
        return FTPTarget(self._path.joinpath(*other), hostname=self._hostname)

    @property
    def md5(self):
        if self.is_file():
            raise NotImplementedError
        else:
            msg = "指定されたパス {0} はファイルではありません".format(self)
            raise FileNotFoundError(msg)
