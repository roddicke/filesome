"""
ローカル、リモートの入出力ターゲットを管理するクラス
"""
import os
import enum
import pathlib
import tempfile

from batch_architecture.core.base import Base


class TargetType(enum.Enum):
    # ローカルファイル
    local = 1
    # S3
    s3 = 2
    # FTP
    ftp = 3
    # SFTP
    sftp = 4
    # HTTP
    http = 5


class FileType(enum.Enum):
    # ファイル
    file = 1
    # ディレクトリ
    dir = 2
    # ファイルが存在しない
    notexists = 3


class Target(Base):
    """
    入出力の対象を管理するクラス。
    """

    @classmethod
    def get_type(cls, uri):
        """
        URI のプロトコル指定部分 (例: `ftp://`` ) を元に、Target の種類を判別する。

        :param uri: パースする URI
        """

        if isinstance(uri, pathlib.PurePath):
            uri = str(uri)

        assert isinstance(uri, str), str
        if str.startswith(uri, "s3://"):
            return TargetType.s3
        elif str.startswith(uri, "ftp://"):
            return TargetType.ftp
        elif str.startswith(uri, "sftp://"):
            return TargetType.sftp
        elif str.startswith(uri, "https://") or str.startswith(uri, "http://"):
            return TargetType.http
        else:
            return TargetType.local

    @classmethod
    def parse(cls, uri):
        """
        URI をパースし、URI で指定された種類の Target インスタンスを
        生成する。

        :param uri: パースする URI
        """
        if isinstance(uri, Target):
            return uri

        if isinstance(uri, pathlib.PurePath):
            uri = str(uri)

        typ = cls.get_type(uri)
        if typ == TargetType.local:
            from batch_architecture.io_target import LocalTarget

            return LocalTarget(uri)
        elif typ == TargetType.s3:
            from batch_architecture.io_target import S3Target

            uri = uri.replace("s3://", "")
            return S3Target(uri)
        elif typ == TargetType.ftp:
            from batch_architecture.io_target import FTPTarget

            uri = uri.replace("ftp://", "")
            return FTPTarget(uri)
        elif typ == TargetType.sftp:
            from batch_architecture.io_target import SFTPTarget

            uri = uri.replace("sftp://", "")
            return SFTPTarget(uri)
        elif typ == TargetType.http:
            from batch_architecture.io_target import HTTPTarget

            return HTTPTarget(uri)
        else:
            msg = "{0} をパースできませんでした"
            ValueError(msg)

    def __init__(self, path):
        msg = "Target クラスを直接インスタンス化することはできません。" "parse メソッドを利用してください"
        raise NotImplementedError(msg)

    def __str__(self):
        if self.is_dir():
            fmt = "{klass}({path})[ディレクトリ]"
        elif self.is_file():
            fmt = "{klass}({path})[ファイル]"
        else:
            fmt = "{klass}({path})[存在しない]"
        klass = self.__class__.__name__
        return fmt.format(klass=klass, path=self._path)

    __repr__ = __str__

    def __eq__(self, other):
        if isinstance(other, (str, pathlib.PurePath)):
            other = Target.parse(other)
            return self == other
        elif not isinstance(other, type(self)):
            return False
        else:
            return self._path == other._path

    def __lt__(self, other):
        if isinstance(other, (str, pathlib.PurePath)):
            other = Target.parse(other)
            return self < other
        else:
            return self._path < other._path

    def __truediv__(self, other):
        if isinstance(other, str):
            return self.__class__(self._path / other)
        else:
            return NotImplemented

    def exists(self):
        """
        対象のパスが存在するかどうか調べる。

        :return: bool
        """
        raise NotImplementedError

    def is_dir(self):
        """
        対象のパスがディレクトリかどうか調べる。

        :return: bool
        """
        raise NotImplementedError

    def is_file(self):
        """
        対象のパスがファイルかどうか調べる。

        :return: bool
        """
        raise NotImplementedError

    def _check_path(self, allow_none=False, allow_file=False, allow_dir=False):
        """
        パスが指定の条件を満たしているかチェックする。

        :param allow_none: bool, パスが存在しないことを許可するかどうか
        :param allow_file: bool, ファイルを許可するかどうか
        :param allow_dir: bool, ディレクトリを許可するかどうか
        """

        if allow_none is False:
            if not self.exists():
                msg = "対象のパス {0} が存在しません".format(self)
                raise FileNotFoundError(msg)

        if allow_file is False:
            if self.is_file():
                msg = "指定したパス {0} にファイルが存在します".format(self)
                raise FileExistsError(msg)

        if allow_dir is False:
            if self.is_dir():
                msg = "指定したパス {0} にディレクトリが存在します".format(self)
                raise FileExistsError(msg)

        return self

    def mkdir(self, parents=False, exist_ok=False):
        """
        対象のディレクトリを作成する。

        :param parents: 親ディレクトリが存在しない場合に作成するかどうか
        :param exist_ok: 対象のディレクトリがすでに存在する場合にエラーとするかどうか
        """
        raise NotImplementedError

    def _assert_copy_condition(self, src, dst):
        """
        コピー元、コピー先のターゲット間の条件を判別する。

        リモートのソースでは is_dir(), is_file() 呼び出しにコストがかかる。
        繰り返しの呼び出しを避けるため、判別した FileType を返す。
        """
        assert isinstance(src, Target), type(src)
        assert isinstance(dst, Target), type(dst)

        if src.is_dir():
            if dst.is_file():
                # ディレクトリをファイルを指定してコピーできない
                msg = (
                    "{src} から {dst} へのコピーに失敗しました。\n"
                    "コピー先のパス {dst} のファイルが存在します。\n"
                    "ディレクトリを既存のファイルに対してコピーすることはできません。"
                )
                raise FileExistsError(msg.format(src=src, dst=dst))
            file_type = FileType.dir
        elif src.is_file():
            if dst.is_dir():
                msg = (
                    "{src} から {dst} へのコピーに失敗しました。\n"
                    "コピー先のパス {dst} のディレクトリが存在します。\n"
                    "ファイルを既存のディレクトリに対してコピーすることはできません。"
                )
                raise FileExistsError(msg.format(src=src, dst=dst))
            file_type = FileType.file
        elif not src.exists():
            msg = "{src} から {dst} へのコピーに失敗しました。" "コピー元のパス {src} は存在しません"
            raise FileNotFoundError(msg.format(src=src, dst=dst))
        return file_type

    def copy_to(self, dst):
        """
        このターゲットから、指定されたターゲットへファイル・ディレクトリを
        コピー・転送する。

        コピー後のデータを指す Target を返す。
        """
        # エラーハンドリングを共通化するため、サブクラスでは _copy_to を実装する
        file_type = self._assert_copy_condition(self, dst)
        self._copy_to(dst, file_type)
        return dst

    def _copy_to(self, dst, file_type):
        msg = "_copy_to が実装されていません。"
        raise NotImplementedError(msg)

    def copy_from(self, src):
        """
        指定されたターゲットから、このターゲットへファイル・ディレクトリを
        コピー・転送する。

        コピー後のデータを指す Target を返す。
        """
        # エラーハンドリングを共通化するため、サブクラスでは _copy_from を実装する
        file_type = self._assert_copy_condition(src, self)
        self._copy_from(src, file_type)
        return self

    def _copy_from(self, src, source_type):
        return src._copy_to(self, source_type)

    def copy_to_temporary(self):
        """
        ターゲットをローカルのテンポラリにコピーし、結果のパスを返す。
        すでにローカルにあるファイル・ディレクトリはコピーしない。
        """

        from batch_architecture.io_target.local_target import LocalTarget

        if isinstance(self, LocalTarget):
            # すでにローカルにあるファイル・ディレクトリはコピーしない
            return self

        if self.is_dir():
            temp = tempfile.mkdtemp()
            file_type = FileType.dir
        elif self.is_file():
            temp = tempfile.mkdtemp()
            temp = os.path.join(temp, self.basename)
            file_type = FileType.file
        else:
            msg = "{src} からローカルのテンポラリフォルダへのコピーに失敗しました。" "コピー元のパス {src} は存在しません"
            raise FileNotFoundError(msg.format(src=self))
        # 実際の転送は各ターゲットに委譲
        dst = LocalTarget(temp)
        self._copy_to(dst, file_type)
        return dst

    def delete(self, recursive=True):
        """
        ターゲットのファイル・ディレクトリを削除する。

        :param recursive: 対象がファイル、サブディレクトリを含む時、再帰的に削除するかどうか
        """
        # エラーハンドリングを共通化するため、サブクラスでは _delete を実装する
        if self.exists():
            self._delete(recursive=recursive)
        else:
            msg = "指定されたパス {0} は存在しません".format(self)
            raise FileNotFoundError(msg)
        return self

    def _delete(self, recursive=True):
        raise NotImplementedError

    @property
    def path(self):
        return self._path

    @property
    def basename(self):
        """
        パスのデリミタ以降 (ファイル名部分) を返す。ディレクトリがデリミタで終わっていない
        場合は最下層のディレクトリ名を返す。
        """
        # self._path は LocalTarget では pathlib.Path、それ以外は PurePosixPath
        return self._path.name

    @property
    def parts(self):
        return self._path.parts

    @property
    def suffix(self):
        return self._path.suffix

    @property
    def suffixes(self):
        return self._path.suffixes

    @property
    def stem(self):
        return self._path.stem

    @property
    def children(self):
        """現在のパス以下にあるディレクトリ、ファイルを返す"""
        raise NotImplementedError


class _RemoteTarget(Target):
    """
    ネットワーク上のターゲットに対する抽象クラス
    """

    def _copy_to(self, dst, file_type):
        from batch_architecture.io_target.local_target import LocalTarget

        if isinstance(dst, (LocalTarget, type(self))):
            if file_type == FileType.dir:
                pairs = []
                for child in self.children:
                    d = dst.joinpath(*child.relative_to(self).parts)
                    if child.is_file():
                        pairs.append((child, d))
                for s, d in pairs:
                    if isinstance(d, LocalTarget):
                        d.parent.mkdir(parents=True, exist_ok=True)

                self._transfer(pairs)

                return dst
            elif file_type == FileType.file:
                return self._transfer_single(self, dst)
            else:
                raise NotImplementedError(file_type)

        raise NotImplementedError(type(dst))

    def _copy_from(self, src, file_type):
        from batch_architecture.io_target.local_target import LocalTarget

        if isinstance(src, (LocalTarget, type(self))):
            if file_type == FileType.dir:
                pairs = []
                for child in src.children:
                    d = self.joinpath(*child.relative_to(src).parts)
                    pairs.append((child, d))

                self._transfer(pairs)

                return self
            elif file_type == FileType.file:
                return self._transfer_single(src, self)
            else:
                raise NotImplementedError(file_type)

        raise NotImplementedError(type(src))

    def _transfer(self, pairs):
        """
        ソース、ターゲットの tuple のリストを受け取り、スレッド並列で転送を行う。
        """
        # ToDo: デバッグモード追加
        if self._parallel is True:
            # msg = '{0} ファイルを並列で転送します'
            # self.logger.info(msg.format(len(pairs)))
            from concurrent.futures import ThreadPoolExecutor

            # ToDo: 並列数変更
            with ThreadPoolExecutor(max_workers=4) as e:
                for res in e.map(lambda x: self._transfer_single(*x), pairs):
                    # ToDo: 結果表示、転送結果確認
                    pass
        else:
            # 逐次転送
            for s, d in pairs:
                self._transfer_single(s, d)

    @classmethod
    def _transfer_single(cls, src, dst):
        """
        単一ファイル同士の転送を行い、正しく転送が行われたかチェックする。

        この関数を呼び出す前に必要な入力チェック(例: 入力がファイルであるかどうか)
        を行うこと。
        """
        cls._transfer_file(src, dst)
        return cls._check_transfer_result(src, dst)

    @classmethod
    def _transfer_file(cls, src, dst):
        """
        単一ファイル同士の転送を行う。継承先にてオーバーライドする。
        """
        raise NotImplementedError

    @classmethod
    def _check_transfer_result(cls, src, dst):
        """
        転送結果の検証を行う。_transfer_single から呼び出される。
        """
        if not dst.exists():
            msg = "出力先のパス {0} にファイルがありません。転送に失敗しました"
            raise FileNotFoundError(msg.format(dst))
        return dst
