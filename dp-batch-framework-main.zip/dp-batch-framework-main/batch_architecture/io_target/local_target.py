"""
ローカルのファイル・ディレクトリに対する入出力制御クラス
"""
import os
import pathlib
import shutil
import hashlib
from datetime import datetime

from batch_architecture.io_target.base import Target, FileType


class LocalTarget(Target):
    _SEP = os.sep

    def __init__(self, path):
        params = dict(
            ifgw_local=self.settings.IFGW_LOCAL,
            resource_dir=self.settings.RESOURCE_DIR,
            end_file_dir=self.settings.END_FILE_DIR,
            batch_date=self.batch_date.batch_date,
            YYYYMMDD=self.batch_date.batch_date,
            YYYY=self.batch_date.batch_date[:4],
            MM=self.batch_date.batch_date[4:6],
            DD=self.batch_date.batch_date[6:],
            timestamp=datetime.now().strftime('%Y%m%d_%H%M%S')
        )
        path = str(path).replace('{', '{{').replace('}', '}}')
        for k in params.keys():
            path = path.replace('{{%s}}' % k, '{%s}' % k)
        path = path.format(**params)
        self._path = pathlib.Path(path)

    @property
    def parent(self):
        return LocalTarget(self._path.parent)

    def exists(self):
        """
        対象のパスが存在するかどうか調べる。

        :return: bool
        """
        return self._path.exists()

    def is_dir(self):
        """
        対象のパスがディレクトリかどうか調べる。

        :return: bool
        """
        return self._path.is_dir()

    def is_file(self):
        """
        対象のパスがファイルかどうか調べる。

        :return: bool
        """
        return self._path.is_file()

    def mkdir(self, mode=0o777, parents=False, exist_ok=False):
        """
        対象のディレクトリを作成する。

        :param mode: 作成したディレクトリに設定するアクセス権
        :param parents: 親ディレクトリが存在しない場合に作成するかどうか
        :param exist_ok: 対象のディレクトリがすでに存在する場合にエラーとするかどうか
        """
        self._path.mkdir(mode=mode, parents=parents, exist_ok=exist_ok)

    def touch(self):
        self._check_path(allow_none=True)
        self._path.touch()

    def write(self, buf):
        file_path = os.path.dirname(self._path)
        if not os.path.exists(file_path):
            os.makedirs(file_path)

        # Windows環境で、'\n'が'\r\n'に自動変換されないようにする
        with open(self._path, 'w', newline='\n') as f:
            f.write(buf)

    def get_file_size(self):
        if not self.is_file():
            msg = "読み込み元 {0} はファイルではありません"
            raise FileNotFoundError(msg.format(self))
        return os.path.getsize(self._path)

    def get_record_count(self):
        if not self.is_file():
            msg = "読み込み元 {0} はファイルではありません"
            raise FileNotFoundError(msg.format(self))

        response = self._path.open()
        row_count = 0
        for x in response:
            if not x.strip():
                continue
            row_count += 1
        response.close()
        return row_count

    def open(self, mode="r", buffering=-1, encoding=None, errors=None, newline=None):
        # openは存在しないファイルを対象する場合もあるため、ファイルの存在確認は行わない。
        return self._path.open(
            mode=mode,
            buffering=buffering,
            encoding=encoding,
            errors=errors,
            newline=newline,
        )

    def read(self, encoding="utf-8"):
        # readは存在するファイルのみ対象を対象にするため、ファイルの存在確認は行う。
        if not self.is_file():
            msg = "読み込み元 {0} はファイルではありません"
            raise FileNotFoundError(msg.format(self))

        response = self.open(encoding=encoding)
        result = response.read()
        response.close()
        return result

    def _copy_to(self, dst, file_type):
        if isinstance(dst, LocalTarget):
            return self._copy_local(dst, file_type)
        else:
            # ローカル -> リモートへのコピーはリモート側の Target に委譲
            return dst._copy_from(self, file_type)
        raise NotImplementedError(type(dst))

    def _copy_local(self, dst, file_type):
        if file_type == FileType.dir:
            pairs = []
            for child in self.children:
                d = dst.joinpath(*child.relative_to(self).parts)
                pairs.append((child, d))
            for s, d in pairs:
                d.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(str(s._path), str(d._path))

        elif file_type == FileType.file:
            dst.parent.mkdir(parents=True, exist_ok=True)
            return shutil.copyfile(str(self._path), str(dst._path))
        else:
            raise NotImplementedError(file_type)

    def _delete(self, recursive=True):
        """
        ターゲットのファイル・ディレクトリを削除する。

        :param recursive: 対象がファイル、サブディレクトリを含む時、再帰的に削除するかどうか
        """
        if self.is_file():
            self._path.unlink()
        elif self.is_dir():
            if self._path == pathlib.Path():
                msg = "カレントディレクトリを削除することはできません"
                raise ValueError(msg)
            # 再帰的に削除
            if recursive is True:
                shutil.rmtree(str(self._path))
            else:
                self._path.rmdir()
        else:
            # ファイルの存在は Target.delete 上でチェック
            raise NotImplementedError

    @property
    def children(self):
        """
        現在のパスの下にあるディレクトリ、ファイルを取得する。

        :return: サブディレクトリ、ファイルの一覧
        :rtype: list of Target
        """
        if self.is_dir():
            res = []
            for x in self._path.iterdir():
                if x.is_file():
                    res.append(LocalTarget(x))
                else:
                    res.extend(LocalTarget(x).children)
            return res
        else:
            msg = "指定されたパス {0} はディレクトリではありません".format(self)
            raise FileNotFoundError(msg)

    def relative_to(self, other):
        if isinstance(other, type(self)):
            return self._path.relative_to(other._path)
        else:
            msg = "パス {0} と {1} の種類が異なるため、相対パスを見つけられません".format(self, other)
            raise ValueError(msg)

    def joinpath(self, *other):
        return LocalTarget(self._path.joinpath(*other))

    @property
    def md5(self):
        if self.is_file():
            # 一度算出したハッシュ値をキャッシュする
            # 算出後にファイルが書き換えられた場合は値がずれるが
            # 通常のフローでは発生し得ないため考慮しない
            if getattr(self, "_md5", None) is None:
                # 逐次読み込むサイズ
                size = 1024
                m = hashlib.md5()
                with self._path.open("rb") as f:
                    while True:
                        buf = f.read(size)
                        if not buf:
                            break
                        m.update(buf)
                self._md5 = m.hexdigest()
            return self._md5
        else:
            msg = "指定されたパス {0} はファイルではありません".format(self)
            raise FileNotFoundError(msg)

    @property
    def file_size(self) -> int:
        """ファイルサイズをバイトで返す"""
        return self._path.stat().st_size

    def archive(self, dst):
        # TODO: 自身が圧縮されているか判定

        import batch_architecture.etl.archive as a

        if self.is_file():
            a.archive_file(self, dst)
        elif self.is_dir():
            a.archive_dir(self, dst)
        else:
            msg = "指定されたパス {0} が存在しません".format(self)
            raise FileNotFoundError(msg)

    def extract(self, dst):
        # 自身が圧縮されているか判定
        import batch_architecture.etl.archive as a

        if self.exists():
            a.extract(self, dst)
        else:
            msg = "指定されたパス {0} が存在しません".format(self)
            raise FileNotFoundError(msg)

    def glob(self, pattern):
        """
        現在のパスの下にあるディレクトリ、ファイルのうちpatternに一致するすべてのファイルを取得する。

        :param pattern: 文字列パターン
        :return: ファイルの一覧
        :rtype: list of Target
        """
        if self.is_dir():
            res = []
            for x in self._path.glob(pattern):
                res.append(LocalTarget(x))
            return res
        else:
            msg = "指定されたパス {0} はディレクトリではありません".format(self)
            raise FileNotFoundError(msg)

    def search_latest_file(self) -> str:
        """
        指定ディレクトリのファイルを捜索して一番ファイル更新日時が新しいファイルのフルパスを返す

        :param path: 検索先のディレクトリ
        :return: 一番更新日時が新しいファイルのフルパス
        """
        if self.is_dir():
            files = [
                str(self._path) + "/" + f
                for f in os.listdir(str(self._path))
                if os.path.isfile(str(self._path) + "/" + f)
            ]
            files.sort(key=os.path.getmtime, reverse=True)
            # 対象ファイルがなかった時
            if len(files) == 0:
                msg = "指定したディレクトリ内にファイルが存在しません。 {0}".format(self)
                raise FileNotFoundError(msg)
            return files[0]
        else:
            msg = "指定されたパス {0} はディレクトリではありません".format(self)
            raise FileNotFoundError(msg)

    def search_oldest_file(self) -> str:
        """
        指定ディレクトリ以下のファイルを捜索して一番ファイル更新日時が古いファイルのフルパスを返す

        :param path: 検索先のディレクトリ
        :return: 一番更新日時が古いファイルのフルパス
        """
        if self.is_dir():
            files = [
                str(self._path) + "/" + f
                for f in os.listdir(str(self._path))
                if os.path.isfile(str(self._path) + "\\" + f)
            ]
            files.sort(key=os.path.getmtime, reverse=False)
            if len(files) == 0:
                msg = "指定したディレクトリ内にファイルが存在しません。 {0}".format(self)
                raise FileNotFoundError(msg)
            return files[0]
        else:
            msg = "指定されたパス {0} はディレクトリではありません".format(self)
            raise FileNotFoundError(msg)
