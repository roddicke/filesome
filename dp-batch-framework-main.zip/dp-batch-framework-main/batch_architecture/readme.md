基本構造を以下のように定義する

* ジョブ定義ファイル

  * リソースディレクトリ (RESOURCE_DEF_DIR) 中の .json ファイルによって定義される
  * ジョブはユニークなジョブIDを持つ (.json ファイルのファイル名部分)
  * ジョブは 1つ以上のロジック制御 (直列) からなる

* ロジック制御クラス (BaseBusinessLogic, apps.core.logic中)

  * すべてのロジック制御クラスの親クラス
  * FTPからのGetなど、バッチの1処理に対応

  * ロジック制御の内容により、利用できる設定は異なる

    * 設定はロジック制御設定クラス (BaseLogicDef) クラスで管理する

* ロジック制御の初期化

  * apps.core.batch_manager.BatchManager に処理対象のジョブIDを指定
  * apps.core.job.Job クラスで .json ファイルを読み取り、 Job クラスとして初期化
  * Job クラスは自身が実行するロジック制御クラスのリストをもつ
