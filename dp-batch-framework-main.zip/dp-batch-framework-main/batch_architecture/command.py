import sys
import os
from datetime import datetime

import click

RET_CREDENTIALS_ERROR = 10001


def setup_path():
    this_file = os.path.abspath(__file__)
    this_path = os.path.dirname(this_file)
    top_path = os.path.dirname(this_path)
    sys.path.insert(0, top_path)


def error_code(exc):
    """
    異常終了時のリターンコードを決定する
    """
    from botocore.exceptions import NoCredentialsError

    if isinstance(exc, (NoCredentialsError,)):
        return RET_CREDENTIALS_ERROR

    return 1


@click.group()
def cmd():
    pass


@cmd.command()
@click.option("-p", default=None)
@click.option("--env", default=None)
@click.option(
    "--sys", "dp_sys_name", default=None,
    type=click.Choice(['dwh', 'nnavi', 'torican', 'mv', 'reporting', 'rit'], case_sensitive=True)
)
@click.option("-v", "verbose", is_flag=True)
@click.option("--dry-run", is_flag=True)
@click.option('--batch-date', type=click.DateTime(formats=["%Y%m%d"]), default=None)
@click.option("--skip-next-job", is_flag=True)
@click.option("--suppress-specific-errors", is_flag=True)
@click.option("--args", default=None)
@click.argument("job_id")
def run(p, env, dp_sys_name, verbose, dry_run, args, job_id,
        batch_date: datetime,
        skip_next_job: bool, suppress_specific_errors: bool):
    """
    実行アーキ起動機能
    """

    # env引数があった場合環境変数を上書き
    if env in [None, '']:
        print("env引数を指定してください ex) command.py run test_job --env dev --sys dwh")
        sys.exit(1)
    if dp_sys_name in [None, '']:
        print("sys引数を指定してください ex) command.py run test_job --env dev --sys dwh")
        sys.exit(1)

    os.environ["ADT_ENV"] = env
    os.environ["ADT_RESOURCE"] = dp_sys_name
    setup_path()
    from batch_architecture.core.settings import Settings
    from batch_architecture.core.log import Logger
    from batch_architecture.core.batch_date import BatchDate
    if verbose:
        Settings.EXEC_MODE = 'VERBOSE'
    if dry_run:
        Settings.EXEC_MODE = 'DRY_RUN'
        Settings.DRY_RUN = True
    if batch_date is not None:
        BatchDate.set_batch_date(batch_date.strftime("%Y%m%d"))
        BatchDate.has_command_line_args_batch_date = True

    if skip_next_job:
        Settings.SENDING_NEXT_JOB_MSG = False

    Logger.set_handler(job_id, Settings.node_name)
    try:
        from batch_architecture.core.batch_manager import BatchManager

        manager = BatchManager(job_id=job_id, parameter_id=p, args=args)
        manager.execute()
    except Exception as e:
        ret_code = error_code(e)
        if suppress_specific_errors and ret_code in (RET_CREDENTIALS_ERROR,):
            Logger.get_logger(__name__).warning("suppress specific error: {}".format(e), cout=True)
        else:
            Logger.get_logger(__name__).exception(e)
        # 異常終了
        sys.exit(ret_code)

    sys.exit(0)


def main():
    cmd()


if __name__ == "__main__":
    main()
