import os

from batch_architecture.client.aws_client import _BotoMixin
from batch_architecture.core.base import Base
from batch_architecture.core.resources import Resources


class STSClient(Base, _BotoMixin):
    _KEY = 'sts'
    _REGION = Resources.get("sts").region
    _ENDPOINT_URL = Resources.get("sts").endpoint_url
    _LOGGER_NAME = os.path.basename(__file__)

    def get_credentials(self, role_arn, role_session_name) -> dict:
        assumed_role_object = self.client.assume_role(RoleArn=role_arn, RoleSessionName=role_session_name)
        credentials = assumed_role_object['Credentials']
        return credentials
