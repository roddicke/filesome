import os
import pathlib
import configparser

from batch_architecture.core.settings import Settings
from batch_architecture.core.resources import Resources


class _BotoMixin(object):
    """
    Boto3 を利用するクラスに共通のメソッドを定義する。
    """

    # Boto3 のサービスを指定する識別子 (s3, emr など)
    _KEY = None
    _REGION = None
    _ENDPOINT_URL = None
    _CREDENTIALS: dict = None

    @property
    def client(self):
        """
        Boto3 のクライアントを取得する。
        """

        if getattr(self, "_client", None) is None:
            try:
                import boto3
                from botocore.client import Config
                from boto3.session import Session
            except ImportError:
                msg = "boto3 をインストールしてください"
                raise ImportError(msg)

            if self._CREDENTIALS is not None:
                boto3 = Session(aws_access_key_id=self._CREDENTIALS['AccessKeyId'],
                                aws_secret_access_key=self._CREDENTIALS['SecretAccessKey'],
                                aws_session_token=self._CREDENTIALS['SessionToken'])
            else:
                try:
                    boto3 = Session(profile_name=Settings.PROFILE_NAME)
                except Exception as e:
                    # credential情報がない場合IAMロールでの認証となる
                    boto3 = Session()
            # KMSキーによる暗号化には署名バージョン4が必要
            self._client = boto3.client(
                self._KEY,
                config=Config(signature_version="s3v4"),
                # verify=False,
                region_name=self._REGION,
                endpoint_url=self._ENDPOINT_URL
            )
        return self._client

    def resource(self, bucket_name):
        """
        Boto3 のリソースを取得する。
        """
        if getattr(self, "_resource", None) is None:
            try:
                import boto3
                from botocore.client import Config
                from boto3.session import Session
            except ImportError:
                msg = "boto3 をインストールしてください"
                raise ImportError(msg)

        if bucket_name in Resources._resources:
            access_key_id = Resources.get(bucket_name)._access_key_id
            secret_access_key = Resources.get(bucket_name)._secret_access_key
        else:
            access_key_id = None
            secret_access_key = None

        if access_key_id is not None:
            boto3 = Session(
                aws_access_key_id=access_key_id, aws_secret_access_key=secret_access_key
            )
        else:
            try:
                boto3 = Session(profile_name=Settings.PROFILE_NAME)
            except Exception as e:
                boto3 = Session()
        # KMSキーによる暗号化には署名バージョン4が必要
        self._resource = boto3.resource(
            self._KEY, config=Config(signature_version="s3v4"),
            # verify=False,
        )

        return self._resource

    def _parse_config(self, config):
        """
        設定ファイルをパースする。

        引数が設定ファイルのパスの場合は設定ファイルを読み込み、
        自身の `_KEY` と同名のセクションをパースする。

        :param config: 設定ファイルの特定セクション (`configparser.SectionProxy`)
                       もしくは設定ファイルのパス
        :return: `configparser.SectionProxy`
        """

        if isinstance(config, (dict, configparser.SectionProxy)):
            return config

        elif isinstance(config, (str, pathlib.Path)):
            config = str(config)

            if not os.path.exists(config):
                msg = "Unable to find config file {0}"
                raise FileNotFoundError(msg.format(config))

            c = configparser.ConfigParser()
            c.read(config)
            # slice section
            return c[self._KEY]

        else:
            # TODO:
            raise ValueError(type(config))

    def _set_waiter_props(self, waiter):
        """
        waiter のリトライ回数 (`max_attempts`)、 リトライ間隔 (`delay`) を設定する。

        :param waiter: Boto3 (botocore) の `Waiter` インスタンス
        :return: Boto3 (botocore) の `Waiter` インスタンス
        """
        if self._max_attempts is not None:
            waiter.config.max_attempts = self._max_attempts
        if self._delay is not None:
            waiter.config.delay = self._delay
        return waiter

    def _assert_bool(self, value):
        """
        値が `bool` もしくは `bool` に変換できる文字列かチェックする。
        `bool` に変換できない場合は `ValueError` が発生する。

        以下の文字列は `bool` に変換される。

        - `True`, `true`
        - `False`, `false`

        このメソッドは設定ファイルをパースする際に利用される。

        :param value: `bool` かどうかチェックする値
        :return: bool
        :rtype: bool
        """
        if isinstance(value, bool):
            return value

        elif isinstance(value, str):
            if value in ("True", "true"):
                return True
            elif value in ("False", "false"):
                return False

        msg = "値 {} は bool 型に変換できませんでした"
        raise ValueError(msg.format(value))
