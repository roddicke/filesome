"""
SQLServer 接続機能
"""
import os
import time

import pymssql

from batch_architecture.core.base import Base
from batch_architecture.core.resources import Resources
from batch_architecture.core.utils import byte_decode


def decode_args(args):
    args = tuple(
        decode_args(x) if isinstance(x, tuple)
        else byte_decode(x) if isinstance(x, bytes)
        else x for x in args
    )
    return args


class SQLServerClient(Base):
    _LOGGER_NAME = "batch_architecture.client.sqlserver_client"
    MAX_CONNECT_RETRY = 3
    MAX_EXE_RETRY = 1
    RETRY_DELAY = 10

    def __init__(self, database=None, username=None, password=None, server=None, port=None):
        """
        クライアントを初期化する。
        """
        try:
            res_name = "sqlserver-{}".format(os.environ["ADT_RESOURCE"])
            self.logger.info('RESOURCE: %s' % res_name)
            sqlserver_resource = Resources.get(res_name)
        except KeyError:
            msg = "resources.iniファイルに指定されたセクション {section} が存在しません。"
            raise KeyError(msg.format(section=database))

        if username is not None:
            self._username = username
        else:
            self._username = sqlserver_resource._username

        if password is not None:
            self._password = password
        else:
            self._password = sqlserver_resource._password

        if server is not None:
            self._server = server
        else:
            self._server = sqlserver_resource._server

        if port is not None:
            self._port = port
        else:
            self._port = sqlserver_resource._port

        if database is not None:
            self._database = database
        else:
            self._database = sqlserver_resource._database

    def __str__(self):
        """インスタンスの文字列表現を取得する。"""
        try:
            self.connect()
            status = "データベース接続完了"
        except:
            status = "データベース接続不可"

        fmt = "{klass}({user}@{host}:{port}/{dbname})[{status}]"
        return fmt.format(
            klass=self.__class__.__name__,
            dbname=self._dbname,
            host=self._host,
            user=self._username,
            port=self._port,
            status=status,
        )

    def __del__(self):
        if getattr(self, "_connection", None) is not None:
            self._connection.close()
            self._connection = None
            self._cursor = None

    __repr__ = __str__

    def is_connected(self):
        """
        指定した DB へ接続しているかどうかを調べる。

        :return: `bool`
        :rtype: bool
        """
        return getattr(self, "_connection", None) is not None

    def connect(self):
        """
        指定した DB に接続する。

        1回目の接続情報をキャッシュし、2回目以降はキャッシュを利用する。

        :return: self
        """
        if getattr(self, "_connection", None) is None:
            for i in range(self.MAX_CONNECT_RETRY + 1):
                try:
                    self._connection = pymssql.connect(
                        server=self._server,
                        port=self._port,
                        user=self._username,
                        password=self._password,
                        database=self._database,
                        # charset='sjis',
                    )
                    self._cursor = self._connection.cursor()
                    return self
                except pymssql.OperationalError as e:
                    e.args = decode_args(e.args)
                    if e.args[0][0] == 20009:  # Unable to connect
                        if i == self.MAX_CONNECT_RETRY:
                            self.logger.error("最大リトライ回数を超えました: {}".format(e))
                            raise
                        self.logger.info("リトライします。: {}".format(e))
                        time.sleep(self.RETRY_DELAY)
                    else:
                        raise
                except Exception as e:
                    e.args = decode_args(e.args)
                    raise

        return self

    def execute_sql(self, query, bind=None, query_log=True):
        """
        指定した DB で SQL を実行する。

        :param query: 実行する SQL
        :param bind: 置換パラメータ
        :param query_log: 実行クエリのログ出力有無
        """
        for i in range(self.MAX_EXE_RETRY + 1):
            try:
                if bind is None:
                    if query_log:
                        self.logger.info("\n" + query)
                    self._cursor.execute(query)
                else:
                    if query_log:
                        self.logger.info("\n" + query.format(**bind))
                    self._cursor.execute(query.format(**bind))
                return
            except pymssql.OperationalError as e:
                lst_errno = (
                    208,  # Invalid object name 'XXX'.
                    916,  # The server principal "XXX" is not able to access the database
                    2702,  # Database 'XXX' does not exist.
                    4701,  # Cannot find the object "XXX" because it does not exist or you do not have permissions
                )
                for no in lst_errno:
                    if no in e.args:
                        raise
                self.logger.warning(e)
                if i == self.MAX_EXE_RETRY:
                    e.args = decode_args(e.args)
                    self.logger.error("最大リトライ回数を超えました: {}".format(e))
                    raise
                self.logger.info("リトライします。: {}回目".format(i + 1))
                time.sleep(self.RETRY_DELAY)
                self.close()
                self.connect()
            except Exception as e:
                e.args = decode_args(e.args)
                raise

    def explain_sql(self, query, bind={}):
        """
        :param query: 実行する SQL
        :param bind: 置換パラメータ
        """
        self.logger.info("\nEXPLAIN\n" + query.format(**bind))
        self._cursor.execute("\nEXPLAIN\n" + query.format(**bind))
        self._cursor.get_results_from_sfqid(self._cursor.sfqid)
        self.logger.info(self._cursor.fetchall())

    def fetch_one(self):
        """現在のカーソルから一レコードを取得する。"""
        result = self._cursor.fetchone()
        return result if result is not None else []

    def fetch_all(self):
        """現在のカーソルから全レコードを取得する。"""
        return self._cursor.fetchall()

    def get_affected_rows(self):
        """現在のカーソルに含まれるレコード数を取得する。"""
        return self._cursor.rowcount

    def get_column_names(self):
        """現在のカーソルに含まれるヘッダ情報を取得する。"""
        return self._cursor.description

    def commit(self):
        """コミットを行う。"""
        if getattr(self, "_connection", None) is not None:
            self.logger.info("コミットを実行しました。")
            self._connection.commit()
        else:
            self.logger.info("コミットを実行しようとしましたが、コネクションがすでに切断されています。")

    def rollback(self):
        """ロールバックを行う。"""
        if getattr(self, "_connection", None) is not None:
            self.logger.info("ロールバックを実行しました。")
            self._connection.rollback()
        else:
            self.logger.info("ロールバックを実行しようとしましたが、コネクションがすでに切断されています。")

    def close(self):
        """指定した DB への接続をクローズする。"""
        if getattr(self, "_connection", None) is not None:
            self.logger.info("コネクションを切断しました。")
            self._connection.close()
            self._connection = None
            self._cursor = None
        else:
            self.logger.info("コネクションを切断しようとしましたが、コネクションがすでに切断されています。")
