import os
import time

from batch_architecture.client.aws_client import _BotoMixin
from batch_architecture.core.base import Base
from batch_architecture.core.resources import Resources


class GlueClient(Base, _BotoMixin):
    _KEY = 'glue'
    _REGION = Resources.get("glue").region
    _ENDPOINT_URL = Resources.get("glue").endpoint_url
    _LOGGER_NAME = os.path.basename(__file__)

    def __init__(self, credentials=None):
        self._CREDENTIALS = credentials

    def start_job_run(self, job_name) -> dict:
        """
        Glueジョブを実行する
        :param job_name:
        :return {'JobRunId': 'string'}:
        """
        self.logger.info(f'Glueジョブ({job_name})を実行します')
        return self.client.start_job_run(JobName=job_name, Arguments={"--env": os.environ["ADT_ENV"]})

    def get_job(self, job_name: str) -> dict:
        return self.client.get_job(JobName=job_name)

    def polling_job_run(self, job_name: str, job_run_id: str, max_polling_min: int, polling_interval_sec: int) -> str:
        """
        実行したGlueジョブが完了になるまで待つ
        エラーになった場合は例外を発生させる
        :param job_name:
        :param job_run_id:
        :param max_polling_min:
        :param polling_interval_sec:
        :return: status:
        """
        # 繰り上げ除算
        max_attempts = -1 * (-60 * max_polling_min // polling_interval_sec)
        self.logger.info(f'Glueジョブ({job_name})のポーリングを開始します。')
        self.logger.info(f'MAX_POLLING_MIN: {max_polling_min}')
        self.logger.info(f'POLLING_INTERVAL_SEC: {polling_interval_sec}')
        for i in range(max_attempts + 1):
            dict_status: dict = self.client.get_job_run(JobName=job_name, RunId=job_run_id)
            status = dict_status['JobRun']['JobRunState']
            log_group_name = dict_status['JobRun']['LogGroupName']
            if status in ['SUCCEEDED', 'FAILED', 'ERROR', 'TIMEOUT']:
                self.logger.info(f"LogGroupName: {log_group_name}")
                self.logger.info(f"JobRunId: {job_run_id}")
                if status == 'SUCCEEDED':
                    self.logger.info(f'Glueジョブ({job_name})は正常終了しました。')
                    self.logger.info(f"実行時間: {dict_status['JobRun']['ExecutionTime']}[sec]")
                    return 'SUCCEEDED'
                elif status == 'FAILED':
                    self.logger.error(f'Glueジョブ({job_name})は異常終了しました。')
                    self.logger.error('ErrorMessage: %s' % dict_status['JobRun']['ErrorMessage'])
                    return 'FAILED'
                elif status == 'ERROR':
                    self.logger.error(f'Glueジョブ({job_name})は削除済みです。')
                    raise Exception(dict_status['JobRun']['ErrorMessage'])
                elif status == 'TIMEOUT':
                    self.logger.info(f'Glueジョブ({job_name})の実行時間がタイムアウト値を超えました。')
                    raise Exception(dict_status['JobRun']['ErrorMessage'])
            else:
                self.logger.info(f"STATUS: {status},"
                                 f" 実行時間: {dict_status['JobRun']['ExecutionTime']}[sec]")
            time.sleep(polling_interval_sec)
        else:
            raise Exception(f'最大ポーリング時間({max_polling_min}[min])を超過しました。')
