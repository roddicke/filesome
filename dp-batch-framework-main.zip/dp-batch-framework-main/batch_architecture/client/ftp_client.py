"""
FTPクライアント機能
"""
from enum import Enum
from functools import wraps
import ftplib
import pathlib

from urllib.parse import splituser, splitpasswd

from batch_architecture.core.settings import Settings
from batch_architecture.core.resources import Resources
from batch_architecture.core.log import Logger


class FTPMode(Enum):
    """
    FTP の転送モードを指定する
    """

    ascii = 1
    binary = 2


def reset_cwd(method):
    """
    FTP のワーキングディレクトリをリセットする
    """

    @wraps(method)
    def wrapper(self, *args, **kwargs):
        if not self._enabled:
            return method(self, *args, **kwargs)

        pwd = self._ftp.pwd()
        res = method(self, *args, **kwargs)
        self._ftp.cwd(pwd)
        return res

    return wrapper


class FTPClient(object):
    """FTP クライアント"""

    # パスは URI の形式で指定
    _SEP = "/"
    _DEFAULT_PORT = 21

    def __init__(self):
        self._ftp = None
        self._logger = Logger.get_logger(self.__class__.__name__)

        ftp_status = Settings.EXTERNAL_TRANSFER_FTP_STATUS
        self._enabled = ftp_status == 'enabled'

    def __del__(self):
        """デストラクタ"""
        if self._ftp is not None:
            self._ftp.close()
            self._ftp = None

    def connect(self, hostname, port=None, user=None, passwd=None):
        """
        FTP サーバに接続する。

        :param hostname: 接続サーバ論理名
        :param port: 接続ポート番号
        :param user: ユーザ名
        :param passwd: パスワード
        :return:
        :rtype: FTPClient
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためFTPサーバへの接続をスキップしました。')
            return self

        act_mode = "1"
        if hostname.startswith('[') and hostname.endswith(']'):
            hostname = hostname[1:-1]
            # 設定ファイルから物理ホストを取得
            host = Resources.get(hostname)._host
            port = Resources.get(hostname)._port
            try:
                user = Resources.get(hostname)._username
                passwd = Resources.get(hostname)._password
                act_mode = Resources.get(hostname)._act_mode
            except KeyError:
                pass
            self._logger.info(
                "FTP config [%s]: %s%s:%s(%s)" % (
                    hostname,
                    '%s@' % user if user and passwd else '',
                    host, port, 'active' if act_mode == '1' else 'passive'
                )
            )
        else:
            host = hostname
            port = self._DEFAULT_PORT if port is None else port
            self._logger.info(
                "FTP config: %s%s:%s(%s)" % (
                    '%s@' % user if user and passwd else '',
                    host, port, 'active' if act_mode == '1' else 'passive'
                )
            )

        ftp = ftplib.FTP()
        self._logger.info("FTP接続を開始します")
        ftp.connect(host, port=port)
        self._logger.info("FTP接続を完了しました")

        if user is not None and passwd is not None:
            self._logger.info("FTPログインを開始します")
            ftp.login(user=user, passwd=passwd)
            self._logger.info("FTPログインを完了しました")
        else:
            ftp.login()
        if act_mode == "1":
            ftp.set_pasv(False)

        try:
            ftp.sendcmd('OPTS UTF8 ON')

            # ftp.voidcmd('OPTS UTF8 ON')
            ftp.encoding = 'utf-8'
        except ftplib.all_errors as e:
            self._logger.warning(e)

        self._ftp = ftp
        return self

    @classmethod
    def parse(self, hostname):
        """
        接続サーバ名中に含まれるユーザ名、パスワード、ポートをパースして分割する

        :param hostname: 接続サーバ名
        :return: hostname, port, username, password
        :rtype: tuple
        """
        u, h = splituser(hostname)

        # ホスト名のパース
        if ":" in h:
            hostname, port = h.split(":")
            port = int(port)
        else:
            hostname = h
            port = None

        # ユーザ名、パスワードのパース
        if u is None:
            user = None
            passwd = None
        else:
            user, passwd = splitpasswd(u)

        return hostname, port, user, passwd

    def _split(self, path):
        """
        パスを区切り文字 (`self._SEP`) で分割する。

        :param path: FTP 上のファイルパス
        :return: パスをフォルダ、ファイルで分割したリスト
        :rtype: list of str
        """
        if isinstance(path, pathlib.PurePath):
            path = str(path)
        return path.split(sep=self._SEP)

    def _move_under(self, path):
        """
        指定されたパスの直下 (パスの親ディレクトリ) まで cwd で移動する。

        :param path: FTP 上のファイルパス
        """
        path = self._split(path)[:-1]
        # ファイルパスの階層をたどる
        self.cwd(path)

    @reset_cwd
    def exists(self, path):
        """指定されたパスが FTP サーバ上に存在するか調べる。

        :param path: FTP 上のファイルパス
        :rtype: bool
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return True

        try:
            self._move_under(path)
            target = self._split(path)[-1]
            if target in self._ftp.nlst():
                return True
        except:
            pass
        return False

    @reset_cwd
    def is_dir(self, path):
        """
        指定されたパスがディレクトリかどうか調べる。

        制約事項: 対象のパスへ cwd できるかで判定するため、参照権限のないディレクトリは
        ファイルとして判定される。

        :param path: FTP 上のファイルパス
        :rtype: bool
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return False

        try:
            # 指定したパスに移動できればディレクトリである
            self.cwd(path)
            return True
        except:
            pass
        return False

    @reset_cwd
    def is_file(self, path):
        """
        指定されたパスがファイルかどうか調べる。

        :param path: FTP 上のファイルパス
        :rtype: bool
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return True

        if self.is_dir(path):
            # ディレクトリならばファイルではない
            return False
        try:
            self._move_under(path)
            target = self._split(path)[-1]
            if target in self._ftp.nlst():
                return True
        except:
            return False

    @reset_cwd
    def upload(self, src, dst, mode=FTPMode.binary):
        """
        ローカルのファイルを指定されたモードで FTP にアップロードする。

        :param src: アップロード元のパス (ローカルのファイルパス)
        :param dst: アップロード先のパス (FTP 上のファイルパス)
        :param mode: 転送モード、デフォルトは Binary
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return

        dst_path = self._split(dst)
        # アップロードするファイル名
        dst_file = dst_path[-1]
        # CWDで移動していくパス
        dst_path = dst_path[:-1]

        # ファイルパスの階層をたどり、ディレクトリがない場合は作成する
        self.mkdir(self._SEP.join(dst_path), cwd=True, parents=True, exist_ok=True)

        from batch_architecture.io_target import LocalTarget

        src = LocalTarget(src)._check_path(allow_file=True)

        if mode == FTPMode.ascii:
            self._ftp.storlines("STOR %s" % dst_file, src.open(mode="rb"))
        elif mode == FTPMode.binary:
            self._ftp.storbinary("STOR %s" % dst_file, src.open(mode="rb"))
        else:
            msg = "転送モード {0} は不正です".format(mode)
            raise ValueError(msg)

    @reset_cwd
    def download(self, src, dst, mode=FTPMode.binary):
        """
        FTP サーバ上のファイルを指定されたモードでローカルにダウンロードする。

        :param src: ダウンロード元のパス (FTP 上のファイルパス)
        :param dst: ダウンロード先のパス (ローカルのファイルパス)
        :param mode: 転送モード、デフォルトは Binary
        """
        if self.is_dir(src):
            # ダウンロード先は既存のディレクトリ、もしくは空のパス
            msg = "ダウンロード対象のパス {0} はディレクトリです".format(src)
            raise FileExistsError(msg)
        elif self.is_file(src):
            # ダウンロード先は既存のファイル、もしくは空のパス
            from batch_architecture.io_target import LocalTarget

            dst = LocalTarget(dst)
            dst._check_path(allow_none=True, allow_file=True)

            dst = dst._path
            if not dst.exists():
                dst.touch()

            self._move_under(src)
            file = self._split(src)[-1]
            return self._download_single(file, dst, mode=mode)
        else:
            msg = "FTP サーバ上のパス {0} がありません".format(src)
            raise FileNotFoundError(msg)

    def _download_single(self, src, dst, mode=FTPMode.binary):
        """
        単一のファイルをダウンロードする際に呼び出される処理。
        外部から直接利用することは想定しない。
        連続して呼び出されるため、reset_cwd してはならない。

        :param src: ダウンロード元のパス (FTP 上の cwd からの相対パス)
        :param dst: ダウンロード先のパス (ローカルのファイルパス)
        :param mode: 転送モード、デフォルトは Binary
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return

        if mode == FTPMode.ascii:
            self._ftp.retrlines("RETR %s" % src, dst.open(mode="w").write)
        elif mode == FTPMode.binary:
            self._ftp.retrbinary("RETR %s" % src, dst.open(mode="wb").write)
        else:
            msg = "転送モード {0} は不正です".format(mode)
            raise ValueError(msg)

    @reset_cwd
    def ls(self, path=None):
        """
        指定したパスに含まれるファイル・フォルダの一覧を取得する。
        `path` が指定されない場合、cwd に含まれるファイル・フォルダの一覧を取得する。

        :param path: FTP 上のファイルパス
        :return: ファイル・フォルダの一覧
        :rtype: list of str
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return []

        if path is not None:
            self.cwd(path)

        files = []

        def dir_callback(line):
            bits = line.split()
            if "d" not in bits[0]:
                files.append(bits[-1])

        self._ftp.dir(dir_callback)
        return files

    def mkdir(self, path, cwd=True, parents=False, exist_ok=False):
        """
        FTP 上にディレクトリを作成する。

        :param path: 作成するディレクトリのパス
        :param cwd: 作成したディレクトリをカレントディレクトリとするかどうか
        :param parents: 親ディレクトリが存在しない場合に作成するかどうか
        :param exist_ok: 対象のディレクトリがすでに存在する場合にエラーとするかどうか
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return

        # すでに作成対象のディレクトリが存在する場合
        if self.exists(path):
            if exist_ok is True:
                if cwd is True:
                    self.cwd(path)
                return
            else:
                msg = "FTP サーバ上のパス {0} はすでに存在します".format(path)
                raise FileExistsError(msg)

        # 現在のワーキングディレクトリを記憶
        pwd = self.pwd()
        if parents is True:
            # 再帰的にディレクトリを作成
            path = self._split(path)
            for p in path:

                try:
                    self._ftp.cwd(p)
                except ftplib.error_perm as e:
                    if e.args[0][:3] == "550":
                        self._ftp.mkd(p)
                        self._ftp.cwd(p)
                    else:
                        raise
        else:
            try:
                self._ftp.mkd(path)
                self._ftp.cwd(path)
            except ftplib.error_perm as e:
                if e.args[0][:3] == "550":
                    msg = "指定したパス {0} のパレントディレクトリが存在しません"
                    raise FileNotFoundError(msg.format(path))
                raise

        if not cwd:
            # ディレクトリ作成前のワーキングディレクトリに戻る
            self.cwd(pwd)

    def delete(self, path, recursive=True):
        """
        FTP 上のファイル・ディレクトリを削除する。

        :param path: 削除するファイル・ディレクトリのパス
        :param recursive: 対象がファイル、サブディレクトリを含む時、再帰的に削除するかどうか
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return

        if self.is_dir(path):
            if recursive:
                pwd = self.pwd()
                self.cwd(path)
                childs = self.ls()
                for child in childs:
                    self.delete(child, recursive=recursive)
                self.cwd(pwd)
            return self._ftp.rmd(path)
        elif self.is_file(path):
            return self._ftp.delete(path)
        else:
            msg = "FTP サーバ上のパス {0} がありません".format(path)
            raise FileNotFoundError(msg)

    def cwd(self, path):
        """
        指定されたパスに移動する。

        :param path: FTP 上のファイルパス
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return

        if isinstance(path, list):
            path = self._SEP.join(path)

        if isinstance(path, str):
            try:
                return self._ftp.cwd(path)
            except:
                msg = "FTP サーバ上のパス {0} がありません".format(path)
                raise FileNotFoundError(msg)
        else:
            raise ValueError(type(path))

    def pwd(self):
        """
        ワーキングディレクトリを取得する。

        :return: FTP 上のファイルパス
        """
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return ''

        return self._ftp.pwd()

    def close(self):
        """FTP 接続をクローズする。"""
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return

        # TODO: デストラクタでのクローズ処理実施
        self._ftp.close()
        self._ftp = None

    def set_passive_mode(self):
        """パッシブモードに切り替える"""
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return

        self._ftp.set_pasv(True)

    def set_active_mode(self):
        """アクティブモードに切り替える"""
        if not self._enabled:
            self._logger.info('外部へのFTP送信機能が無効になっているためスキップしました。')
            return

        self._ftp.set_pasv(False)
