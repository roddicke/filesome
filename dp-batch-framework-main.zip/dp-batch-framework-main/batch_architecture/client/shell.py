"""
共通シェル機能
"""
import time
import threading
import subprocess as sp
import tempfile

from batch_architecture.core.base import Base

# 経過途中ログ出力間隔
LOGOUT_INT_SEC = 60


class Shell(Base):
    """シェルコマンド実行クライアント"""
    _LOGGER_NAME = 'batch_architecture.client.shell'

    def execute(self, cmd, env=None, stdin=None):
        """
        指定されたコマンドを実行する。

        :param cmd: 実行するコマンド
        :param env: 環境変数
        :param stdin: 入力データ
        :return: リターンコード、標準出力、エラー出力のタプル
        :rtype: tuple of str
        """
        if stdin is not None:
            fp = tempfile.NamedTemporaryFile(mode='w+b')
            fp.write(stdin)
            fp.seek(0)
            stdin = fp
        else:
            stdin = sp.PIPE

        pipe = []

        # コマンド実行関数
        def run():
            self.logger.info("コマンドを実行します: %s" % cmd)
            p = sp.run(cmd, shell=True, env=env, stdin=stdin, stdout=sp.PIPE, stderr=sp.PIPE, text=True)
            pipe.append(p)

        # 非同期にログを出力するように、コマンド実行をスレッド化する
        th = threading.Thread(target=run)
        th.setDaemon(True)
        th.start()
        s_time = check_time = time.time()
        while th.is_alive():
            now = time.time()
            if check_time + LOGOUT_INT_SEC < now:
                self.logger.info('実行中: %d秒経過' % int(now - s_time))
                check_time = now
            time.sleep(0.1)
        th.join()

        p = pipe[0]
        if p.returncode != 0:
            msg = f"{cmd} コマンド実行に失敗しました。\n標準出力: {p.stdout}\n標準エラー: {p.stderr}"
            raise SystemError(msg)

        ret = p.returncode
        out = p.stdout
        err = p.stderr

        return ret, out, err
