import os
import time

from batch_architecture.client.aws_client import _BotoMixin
from batch_architecture.core.base import Base
from batch_architecture.core.exceptions import RetryOutError
from batch_architecture.core.resources import Resources


class SqsClient(Base, _BotoMixin):
    _KEY = 'sqs'
    _REGION = Resources.get("sqs").region
    _ENDPOINT_URL = Resources.get("sqs").endpoint_url
    _LOGGER_NAME = os.path.basename(__file__)

    def purge_queue(self, url) -> None:
        """
        対象のQUEUE URLのメッセージをすべて削除します。
        削除に最大60s掛かるので、QUEUEの大きさによらず毎回60s待ちます。
        :param url:
        :return:
        """
        self.client.purge_queue(QueueUrl=url)
        self.logger.info('キューの中身を削除するために60秒sleepします')
        time.sleep(60)

    def send_message_batch(self, url, message_bodies, max_retry=5) -> None:
        """
        SQSにバッチでメッセージを送ります。
        指定したリトライ回数を超えると例外を発生させます。

        """
        retry_count = 0
        while message_bodies:
            failed = []
            if retry_count >= max_retry:
                self.logger.error('sqsへのキューイングに失敗しました。 url: {}, failed: {}'.format(url, message_bodies))
                raise RetryOutError
            for i in range((len(message_bodies)-1)//10 + 1):
                batch = message_bodies[i * 10:(i + 1) * 10]
                req = self._send_message_batch(url, batch)
                failed.extend([m for i, m in enumerate(batch) if i in req['failed']])

            message_bodies = failed
            retry_count += 1

    def _send_message_batch(self, url, message_bodies) -> dict:
        """

        :rtype: dict return indexes of message_bodies such like: {'successful': [0, 1, 3], 'failed': [2]}
        """
        if len(message_bodies) > 10:
            self.logger.error('SQSに一度に送れるメッセージは最大10件です。現在{}件送ろうとしています。'.format(len(message_bodies)))
            raise ValueError

        entries = []
        for i, body in enumerate(message_bodies):
            entries.append(
                {'Id': str(i), 'MessageBody': body}
            )
        res = self.client.send_message_batch(QueueUrl=url, Entries=entries)
        ret = {'successful': [int(x['Id']) for x in res['Successful']],
               'failed': []}
        if 'Failed' in res:
            ret['failed'] = [int(x['Id']) for x in res['Failed']]

        return ret
