import time

import psycopg2
from psycopg2 import OperationalError

from batch_architecture.core.base import Base
from batch_architecture.core.resources import Resources


class PostgresSQLClient(Base):
    """SQL クライアント"""
    _LOGGER_NAME = "batch_architecture.client.postgresql_client"
    MAX_RETRY = 3
    RETRY_DELAY = 10

    # PostgreSQL では、エラー発生後は rollback しないと
    # 後続のトランザクションを受け付けない
    # 各 SQL 共通のテストケースを書く場合は エラー後に rollback すること

    def __init__(self, host=None, dbname=None, user=None, password=None, port=None):
        """
        SQL クライアントを初期化する。

        :param dbname: 接続先 DB の DB 名
        :param user: DB 接続時のユーザ名
        :param password: DB 接続時のパスワード
        :param port: 接続先 DB のポート番号
        """
        try:
            Resources.get("postgresql")
        except KeyError:
            msg = "resources.iniファイルに指定されたセクション {section} が存在しません。"
            raise KeyError(msg.format(section="postgresql"))

        if host is not None:
            self._host = host
        else:
            self._host = Resources.get("postgresql")._host
        if dbname is not None:
            self._dbname = dbname
        else:
            self._dbname = Resources.get("postgresql")._dbname
        if user is not None:
            self._user = user
        else:
            self._user = Resources.get("postgresql")._user
        if password is not None:
            self._password = password
        else:
            self._password = Resources.get("postgresql")._password
        if port is not None:
            self._port = port
        else:
            self._port = Resources.get("postgresql")._port

    def __str__(self):
        """インスタンスの文字列表現を取得する。"""
        try:
            self.connect()
            status = "データベース接続完了"
        except Exception:
            status = "データベース接続不可"

        fmt = "{klass}({user}@{host}:{port}/{dbname})[{status}]"
        return fmt.format(
            klass=self.__class__.__name__,
            dbname=self._dbname,
            host=self._host,
            user=self._user,
            port=self._port,
            status=status,
        )

    __repr__ = __str__

    def is_connected(self):
        """
        指定した DB へ接続しているかどうかを調べる。

        :return: `bool`
        :rtype: bool
        """
        return getattr(self, "_connection", None) is not None

    def connect(self):
        """
        データベースに接続する。1回目の接続情報をキャッシュし、2回目以降はキャッシュを返す。
        """
        if getattr(self, "_connection", None) is None:
            for i in range(self.MAX_RETRY + 1):
                try:
                    self._connection = psycopg2.connect(
                        dbname=self._dbname,
                        host=self._host,
                        user=self._user,
                        password=self._password,
                        port=self._port,
                    )
                    self._cursor = self._connection.cursor()
                    break
                except OperationalError as e:
                    self.logger.warning(e)
                    if i == self.MAX_RETRY:
                        self.logger.error("最大リトライ回数を超えました。")
                        raise
                    self.logger.info("リトライします。: {}回目".format(i + 1))
                    time.sleep(self.RETRY_DELAY)

        return self

    def execute_sql(self, query, query_log=True):
        """
        指定した DB で SQL を実行する。

        :param query: 実行する SQL
        :param query_log: 実行クエリのログ出力有無
        """
        for i in range(self.MAX_RETRY + 1):
            try:
                if query_log:
                    self.logger.info("\n" + query)
                self._cursor.execute(query)
                return
            except OperationalError as e:
                """
                リカバリ可能そうなエラーの場合、所定回数リトライする
                トランザクションは考慮しない前提
                """
                self.logger.warning(e)
                if i == self.MAX_RETRY:
                    self.logger.error("最大リトライ回数を超えました。")
                    raise
                self.logger.info("リトライします。: {}回目".format(i + 1))
                time.sleep(self.RETRY_DELAY)
                self.close()
                self.connect()

    def fetch_one(self):
        """現在のカーソルから一レコードを取得する。"""
        result = self._cursor.fetchone()
        return result if result is not None else []

    def fetch_all(self):
        """現在のカーソルから全レコードを取得する。"""
        return self._cursor.fetchall()

    def get_affected_rows(self):
        """現在のカーソルに含まれるレコード数を取得する。"""
        return self._cursor.rowcount

    def commit(self):
        """コミットを行う。"""
        if getattr(self, "_connection", None) is not None:
            self._connection.commit()

    def rollback(self):
        """ロールバックを行う。"""
        if getattr(self, "_connection", None) is not None:
            self._connection.rollback()

    def close(self):
        """指定した DB への接続をクローズする。"""
        # TODO: デストラクタでのクローズ処理追加
        if getattr(self, "_connection", None) is not None:
            self._connection.close()
            self._connection = None
            self._cursor = None
