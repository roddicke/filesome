"""
SFTPクライアント機能
"""
import pathlib
from functools import wraps
from paramiko import SSHClient, AutoAddPolicy
from urllib.parse import splituser, splitpasswd

from batch_architecture.core.settings import Settings
from batch_architecture.core.resources import Resources, SFTPResource
from batch_architecture.core.log import Logger


def reset_cwd(method):
    """
    SFTP のワーキングディレクトリをリセットする
    """

    @wraps(method)
    def wrapper(self, *args, **kwargs):
        pwd = self._sftp.getcwd()
        res = method(self, *args, **kwargs)
        self._sftp.chdir(pwd)
        return res

    return wrapper


class SFTPClient(object):
    """SFTP クライアント"""

    # パスは URI の形式で指定
    _SEP = "/"
    _DEFAULT_PORT = 22

    def __init__(self):
        self._sftp = None
        self._logger = Logger.get_logger(self.__class__.__name__)
        sftp_status = Settings.EXTERNAL_TRANSFER_SFTP_STATUS
        self._enabled = sftp_status == 'enabled'

    def connect(self, hostname, user=None, port=22, private_key=None, passwd=None):
        """
        SFTP サーバに接続する。

        :param hostname: 接続サーバ名
        :param user: ユーザ名
        :param port: 接続ポート番号
        :param private_key: 鍵パス
        :param passwd: パスワード
        :return:
        :rtype: SFTPClient
        """
        if not self._enabled:
            self._logger.info('外部へのSFTP送信機能が無効になっているためSFTPサーバへの接続をスキップしました。')
            return self

        client = SSHClient()
        client.set_missing_host_key_policy(AutoAddPolicy())

        if user is None:
            user = Resources.get(hostname)._username
        if private_key is None:
            private_key = Resources.get(hostname)._private_key
        if passwd is None:
            passwd = Resources.get(hostname)._password

        if private_key is not None:
            client.connect(
                hostname=hostname, port=port, username=user, key_filename=private_key
            )
        elif passwd is not None:
            client.connect(
                hostname=hostname,
                port=port,
                username=user,
                password=passwd,
                look_for_keys=False,
            )
        else:
            msg = "認証鍵のパス、あるいは、パスワードが指定されていないためSFTP接続できません。認証鍵のパスかパスワードを指定してください。"
            raise ValueError(msg)

        self._sftp = client.open_sftp()
        return self

    @classmethod
    def parse(self, hostname):
        """
        接続サーバ名中に含まれるユーザ名、パスワード、ポートをパースして分割する

        :param hostname: 接続サーバ名
        :return: hostname, port, username, password
        :rtype: tuple
        """
        u, h = splituser(hostname)

        # ホスト名のパース
        if ":" in h:
            hostname, port = h.split(":")
            port = int(port)
        else:
            hostname = h
            port = self._DEFAULT_PORT

        # ユーザ名、パスワードのパース
        if u is None:
            user = None
            passwd = None
        else:
            user, passwd = splitpasswd(u)

        return hostname, port, user, passwd

    def _split(self, path):
        """
        パスを区切り文字 (`self._SEP`) で分割する。

        :param path: SFTP 上のファイルパス
        :return: パスをフォルダ、ファイルで分割したリスト
        :rtype: list of str
        """
        if isinstance(path, pathlib.PurePath):
            path = str(path)
        return path.split(sep=self._SEP)

    def _move_under(self, path):
        """
        指定されたパスの直下 (パスの親ディレクトリ) まで cwd で移動する。

        :param path: SFTP 上のファイルパス
        """
        path = self._split(path)[:-1]
        # ファイルパスの階層をたどる
        self.cwd(path)

    @reset_cwd
    def exists(self, path):
        """指定されたパスが SFTP サーバ上に存在するか調べる。

        :param path: SFTP 上のファイルパス
        :rtype: bool
        """
        try:
            self._move_under(path)
            target = self._split(path)[-1]
            if target in self._sftp.listdir(self.pwd()):
                return True
        except:
            pass
        return False

    @reset_cwd
    def is_dir(self, path):
        """
        指定されたパスがディレクトリかどうか調べる。

        制約事項: 対象のパスへ cwd できるかで判定するため、参照権限のないディレクトリは
        ファイルとして判定される。

        :param path: SFTP 上のファイルパス
        :rtype: bool
        """
        try:
            # 指定したパスに移動できればディレクトリである
            self.cwd(path)
            return True
        except:
            pass
        return False

    @reset_cwd
    def is_file(self, path):
        """
        指定されたパスがファイルかどうか調べる。

        :param path: SFTP 上のファイルパス
        :rtype: bool
        """
        if self.exists(path) and not self.is_dir(path):
            return True
        return False

    @reset_cwd
    def upload(self, src, dst):
        """
        ローカルのファイルを SFTP にアップロードする。

        :param src: アップロード元のパス (ローカルのファイルパス)
        :param dst: アップロード先のパス (SFTP 上のファイルパス)
        """
        dst_path = self._split(dst)
        # アップロードするファイル名
        dst_file = dst_path[-1]
        # CWDで移動していくパス
        dst_path = dst_path[:-1]

        # ファイルパスの階層をたどり、ディレクトリがない場合は作成する
        self.mkdir(self._SEP.join(dst_path), cwd=True, parents=True, exist_ok=True)

        from batch_architecture.io_target import LocalTarget

        src = LocalTarget(src)._check_path(allow_file=True)
        src = str(src._path)

        self._sftp.put(src, dst_file)

    @reset_cwd
    def download(self, src, dst):
        """
        SFTP サーバ上のファイルを指定されたモードでローカルにダウンロードする。

        :param src: ダウンロード元のパス (SFTP 上のファイルパス)
        :param dst: ダウンロード先のパス (ローカルのファイルパス)
        """
        if self.is_dir(src):
            # ダウンロード先は既存のディレクトリ、もしくは空のパス
            msg = "ダウンロード対象のパス {0} はディレクトリです".format(src)
            raise FileExistsError(msg)
        elif self.is_file(src):
            # ダウンロード先は既存のファイル、もしくは空のパス
            from batch_architecture.io_target import LocalTarget

            dst = LocalTarget(dst)
            dst._check_path(allow_none=True, allow_file=True)

            dst = dst._path
            if not dst.exists():
                dst.touch()

            return self._download_single(src, str(dst))
        else:
            msg = "SFTP サーバ上のパス {0} がありません".format(src)
            raise FileNotFoundError(msg)

    def _download_single(self, src, dst):
        """
        単一のファイルをダウンロードする際に呼び出される処理。
        外部から直接利用することは想定しない。
        連続して呼び出されるため、reset_cwd してはならない。

        :param src: ダウンロード元のパス (SFTP 上の cwd からの相対パス)
        :param dst: ダウンロード先のパス (ローカルのファイルパス)
        """
        self._sftp.get(src, dst)

    @reset_cwd
    def ls(self, path=None):
        """
        指定したパスに含まれるファイル・フォルダの一覧を取得する。
        `path` が指定されない場合、cwd に含まれるファイル・フォルダの一覧を取得する。

        :param path: SFTP 上のファイルパス
        :return: ファイル・フォルダの一覧
        :rtype: list of str
        """

        if path is not None:
            self.cwd(path)

        return self._sftp.listdir(self.pwd())

    def mkdir(self, path, cwd=True, parents=False, exist_ok=False):
        """
        SFTP 上にディレクトリを作成する。

        :param path: 作成するディレクトリのパス
        :param cwd: 作成したディレクトリをカレントディレクトリとするかどうか
        :param parents: 親ディレクトリが存在しない場合に作成するかどうか
        :param exist_ok: 対象のディレクトリがすでに存在する場合にエラーとするかどうか
        """
        # すでに作成対象のディレクトリが存在する場合
        if self.exists(path):
            if exist_ok is True:
                if cwd is True:
                    self.cwd(path)
                return
            else:
                msg = "SFTP サーバ上のパス {0} はすでに存在します".format(path)
                raise FileExistsError(msg)

        # 現在のワーキングディレクトリを記憶
        pwd = self.pwd()
        if parents is True:
            # 再帰的にディレクトリを作成
            path = self._split(path)
            for p in path:

                try:
                    self._sftp.chdir(p)
                except IOError as e:
                    self._sftp.mkdir(p)
                    self._sftp.chdir(p)
        else:
            try:
                self._sftp.mkdir(path)
                self._sftp.chdir(path)
            except IOError as e:
                msg = "指定したパス {0} のパレントディレクトリが存在しません"
                raise FileNotFoundError(msg.format(path))

        if not cwd:
            # ディレクトリ作成前のワーキングディレクトリに戻る
            self.cwd(pwd)

    def delete(self, path, recursive=True):
        """
        SFTP 上のファイル・ディレクトリを削除する。

        :param path: 削除するファイル・ディレクトリのパス
        :param recursive: 対象がファイル、サブディレクトリを含む時、再帰的に削除するかどうか
        """
        if self.is_dir(path):
            if recursive:
                pwd = self.pwd()
                self.cwd(path)
                childs = self.ls()
                for child in childs:
                    self.delete(child, recursive=recursive)
                self.cwd(pwd)
            return self._sftp.rmdir(path)
        elif self.is_file(path):
            return self._sftp.remove(path)
        else:
            msg = "SFTP サーバ上のパス {0} がありません".format(path)
            raise FileNotFoundError(msg)

    def cwd(self, path):
        """
        指定されたパスに移動する。

        :param path: SFTP 上のファイルパス
        """
        if isinstance(path, list):
            path = self._SEP.join(path)

        if isinstance(path, str):
            try:
                return self._sftp.chdir(path)
            except:
                msg = "SFTP サーバ上のパス {0} がありません".format(path)
                raise FileNotFoundError(msg)
        else:
            raise ValueError(type(path))

    def pwd(self):
        """
        ワーキングディレクトリを取得する。

        :return: SFTP 上のファイルパス
        """
        if self._sftp.getcwd() is None:
            self.cwd(path="/")

        return self._sftp.getcwd()

    def close(self):
        """SFTP 接続をクローズする。"""

        # TODO: デストラクタでのクローズ処理実施
        self._sftp.close()
        self._sftp = None
