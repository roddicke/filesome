"""
SMTPクライアント機能
"""
import time
import smtplib
from email.mime.text import MIMEText

from batch_architecture.core.resources import Resources
from batch_architecture.core.settings import Settings
from batch_architecture.core.base import Base


class SMTPClient(Base):
    """SMTP クライアント"""
    _LOGGER_NAME = "batch_architecture.client.smtp_client"

    def __init__(self):
        self._smtp = None
        self._enabled = Settings.EXTERNAL_TRANSFER_SMTP_ENABLED

    def connect(self):
        """
        SMTP サーバに接続する。

        :param hostname: 接続サーバ論理名
        :param port: 接続ポート番号
        :param user: ユーザ名
        :param passwd: パスワード
        :return:
        :rtype: SMTPClient
        """
        if not self._enabled:
            self.logger.info('外部へのメール送信機能が無効になっているためSMTPサーバへの接続をスキップしました。')
            return self

        resource = Resources.get('smtp')
        smtp_host = resource._host
        smtp_port = resource._port
        account = resource._account
        password = resource._password

        try:
            smtp = smtplib.SMTP(smtp_host, smtp_port)
            smtp.ehlo()
            if smtp.has_extn('STARTTLS'):
                smtp.starttls()
                smtp.ehlo()
            if account and password:
                smtp.login(account, password)
        except smtplib.SMTPResponseException as e:
            self.logger.error('SMTPサーバからエラーコードが返されました。%s' % e)
            raise
        except Exception as e:
            self.logger.error('SMTPサーバとの接続に失敗しました。%s' % e)
            raise

        self._smtp = smtp
        return self

    def send_mail(self, to_addr, body, subject=None, from_addr='no-reply'):
        """Email送信

        Args:
            to_addr (str): 宛先メールアドレス
            body (str): 本文
            subject (str, optional): 件名. Defaults to None.
            from_addr (str, optional): 送信元.
        """
        msg = MIMEText(body, "plain")
        msg["Subject"] = subject if subject else ''
        msg["To"] = to_addr
        msg["From"] = from_addr

        if self._enabled:
            self._smtp.send_message(msg)
        else:
            self.logger.info(f'外部へのメール送信機能が無効になっているため {to_addr} へのメール送信をスキップしました。')

    def send_message(self, message):
        """Email送信

        Args:
            message (email.message.Message): Messageオブジェクト(.emlをemail.message_from_bytes等で読込むと生成可能)
        """
        if self._enabled:
            self._smtp.send_message(message)
        else:
            to_addr = message.get('To')
            self.logger.info(f'外部へのメール送信機能が無効になっているため {to_addr} へのメール送信をスキップしました。')
