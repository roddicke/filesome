"""
Snowflake 接続機能
"""
import os
import time

import snowflake.connector
from snowflake.connector.errors import OperationalError

from batch_architecture.core.base import Base
from batch_architecture.core.resources import Resources


class SnowflakeClient(Base):
    _LOGGER_NAME = "batch_architecture.client.snowflake_client"
    MAX_RETRY = 1
    RETRY_DELAY = 1

    def __init__(
            self,
            account=None,
            username=None,
            private_key_file=None,
            warehouse=None,
            database=None,
            schema=None,
    ):
        """
        SQL クライアントを初期化する。
        """
        try:
            res_name = "snowflake-{}".format(os.environ["ADT_RESOURCE"])
            self.logger.info('RESOURCE: %s' % res_name)
            snowflake_resource = Resources.get(res_name)
        except KeyError:
            msg = "resources.iniファイルに指定されたセクション {section} が存在しません。"
            raise KeyError(msg.format(section=account))
        if account is not None:
            self._account = account
        else:
            self._account = snowflake_resource._account

        if username is not None:
            self._username = username
        else:
            self._username = snowflake_resource._username

        if private_key_file is not None:
            self._private_key_file = private_key_file
        else:
            self._private_key_file = snowflake_resource._private_key_file

        if warehouse is not None:
            self._warehouse = warehouse
        else:
            self._warehouse = snowflake_resource._warehouse

        if database is not None:
            self._database = database
        else:
            self._database = snowflake_resource._database

        if schema is not None:
            self._schema = schema
        else:
            self._schema = snowflake_resource._schema

    def __str__(self):
        """インスタンスの文字列表現を取得する。"""
        try:
            self.connect()
            status = "データベース接続完了"
        except:
            status = "データベース接続不可"

        fmt = "{klass}({user}@{host}:{port}/{dbname})[{status}]"
        return fmt.format(
            klass=self.__class__.__name__,
            dbname=self._dbname,
            host=self._host,
            user=self._username,
            port=self._port,
            status=status,
        )

    def __del__(self):
        if getattr(self, "_connection", None) is not None:
            self._connection.close()
            self._connection = None
            self._cursor = None

    __repr__ = __str__

    def is_connected(self):
        """
        指定した DB へ接続しているかどうかを調べる。

        :return: `bool`
        :rtype: bool
        """
        return getattr(self, "_connection", None) is not None

    def connect(self, autocommit=True):
        """
        指定した DB に接続する。

        1回目の接続情報をキャッシュし、2回目以降はキャッシュを利用する。

        :return: self
        """
        if getattr(self, "_connection", None) is None:
            self.logger.info("WAREHOUSE: {s}".format(s=self._warehouse))
            for i in range(self.MAX_RETRY + 1):
                try:
                    self._connection = snowflake.connector.connect(
                        user=self._username,
                        private_key_file=self._private_key_file,
                        account=self._account,
                        warehouse=self._warehouse,
                        database=self._database,
                        schema=self._schema,
                        autocommit=autocommit,
                    )
                    self._cursor = self._connection.cursor()
                    return self
                except OperationalError as e:
                    self.logger.warning(e)
                    if i == self.MAX_RETRY:
                        self.logger.error("最大リトライ回数を超えました。")
                        raise
                    self.logger.info("リトライします。: {}回目".format(i + 1))
                    time.sleep(self.RETRY_DELAY)

        return self

    def execute_sql(self, query, bind=None, query_log=True):
        """
        指定した DB で SQL を実行する。
        1ステートメントしか受け付けないので注意
        特定エラーの場合はリトライを行う。

        :param query: 実行する SQL
        """
        for i in range(self.MAX_RETRY + 1):
            try:
                if bind is not None:
                    query = query.format(**bind)
                if query_log:
                    self.logger.info("\n" + query)
                self._cursor.execute(query)
                return
            except OperationalError as e:
                self.logger.warning(e)
                if i == self.MAX_RETRY:
                    self.logger.error("最大リトライ回数を超えました。")
                    raise
                self.logger.info("リトライします。: {}回目".format(i + 1))
                time.sleep(self.RETRY_DELAY)
                self.close()
                self.connect()

    def execute_string(self, query, bind=None, query_log=True):
        """
        複数ステートメントを一度に実行する場合はこちらを使用する。
        特定エラーの場合はリトライを行う。

        :param query: 実行する SQL
        :param bind: 置換パラメータ
        :param query_log: 実行クエリのログ出力有無
        :return cursors: SnowflakeCursorのリスト
        """
        for i in range(self.MAX_RETRY + 1):
            try:
                if bind is not None:
                    query = query.format(**bind)
                if query_log:
                    self.logger.info("\n" + query)
                cursors = self._connection.execute_string(query)
                return cursors
            except OperationalError as e:
                self.logger.warning(e)
                if i == self.MAX_RETRY:
                    self.logger.error("最大リトライ回数を超えました。")
                    raise
                self.logger.info("リトライします。: {}回目".format(i + 1))
                time.sleep(self.RETRY_DELAY)
                self.close()
                self.connect()

    @property
    def rowcount(self):
        if self._cursor.description and 0 < len(self._cursor.description):
            desc = self._cursor.description[0]
            if desc.name.startswith('number of rows '):
                # DELETE, INSERT, UPDATE
                return None
            else:
                return self._cursor.rowcount
        else:
            return None

    @property
    def column_names(self):
        return tuple(d.name for d in self._cursor.description) \
            if self._cursor.description else tuple()

    def explain_sql(self, query, bind={}):
        """
        :param query: 実行する SQL
        :param bind: 置換パラメータ
        """
        self.logger.info("\nEXPLAIN\n" + query.format(**bind))
        self._cursor.execute("\nEXPLAIN\n" + query.format(**bind))
        self._cursor.get_results_from_sfqid(self._cursor.sfqid)
        self.logger.info(self._cursor.fetchall())

    def fetch_one(self):
        """現在のカーソルから一レコードを取得する。"""
        result = self._cursor.fetchone()
        return result if result is not None else []

    def fetch_all(self):
        """現在のカーソルから全レコードを取得する。"""
        return self._cursor.fetchall()

    def get_affected_rows(self):
        """現在のカーソルに含まれるレコード数を取得する。"""
        raise NotImplementedError()
        # このAPIだと処理件数を取得できないので未実装
        # return self._cursor.rowcount

    def commit(self):
        """コミットを行う。"""
        if getattr(self, "_connection", None) is not None:
            self._connection.commit()

    def rollback(self):
        """ロールバックを行う。"""
        if getattr(self, "_connection", None) is not None:
            self._connection.rollback()

    def close(self):
        """指定した DB への接続をクローズする。"""
        if getattr(self, "_connection", None) is not None:
            self._connection.close()
            self._connection = None
            self._cursor = None
