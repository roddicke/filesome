import os

from batch_architecture.client.aws_client import _BotoMixin
from batch_architecture.core.base import Base
from batch_architecture.core.resources import Resources


class LogsClient(Base, _BotoMixin):
    _KEY = 'logs'
    _REGION = Resources.get("logs").region
    _ENDPOINT_URL = Resources.get("logs").endpoint_url
    _LOGGER_NAME = os.path.basename(__file__)

    def __init__(self, credentials=None):
        self._CREDENTIALS = credentials

    def describe_log_streams(self, log_group_name) -> dict:
        """
        ログストリームを取得する
        :param log_group_name:
        :return {'ResponseMetadata': {}, 'logStreams': []}:
        """
        self.logger.info(f'ロググループ({log_group_name})のログストリームを取得します。')
        return self.client.describe_log_streams(logGroupName=log_group_name, orderBy='LastEventTime', descending=True)

    def get_log_events(self, log_group_name, log_stream_name):
        """
        ログイベントを取得する

        """
        self.logger.info(f'ロググループ({log_group_name})のログストリーム({log_stream_name})からログイベントを取得します。')
        return self.client.get_log_events(logGroupName=log_group_name, logStreamName=log_stream_name, startFromHead=True)
