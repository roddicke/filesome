"""
Windowsコマンド機能
"""
from batch_architecture.client import Shell


class WindowsCMD(Shell):
    """
    Windows cmd管理クラス
    """

    pass
