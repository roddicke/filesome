"""
Windows Log 出力機能
※前提条件としてイベントログ出力するsourceは事前にPowerShellから以下コマンドで登録済みとする
  >New-EventLog -LogName $LOG_NAME -Source $SOURCE
"""
import pywintypes  # noqa
import win32evtlog
import win32evtlogutil

from batch_architecture.core.base import Base


class WindowsEventLog(Base):
    def __init__(self, app_name='batch_framework', event_id=0):
        self.app_name = app_name
        self.event_id = event_id

    # Windows Event Log
    def output_event_log(self, msg, entry_type="Error"):
        if entry_type == "Information":
            entry_type = win32evtlog.EVENTLOG_INFORMATION_TYPE
        elif entry_type == "Warning":
            entry_type = win32evtlog.EVENTLOG_WARNING_TYPE
        elif entry_type == "Error":
            entry_type = win32evtlog.EVENTLOG_ERROR_TYPE
        else:
            msg = "entry_typeは'Information','Warning','Error'のいずれかを指定してください。"
            raise ValueError(msg)

        # Windowsイベントログで表示可能な文字数を超えないようにするため、1万字で切る
        if len(msg) > 10000:
            msg = msg[:10000]

        win32evtlogutil.ReportEvent(
            appName=self.app_name,
            eventID=self.event_id,
            eventType=entry_type,
            strings=[msg],
            data=b'',
        )
