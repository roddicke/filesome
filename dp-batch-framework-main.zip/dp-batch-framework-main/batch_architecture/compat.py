"""
環境チェックを統合
"""

import sys

IS_WINDOWS = sys.platform.startswith("win")

try:
    import pymssql

    PYMSSQL_INSTALLED = True
except ImportError:
    pymssql = None
    PYMSSQL_INSTALLED = False

try:
    import pyodbc

    PYODBC_INSTALLED = True
except ImportError:
    pyodbc = None
    PYODBC_INSTALLED = False

try:
    import boto3

    BOTO3_INSTALLED = True
except ImportError:
    boto3 = None
    BOTO3_INSTALLED = False
