batch_framework.tests.client package
====================================

Submodules
----------

batch_framework.tests.client.test_emr module
--------------------------------------------

.. automodule:: batch_framework.tests.client.test_emr
    :members:
    :undoc-members:
    :show-inheritance:

batch_framework.tests.client.test_ftp_client module
---------------------------------------------------

.. automodule:: batch_framework.tests.client.test_ftp_client
    :members:
    :undoc-members:
    :show-inheritance:

batch_framework.tests.client.test_redshift_client module
--------------------------------------------------------

.. automodule:: batch_framework.tests.client.test_redshift_client
    :members:
    :undoc-members:
    :show-inheritance:

batch_framework.tests.client.test_shell module
----------------------------------------------

.. automodule:: batch_framework.tests.client.test_shell
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: batch_framework.tests.client
    :members:
    :undoc-members:
    :show-inheritance:
