.. batch_framework documentation master file, created by
   sphinx-quickstart on Thu Apr 27 09:36:58 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to batch_framework's documentation!
===========================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   batch_framework


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
