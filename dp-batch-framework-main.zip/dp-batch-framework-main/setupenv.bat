@echo off

set DIR=%~dp0

set CMD=set PYTHONPATH=%DIR%;%DIR%\batch_architecture
echo %CMD%
%CMD%
set CMD=set ADT_HOME=%DIR%%
echo %CMD%
%CMD%
