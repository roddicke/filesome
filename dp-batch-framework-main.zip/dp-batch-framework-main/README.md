# 実行アーキ

# 環境構築手順

## python 3.9.5 をインストール

* https://www.python.org/downloads/windows/ から、Python 3.5.3 ( ``python-3.9.5-amd64.exe ``) をダウンロード
* インストール時に `Add python 3.9 to Path` にチェック

## ADTのClone

* Git をインストールしていない場合はインストールする
  * * https://git-scm.com/downloads
* [innersource](https://innersource.accenture.com/projects/NDWH/repos/dp-batch-framework/browse) にアクセスする
*  サイト左側の <クローン> アイコンから、クローン用のURLを取得する

*  ``cd <ADTを配置するパス>``コマンドを実行し、ADT配置ディレクトリに移動する
*  ``git clone <クローン用のURL>``コマンドを実行し、リポジトリをクローンする
  * 開発環境では``git checkout devlop``コマンドを実行し、開発用ブランチに移動する

# 設定手順

### オフライン環境における依存パッケージのインストール

* インストール先がオフライン環境である場合には、ネットワーク経由での依存パッケージのインストールはできない。そのため、事前に別環境で依存パッケージをダウンロードし、オフライン環境へ移動する必要がある。

* オンライン環境で下記のコマンドを実行し、依存パッケージをダウンロードする
  * ``cd batch_framework``コマンドを実行し、ADTのディレクトリ (`setup.py` があるディレクトリ)に移動する
  * ``pip download -d <ダウンロード先パス> -r requirements.txt``コマンドを実行し、依存パッケージをダウンロードする

* オフライン環境にダウンロードした依存パッケージをコピーする
* オフライン環境で下記のコマンドを実行し、依存パッケージをインストールする
  * ``cd batch_framework``コマンドを実行し、ADTのディレクトリ (`setup.py` があるディレクトリ)に移動する
  * ``pip install --find-links=<依存パッケージのパス> -r requirements.txt``を実行し、依存パッケージをインストールする

## AWS接続設定

*  ``aws configure``コマンドを実行し、AWSへの接続情報を入力する
  * http://docs.aws.amazon.com/cli/latest/userguide/cli-chap-getting-started.html

## グローバル設定の変更

TBW

## ジョブ定義の記載

* ``resource\job_def`` ディレクトリ中にジョブ定義ファイルを ``.json`` で作成する。
  共通項目の意味は以下の通り。

  * ``comment`` : コメント、任意
  * ``program_type`` : ロジック制御処理の種類 (ToDo: 別表に整理)
  * ``program_name`` : プログラム名称、ログに出力される名前 (削除予定)

```
[
    {
        "comment": {
            "プログラムID": "",
            "概要": "",
            "初回作成日": "",
            "初回作成者": "",
            "最終変更日": "",
            "最終変更者": "",
            "バージョン": "",
            "更新履歴": ""
        }
        ,"program_type": "TRANSFER"
        ,"program_name": "get_ftp_test"

        ,"input": "ftp://10.0.3.168/test.txt"
        ,"output": "s3://horikoshi/upload.txt"
    }
]
```

### 共通パラメータ

  * ``program_type``: 実行するロジックの種類を指定
  * ``program_name`` : ロジックの表示名 (任意、ログの表示にのみ利用)
  * ``comments``: コメント (任意、実行には一切関係しない)
  * ``delay`` : リトライ間隔(秒)、既定 60秒 (任意、未実装)
  * ``max_attempts``: 試行回数、既定 1回=リトライしない (任意、未実装)

### ロジック固有パラメータ

| ロジック | ``json``属性 | 概要 |
|---------|-------------|-----|
|ファイル転送 | ``program_type`` | ``"TRANSFER"`` |
|           | ``input``        | 入力元のパス     |
|           | ``output``       | 出力先のパス     |
|           | ``overwrite``    | ``true`` or ``false`` |
|ファイル存在確認 | ``program_type`` | ``"EXISTENCE"`` |
|              | ``target``       | 存在確認するパス   |
|パラメータ更新 | ``program_type`` | ``"WRITE_PARAMETERS"``  |
|             | ``update``        | パラメータのキーと更新ルール(``"day"``, ``"month"``)の辞書 例 ``{"key1": "day"}``     |
|ファイル圧縮 | ``program_type`` | ``"ARCHIVE"``  |
|           | ``input``        | 入力元のパス     |
|           | ``output``       | 出力先のパス     |
|ファイル展開 | ``program_type`` | ``"EXTRACT"``  |
|           | ``input``        | 入力元のパス     |
|           | ``output``       | 出力先のパス     |
|ファイル実行 | ``program_type`` | ``"EXECUTE"``  |
|           | ``script``       | 実行するファイル |

### パスの記載方法

  * ローカル : ``C:\\dir\test.txt``, ``dir\test.txt`` (相対パスはツール実行ディレクトリからのパスになる)
  * FTP : ``ftp:\\server\dir\test.txt``

    * 認証情報を含める場合は、``username:password@server`` と URI 中に記載する。

  * S3 : ``s3:\\bucket\dir\test.txt``

    * S3 との接続には、事前に `aws-cli` での認証情報設定が必要(上述)。

# ツール実行手順(例)

## バッチ実行

``command.py run`` を実行する。実行したいジョブはオプションで指定する。
例えば ``ftp_to_s3.json`` を実行したい場合、引数は以下のようになる。

```
python batch_architecture/command.py run ftp_to_s3 --env local --sys dwh
```

### バッチ日付を指定するオプション

runコマンド実行時に``--batch-date YYYYMMDD``オプションを指定する。

バッチ日付ファイルの値をオーバーライドします。次のジョブについても指定したバッチ日付で実行されます。

```
python batch_architecture/command.py run ftp_to_s3 --env local --sys dwh --batch-date 20220721
```

### 次のジョブをSQSに送らないオプション

runコマンド実行時に``--skip-next-job``オプションを指定する。

実行されたジョブに次のジョブが指定されていてもSQSに送信されません。

```
python batch_architecture/command.py run ftp_to_s3 --env local --sys dwh --skip-next-job
```


※カレントディレクトリに、リポジトリ直下の `config`, `resource` をコピーしておくこと。もしくは、`config`, `resource` を含むディレクトリを ADT ホームディレクトリとして、環境変数 `ADT_HOME` に設定しておくこと。


### 機能追加・デバッグ履歴
**2021/12/13**
* バインド変数をDB_NSONLINEからDB_NSONLINETに変更

**2021/12/14**
* snowflakeのデフォルト接続先がsystemによって変わるように変更
* snowflakeのバインドがsystemによって変わるように変更
* エラーテーブル内のPK重複データを見つけるためのガイドクエリがログ出力されるように変更
* export_snowflakeで処理件数が0件の場合に空ファイルを出力するように変更
* export_snowflakeで処理件数とテーブルの行数が一致していることを確認するバリデーション機能を追加
* ジョブ定義に記載するウェアハウス名が環境定義ファイルに記載されたバインドで置換されるように修正
* ジョブ定義に記載するパスに{IFGW_LOCAL}と記載するとdp-batch-framework/tempに置換されるように修正

**2021/12/15**
* END_FILE格納先のパスを設定ファイルに記載

**2021/12/20**
* pre_goとpost_goロジックにて全てのバケット間で処理できるように改修
* ジョブ定義に記載するパスに{IFGW_LOCAL}と記載するとE:/環境名/tmpに置換されるように修正
* ローカルで処理した元ファイルを削除できるように修正

**2022/01/07**
* nnaviとtoricanの?置換ができるように修正
* pk_checkがtrueなのにpk_check_tablesでテーブルが指定されていないとエラーにするように修正
* 設定ファイルのパラメータをtry/exceptで読み込むように修正
* エラーテーブル作成クエリのログがバインドされていなかったので修正

**2022/01/18**
* ジョブ定義に記載されたみなし日変数の置換機能の実装 
* 処理件数の取得方法を変更
* LOAD_SNOWFlAKE作成
* EXECUTE_SNOWFLAKE_TRC作成
* エラーテーブル一括削除機能の実装
* NNAVIのバインド変数に{DB_NSDWH}を追加

**2022/01/21**
* execute_snowflake_trcで$がすべからく消えるバグを修正

**2022/01/27**
* 項目編集ロジック追加
* 後続ジョブの起動命令を出す機能を追加
* 取引管理のCHK_LGC_SEQ_NOをジョブ定義から受け取れるように修正

**2022/01/28**
* sqlのパスを設定ファイルに持たせるように修正

**2022/01/31**
* ファイル作成ロジックを実装

